package com.bayer.pmodi.masterlist.authorization;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;

import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.model.EntityWithPrioritization;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.nimbusds.oauth2.sdk.util.StringUtils;

public class AuthorizationUtil {

	private AuthorizationUtil() {
		// No instance allowed
	}

	public static List<String> getCheckedFields(Class<?> clazz) {
		List<String> fields = Stream.of(clazz.getDeclaredFields())
				.filter(field -> field.isAnnotationPresent(CheckedField.class)).map(field -> field.getName())
				.collect(Collectors.toList());
		return fields;
	}

	public static List<String> getCheckedFieldsOfRole(Class<?> clazz, String role) {
		List<String> fields = Stream.of(clazz.getDeclaredFields())
				.filter(field -> field.isAnnotationPresent(CheckedField.class)
						&& ArrayUtils.contains(field.getAnnotation(CheckedField.class).roles(), role))
				.map(field -> field.getName()).collect(Collectors.toList());
		return fields;
	}

	public static List<String> getCheckedFieldsOfGroup(Class<?> clazz, String group) {
		List<String> fields = Stream.of(clazz.getDeclaredFields())
				.filter(field -> field.isAnnotationPresent(CheckedField.class)
						&& group.equals(field.getAnnotation(CheckedField.class).group()))
				.map(field -> field.getName()).collect(Collectors.toList());
		return fields;
	}

	public static Map<String, String> getCheckedFieldsWithSpecialTreatment(Class<?> clazz) {
		Map<String, String> fields = Stream.of(clazz.getDeclaredFields())
				.filter(field -> field.isAnnotationPresent(CheckedField.class)
						&& StringUtils.isNotBlank(field.getAnnotation(CheckedField.class).specialTreatment()))
				.collect(Collectors.toMap(field -> field.getName(),
						field -> field.getAnnotation(CheckedField.class).specialTreatment()));
		return fields;
	}

	/**
	 * Check which fields are allowed to be edited by the current user (given by the
	 * UserDetailsHelper) according to his/her roles. Locked groups are not taken
	 * into account!
	 * 
	 * @param userDetailsHelper  UserDetailsHelper to check roles; mandatory
	 * @param isFailFastMode     If true an exception is thrown at the first checked
	 *                           field that is not allowed, otherwise all fields are
	 *                           collected
	 * @param updateDto          Entity to get values for special treatments;
	 *                           mandatory (only used for special treatments)
	 * @param definition         AuthenticatedFieldDefinition to get lists of fields
	 *                           for the different roles; mandatory
	 * @param regionRoleSuffixes Collection of role suffixes (defined in regions);
	 *                           optional
	 * @param isFieldChecked     Function to define which field has to be checked
	 *                           e.g. if only changed values have to be check
	 * @return List of allowed fields if isFailFastMode is false; never null (but
	 *         may be empty)
	 */
	public static <T extends Object & EntityWithPrioritization> List<String> checkFields(
			UserDetailsHelper userDetailsHelper, boolean isFailFastMode, T updateDto,
			AuthenticatedFieldDefinition definition, Collection<String> regionRoleSuffixes,
			Predicate<String> isFieldChecked) {
		return checkFields(userDetailsHelper, isFailFastMode, updateDto, definition, regionRoleSuffixes, isFieldChecked,
				null);
	}

	/**
	 * Check which fields are allowed to be edited by the current user (given by the
	 * UserDetailsHelper) according to his/her roles.
	 * 
	 * @param userDetailsHelper  UserDetailsHelper to check roles; mandatory
	 * @param isFailFastMode     If true an exception is thrown at the first checked
	 *                           field that is not allowed, otherwise all fields are
	 *                           collected
	 * @param updateDto          Entity to get values for special treatments;
	 *                           mandatory (only used for special treatments)
	 * @param definition         AuthenticatedFieldDefinition to get lists of fields
	 *                           for the different roles; mandatory
	 * @param regionRoleSuffixes Collection of role suffixes (defined in regions);
	 *                           optional
	 * @param isFieldChecked     Function to define which field has to be checked
	 *                           e.g. if only changed values have to be check
	 * @param lockedGroups       List of locked groups; optional
	 * @return List of allowed fields if isFailFastMode is false; never null (but
	 *         may be empty)
	 */
	public static <T extends Object & EntityWithPrioritization> List<String> checkFields(
			UserDetailsHelper userDetailsHelper, boolean isFailFastMode, T updateDto,
			AuthenticatedFieldDefinition definition, Collection<String> regionRoleSuffixes,
			Predicate<String> isFieldChecked, Collection<String> lockedGroups) {
		List<String> results = new ArrayList<>(definition.getEditableFields().size());
		boolean isAllowedToEditAll = userDetailsHelper.hasRole(Roles.ROLE_SUPER_ADMIN);
		if (isAllowedToEditAll) {
			results.addAll(definition.getEditableFields());
		} else {
			for (String fieldName : definition.getEditableFields()) {
				boolean doCheck = isFieldChecked.test(fieldName);
				if (doCheck) {
					boolean isAllowed = false;
					if (isMemberOfLockedGroup(fieldName, lockedGroups, definition)) {
						// Editing is restricted to global admin only
						// Attention: it is NOT checked if the glogbal admin is in the roles annotation
						if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_ADMIN)) {
							isAllowed = true;
						}
					} else {
						String specialTreatmentType = definition.getSpecialFields().get(fieldName);
						if (specialTreatmentType != null) {
							// First handle special fields
							if (SpecialTreatment.PRIORITIZATION_TYPE_BY_GOVERNANCE.equals(specialTreatmentType)) {
								if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_ADMIN)) {
									isAllowed = true;
								} else {
									if (LocationTypeEnum.GLOBAL.equals(updateDto.getPrioritizationGovernance())) {
										if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_MARKETING)) {
											isAllowed = true;
										}
									} else if (LocationTypeEnum.REGIONAL
											.equals(updateDto.getPrioritizationGovernance())) {
										String[] possibleRoles = Roles.getPossibleRegionalRoles(regionRoleSuffixes,
												Roles.ROLE_PREFIX_REGIONAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_MARKETING);
										if (userDetailsHelper.hasRole(possibleRoles)) {
											isAllowed = true;
										}
									}
								}
							} else {
								throw new IllegalStateException(
										"No special treatment supported for '" + specialTreatmentType + "'!");
							}
						} else {
							// Then use general approach
							if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_ADMIN)
									&& definition.getGlobalAdminFields().contains(fieldName)) {
								isAllowed = true;
							} else if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_DEVELOPMENT)
									&& definition.getGlobalDevelopmentFields().contains(fieldName)) {
								isAllowed = true;
							} else if (userDetailsHelper.hasRole(Roles.ROLE_GLOBAL_MARKETING)
									&& definition.getGlobalMarketingFields().contains(fieldName)) {
								isAllowed = true;
							} else if (definition.getRegionalAdminFields().contains(fieldName)
									&& userDetailsHelper.hasRole(

											Roles.getPossibleRegionalRoles(regionRoleSuffixes,
													Roles.ROLE_PREFIX_REGIONAL_ADMIN))) {
								isAllowed = true;
							} else if (definition.getRegionalDevelopmentFields().contains(fieldName)
									&& userDetailsHelper.hasRole(Roles.getPossibleRegionalRoles(regionRoleSuffixes,
											Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT))) {
								isAllowed = true;
							} else if (definition.getRegionalMarketingFields().contains(fieldName)
									&& userDetailsHelper.hasRole(Roles.getPossibleRegionalRoles(regionRoleSuffixes,
											Roles.ROLE_PREFIX_REGIONAL_MARKETING))) {
								isAllowed = true;
							}
						}
					}
					if (isFailFastMode) {
						if (!isAllowed) {
							throw new PmodiForbiddenException("User has no right to edit field '" + fieldName + "'!");
						}
					} else {
						if (isAllowed) {
							results.add(fieldName);
						}
					}

				}
			}
		}
		return results;
	}

	/**
	 * @param fieldName    Field name; mandatory (but not checked)
	 * @param lockedGroups List of locked groups; optional
	 * @param definition   AuthenticatedFieldDefinition to get lists of fields for
	 *                     the different roles; mandatory (but not checked)
	 * @return True if this field is a member of a locked group
	 */
	private static boolean isMemberOfLockedGroup(String fieldName, Collection<String> lockedGroups,
			AuthenticatedFieldDefinition definition) {
		if (lockedGroups == null || lockedGroups.isEmpty()) {
			return false;
		}
		for (String lockedGroup : lockedGroups) {
			if (definition.getGroupFields(lockedGroup).contains(fieldName)) {
				return true;
			}
		}
		return false;
	}

}
