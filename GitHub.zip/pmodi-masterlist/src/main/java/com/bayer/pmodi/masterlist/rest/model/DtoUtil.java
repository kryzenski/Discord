package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.*;

public final class DtoUtil {

	private DtoUtil() {
		// No instance allowed
	}

	/**
	 * @param source Source used to fill the values; optional (but then null is
	 *               returned)
	 * @return IdDisplayNameSourceKeyDto or null
	 */
	public static IdDisplayNameSourceKeyDto toIdDisplayNameSourceKeyDto(Country source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyDto(source.getId(), source.getName(), source.getSourceKey());
	}

	/**
	 * @param source Source used to fill the values; optional (but then null is
	 *               returned)
	 * @return IdDisplayNameSourceKeyDto or null
	 */
	public static IdDisplayNameSourceKeyDto toIdDisplayNameSourceKeyDto(SubRegion source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyDto(source.getId(), source.getName(), source.getSourceKey());
	}

	/**
	 * @param source Source used to fill the values; optional (but then null is
	 *               returned)
	 * @return IdDisplayNameSourceKeyDto or null
	 */
	public static IdDisplayNameSourceKeyRoleSuffixDto toIdDisplayNameSourceKeyRoleSuffixDto(Region source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyRoleSuffixDto(source.getId(), source.getName(), source.getSourceKey(), source.getRoleSuffix());
	}

	/**
	 * @param source Source used to fill the values; optional (but then null is
	 *               returned)
	 * @return IdDisplayNameSourceKeyDto or null
	 */
	public static IdDisplayNameSourceKeyDto toIdDisplayNameSourceKeyDto(Crop source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyDto(source.getId(), source.getName(), source.getSourceKey());
	}

	/**
	 * @param source Source used to fill the values; optional (but then null is
	 *               returned)
	 * @return IdDisplayNameDto or null
	 */
	public static IdDisplayNameDto toIdDisplayNameDto(Product source) {
		return source == null ? null : new IdDisplayNameDto(source.getId(), source.getProductLineText());
	}


	public static IdDisplayNameSourceKeyDto toIdDisplayNameSourceKeyDto(CropGroup source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyDto(source.getId(), source.getName(), source.getSourceKey());
	}


	public static IdDisplayNameSourceKeyDto toIdDisplayNameSourceKeyDto(CropPlatform source) {
		return source == null ? null
				: new IdDisplayNameSourceKeyDto(source.getId(), source.getName(), source.getSourceKey());
	}

}
