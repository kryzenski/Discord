package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.ProjectComment;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

public interface ProjectCommentRepository extends BaseRepository<ProjectComment> {

	Page<ProjectComment> findByProjectId(Long id, Pageable pageInfo);

	Page<ProjectComment> findByProjectIdAndDtype(Long id, ModuleTypeEnum dtype, Pageable pageInfo);

}
