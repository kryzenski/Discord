package com.bayer.pmodi.masterlist.config.webclients;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;

@Component
@Profile("!sso")
public class DevWebClients implements WebClients {

	@Value("${external-apis.regprime.host}")
	private String regprimeHost;

	@Value("${external-apis.regprime.user}")
	private String regprimeUser;

	@Value("${external-apis.regprime.password}")
	private String regprimePassword;

	@Value("${external-apis.nautilos.host}")
	private String nautilosHost;

	@Value("${external-apis.nautilos.user}")
	private String nautilosUser;

	@Value("${external-apis.nautilos.password}")
	private String nautilosPassword;

	@Value("${external-apis.quickscan.host}")
	private String quickscanHost;

	@Value("${external-apis.quickscan.user}")
	private String quickscanUser;

	@Value("${external-apis.quickscan.password}")
	private String quickscanPassword;

	@Value("${external-apis.newport-connector.host}")
	private String newportConnectorHost;


	@Override
	public WebClient getRegprimeWebClient(String token) {
		SslContext sslContext = null;
		HttpClient httpClient =null;
		try {
			sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build();
			SslContext finalSslContext = sslContext;
			httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext));
		} catch (SSLException e) {
			throw new RuntimeException(e);
		}

		// TcpClient tcpClient =
		// TcpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 2_000)
		// .doOnConnected(connection -> connection.addHandlerLast(new
		// ReadTimeoutHandler(2)).addHandlerLast(new WriteTimeoutHandler(2)));
		return WebClient.builder().baseUrl(regprimeHost)
				// .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient)))
//				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
//				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
//				.defaultHeaders(header -> header.setBasicAuth(regprimeUser, regprimePassword))
//				.defaultHeader(HttpHeaders.USER_AGENT, "I'm a coffee cup")
				.clientConnector(new ReactorClientHttpConnector(httpClient))
		.build();
	}

	@Override
	public WebClient getNautilosWebClient() {
		return WebClient.builder().baseUrl(nautilosHost)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeaders(header -> header.setBasicAuth(nautilosUser, nautilosPassword))
				.defaultHeader(HttpHeaders.USER_AGENT, "I'm a tee cup").build();
	}

	@Override
	public WebClient getQuickscanWebClient() {
		if (StringUtils.isBlank(quickscanUser)) {
			return WebClient.builder().baseUrl(quickscanHost)
					.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
					.defaultHeader(HttpHeaders.USER_AGENT, "I'm a lemonade can").build();
		} else {
			return WebClient.builder().baseUrl(quickscanHost)
					.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
					.defaultHeaders(header -> header.setBasicAuth(quickscanUser, quickscanPassword))
					.defaultHeader(HttpHeaders.USER_AGENT, "I'm a cola can").build();
		}
	}

	@Override
	public WebClient getNewportConnectorWebClient() {
		return WebClient.builder().baseUrl(newportConnectorHost)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeader(HttpHeaders.USER_AGENT, "I'm a tee pot").build();
	}

}
