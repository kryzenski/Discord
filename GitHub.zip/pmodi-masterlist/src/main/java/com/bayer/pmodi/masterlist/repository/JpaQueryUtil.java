package com.bayer.pmodi.masterlist.repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;

public final class JpaQueryUtil {

	private JpaQueryUtil() {
		// No instance allowed
	}

	/**
	 * @param em                 Entity manager; mandatory
	 * @param clazz              Parent entity of the given column; mandatory
	 * @param distinctColumnName Project column name; mandatory
	 * @param valueLike          Like expression (which has to contain the
	 *                           wildcards) to restrict the values to; optional (but
	 *                           then no restriction is done)
	 * @param limit              Maximum number of records; optional (but then all
	 *                           results are returned)
	 * @param isCaseSensitive    True if the query should be case sensitive
	 * @return Query
	 */
	public static <T> TypedQuery<String> getDistinctFieldWithValueQuery(EntityManager em, final Class<T> clazz,
			final String distinctColumnName, String valueLike, Integer limit, boolean isCaseSensitive) {
		if (em == null || clazz == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		if (distinctColumnName == null) {
			throw new IllegalArgumentException("Missing column name!");
		}
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<String> query = builder.createQuery(String.class);
		Root<T> root = query.from(clazz);
		Expression<String> exp = getFieldExpressionString(distinctColumnName, root);
		query.distinct(true);
		query.multiselect(exp);
		if (valueLike != null) {
			Predicate p = isCaseSensitive ? builder.like(exp, valueLike)
					: builder.like(builder.lower(exp), valueLike.toLowerCase());
			query.where(p);
		}
		query.orderBy(builder.asc(exp));

		if (limit != null) {
			return em.createQuery(query).setMaxResults(limit.intValue());
		}
		return em.createQuery(query);
	}

	public static <T> Expression<String> getFieldExpressionString(String fieldName, Root<T> root) {
		Expression<?> exp = getFieldExpression(fieldName, root);
		if (exp.getJavaType() == String.class) {
			@SuppressWarnings("unchecked")
			Expression<String> expAsString = (Expression<String>) exp;
			return expAsString;
		}
		throw new IllegalArgumentException("Unsupported data type '" + exp.getJavaType().getSimpleName() + "'!");
	}

	public static <T> Expression<?> getFieldExpression(String fieldName, Root<T> root) {
		final Expression<?> exp;
		if (StringUtils.contains(fieldName, ".")) {
			String[] parts = StringUtils.split(fieldName, ".");
			Join<T, ?> joins = root.join(parts[0]);
			int len = parts.length;
			if (len == 2) {
				exp = joins.get(parts[1]);
			} else {
				Path<Object> j = joins.get(parts[1]);
				for (int i = 2; i < len - 1; i++) {
					j = j.get(parts[i]);
				}
				exp = j.get(parts[len - 1]);
			}
		} else {
			exp = root.get(fieldName);
		}
		return exp;
	}

}
