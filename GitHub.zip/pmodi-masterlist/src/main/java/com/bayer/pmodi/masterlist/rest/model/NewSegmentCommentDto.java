package com.bayer.pmodi.masterlist.rest.model;

import java.time.OffsetDateTime;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.SegmentComment;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewSegmentCommentDto extends SegmentCommentEditableFieldsDto {

	public static NewSegmentCommentDto from(SegmentComment src) {
		NewSegmentCommentDto result = new NewSegmentCommentDto();
		SegmentCommentEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentComment src, NewSegmentCommentDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public static void applyKeyPropertiesTo(SegmentComment result, ModuleTypeEnum dtype, OffsetDateTime timestamp,
			String user) {
		result.setDtype(dtype);
		result.setTimestamp(timestamp);
		result.setUser(user);
	}

	private ModuleTypeEnum dtype;

	private OffsetDateTime timestamp;

}