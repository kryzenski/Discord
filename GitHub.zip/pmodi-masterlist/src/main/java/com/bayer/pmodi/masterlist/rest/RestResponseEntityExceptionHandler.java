package com.bayer.pmodi.masterlist.rest;

import java.sql.SQLException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.OptimisticLockException;
import javax.persistence.RollbackException;
import javax.validation.ConstraintViolation;

import org.hibernate.envers.exception.RevisionDoesNotExistException;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.DataException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiUnauthorizedException;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.java.Log;

/**
 * Implements Exception Handling with Spring for a REST API in a general way.
 * <p>
 * Handles the exceptions which are not handled by the controllers.
 */
@ControllerAdvice
@Log
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = { PmodiUnauthorizedException.class })
	protected ResponseEntity<ErrorInfo> handleUnauthorizedException(RuntimeException ex) {
		logException(ex);
		return createResponse(HttpStatus.UNAUTHORIZED, getMessageFrom(ex), getDetailsFrom(ex));
	}

	@ExceptionHandler(value = { PmodiForbiddenException.class })
	protected ResponseEntity<ErrorInfo> handleForbiddenException(RuntimeException ex) {
		logException(ex);
		return createResponse(HttpStatus.FORBIDDEN, getMessageFrom(ex), getDetailsFrom(ex));
	}

	// error handle for @Valid
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		Map<String, Object> body = new LinkedHashMap<>();
		body.put("timestamp", new Date());
		body.put("status", status.value());

		// Get all fields errors
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getDefaultMessage())
				.collect(Collectors.toList());

		body.put("errors", errors);

		return new ResponseEntity<>(body, headers, status);

	}

	@ExceptionHandler(value = { javax.validation.ConstraintViolationException.class })
	protected ResponseEntity<ErrorInfo> handleConstraintViolationException(RuntimeException ex, WebRequest request) {
		logException(ex);
		return createResponse(HttpStatus.BAD_REQUEST, "Constraint violation!", getConstraintDetails(ex));
	}

	@Override
	protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		String detail = ex.getMessage();
		ResponseEntity<ErrorInfo> raw = createResponse(HttpStatus.BAD_REQUEST,
				"Illegal data! Failed to bind to parameter.", detail);
		return new ResponseEntity<>(raw.getBody(), raw.getHeaders(), raw.getStatusCode());
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String detail = ex.getMessage();
		ResponseEntity<ErrorInfo> raw = createResponse(HttpStatus.BAD_REQUEST, "Illegal data! Message not readable.",
				detail);
		return new ResponseEntity<>(raw.getBody(), raw.getHeaders(), raw.getStatusCode());
	}

	@ExceptionHandler(value = { OptimisticLockException.class })
	protected ResponseEntity<ErrorInfo> handleOptimisticLock(RuntimeException ex, WebRequest request) {
		logException(ex);
		return createResponse(HttpStatus.CONFLICT, getMessageFrom(ex), getDetailsFrom(ex));
	}

	// @ExceptionHandler(value = { CommunicationException.class })
	// protected ResponseEntity<ErrorInfo> handleLdapError(RuntimeException ex,
	// WebRequest request) {
	// logException(ex);
	// return createResponse(HttpStatus.INTERNAL_SERVER_ERROR, getMessageFrom(ex));
	// }

	@ExceptionHandler(value = { IllegalArgumentException.class, IllegalStateException.class,
			InvalidDataAccessApiUsageException.class })
	protected ResponseEntity<ErrorInfo> handleBadRequest(RuntimeException ex, WebRequest request) {
		logException(ex);
		return createResponse(HttpStatus.BAD_REQUEST, getMessageFrom(ex), getDetailsFrom(ex));
	}

	// @ExceptionHandler(value = { IllegalPropertyException.class })
	// protected ResponseEntity<ErrorInfo>
	// handleBadRequestDueToIllegalPropertyException(RuntimeException ex,
	// WebRequest request) {
	// logException(ex);
	// String msg = ex.getMessage();
	// String detail = null;
	// if (ex.getCause() instanceof PropertyReferenceException) {
	// detail = ex.getCause().getMessage();
	// }
	// return createResponse(HttpStatus.BAD_REQUEST, msg, detail);
	// }

	// @ExceptionHandler(value = { ConstraintViolationException.class })
	// protected ResponseEntity<ErrorInfo>
	// handleValidationErrorAsBadRequest(RuntimeException ex, WebRequest request) {
	// logException(ex);
	// String msg = getMessageFrom(ex);
	// String[] details = null;
	// if (ex instanceof ConstraintViolationException) {
	// String cName = ((ConstraintViolationException) ex).getConstraintName();
	// if (cName != null) {
	// details = new String[] { cName };
	// }
	// }
	// return createResponse(HttpStatus.BAD_REQUEST, msg, details);
	// }

	@ExceptionHandler(value = { DataIntegrityViolationException.class })
	protected ResponseEntity<ErrorInfo> handleBadRequestDueToDataIntegrity(RuntimeException ex, WebRequest request) {
		logException(ex);
		String msg = getIntegrityMessageFrom(ex);
		String[] details = getIntegrityDetailsFrom(ex);
		if (msg == null) {
			msg = getMessageFrom(ex);
		}
		return createResponse(HttpStatus.BAD_REQUEST, msg, details);
	}

	@ExceptionHandler(value = { JsonProcessingException.class })
	protected ResponseEntity<ErrorInfo> handleBadRequestDueToJsonException(Exception ex, WebRequest request) {
		logException(ex);
		String msg = "Illegal JSON!";
		String[] details = new String[] { ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage() };
		return createResponse(HttpStatus.BAD_REQUEST, msg, details);
	}

	@ExceptionHandler(value = { TransactionSystemException.class })
	protected ResponseEntity<ErrorInfo> handleBadRequestDueToConstraints(RuntimeException ex, WebRequest request) {
		logException(ex);
		if (ex.getCause() instanceof RollbackException) {
			Throwable rollbackCause = ex.getCause().getCause();
			if (rollbackCause instanceof javax.validation.ConstraintViolationException) {
				String[] details = getConstraintDetails(rollbackCause);
				return createResponse(HttpStatus.BAD_REQUEST, "Constraint violation!", details);
			}
		}
		return handleOthers(ex, request);
	}

	@ExceptionHandler(value = { NoResultException.class, NonUniqueResultException.class,
			EmptyResultDataAccessException.class, EntityNotFoundException.class })
	protected ResponseEntity<ErrorInfo> handleNotFound(RuntimeException ex, WebRequest request) {
		logException(ex);
		return createResponse(HttpStatus.NOT_FOUND, getMessageFrom(ex), getDetailsFrom(ex));
	}

	@ExceptionHandler(value = { RevisionDoesNotExistException.class })
	protected ResponseEntity<ErrorInfo> handleConflict(RuntimeException ex, WebRequest request) {
		logException(ex);
		return createResponse(HttpStatus.CONFLICT, getMessageFrom(ex), getDetailsFrom(ex));
	}

	@ExceptionHandler(value = { WebClientResponseException.class })
	protected ResponseEntity<ErrorInfo> handleWebClientResponseException(WebClientResponseException ex,
			WebRequest request) {
		logException(ex);
		return createResponse(ex.getStatusCode(), getMessageFrom(ex), getDetailsFrom(ex));
	}

	@ExceptionHandler
	protected ResponseEntity<ErrorInfo> handleOthers(Throwable t, WebRequest request) {
		logException(t);
		return createGeneralResponse(HttpStatus.INTERNAL_SERVER_ERROR, getMessageFrom(t), t, request,
				getDetailsFrom(t));
	}

	private ResponseEntity<ErrorInfo> createResponse(HttpStatus status, String message, String... details) {
		if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
			throw new IllegalArgumentException("Please use createResponse(HttpStatus, String, Throwable, WebRequest)!");
		}
		return createGeneralResponse(status, message, null, null, details);
	}

	private void logException(Throwable t) {
		log.log(Level.SEVERE, t, () -> "service request finished with exception:");
	}

	private ResponseEntity<ErrorInfo> createGeneralResponse(HttpStatus status, String message, Throwable t,
			WebRequest request, String... details) {
		HttpStatus usedStatus = status != null ? status : HttpStatus.INTERNAL_SERVER_ERROR;
		if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, t, WebRequest.SCOPE_REQUEST);
		}
		ErrorInfo error = new ErrorInfo(usedStatus.value(), message, details);
		return new ResponseEntity<ErrorInfo>(error, new HttpHeaders(), usedStatus);
	}

	private String getIntegrityMessageFrom(Throwable ex) {
		if (ex instanceof DataIntegrityViolationException) {
			Throwable violationCause = ex.getCause();
			if (violationCause instanceof ConstraintViolationException) {
				return "Constraint violation!";
			} else if (violationCause instanceof DataException) {
				return "Illegal data!";
			}
		}
		return null;
	}

	private String[] getIntegrityDetailsFrom(Throwable ex) {
		if (ex instanceof DataIntegrityViolationException) {
			Throwable violationCause = ex.getCause();
			if (violationCause instanceof ConstraintViolationException) {
				if (violationCause.getCause() != null) {
					return new String[] { violationCause.getCause().getMessage() };
				}
			} else if (violationCause instanceof DataException) {
				if (violationCause.getCause() instanceof SQLException) {
					return new String[] { ((SQLException) violationCause.getCause()).getMessage() };
				}
			}
		}
		return null;
	}

	private static String getMessageFrom(Throwable ex) {
		if (ex instanceof DataIntegrityViolationException) {
			Throwable violationCause = ex.getCause();
			if (violationCause instanceof ConstraintViolationException) {
				return "Constraint violation!";
			} else if (violationCause instanceof DataException) {
				return "Illegal data!";
			}
		}
		String rootMsg = ex.getMessage();
		Throwable cause = ex.getCause();
		if (cause != null && cause.getMessage() != null) {
			if (rootMsg.contains(cause.getMessage())) {
				return cause.getMessage();
			} else {
				return rootMsg; // + "\n\nDetails: " + cause.getMessage();
			}
		}
		return rootMsg;
	}

	private static String[] getDetailsFrom(Throwable ex) {
		if (ex instanceof DataIntegrityViolationException) {
			Throwable violationCause = ex.getCause();
			if (violationCause instanceof ConstraintViolationException) {
				return new String[0];
			} else if (violationCause instanceof DataException) {
				return new String[0];
			}
		}
		String rootMsg = ex.getMessage();
		Throwable cause = ex.getCause();
		if (cause != null && cause.getMessage() != null) {
			if (rootMsg.contains(cause.getMessage())) {
				return new String[0];
			} else {
				return new String[] { cause.getMessage() };
			}
		}
		return new String[0];
	}

	private String[] getConstraintDetails(Throwable exeption) {
		Set<ConstraintViolation<?>> violations = ((javax.validation.ConstraintViolationException) exeption)
				.getConstraintViolations();
		String[] details = violations.stream().map(c -> c.getRootBeanClass().getSimpleName() + "."
				+ c.getPropertyPath().toString() + ": " + c.getMessage()).toArray(size -> new String[size]);
		return details;
	}

}