package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a project question definition which are
 * allowed to be updated i.e. no primary or foreign keys.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ProjectQuestionDefinitionUpdateDto extends ProjectQuestionDefinitionEditableFieldsDto {
	// implements VersionedEntity {

	public static ProjectQuestionDefinitionUpdateDto from(ProjectQuestionDefinition src) {
		ProjectQuestionDefinitionUpdateDto result = new ProjectQuestionDefinitionUpdateDto();
		ProjectQuestionDefinitionEditableFieldsDto.mapOwn(src, result);
		// mapOwn(src, result);
		return result;
	}

//	public static void mapOwn(ProjectComment src, ProjectQuestionDefinitionUpdateDto result) {
//		result.setVersion(src.getVersion());
//	}
//
//	private Integer version;

}
