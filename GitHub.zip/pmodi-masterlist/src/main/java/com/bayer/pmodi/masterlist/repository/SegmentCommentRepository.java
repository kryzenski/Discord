package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.SegmentComment;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

public interface SegmentCommentRepository extends BaseRepository<SegmentComment> {

	Page<SegmentComment> findBySegmentId(Long id, Pageable pageInfo);

	Page<SegmentComment> findBySegmentIdAndDtype(Long id, ModuleTypeEnum dtype, Pageable pageInfo);

	long deleteBySegmentId(Long id);

}
