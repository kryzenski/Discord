package com.bayer.pmodi.masterlist.repository;

import java.util.Optional;

import javax.persistence.NoResultException;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

@NoRepositoryBean
public interface BaseRepository<T> extends PagingAndSortingRepository<T, Long> {

	/**
	 * Get an entity for a given ID. Throws an exception if none is found (or the
	 * given id was null).
	 * 
	 * @param id Primary key; mandatory
	 * @return Entity; never null
	 */
	public default T getOne(Long id) {
		if (id == null) {
			throw new IllegalArgumentException("ID missing!");
		}
		Optional<T> result = findById(id);
		if (!result.isPresent()) {
			throw new NoResultException("No result found for id " + id + "!");
		}
		return result.get();
	}

	/**
	 * Get an entity for a given ID. Returns null if none is found.
	 * 
	 * @param id Primary key; optional (but then null is returned)
	 * @return Entity or null
	 */
	public default T findOneIfExists(Long id) {
		if (id != null) {
			Optional<T> result = findById(id);
			if (result.isPresent()) {
				return result.get();
			}
		}
		return null;
	}

}