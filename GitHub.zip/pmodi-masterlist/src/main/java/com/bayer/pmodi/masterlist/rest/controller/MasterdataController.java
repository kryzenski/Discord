package com.bayer.pmodi.masterlist.rest.controller;

import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.model.ActiveIngrediant;
import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.CropGroup;
import com.bayer.pmodi.masterlist.model.CropPlatform;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.SubRegion;
import com.bayer.pmodi.masterlist.repository.ActiveIngrediantRepository;
import com.bayer.pmodi.masterlist.repository.CountryRepository;
import com.bayer.pmodi.masterlist.repository.CropGroupRepository;
import com.bayer.pmodi.masterlist.repository.CropPlatformRepository;
import com.bayer.pmodi.masterlist.repository.CropRepository;
import com.bayer.pmodi.masterlist.repository.ProductRepository;
import com.bayer.pmodi.masterlist.repository.RegionRepository;
import com.bayer.pmodi.masterlist.repository.SubRegionRepository;
import com.bayer.pmodi.masterlist.rest.NautilosService;
import com.bayer.pmodi.masterlist.rest.QuickScanService;
import com.bayer.pmodi.masterlist.rest.RegprimeService;
import com.bayer.pmodi.masterlist.rest.RestConstants;
import com.bayer.pmodi.masterlist.rest.RestUtil;
import com.bayer.pmodi.masterlist.rest.model.ActiveIngrediantDto;
import com.bayer.pmodi.masterlist.rest.model.CropDto;
import com.bayer.pmodi.masterlist.rest.model.CropGroupDto;
import com.bayer.pmodi.masterlist.rest.model.CropGroupWithParentDto;
import com.bayer.pmodi.masterlist.rest.model.CropPlatformDto;
import com.bayer.pmodi.masterlist.rest.model.CropSearchCriteria;
import com.bayer.pmodi.masterlist.rest.model.CropValidationDto;
import com.bayer.pmodi.masterlist.rest.model.CropWithParentDto;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedById;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedByName;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedByNull;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedByProductLineText;
import com.bayer.pmodi.masterlist.rest.model.ProductDto;
import com.bayer.pmodi.masterlist.rest.model.RegprimeRegistrationActionDto;
import com.bayer.pmodi.masterlist.rest.model.RegprimeSearchCriteria;
import com.bayer.pmodi.masterlist.rest.model.TerritoryDto;
import com.bayer.pmodi.masterlist.rest.model.nautilos.AprsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(MasterdataController.ROOT_URL)
public class MasterdataController {

	public static final String ROOT_URL = "/masterdata";

	private static final String PARAM_PLT = "plt";
	private static final String PARAM_SPEC_NUMBER = "specNumber";
	private static final String PARAM_PLACEHOLDER = "placeholder";

	private static final String LIST_CROP_PLATFORMS = "crop-platforms";
	private static final String ONE_CROP_PLATFORM = LIST_CROP_PLATFORMS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String LIST_CROP_GROUPS = "crop-groups";
	private static final String ONE_CROP_GROUP = LIST_CROP_GROUPS + "/{" + RestConstants.PARAM_ID + "}";
	private static final String LIST_CROP_GROUPS_OF_CROP_PLATFORM = ONE_CROP_PLATFORM + "/" + LIST_CROP_GROUPS;

	private static final String LIST_CROPS = "crops";
	private static final String ONE_CROP = LIST_CROPS + "/{" + RestConstants.PARAM_ID + "}";
	private static final String LIST_CROPS_OF_CROP_GROUP = ONE_CROP_GROUP + "/" + LIST_CROPS;
	private static final String ONE_CROP_BY_NAMES = LIST_CROPS + "/by-parent-names";
	private static final String ONE_CROP_VALIDATION = LIST_CROPS + "/validate";

	private static final String LIST_REGIONS = "regions";
	private static final String ONE_REGION = LIST_REGIONS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String LIST_SUB_REGIONS = "sub-regions";
	private static final String ONE_SUB_REGION = LIST_SUB_REGIONS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String LIST_COUNTRIES = "countries";
	private static final String ONE_COUNTRY = LIST_COUNTRIES + "/{" + RestConstants.PARAM_ID + "}";
	private static final String ONE_COUNTRY_BY_NAME = LIST_COUNTRIES + "/by-name/{" + RestConstants.PARAM_NAME + "}";

	private static final String LIST_REGPRIME_COUNTRIES = "regprime-countries";
	private static final String ONE_REGPRIME_COUNTRY = LIST_REGPRIME_COUNTRIES + "/by-code";

	private static final String LIST_REGPRIME_CROPS = "regprime-crops";
	private static final String ONE_REGPRIME_CROP = LIST_REGPRIME_CROPS + "/by-code";

	private static final String LIST_REGPRIME_PLTS = "regprime-plts";
	private static final String ONE_REGPRIME_PLT = LIST_REGPRIME_PLTS + "/{" + RegprimeService.PARAM_PRODUCT_LINE_NUMBER
			+ "}";

	private static final String LIST_REGPRIME_MILESTONE_CANDIDATES = "regprime-milestone-candidates";

	private static final String LIST_PRODUCTS = "products";
	private static final String ONE_PRODUCT = LIST_PRODUCTS + "/{" + RestConstants.PARAM_ID + "}";
	private static final String ONE_PRODUCT_BY_PLT = LIST_PRODUCTS + "/by-product-line-text";
	private static final String ONE_PRODUCT_BY_SPEC_NO = LIST_PRODUCTS + "/by-spec-number";

	private static final String LIST_ACTIVE_INGREDIANTS = "active-ingrediants";
	private static final String ONE_ACTIVE_INGREDIANT = LIST_ACTIVE_INGREDIANTS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String LIST_APRS = "aprs";
	private static final String ONE_APRS_BY_KEY = LIST_APRS + "/by-region-and-active-ingrediant";

	private static final String LIST_QUICKSCAN_ASSESSMENTS = "quickscan-assessments";
	private static final String QUICKSCAN_ASSESSMENT_BY_KEYS = LIST_QUICKSCAN_ASSESSMENTS + "/by-crop-country-product";
	private static final String ONE_QUICKSCAN_ASSESSMENT = LIST_QUICKSCAN_ASSESSMENTS + "/{" + RestConstants.PARAM_ID
			+ "}";

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CropPlatformRepository cropPlatformRepository;

	@Autowired
	private CropGroupRepository cropGroupRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ActiveIngrediantRepository activeIngrediantRepository;

	@Autowired
	private RegprimeService regprimeService;

	@Autowired
	private NautilosService nautilosService;

	@Autowired
	private QuickScanService quickScanService;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get list of crop platform entities. Pageable and sortable.")
	@GetMapping(path = LIST_CROP_PLATFORMS)
	@ResponseBody
	public Page<CropPlatformDto> getCropPlatforms(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<CropPlatform> results = cropPlatformRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, CropPlatformDto.class));
	}

	@ApiOperation(value = "Retrieve a single crop platform entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_CROP_PLATFORM)
	@ResponseBody
	public CropPlatformDto getCropPlatform(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		CropPlatform result = cropPlatformRepository.getOne(id);
		CropPlatformDto dto = modelMapper.map(result, CropPlatformDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of crop group entities. Pageable and sortable.")
	@GetMapping(path = LIST_CROP_GROUPS)
	@ResponseBody
	public Page<CropGroupWithParentDto> getCropGroups(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<CropGroup> results = cropGroupRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, CropGroupWithParentDto.class));
	}

	@ApiOperation(value = "Get list of crop group entities of a given parent crop platform (given by {"
			+ RestConstants.PARAM_ID + "}). Pageable and sortable.")
	@GetMapping(path = LIST_CROP_GROUPS_OF_CROP_PLATFORM)
	@ResponseBody
	public Page<CropGroupDto> getCropGroupsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID of the parent crop platform.", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<CropGroup> results = cropGroupRepository.findByCropPlatformId(id, pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, CropGroupDto.class));
	}

	@ApiOperation(value = "Retrieve a single crop group entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_CROP_GROUP)
	@ResponseBody
	public CropGroupWithParentDto getCropGroup(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		CropGroup result = cropGroupRepository.getOne(id);
		CropGroupWithParentDto dto = modelMapper.map(result, CropGroupWithParentDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of crop entities. Pageable and sortable.")
	@GetMapping(path = LIST_CROPS)
	@ResponseBody
	public Page<CropWithParentDto> getCrops(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Crop> results = cropRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, CropWithParentDto.class));
	}

	@ApiOperation(value = "Get list of crop entities of a given parent crop group (given by {" + RestConstants.PARAM_ID
			+ "}). Pageable and sortable.")
	@GetMapping(path = LIST_CROPS_OF_CROP_GROUP)
	@ResponseBody
	public Page<CropDto> getCropsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID of the parent crop group.", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Crop> results = cropRepository.findByCropGroupId(id, pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, CropDto.class));
	}

	@ApiOperation(value = "Retrieve a single crop entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_CROP)
	@ResponseBody
	public CropWithParentDto getCrop(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Crop result = cropRepository.getOne(id);
		CropWithParentDto dto = modelMapper.map(result, CropWithParentDto.class);
		return dto;
	}

	@ApiOperation(value = "Retrieve a single crop entity by its and its parent's names.")
	@GetMapping(path = ONE_CROP_BY_NAMES)
	@ResponseBody
	public CropDto getCropByParentNames(@Valid CropSearchCriteria criteria) {
		Crop result = cropRepository.findByNameAndCropGroupNameAndCropGroupCropPlatformName(criteria.getCropName(),
				criteria.getCropGroupName(), criteria.getCropPlatformName());
		if (result == null) {
			throw new NoResultException("No crop found for the given name combination!");
		}
		CropDto dto = modelMapper.map(result, CropDto.class);
		return dto;
	}

	@ApiOperation(value = "Validate the given crop. Returns (status 200 and) the crop if the given combination is valid and status 404 if the validation fails (then with an error message in the response JSON).")
	@GetMapping(path = ONE_CROP_VALIDATION)
	@ResponseBody
	public CropWithParentDto validateCrop(@Valid CropValidationDto dto) {
		Crop result = cropRepository.findBySourceKeyAndCropGroupSourceKeyAndCropGroupCropPlatformSourceKey(
				dto.getCropId(), dto.getCropGroupId(), dto.getCropPlatformId());
		if (result == null) {
			throw new NoResultException("No crop found for the given ids!");
		}
		if (!dto.getCrop().equals(result.getName()) || !dto.getCropGroup().equals(result.getCropGroup().getName())
				|| !dto.getCropPlatform().equals(result.getCropGroup().getCropPlatform().getName())) {
			throw new NoResultException("Crop found by given ids, but the names do not match!");
		}
		return modelMapper.map(result, CropWithParentDto.class);
	}

	@ApiOperation(value = "Get list of region entities. Pageable and sortable.")
	@GetMapping(path = LIST_REGIONS)
	@ResponseBody
	public Page<TerritoryDto> getRegions(PageAndSortCriteriaSortedById pageAndSortParameters,
			@RequestParam(required = false) @ApiParam(name = PARAM_PLACEHOLDER, value = "Restricts results to such with the same placeholder. If omitted, no restriction is done.", example = "false") Boolean placeholder) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Region> results = placeholder == null ? regionRepository.findAll(pageInfo)
				: regionRepository.findByIsPlaceholder(placeholder.booleanValue(), pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, TerritoryDto.class));
	}

	@ApiOperation(value = "Retrieve a single region entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_REGION)
	@ResponseBody
	public TerritoryDto getRegion(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Region result = regionRepository.getOne(id);
		TerritoryDto dto = modelMapper.map(result, TerritoryDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of sub-region entities. Pageable and sortable.")
	@GetMapping(path = LIST_SUB_REGIONS)
	@ResponseBody
	public Page<TerritoryDto> getSubRegions(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<SubRegion> results = subRegionRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, TerritoryDto.class));
	}

	@ApiOperation(value = "Retrieve a single sub-region entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_SUB_REGION)
	@ResponseBody
	public TerritoryDto getSubRegion(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		SubRegion result = subRegionRepository.getOne(id);
		TerritoryDto dto = modelMapper.map(result, TerritoryDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of country entities. Pageable and sortable.")
	@GetMapping(path = LIST_COUNTRIES)
	@ResponseBody
	public Page<TerritoryDto> getCountries(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Country> results = countryRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, TerritoryDto.class));
	}

	@ApiOperation(value = "Retrieve a single country entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_COUNTRY)
	@ResponseBody
	public TerritoryDto getCountry(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Country result = countryRepository.getOne(id);
		TerritoryDto dto = modelMapper.map(result, TerritoryDto.class);
		return dto;
	}

	@ApiOperation(value = "Retrieve a single country entity by its unique name (given by {" + RestConstants.PARAM_NAME
			+ "}).")
	@GetMapping(path = ONE_COUNTRY_BY_NAME)
	@ResponseBody
	public TerritoryDto getCountryByName(
			@PathVariable(name = RestConstants.PARAM_NAME, required = true) @ApiParam(name = RestConstants.PARAM_NAME, required = true, allowEmptyValue = false, value = "Name of the country.", example = "Greece") String name) {
		Country result = countryRepository.findByName(name);
		if (result == null) {
			throw new NoResultException("No country found for the given name!");
		}
		TerritoryDto dto = modelMapper.map(result, TerritoryDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of REGPRIME country entities (REGPRIME territories of type COUNTRY). Pageable and sortable.")
	@GetMapping(path = LIST_REGPRIME_COUNTRIES)
	@ResponseBody
	public Map<String, Object> getRegprimeCountries(PageAndSortCriteriaSortedByName pageAndSortParameters) {
		return regprimeService.getCountries(pageAndSortParameters);
	}

	@ApiOperation(value = "Retrieve a single REGPRIME country entity by its code.")
	@GetMapping(path = ONE_REGPRIME_COUNTRY)
	@ResponseBody
	public Map<String, Object> getRegprimeCountry(
			@RequestParam(name = RegprimeService.PARAM_CODE, required = true) @ApiParam(name = RegprimeService.PARAM_CODE, required = true, allowEmptyValue = false, value = "Unique code", type = "string", example = "GBR") String code) {
		return regprimeService.getCountry(code);
	}

	@ApiOperation(value = "Get list of REGPRIME crop entities. Pageable and sortable.")
	@GetMapping(path = LIST_REGPRIME_CROPS)
	@ResponseBody
	public Map<String, Object> getRegprimeCrops(PageAndSortCriteriaSortedByName pageAndSortParameters) {
		return regprimeService.getCrops(pageAndSortParameters);
	}

	@ApiOperation(value = "Retrieve a single REGPRIME crop entity by its code.")
	@GetMapping(path = ONE_REGPRIME_CROP)
	@ResponseBody
	public Map<String, Object> getRegprimeCrop(
			@RequestParam(name = RegprimeService.PARAM_CODE, required = true) @ApiParam(name = RegprimeService.PARAM_CODE, required = true, allowEmptyValue = false, value = "Unique code", type = "string", example = "ALLCE") String code) {
		return regprimeService.getCrop(code);
	}

	@ApiOperation(value = "Get list of REGPRIME product line entities. Pageable and sortable.")
	@GetMapping(path = LIST_REGPRIME_PLTS)
	@ResponseBody
	public Map<String, Object> getRegprimePlts(PageAndSortCriteriaSortedByProductLineText pageAndSortParameters) {
		return regprimeService.getProductLines(pageAndSortParameters);
	}

	@ApiOperation(value = "Retrieve a single REGPRIME PLT entity (given by {"
			+ RegprimeService.PARAM_PRODUCT_LINE_NUMBER + "}).")
	@GetMapping(path = ONE_REGPRIME_PLT)
	@ResponseBody
	public Map<String, Object> getRegprimePlt(
			@PathVariable(name = RegprimeService.PARAM_PRODUCT_LINE_NUMBER, required = true) @ApiParam(name = RegprimeService.PARAM_PRODUCT_LINE_NUMBER, required = true, allowEmptyValue = false, value = "Product line number", type = "string", example = "108000000110") String productLineNumber) {
		return regprimeService.getProductLine(productLineNumber);
	}

	@ApiOperation(value = "Retrieve REGPRIME regulatory actions as milestone candidates for a given combination of country, crop and product line.")
	@GetMapping(path = LIST_REGPRIME_MILESTONE_CANDIDATES)
	@ResponseBody
	public List<RegprimeRegistrationActionDto> getRegprimeMilestones(@Valid RegprimeSearchCriteria criteria) {
		return regprimeService.getMilestoneCandidates(criteria);
	}

	@ApiOperation(value = "Get list of product entities. Pageable and sortable.")
	@GetMapping(path = LIST_PRODUCTS)
	@ResponseBody
	public Page<ProductDto> getProducts(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Product> results = productRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, ProductDto.class));
	}

	@ApiOperation(value = "Retrieve a single product entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_PRODUCT)
	@ResponseBody
	public ProductDto getProduct(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Product result = productRepository.getOne(id);
		ProductDto dto = modelMapper.map(result, ProductDto.class);
		return dto;
	}

	@ApiOperation(value = "Retrieve a single product entity by its unique product line text (given by {" + PARAM_PLT
			+ "}). Comparison is done case insensitive.")
	@GetMapping(path = ONE_PRODUCT_BY_PLT)
	@ResponseBody
	public ProductDto getProductByProductLineText(
			@RequestParam(name = PARAM_PLT, required = true) @ApiParam(name = PARAM_PLT, required = true, allowEmptyValue = false, value = "Unique product line text.", example = "atrazine SC 480 (480 g/L)") String plt) {
		Product result = productRepository.findByProductLineTextIgnoreCase(plt);
		if (result == null) {
			throw new NoResultException("No product found for the given product line text!");
		}
		ProductDto dto = modelMapper.map(result, ProductDto.class);
		return dto;
	}

	@ApiOperation(value = "Retrieve a single product entity by its unique spec number (given by {" + PARAM_SPEC_NUMBER
			+ "}).")
	@GetMapping(path = ONE_PRODUCT_BY_SPEC_NO)
	@ResponseBody
	public ProductDto getProductBySpecNumber(
			@RequestParam(name = PARAM_SPEC_NUMBER, required = true) @ApiParam(name = PARAM_SPEC_NUMBER, required = true, allowEmptyValue = false, value = "Unique product spec number.", example = "108000000006") String specNumber) {
		Product result = productRepository.findBySpecNumber(specNumber);
		if (result == null) {
			throw new NoResultException("No product found for the given spec number!");
		}
		ProductDto dto = modelMapper.map(result, ProductDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of active ingrediant entities. Pageable and sortable.")
	@GetMapping(path = LIST_ACTIVE_INGREDIANTS)
	@ResponseBody
	public Page<ActiveIngrediantDto> getActiveIngrediants(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<ActiveIngrediant> results = activeIngrediantRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> modelMapper.map(e, ActiveIngrediantDto.class));
	}

	@ApiOperation(value = "Retrieve a single active ingrediant entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_ACTIVE_INGREDIANT)
	@ResponseBody
	public ActiveIngrediantDto getActiveIngrediant(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		ActiveIngrediant result = activeIngrediantRepository.getOne(id);
		ActiveIngrediantDto dto = modelMapper.map(result, ActiveIngrediantDto.class);
		return dto;
	}

	@ApiOperation(value = "Get list of Nautilos APRS entities. Pageable and sortable.")
	@GetMapping(path = LIST_APRS)
	@ResponseBody
	public Map<String, Object> getAprs(PageAndSortCriteriaSortedByNull pageAndSortParameters) {
		return nautilosService.getAprsList(pageAndSortParameters);
	}

	@ApiOperation(value = "Retrieve a single Nautilos APRS entity by region and active ingrediant.")
	@GetMapping(path = ONE_APRS_BY_KEY)
	@ResponseBody
	public AprsDto getAprsByRegionAndActiveIngrediant(
			@RequestParam(name = NautilosService.PARAM_REGION, required = true) @ApiParam(name = NautilosService.PARAM_REGION, required = true, allowEmptyValue = false, value = "Region", type = "string", example = "APAC") String region,
			@RequestParam(name = NautilosService.PARAM_ACTIVE_INGREDIANT, required = true) @ApiParam(name = NautilosService.PARAM_ACTIVE_INGREDIANT, required = true, allowEmptyValue = false, value = "Active ingrediant", type = "string", example = "BIX") String activeIngrediant) {
		return nautilosService.findAprsByRegionAndActiveIngrediant(region, activeIngrediant);
	}

	@ApiOperation(value = "Retrieve QuickScan assessment entities by crop, country and product.")
	@GetMapping(path = QUICKSCAN_ASSESSMENT_BY_KEYS)
	@ResponseBody
	public List<?> getAssessmentsByCountryCropAndProduct(
			@RequestParam(name = QuickScanService.PARAM_COUNTRY_CODE, required = true) @ApiParam(name = QuickScanService.PARAM_COUNTRY_CODE, required = true, allowEmptyValue = false, value = "Country Code", type = "string") String countryCode,
			@RequestParam(name = QuickScanService.PARAM_CROP_CODE, required = true) @ApiParam(name = QuickScanService.PARAM_CROP_CODE, required = true, allowEmptyValue = false, value = "Crop Code", type = "string") String cropCode,
			@RequestParam(name = QuickScanService.PARAM_PLT, required = true) @ApiParam(name = QuickScanService.PARAM_PLT, required = true, allowEmptyValue = false, value = "Product Line Text", type = "string") String productLineText) {
		return quickScanService.findAssessmentsByCountryCropAndProduct(countryCode, cropCode, productLineText);
	}

	@ApiOperation(value = "Retrieve QuickScan assessment entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_QUICKSCAN_ASSESSMENT)
	@ResponseBody
	public Map<String, Object> getAssessmentById(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		return quickScanService.getAssessmentById(id);
	}

}
