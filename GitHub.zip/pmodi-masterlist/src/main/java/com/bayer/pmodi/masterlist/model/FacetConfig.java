package com.bayer.pmodi.masterlist.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table
@ToString
@EqualsAndHashCode
public class FacetConfig {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	// @Version
	// @Column(nullable = false)
	// private Integer version = null;

	@NotNull
	@Column(nullable = false)
	private String facetName;

	@NotNull
	@Column(nullable = false)
	private String entityType;

	@NotNull
	@Column(nullable = false)
	private String fieldName;

	@NotNull
	@Column(nullable = false)
	private String dataType;

	@NotNull
	@Column(nullable = false)
	private String facetType;

	@Column(nullable = true)
	private String groupName;

	@Column(nullable = false)
	private boolean multiSelect;

	@Column(nullable = true)
	private String endpointAddress;

	@OneToMany(mappedBy = "facetConfig", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AllowedValue> values;

}