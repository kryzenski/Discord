package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.search.SearchCriterion;

public interface CustomSegmentRepository {

	Page<Segment> search(List<SearchCriterion> searchCriteria, Pageable pageable);

	List<String> findDistinctValuesStartingWith(String columnName, String valueStartsWith, Integer limit,
			boolean isCaseSensitive);

}
