package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.Project;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains some important properties of a project.
 */
@Data
@ToString
@EqualsAndHashCode
public class ProjectShortInfoDto {

	public static ProjectShortInfoDto from(Project src) {
		ProjectShortInfoDto result = new ProjectShortInfoDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Project src, ProjectShortInfoDto target) {
		BeanUtils.copyProperties(src, target);
	}

	@NotNull
	private Long id;

	private String newportFreeText;

	private String newportName;

	@NotNull
	private String preciseNewportId;

}