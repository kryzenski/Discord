package com.bayer.pmodi.masterlist.rest.model.mapping;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.github.jmnarloch.spring.boot.modelmapper.ModelMapperConfigurer;

@Component
public class CustomConfigurer implements ModelMapperConfigurer {

	public void configure(ModelMapper modelMapper) {
		// modelMapper.getConfiguration().setSourceNamingConvention(NamingConventions.NONE)
		// .setDestinationNamingConvention(NamingConventions.NONE);
		modelMapper.getConfiguration().setAmbiguityIgnored(true);
	}
}
