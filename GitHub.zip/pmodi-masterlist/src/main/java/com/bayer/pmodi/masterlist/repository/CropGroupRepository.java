package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.CropGroup;

public interface CropGroupRepository extends BaseRepository<CropGroup> {

	Page<CropGroup> findByCropPlatformId(Long id, Pageable page);

}
