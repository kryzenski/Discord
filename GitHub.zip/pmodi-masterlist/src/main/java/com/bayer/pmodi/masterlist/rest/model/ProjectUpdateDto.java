package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.Project;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a project which are allowed to be
 * updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ProjectUpdateDto extends ProjectEditableFieldsDto implements VersionedEntity {

	public static ProjectUpdateDto from(Project src) {
		ProjectUpdateDto result = new ProjectUpdateDto();
		ProjectEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Project src, ProjectUpdateDto result) {
		result.setVersion(src.getVersion());
	}

	private Integer version;

}