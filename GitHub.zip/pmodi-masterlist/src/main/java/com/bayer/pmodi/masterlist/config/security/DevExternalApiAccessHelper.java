package com.bayer.pmodi.masterlist.config.security;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("!sso")
public class DevExternalApiAccessHelper implements ExternalApiAccessHelper {

	@Override
	public String getNautilosAccessToken() throws Exception {
		return "";
	}

	@Override
	public String getRegPrimeAccessToken(String token) throws Exception {
		return "";
	}

	@Override
	public String getQuickscanAccessToken() throws Exception {
		return getNautilosAccessToken();
	}

	@Override
	public String getNewportConnectorAccessToken() throws Exception {
		return "";
	}

}
