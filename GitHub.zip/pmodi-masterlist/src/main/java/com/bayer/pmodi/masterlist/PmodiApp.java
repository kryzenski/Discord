package com.bayer.pmodi.masterlist;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.format.Formatter;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@EnableEncryptableProperties
@SpringBootApplication
public class PmodiApp {

	public static void main(String[] args) {
		SpringApplication.run(PmodiApp.class, args);
	}

	@Bean
	public Formatter<ZonedDateTime> zonedDateTimeFormatter() {
		// Introduced own formatter because Java 8 Dates are otherwise not
		// recognized/parsed in request parameters
		return new Formatter<ZonedDateTime>() {
			@Override
			public ZonedDateTime parse(String text, Locale locale) {
				return ZonedDateTime.parse(text, DateTimeFormatter.ISO_DATE_TIME);
			}

			@Override
			public String print(ZonedDateTime object, Locale locale) {
				return DateTimeFormatter.ISO_DATE_TIME.format(object);
			}
		};
	}

	@Bean
	public Formatter<LocalDateTime> localDateTimeFormatter() {
		// Introduced own formatter because Java 8 Dates are otherwise not
		// recognized/parsed in request parameters
		return new Formatter<LocalDateTime>() {
			@Override
			public LocalDateTime parse(String text, Locale locale) {
				return LocalDateTime.parse(text, DateTimeFormatter.ISO_DATE_TIME);
			}

			@Override
			public String print(LocalDateTime object, Locale locale) {
				return DateTimeFormatter.ISO_DATE_TIME.format(object);
			}
		};
	}

}