package com.bayer.pmodi.masterlist.search;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class AbstractSpecification<T> implements Specification<T> {

	private static final long serialVersionUID = -3521930461734144980L;

	private List<SearchCriterion> searchCriteria;

	@Override
	public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
		if (searchCriteria == null || searchCriteria.isEmpty()) {
			return null;
		}

		List<Predicate> predicates = new ArrayList<>();

		for (SearchCriterion criterion : searchCriteria) {
			Predicate p = SearchUtil.predicateFrom(criterion, root, builder);
			predicates.add(p);
		}
		query.distinct(true);
		return builder.and(predicates.toArray(new Predicate[0]));
	}

}
