package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@Table
@ToString
@EqualsAndHashCode
public class OrcaProjectCost {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@Column(nullable = false)
	private String projectId;

	@Column(nullable = true)
	private String spgName;

	@NotNull
	@Column(nullable = false)
	private String newportArea;

	@NotNull
	@Column(nullable = false)
	private String newportNumber;

	@Column(nullable = true)
	private String freeText;

	@NotNull
	@Column(nullable = false)
	private String projectName;

	@Column(nullable = true)
	private String projectStatus;

	@Column(nullable = true)
	private String projectCategory;

	@Column(nullable = true)
	private String leadAi;

	@Column(nullable = true)
	private String pltName;

	@Column(nullable = true)
	private String projectFramework;

	@Column(nullable = true)
	private String businessGroup;

	@Column(nullable = true)
	private String businessUnit;

	@Column(nullable = true)
	private String businessSegment;

	@Column(nullable = true)
	private String businessObjectNumber;

	@Column(nullable = true)
	private String formulationType;

	@Column(nullable = true)
	private String concentrationUnit;

	@Column(nullable = true)
	private String region;

	@Column(nullable = true)
	private String subregion;

	@NotNull
	@Column(nullable = false)
	private String country;

	@Column(nullable = true)
	private String cropPlatform;

	@Column(nullable = true)
	private String cropGroup;

	@NotNull
	@Column(nullable = false)
	private String crop;

	@NotNull
	@Column(nullable = false)
	private String diseasesPestsWeeds;

	@Column(nullable = true)
	private String excelTemplate;

	@NotNull
	@Column(nullable = false)
	private String calendarYear;

	@Column(nullable = true)
	private Double agronomicDev;

	@Column(nullable = true)
	private Double environment;

	@Column(nullable = true)
	private Double fieldDev;

	@Column(nullable = true)
	private Double formulationDev;

	@Column(nullable = true)
	private Double globalResourceConsumption;

	@Column(nullable = true)
	private Double productSupply;

	@Column(nullable = true)
	private Double launchMarket;

	@Column(nullable = true)
	private Double customerAdvisory;

	@Column(nullable = true)
	private Double regulationAffair;

	@Column(nullable = true)
	private Double research;

	@Column(nullable = true)
	private Double registrationFees;

	@Column(nullable = true)
	private Double humanSafety;

	@Column(nullable = true)
	private Double other;

	@Column(nullable = true)
	private Double totalProjectCosts;

}