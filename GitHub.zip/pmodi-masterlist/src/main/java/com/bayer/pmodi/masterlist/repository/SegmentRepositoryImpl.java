package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.search.SearchCriterion;
import com.bayer.pmodi.masterlist.search.SegmentSpecification;

public class SegmentRepositoryImpl implements CustomSegmentRepository {

	@Autowired
	private EntityManager em;

	@Autowired
	private SegmentRepository segmentRepository;

	@Override
	public Page<Segment> search(List<SearchCriterion> searchCriteria, Pageable pageable) {
		Pageable pageInfo = pageable == null ? Pageable.unpaged() : pageable;
		if (searchCriteria == null || searchCriteria.isEmpty()) {
			return segmentRepository.findAll(pageInfo);
		} else {
			SegmentSpecification spec = new SegmentSpecification(searchCriteria);
			return segmentRepository.findAll(spec, pageInfo);
		}
	}

	@Override
	public List<String> findDistinctValuesStartingWith(String columnName, String valueStartsWith, Integer limit,
			boolean isCaseSensitive) {
		return JpaQueryUtil.getDistinctFieldWithValueQuery(em, Segment.class, columnName,
				valueStartsWith == null ? null : valueStartsWith + "%", limit, isCaseSensitive).getResultList();
	}

}
