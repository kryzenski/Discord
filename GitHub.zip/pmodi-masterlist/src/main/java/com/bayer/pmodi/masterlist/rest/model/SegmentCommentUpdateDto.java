package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.SegmentComment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a segment comment which are allowed to
 * be updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentCommentUpdateDto extends SegmentCommentEditableFieldsDto implements VersionedEntity {

	public static SegmentCommentUpdateDto from(SegmentComment src) {
		SegmentCommentUpdateDto result = new SegmentCommentUpdateDto();
		SegmentCommentEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentComment src, SegmentCommentUpdateDto target) {
		target.setVersion(src.getVersion());
	}

	private Integer version;

}
