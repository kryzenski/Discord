package com.bayer.pmodi.masterlist.config.webclients;

import org.springframework.web.reactive.function.client.WebClient;

public interface WebClients {

	WebClient getRegprimeWebClient(String token);

	WebClient getNautilosWebClient();

	WebClient getQuickscanWebClient();

	WebClient getNewportConnectorWebClient();

}