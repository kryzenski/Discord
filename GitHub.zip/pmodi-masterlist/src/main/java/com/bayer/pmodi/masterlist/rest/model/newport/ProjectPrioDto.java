package com.bayer.pmodi.masterlist.rest.model.newport;

import com.bayer.pmodi.masterlist.model.Project;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class ProjectPrioDto {

	/**
	 * Create DTO from the given entity.
	 * 
	 * @param project Source; mandatory (but not checked)
	 * @return DTO
	 */
	public static ProjectPrioDto from(Project project) {
		String prioType = project.getPrioritizationType() == null ? "Not Assigned"
				: project.getPrioritizationType().name();
		ProjectPrioDto dto = new ProjectPrioDto(project.getId(), project.getNewportProjectId(), prioType,
				project.getNewportStatus());
		return dto;
	}

	@NonNull
	private Long id;
	@NonNull
	private String newportProjectId;

	private String prioritizationType;

	private String newportStatus;
}