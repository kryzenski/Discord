package com.bayer.pmodi.masterlist.model.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public interface CodeEnum<T extends Enum<T>> {

	@JsonValue
	String code();

	String label();

	public static <T extends Enum<T> & CodeEnum<T>> T fromCode(final String code, Class<T> type) {
		if (code == null) {
			return null;
		}
		for (T en : type.getEnumConstants()) {
			if (en.code().equals(code))
				return en;
		}
		throw new IllegalArgumentException("code \"" + code + "\" does not exist in domain");
	}

}
