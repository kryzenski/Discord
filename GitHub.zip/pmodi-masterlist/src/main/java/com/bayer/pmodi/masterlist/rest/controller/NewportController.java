package com.bayer.pmodi.masterlist.rest.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.*;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import lombok.extern.java.Log;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.hibernate.envers.query.criteria.AuditCriterion;
import org.hibernate.envers.query.criteria.AuditDisjunction;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SegmentCost;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.bayer.pmodi.masterlist.rest.model.newport.ProjectCostDto;
import com.bayer.pmodi.masterlist.rest.model.newport.ProjectPrioDto;
import com.bayer.pmodi.masterlist.rest.model.newport.ProjectPtrsDto;
import com.bayer.pmodi.masterlist.rest.model.newport.SegmentPtrsDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(NewportController.ROOT_URL)
@Log
public class NewportController {

	public static final String ROOT_URL = "/newport";

	private static final String PARAM_DATE = "date";
	private static final String PARAM_REGION_ID = "regionId";

	private static final String LIST_MODIFIED_PROJECT_PTRS = "modified-project-ptrs";
	private static final String LIST_MODIFIED_PROJECT_PRIO = "modified-project-prioritization";
	private static final String LIST_MODIFIED_PROJECT_COSTS = "modified-project-costs";
	private static final String LIST_MODIFIED_SEGMENT_PTRS = "modified-segment-ptrs";



	@PersistenceContext
	private EntityManager entityManager;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get project PTRS overall scores which are modified after a given date.")
	@GetMapping(path = LIST_MODIFIED_PROJECT_PTRS)
	@ResponseBody
	public List<ProjectPtrsDto> getModifiedProjectPtrs( //
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date)
			throws IOException {
		List<Project> revisions = getModifiedFields(Project.class, new String[] { "overallPtrsScore" }, date);
		List<ProjectPtrsDto> results = new ArrayList<>(revisions.size());
		for (Project p : revisions) {
			results.add(ProjectPtrsDto.from(p));
		}
		return results;
	}

	@ApiOperation(value = "Get project prioritization properties which are modified after a given date.")
	@GetMapping(path = LIST_MODIFIED_PROJECT_PRIO)
	@ResponseBody
	public List<ProjectPrioDto> getModifiedProjectPrioritization( //
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date)
			throws IOException {
		List<Project> revisions = getModifiedFields(Project.class, new String[] { "prioritizationType" }, date);
		List<ProjectPrioDto> results = new ArrayList<>(revisions.size());
		for (Project p : revisions) {
			if (p.getPrioritizationType() == null
					|| !PrioritizationTypeEnum.Cancelled.equals(p.getPrioritizationType())) {
				results.add(ProjectPrioDto.from(p));
			}
		}
		return results;
	}

	@ApiOperation(value = "Get project costs of a given region (optional) which are modified after a given date.")
	@GetMapping(path = LIST_MODIFIED_PROJECT_COSTS)
	@ResponseBody
	public List<ProjectCostDto> getModifiedProjectCosts( //
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date,
			@RequestParam(required = false) @ApiParam(name = PARAM_REGION_ID, required = false, value = "NewPort key of the region (e.g. 5 for North America). Optional.", example = "5") String regionId)
			throws IOException {
		// Approach: filter out not matching regions after reading data. This is not
		// nice, but envers does not support joins.
		List<SegmentCost> revisions = getModified(SegmentCost.class, date);
		List<ProjectCostDto> results = new ArrayList<>(revisions.size());
		for (SegmentCost s : revisions) {
			if (StringUtils.isBlank(regionId) || regionId.equalsIgnoreCase(s.getSegment().getRegion().getSourceKey())) {
				results.add(ProjectCostDto.from(s));
			}
		}
		return results;
	}

	@ApiOperation(value = "Get segment PTRS overall scores of a given region (optional) which are modified after a given date.")
	@GetMapping(path = LIST_MODIFIED_SEGMENT_PTRS)
	@ResponseBody
	public List<SegmentPtrsDto> getModifiedSegmentPtrs( //
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date,
			@RequestParam(required = false) @ApiParam(name = PARAM_REGION_ID, required = false, value = "NewPort key of the region (e.g. 5 for North America). Optional.", example = "5") String regionId)
			throws IOException {
		log.warning("entering in the getmodifiedSegmentPtrs");
		// Approach: filter out not matching regions after reading data. This is not
		// nice, but envers does not support joins.

		List<Segment> revisions = getModifiedFields(Segment.class, new String[] { "ptrsSegmentOverallScore" }, date);
		List<SegmentPtrsDto> results = new ArrayList<>(revisions.size());
		for (Segment s : revisions) {

			if (StringUtils.isBlank(regionId) || regionId.equalsIgnoreCase(s.getRegion().getSourceKey())) {
				results.add(SegmentPtrsDto.from(s));
			}
		}
		log.warning("segment is completed "+revisions.size());
		results.forEach(val->log.warning("Segment id: "+val.getId()+" score: "+ val.getOverallPtrsScore()));
		return results;
	}

	/**
	 * Get the entities that were modified after a given date. This only returns the
	 * newest revision of an entity if several modifications took place!
	 * 
	 * @param clazz Class to find; mandatory
	 * @param date  Date after which the modification took place; mandatory
	 * @return List of entities (each only once with the newest revision); never
	 *         null
	 */
	private <T> List<T> getModified(Class<T> clazz, OffsetDateTime date) {
		if (clazz == null || date == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}

		java.util.Date dateAsOldJavaDate = Date.from(date.toInstant());
		AuditReader reader = AuditReaderFactory.get(entityManager);
		AuditQuery query = reader.createQuery().forRevisionsOfEntity(clazz, true, true)
				.add(AuditEntity.revisionNumber().maximize().computeAggregationInInstanceContext())
				.add(AuditEntity.revisionProperty("timestamp").ge(dateAsOldJavaDate.getTime()));

		@SuppressWarnings("unchecked")
		List<T> revisions = query.getResultList();
		return revisions;
	}

	/**
	 * Get the entities where given fields are modified. This only returns the
	 * newest revision of an entity if several modifications took place!
	 * 
	 * @param clazz      Class to find; mandatory
	 * @param fieldNames Array of field names which have to be modified (if several
	 *                   names are given they are combined by OR); mandatory
	 * @param date       Date after which the modification took place; mandatory
	 * @return List of entities (each only once with the newest revision); never
	 *         null
	 */
	private <T> List<T> getModifiedFields(Class<T> clazz, String[] fieldNames, OffsetDateTime date) {
		log.warning("entering in the getModifiedField");
		if (clazz == null || fieldNames == null || fieldNames.length == 0 || date == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}


		java.util.Date dateAsOldJavaDate = Date.from(date.toInstant());
		java.util.Date dateAsOldJavaDateEnd=Date.from(Instant.parse("2024-02-08T23:59:59Z"));
        log.warning("starting date"+dateAsOldJavaDate);
		//log.warning("end date "+dateAsOldJavaDateEnd);
		AuditReader reader = AuditReaderFactory.get(entityManager);
		final AuditCriterion hasChanged;
		if (fieldNames.length == 1) {
			AuditDisjunction auditDisj = AuditEntity.disjunction();

			//uncomeenting for returning the field which is passed gettign changed
			hasChanged = AuditEntity.property(fieldNames[0]).hasChanged();// commented for returning all values
//			for (int i=0;i<2;i++){
//				if(i==0) {
//					auditDisj.add(AuditEntity.property(fieldNames[0]).hasChanged());
//				}
//				else {
//					auditDisj.add(AuditEntity.property(fieldNames[0]).hasNotChanged());
//				}
//			}
//			hasChanged = auditDisj;
		} else {

			AuditDisjunction disjunction = AuditEntity.disjunction();
			for (int i = 0; i < fieldNames.length; i++) {
				String fieldName = fieldNames[i];
				disjunction.add(AuditEntity.property(fieldName).hasChanged());
			}
			hasChanged = disjunction;
		}

		AuditQuery query = reader.createQuery().forRevisionsOfEntity(clazz, true, true)

				//.add(AuditEntity.revisionNumber().maximize().computeAggregationInInstanceContext())
				.add(hasChanged)
				.addOrder(AuditEntity.property("version").desc())
				.add(AuditEntity.revisionProperty("timestamp").ge(dateAsOldJavaDate.getTime()));
		// .add(AuditEntity.revisionProperty("timestamp").le(dateAsOldJavaDateEnd.getTime()));


		@SuppressWarnings("unchecked")
		List<T> revisions = query.getResultList();


		//Newly added
		if (clazz.getSimpleName().equalsIgnoreCase("Segment") && fieldNames.length == 1 && fieldNames[0].equalsIgnoreCase("ptrsSegmentOverallScore")) {
			List<Segment> segments = new ArrayList<>();
			TreeSet set = removeDuplicate(revisions);
			segments.addAll(set);
			List<Segment> revisedSegment = new ArrayList<>();
			for (Segment segment : segments) {
				if (segment != null) {

					if (segment.getPtrsSegmentOverallScore() != null)
						revisedSegment.add(segment);
				}
			}
			List<T> revised = (List<T>) revisedSegment;
			return revised;
		} else if (clazz.getSimpleName().equalsIgnoreCase("Project") && fieldNames.length == 1 && fieldNames[0].equalsIgnoreCase("overallPtrsScore")) {
			List<Project> project = new ArrayList<>();
			TreeSet set = removeDuplicate(revisions);
			project.addAll(set);

			List<Project> revisedPro = new ArrayList<>();
			for (Project pro : project) {
				if (pro != null) {
					if (pro.getOverallPtrsScore() != null)
						revisedPro.add(pro);
				}
			}
			List<T> revised = (List<T>) revisedPro;
			return revised;
		}
		return new ArrayList<>(removeDuplicate(revisions));
	}
	private <T> TreeSet removeDuplicate(List<T> revisions) {
		TreeSet<T> set = new TreeSet<>();
		revisions.forEach(revision -> set.add(revision));
		return set;
	}
}
