package com.bayer.pmodi.masterlist.repository;

import com.bayer.pmodi.masterlist.model.CropPlatform;

public interface CropPlatformRepository extends BaseRepository<CropPlatform> {

}
