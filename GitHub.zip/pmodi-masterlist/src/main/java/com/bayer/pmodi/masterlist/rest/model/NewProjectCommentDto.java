package com.bayer.pmodi.masterlist.rest.model;

import java.time.OffsetDateTime;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.ProjectComment;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewProjectCommentDto extends ProjectCommentEditableFieldsDto {

	public static NewProjectCommentDto from(ProjectComment src) {
		NewProjectCommentDto result = new NewProjectCommentDto();
		ProjectCommentEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(ProjectComment src, NewProjectCommentDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public static void applyKeyPropertiesTo(ProjectComment result, ModuleTypeEnum dtype, OffsetDateTime timestamp,
			String user) {
		result.setDtype(dtype);
		result.setTimestamp(timestamp);
		result.setUser(user);
	}

	private ModuleTypeEnum dtype;

	private OffsetDateTime timestamp;

}