package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class SegmentQuestionDefinition extends AbstractAuditedEntity {

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private ModuleTypeEnum dtype;

	@Column(nullable = false)
	private boolean isActive;

	@Column(nullable = false)
	private String questionText;

	@NotNull
	@Column(nullable = false)
	private Integer pos;

}