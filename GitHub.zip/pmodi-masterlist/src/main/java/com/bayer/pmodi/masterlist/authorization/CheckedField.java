package com.bayer.pmodi.masterlist.authorization;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface CheckedField {

	/**
	 * The roles that are allowed to edit this field.
	 */
	String[] roles();

	/**
	 * The group this field is a member of.
	 */
	String group() default "";

	/**
	 * Constant that is used to identify how a special treatment can be done. If no
	 * special treatment is needed omit this.
	 */
	String specialTreatment() default "";

}