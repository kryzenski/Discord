package com.bayer.pmodi.masterlist.rest;

import java.util.List;
import java.util.Map;

import com.bayer.pmodi.masterlist.config.webclients.WebClients;

import lombok.extern.java.Log;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@Log
public class QuickScanService {

	public static final String PARAM_CROP_CODE = "cropCode";
	public static final String PARAM_PLT = "productLineText";
	public static final String PARAM_COUNTRY_CODE = "countryIsoCode";

	//	public static final String PARAM_LOCKED = "is-locked";

	private static final String PLACEHOLDER_ID = "{" + RestConstants.PARAM_ID + "}";

	private static final String PATH_ASSESSMENT_LIST = "/precise";
	private static final String PATH_ASSESSMENT = PATH_ASSESSMENT_LIST + "/" + PLACEHOLDER_ID;

	private static final String PATH_MITIGATION_MODULE = PATH_ASSESSMENT_LIST +"/review/id/details";

	@Autowired
	private WebClients webClients;

	private WebClient getWebClient() {
		return webClients.getQuickscanWebClient();
	}

	public Map<String, Object> getAssessmentById(Long id) {
		try {
			String uri = StringUtils.replace(PATH_ASSESSMENT, PLACEHOLDER_ID, String.valueOf(id));
			return RestUtil.getResult(getWebClient(), uri);
		} catch (Exception e) {
			String msg = e.getMessage();
			if (msg.contains("404 Not Found")) {
				return null;
			}
			throw new RuntimeException(e);
		}
	}

	public Map<String, Object> getAssessmentMitigationById(Long id){
		try{
			String uri = StringUtils.replace(PATH_MITIGATION_MODULE,RestConstants.PARAM_ID,String.valueOf(id));
			return RestUtil.getResult(getWebClient(), uri);
			}
		catch (Exception e){
			String msg = e.getMessage();
			if(msg.contains("404 Not Found")){
				return null;
			}
			throw new RuntimeException();
		}
	}

	public List<?> findAssessmentsByCountryCropAndProduct(String countryCode, String cropCode, String productLineText) {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add(PARAM_COUNTRY_CODE, countryCode);
		params.add(PARAM_CROP_CODE, cropCode);
		params.add(PARAM_PLT, productLineText);
		try {
			// return RestUtil.getResult(webClient, PATH_ASSESSMENT_LIST, params);
			List<?> results = getWebClient().get()
					.uri(uriBuilder -> uriBuilder.path(PATH_ASSESSMENT_LIST).queryParams(params).build()) //
					.retrieve() //
					.bodyToFlux(RestUtil.TypedMap.class).collectList() //
					.block();
			return results;
		} catch (Exception wex) {
			if (wex instanceof WebClientResponseException) {
				if (((WebClientResponseException) wex).getStatusCode() == HttpStatus.NOT_FOUND) {
					throw new IllegalArgumentException("No assessment found for country '" + countryCode + "', crop '"
							+ cropCode + "' and product line '" + productLineText + "'!");
				}
			}
			throw wex;
		}
	}

	public void lockAssessment(String id, boolean isLocked) {

		String uri = StringUtils.replace(PATH_ASSESSMENT, PLACEHOLDER_ID, String.valueOf(id));

		ClientResponse result = getWebClient().post()
				.uri(uriBuilder -> uriBuilder.path(uri).queryParam("lock",isLocked)
						.build())
				.exchange().block();

		if (result.rawStatusCode() != 200) {
			WebClientResponseException cause = result.createException().block();
			throw new IllegalArgumentException("Assessment with id " + id + " can't be " + //
					(isLocked ? "locked" : "unlocked") + "!", cause);
		}
	}

}

