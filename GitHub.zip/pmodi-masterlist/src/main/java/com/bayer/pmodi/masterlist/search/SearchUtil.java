package com.bayer.pmodi.masterlist.search;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.bayer.pmodi.masterlist.model.enums.CodeEnum;
import com.bayer.pmodi.masterlist.repository.JpaQueryUtil;
import org.apache.commons.lang3.StringUtils;

public final class SearchUtil {

	private SearchUtil() {
		// No instance allowed
	}

	public static <T> Predicate predicateFrom(SearchCriterion criterion, Root<T> root, CriteriaBuilder builder) {

		if (criterion == null)
			throw new IllegalArgumentException("Search criterion may not be null!");

		String fieldName = criterion.getFieldName();
		if (fieldName == null) {
			throw new IllegalArgumentException("fieldName must be provided in the filterCondition");
		}

		if (criterion.getOperator() == null) {
			throw new IllegalArgumentException("Operator must be provided in the filterCondition");
		}
		boolean isMonthPresent=false;
		if(fieldName.contains("creationYear") || fieldName.contains("approvalYear") || fieldName.contains("draftYear")){
			if(criterion.getStringValues().size() > 0){
				for(String val:criterion.getStringValues()){
					if(val.contains("-")) {
						isMonthPresent = true;
						break;
					}
				}
			}
		}
		String modifiedFieldName=fieldName;
		if(isMonthPresent){
			if(fieldName.contains("creationYear")) {
				if (StringUtils.contains(fieldName, ".")) {
					modifiedFieldName = "segments.creationDateMonth";
				} else {
					modifiedFieldName = "creationDateMonth";
				}
			}
			else if(fieldName.contains("approvalYear")){
				if (StringUtils.contains(fieldName, ".")) {
					modifiedFieldName = "project.approvalYearMonth";
				} else {
					modifiedFieldName = "approvalYearMonth";
				}
			}
			else {
				if (StringUtils.contains(fieldName, ".")) {
					modifiedFieldName = "project.draftYearMonth";
				} else {
					modifiedFieldName = "draftYearMonth";
				}
			}
		}

		Expression<?> exp = JpaQueryUtil.getFieldExpression(modifiedFieldName, root);
		Class<?> javaType = exp.getJavaType();

		if (javaType == String.class) {
			@SuppressWarnings("unchecked")
			Expression<String> expAsString = (Expression<String>) exp;
			return SearchUtil.createStringPredicate(criterion, builder, expAsString);
		} else if (exp.getJavaType().isEnum()) {
			return SearchUtil.createEnumPredicate(criterion, builder, exp);
		} else if (exp.getJavaType() == Double.class) {
			@SuppressWarnings("unchecked")
			Expression<Double> expAsDouble = (Expression<Double>) exp;
			return SearchUtil.createNumberOperatorPredicate(criterion.getDoubleValues(),
					NumberOperatorEnum.fromCode(criterion.getOperator()), builder, expAsDouble);
		} else if (exp.getJavaType() == Integer.class) {
			@SuppressWarnings("unchecked")
			Expression<Integer> expAsInt = (Expression<Integer>) exp;
			List<Integer> criterionIntValues = criterion.getIntValues().stream() //
					.map(Long::intValue).collect(Collectors.toList());
			return SearchUtil.createNumberOperatorPredicate(criterionIntValues,
					NumberOperatorEnum.fromCode(criterion.getOperator()), builder, expAsInt);
		} else if (exp.getJavaType() == Long.class) {
			@SuppressWarnings("unchecked")
			Expression<Long> expAsLong = (Expression<Long>) exp;
			return SearchUtil.createNumberOperatorPredicate(criterion.getIntValues(),
					NumberOperatorEnum.fromCode(criterion.getOperator()), builder, expAsLong);
		} else if (exp.getJavaType() == LocalDate.class) {
			@SuppressWarnings("unchecked")
			Expression<LocalDate> expAsLocalDate = (Expression<LocalDate>) exp;
			List<LocalDate> dateList = criterion.getDateValues() == null ? null
					: criterion.getDateValues().stream().map(v -> LocalDate.parse(v)).collect(Collectors.toList());
			return SearchUtil.createNumberOperatorPredicate(dateList,
					NumberOperatorEnum.fromCode(criterion.getOperator()), builder, expAsLocalDate);
		} else if (exp.getJavaType() == boolean.class) {
			return SearchUtil.createBooleanPredicate(criterion, builder, exp);
		}

		throw new IllegalArgumentException("Unsupported data type '" + javaType.getSimpleName() + "'!");
	}

	public static <Y extends Comparable<? super Y>> Predicate createNumberOperatorPredicate(List<Y> values,
			NumberOperatorEnum op, CriteriaBuilder builder, Expression<? extends Y> exp) {

		if (NumberOperatorEnum.IS_NULL.equals(op)) {
			return builder.isNull(exp);
		}
		if (NumberOperatorEnum.IS_NOT_NULL.equals(op)) {
			return builder.isNotNull(exp);
		}

		SearchUtil.checkIfEmpty(values);
		SearchUtil.checkForNullValue(values);

		if (NumberOperatorEnum.BETWEEN.equals(op) || NumberOperatorEnum.IN.equals(op)) {
			if (NumberOperatorEnum.BETWEEN.equals(op)) {
				if (values.size() != 2) {
					throw new IllegalArgumentException("Between operator needs two values!");
				}
				Y compareValue1 = values.get(0);
				Y compareValue2 = values.get(1);
				return builder.between(exp, compareValue1, compareValue2);
			} else if (NumberOperatorEnum.IN.equals(op)) {
				In<Y> inClause = builder.in(exp);
				for (Y value : values) {
					inClause.value(value);
				}
				return inClause;
			}
		} else {
			Y compareValue = values.get(0);
			if (NumberOperatorEnum.EQUALS.equals(op)) {
				return builder.equal(exp, compareValue);
			} else if (NumberOperatorEnum.NOT_EQUALS.equals(op)) {
				return builder.notEqual(exp, compareValue);
			} else if (NumberOperatorEnum.GREATER.equals(op)) {
				return builder.greaterThan(exp, compareValue);
			} else if (NumberOperatorEnum.GREATER_OR_EQUAL.equals(op)) {
				return builder.greaterThanOrEqualTo(exp, compareValue);
			} else if (NumberOperatorEnum.LESS.equals(op)) {
				return builder.lessThan(exp, compareValue);
			} else if (NumberOperatorEnum.LESS_OR_EQUAL.equals(op)) {
				return builder.lessThanOrEqualTo(exp, compareValue);
			}
		}
		throw new IllegalArgumentException("Unsupported operator '" + op.code() + "' for '"
				+ values.get(0).getClass().getSimpleName() + "' properties!");
	}

	public static Predicate createStringPredicate(SearchCriterion criterion, CriteriaBuilder builder,
			Expression<String> exp) {
		TextOperatorEnum op = TextOperatorEnum.fromCode(criterion.getOperator());
		if (TextOperatorEnum.IS_NULL.equals(op)) {
			return builder.isNull(exp);
		}

		checkIfEmpty(criterion.getStringValues());
		checkForNullValue(criterion.getStringValues());

		boolean ignoreCase = criterion.getOperatorOptions() != null
				&& criterion.getOperatorOptions().contains("ignoreCase");
		if (ignoreCase) {
			exp = builder.lower(exp);
		}
		if (TextOperatorEnum.IN.equals(op)) {
			@SuppressWarnings("unchecked")
			List<String> textValues = getValues(criterion, String.class);
			In<String> inClause = builder.in(exp);
			for (String textValue : textValues) {
				if (ignoreCase) {
					inClause.value(textValue.toLowerCase());
				} else {
					inClause.value(textValue);
				}
			}
			return inClause;
		}

		String searchText = (String) getSingleValue(criterion, String.class);
		if (ignoreCase) {
			searchText = searchText.toLowerCase();
		}
		if (TextOperatorEnum.EQUALS.equals(op)) {
			return builder.equal(exp, searchText);
		} else if (TextOperatorEnum.CONTAINS.equals(op)) {
			return builder.like(exp, "%" + searchText + "%");
		}
		throw new IllegalArgumentException(
				"Unsupported operator '" + criterion.getOperator() + "' for string properties!");
	}

	public static Predicate createBooleanPredicate(SearchCriterion criterion, CriteriaBuilder builder,
			Expression<?> exp) {
		TextOperatorEnum op = TextOperatorEnum.fromCode(criterion.getOperator());
		if (TextOperatorEnum.IS_NULL.equals(op)) {
			return builder.isNull(exp);
		}

		SearchUtil.checkIfEmpty(criterion.getStringValues());
		SearchUtil.checkForNullValue(criterion.getStringValues());

		if (TextOperatorEnum.IN.equals(op)) {
			List<String> textValues = criterion.getStringValues();
			List<Object> enumValues = textValues.stream().map(v -> getAsBoolean(v)).collect(Collectors.toList());
			return exp.in(enumValues);
		} else if (TextOperatorEnum.EQUALS.equals(op)) {
			String searchText = (String) getSingleValue(criterion, String.class);
			boolean searchEnum = getAsBoolean(searchText);
			return builder.equal(exp, searchEnum);
		}
		throw new IllegalArgumentException(
				"Unsupported operator '" + criterion.getOperator() + "' for enum properties!");
	}

	public static Predicate createEnumPredicate(SearchCriterion criterion, CriteriaBuilder builder, Expression<?> exp) {

		TextOperatorEnum op = TextOperatorEnum.fromCode(criterion.getOperator());
		if (TextOperatorEnum.IS_NULL.equals(op)) {
			return builder.isNull(exp);
		}

		SearchUtil.checkIfEmpty(criterion.getStringValues());
		SearchUtil.checkForNullValue(criterion.getStringValues());

		if (TextOperatorEnum.IN.equals(op)) {
			List<String> textValues = criterion.getStringValues();
			List<Object> enumValues = textValues.stream().map(v -> getAsEnum(exp, v)).collect(Collectors.toList());
			return exp.in(enumValues);
		} else if (TextOperatorEnum.EQUALS.equals(op)) {
			String searchText = (String) getSingleValue(criterion, String.class);
			Enum<?> searchEnum = getAsEnum(exp, searchText);
			return builder.equal(exp, searchEnum);
		}
		throw new IllegalArgumentException(
				"Unsupported operator '" + criterion.getOperator() + "' for enum properties!");
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Enum<?> getAsEnum(Expression<?> exp, String value) {
		System.out.println(exp.getJavaType().getCanonicalName());
		for (Class<?> i : exp.getJavaType().getInterfaces()) {
			if (i == CodeEnum.class) {
				Enum<?> codeEnumValue = CodeEnum.fromCode(value, (Class) exp.getJavaType());
				System.out.println(codeEnumValue);
				return codeEnumValue;
			}
		}
		Enum<?> enumValue = Enum.valueOf((Class<Enum>) exp.getJavaType(), value);
		return enumValue;
	}

	public static boolean getAsBoolean(String value) {
		List<String> ALLOWED_BOOLEAN_STRINGS = Arrays.asList("true", "false", "yes", "no");
		boolean isValid = false;
		for (String allowed : ALLOWED_BOOLEAN_STRINGS) {
			if (allowed.equalsIgnoreCase(value)) {
				isValid = true;
				break;
			}
		}
		if (!isValid) {
			throw new IllegalArgumentException("Unsupported boolean text value!");
		}

		return "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value) ? true : false;
	}

	public static void checkIfEmpty(@SuppressWarnings("rawtypes") List values) {
		if (values == null || values.isEmpty()) {
			throw new IllegalArgumentException("Search value missing!");
		}
	}

	public static void checkForNullValue(@SuppressWarnings("rawtypes") List values) {
		for (Object value : values) {
			if (value == null) {
				throw new IllegalArgumentException("Search value may not be null!");
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public static List getValues(SearchCriterion criterion, Class clazz) {
		if (clazz.equals(String.class))
			return criterion.getStringValues();
		else if (clazz.equals(Integer.class))
			return criterion.getIntValues();
		else if (clazz.equals(Double.class))
			return criterion.getDoubleValues();
		else if (clazz.equals(OffsetDateTime.class))
			return criterion.getDateValues();
		else
			throw new IllegalArgumentException("Unsupported data type '" + clazz.getSimpleName() + "'!");
	}

	public static boolean hasRawStringValues(SearchCriterion criterion) {
		return criterion.getStringValues().get(0) instanceof String;
	}

	public static Object getSingleValue(SearchCriterion criterion, @SuppressWarnings("rawtypes") Class clazz) {
		@SuppressWarnings("rawtypes")
		List values = getValues(criterion, clazz);
		int size = values.size();
		if (size == 1) {
			return values.get(0);
		} else {
			throw new IllegalArgumentException("Exactly one search value expected!");
		}
	}

	@SuppressWarnings("unchecked")
	public static <T extends Object> T convertTo(Class<T> clazz, Object value) {
		if (value == null) {
			return null;
		}
		if (!clazz.equals(value.getClass())) {
			throw new IllegalArgumentException("Data type does not match!");
		}
		return (T) value;
	}

}
