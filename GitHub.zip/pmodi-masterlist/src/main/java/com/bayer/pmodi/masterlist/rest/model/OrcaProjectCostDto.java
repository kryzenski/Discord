package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.OrcaProjectCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class OrcaProjectCostDto extends OrcaProjectCostEditableFieldsDto {

	public static OrcaProjectCostDto from(OrcaProjectCost src) {
		OrcaProjectCostDto result = new OrcaProjectCostDto();
		OrcaProjectCostEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(OrcaProjectCost src, OrcaProjectCostDto result) {
		result.setId(src.getId());
	}

	@NotNull
	private Long id;

}