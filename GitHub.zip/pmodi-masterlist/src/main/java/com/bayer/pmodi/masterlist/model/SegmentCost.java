package com.bayer.pmodi.masterlist.model;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class SegmentCost extends AbstractVersionedEntity {

	@NotNull
	@Column(nullable = false)
	private String year;

	@Column(nullable = true)
	private Double agronomicDevelopment;

	@Column(nullable = true)
	private Double environmentalSafety;

	@Column(nullable = true)
	private Double formulationTechnology;

	@Column(nullable = true)
	private Double productSupply;

	@Column(nullable = true)
	private Double launchMarketing;

	@Column(nullable = true)
	private Double regulatoryAffairs;

	@Column(nullable = true)
	private Double registrationFees;

	@Column(nullable = true)
	private Double research;

	@Column(nullable = true)
	private Double humanSafety;

	@Column(nullable = true)
	private Double otherCosts;

	@Column(nullable = true)
	private Double totalProjectCosts;

	@Column(nullable = true)
	private Double fieldDevelopment;

	@Column(nullable = true)
	private Double customerAdvisory;

	@Column(nullable = true)
	private Double rocsEnvironmentalResearch;

	@NotNull
	@Column(nullable = false)
	private OffsetDateTime lastModifiedOn;

	@PrePersist
	@PreUpdate
	public void calculateDependentScores() {
		setLastModifiedOn(OffsetDateTime.now());
	}

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "SEGMENT_ID", referencedColumnName = "ID", nullable = false)
	private Segment segment;

}