package com.bayer.pmodi.masterlist.profile;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.fluttercode.datafactory.impl.DataFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bayer.pmodi.masterlist.model.ActiveIngrediant;
import com.bayer.pmodi.masterlist.model.ActiveIngrediant2Product;
import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.CropGroup;
import com.bayer.pmodi.masterlist.model.CropPlatform;
import com.bayer.pmodi.masterlist.model.DomainUtil;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.ProjectComment;
import com.bayer.pmodi.masterlist.model.ProjectQuestion;
import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SegmentComment;
import com.bayer.pmodi.masterlist.model.SegmentCost;
import com.bayer.pmodi.masterlist.model.SegmentQuestion;
import com.bayer.pmodi.masterlist.model.SegmentQuestionDefinition;
import com.bayer.pmodi.masterlist.model.SubRegion;
import com.bayer.pmodi.masterlist.model.enums.CostCenterEnum;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.bayer.pmodi.masterlist.repository.ActiveIngrediant2ProductRepository;
import com.bayer.pmodi.masterlist.repository.ActiveIngrediantRepository;
import com.bayer.pmodi.masterlist.repository.CountryRepository;
import com.bayer.pmodi.masterlist.repository.CropGroupRepository;
import com.bayer.pmodi.masterlist.repository.CropPlatformRepository;
import com.bayer.pmodi.masterlist.repository.CropRepository;
import com.bayer.pmodi.masterlist.repository.ProductRepository;
import com.bayer.pmodi.masterlist.repository.ProjectCommentRepository;
import com.bayer.pmodi.masterlist.repository.ProjectQuestionDefinitionRepository;
import com.bayer.pmodi.masterlist.repository.ProjectQuestionRepository;
import com.bayer.pmodi.masterlist.repository.ProjectRepository;
import com.bayer.pmodi.masterlist.repository.RegionRepository;
import com.bayer.pmodi.masterlist.repository.SegmentCommentRepository;
import com.bayer.pmodi.masterlist.repository.SegmentCostRepository;
import com.bayer.pmodi.masterlist.repository.SegmentQuestionDefinitionRepository;
import com.bayer.pmodi.masterlist.repository.SegmentQuestionRepository;
import com.bayer.pmodi.masterlist.repository.SegmentRepository;
import com.bayer.pmodi.masterlist.repository.SubRegionRepository;

import lombok.extern.java.Log;

@Log
@Component
@Transactional
@Profile({ "mock" })
public class MockDataLoader implements CommandLineRunner {

//	private static final String COST_TYPE_TOTAL_DEVELOPMENT = "Total Development";

	private static final DateTimeFormatter DATE_TEXT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	/**
	 * If false the same random data is created every run because of using the same
	 * seed. May be useful when stable data is needed.
	 */
	private static final boolean RANDOMIZE = true;

	private static DataFactory df = createDataFactory();

//	private static final List<Object[]> COST_AND_LOCATION_TYPES = createCostData();

	private static final List<String> ROLE_SUFFIXES = Arrays.asList("EMEA", "NA", "APAC", "LATAM");

	private static final List<String> PROJECT_CATEGORIES = Arrays.asList("Formulation Development",
			"New Formulation Proof of Concept", "Country Extension", "Label Extension", "Third Party",
			"New Active Substance Developments");

	private static final List<String> PROJECT_STATES = Arrays.asList("Draft", "Proposal", "Freeze", "In Progress",
			"Launched", "Under Assessment", "Cancelled", "Deleted");

	private static final String DEFAULT_CWID = "ENUFB";

	private HashMap<String, String> cwidToUserMap = new HashMap<>();
	private HashMap<String, String> targetMap = new HashMap<>();

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CropPlatformRepository cropPlatformRepository;

	@Autowired
	private CropGroupRepository cropGroupRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private ActiveIngrediantRepository activeIngrediantRepository;

	@Autowired
	private ActiveIngrediant2ProductRepository activeIngrediant2ProductRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectCommentRepository projectCommentRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@Autowired
	private SegmentCommentRepository segmentCommentRepository;

	@Autowired
	private SegmentCostRepository segmentCostRepository;

	@Autowired
	private ProjectQuestionDefinitionRepository projectQuestionDefinitionRepository;

	@Autowired
	private ProjectQuestionRepository projectQuestionRepository;

	@Autowired
	private SegmentQuestionDefinitionRepository segmentQuestionDefinitionRepository;

	@Autowired
	private SegmentQuestionRepository segmentQuestionRepository;

	private static DataFactory createDataFactory() {
		DataFactory result = new DataFactory();
		if (RANDOMIZE) {
			result.randomize((int) System.currentTimeMillis());
		}
		return result;
	}

//	private static List<Object[]> createCostData() {
//		List<Object[]> costAndLocationTypes = new ArrayList<>();
//		costAndLocationTypes.add(new Object[] { "Formulation Technology", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Regulatory Affairs", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Registration Fees", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Human Safety", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Environmental Safety", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Field Development", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Customer Advisory", LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { COST_TYPE_TOTAL_DEVELOPMENT, LocationTypeEnum.REGIONAL });
//		costAndLocationTypes.add(new Object[] { "Agronomic Development", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Environmental Safety", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Formulation Technology", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Regulatory Affairs", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Registration Fees", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Human Safety", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { "Other Costs", LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { COST_TYPE_TOTAL_DEVELOPMENT, LocationTypeEnum.GLOBAL });
//		costAndLocationTypes.add(new Object[] { COST_TYPE_TOTAL_DEVELOPMENT, null });
//		return costAndLocationTypes;
//	}

	@Override
	public void run(String... args) throws Exception {
		log.info("Starting mock data creation...");

		List<Region> regions = IntStream.range(0, df.getNumberBetween(5, 10)).mapToObj(i -> mockRegion(i + 1))
				.collect(Collectors.toList());
		regionRepository.saveAll(regions);

		List<SubRegion> subRegions = IntStream.range(0, df.getNumberBetween(5, 10)).mapToObj(i -> mockSubRegion(i + 1))
				.collect(Collectors.toList());
		subRegionRepository.saveAll(subRegions);

		List<Country> countries = IntStream.range(0, df.getNumberBetween(10, 100)).mapToObj(i -> mockCountry(i + 1))
				.collect(Collectors.toList());
		countryRepository.saveAll(countries);

		List<String> regprimeCountries = IntStream.range(0, df.getNumberBetween(50, 200))
				.mapToObj(i -> mockRegprimeCountry(i + 1)).collect(Collectors.toList());

		List<String> regprimeCrops = IntStream.range(0, df.getNumberBetween(20, 40))
				.mapToObj(i -> mockRegprimeCrop(i + 1)).collect(Collectors.toList());

		List<String> regprimePlts = IntStream.range(0, df.getNumberBetween(20, 40))
				.mapToObj(i -> mockRegprimePlt(i + 1)).collect(Collectors.toList());

		List<CropPlatform> cropPlatforms = IntStream.range(0, df.getNumberBetween(5, 20))
				.mapToObj(i -> mockCropPlatform(i + 1)).collect(Collectors.toList());
		cropPlatformRepository.saveAll(cropPlatforms);

		List<CropGroup> cropGroups = IntStream.range(0, df.getNumberBetween(4, 10) * cropPlatforms.size())
				.mapToObj(i -> mockCropGroup(i + 1, cropPlatforms)).collect(Collectors.toList());
		cropGroupRepository.saveAll(cropGroups);

		List<Crop> crops = IntStream.range(0, df.getNumberBetween(5, 50) * cropGroups.size())
				.mapToObj(i -> mockCrop(i + 1, cropGroups)).collect(Collectors.toList());
		cropRepository.saveAll(crops);

		List<ActiveIngrediant> ingrediants = IntStream.range(0, df.getNumberBetween(20, 100))
				.mapToObj(i -> mockActiveIngrediant(i + 1)).collect(Collectors.toList());
		activeIngrediantRepository.saveAll(ingrediants);

		List<Product> products = IntStream.range(0, df.getNumberBetween(500, 2000)).mapToObj(i -> mockProduct(i + 1))
				.collect(Collectors.toList());
		productRepository.saveAll(products);

		List<ActiveIngrediant2Product> productIngrediants = new ArrayList<>(20 * products.size());
		for (Product product : products) {
			productIngrediants.addAll(createActiveIngrediantProducts(product, ingrediants));
		}
		activeIngrediant2ProductRepository.saveAll(productIngrediants);

		List<Project> projects = IntStream.range(0, df.getNumberBetween(100, 1000))
				.mapToObj(i -> mockProject(i + 1, products)).collect(Collectors.toList());
		projectRepository.saveAll(projects);

		// Add comments to only a few projects (but always to the first project)
		List<ProjectComment> projectComments = new ArrayList<>(100);
		for (int j = 0; j < 10; j++) {
			Project p = j == 0 ? projects.get(0) : projects.get(df.getNumberBetween(1, projects.size() - 1));
			List<ProjectComment> newComments = IntStream.range(0, df.getNumberBetween(5, 10))
					.mapToObj(i -> mockProjectComment(i + 1, p)).collect(Collectors.toList());
			projectComments.addAll(newComments);
		}
		projectCommentRepository.saveAll(projectComments);

		List<ProjectQuestionDefinition> projectQuestionDefinitions = IntStream.range(0, df.getNumberBetween(6, 30))
				.mapToObj(i -> mockProjectQuestionDefinition(i + 1)).collect(Collectors.toList());
		projectQuestionDefinitionRepository.saveAll(projectQuestionDefinitions);

		// Add questions to only a few projects (but always to the first project)
		List<ProjectQuestion> projectQuestions = new ArrayList<>(100);
		for (int j = 0; j < 10; j++) {
			Project p = j == 0 ? projects.get(0) : projects.get(j * (projects.size() - 1) / 10);
			projectQuestions.addAll(createProjectQuestions(p, projectQuestionDefinitions));
		}
		projectQuestionRepository.saveAll(projectQuestions);

		List<Segment> segments = new ArrayList<>(10 * projects.size());
		for (Project p : projects) {
			List<Segment> projectSegments = IntStream
					.range(0, df.getNumberBetween(1, 10)).mapToObj(i -> mockSegment(i + 1, p, countries, subRegions,
							regions, crops, regprimeCountries, regprimeCrops, regprimePlts))
					.collect(Collectors.toList());
			segments.addAll(projectSegments);
		}
		segmentRepository.saveAll(segments);

		List<SegmentComment> segmentComments = new ArrayList<>(10);
		for (int j = 0; j < 10; j++) {
			Segment s = j == 0 ? segments.get(0) : segments.get(df.getNumberBetween(1, segments.size() - 1));
			List<SegmentComment> newComments = IntStream.range(0, df.getNumberBetween(5, 100))
					.mapToObj(i -> mockSegmentComment(i + 1, s)).collect(Collectors.toList());
			segmentComments.addAll(newComments);
		}
		segmentCommentRepository.saveAll(segmentComments);

		List<SegmentQuestionDefinition> segmentQuestionDefinitions = IntStream.range(0, df.getNumberBetween(6, 30))
				.mapToObj(i -> mockSegmentQuestionDefinition(i + 1)).collect(Collectors.toList());
		segmentQuestionDefinitionRepository.saveAll(segmentQuestionDefinitions);

		// Add questions to only a few segment (but always to the first)
		List<SegmentQuestion> segmentQuestions = new ArrayList<>(100);
		for (int j = 0; j < 10; j++) {
			Segment s = j == 0 ? segments.get(0) : segments.get(j * (segments.size() - 1) / 10);
			segmentQuestions.addAll(createSegmentQuestions(s, segmentQuestionDefinitions));
		}
		segmentQuestionRepository.saveAll(segmentQuestions);

		List<SegmentCost> segmentCosts = new ArrayList<>(300);
		for (int j = 0; j < segments.size(); j++) {
			if (j == 0 || df.chance(20)) {
				Segment s = segments.get(j);
				List<SegmentCost> newCosts = mockSegmentCosts(s);
				segmentCosts.addAll(newCosts);
			}
		}
		segmentCostRepository.saveAll(segmentCosts);

		log.info("End of mock data creation!");
	}

	private Region mockRegion(int i) {
		Region r = new Region();
		r.setSourceKey(StringUtils.leftPad(String.valueOf(i), 2, '0'));
		r.setName("Region " + StringUtils.leftPad(String.valueOf(i), 2, '0'));
		r.setPlaceholder(df.chance(20));
		if (df.chance(75)) {
			r.setRoleSuffix(df.getItem(ROLE_SUFFIXES));
		}
		return r;
	}

	private SubRegion mockSubRegion(int i) {
		SubRegion sr = new SubRegion();
		sr.setSourceKey(StringUtils.leftPad(String.valueOf(i), 3, '0'));
		sr.setName("Sub-Region " + StringUtils.leftPad(String.valueOf(i), 2, '0'));
		sr.setPlaceholder(df.chance(20));
		return sr;
	}

	private Country mockCountry(int i) {
		Country c = new Country();
		c.setSourceKey(StringUtils.leftPad(String.valueOf(i), 3, '0'));
		c.setName("Country " + i);
		c.setPlaceholder(df.chance(20));
		return c;
	}

	private CropPlatform mockCropPlatform(int i) {
		CropPlatform cp = new CropPlatform();
		cp.setName("Crop Platform " + i);
		cp.setSourceKey("CPLT" + StringUtils.leftPad(String.valueOf(i), 4, '0'));
		return cp;
	}

	private CropGroup mockCropGroup(int i, List<CropPlatform> platforms) {
		CropPlatform parent = df.getItem(platforms);
		CropGroup c = new CropGroup();
		c.setName("Crop Group " + i + " (of " + parent.getName() + ")");
		c.setSourceKey("CGRP" + StringUtils.leftPad(String.valueOf(i), 4, '0'));
		c.setCropPlatform(parent);
		return c;
	}

	private Crop mockCrop(int i, List<CropGroup> groups) {
		Crop c = new Crop();
		c.setName("Crop " + i);
		c.setSourceKey("CROP" + StringUtils.leftPad(String.valueOf(i), 4, '0'));
		c.setCropGroup(df.getItem(groups));
		c.setPlaceholder(df.chance(20));
		if (!c.isPlaceholder() && df.chance(80)) {
			c.setUri("http://pid.bayer.com/kos/k00000004/crop/" + i);
		}
		return c;
	}

	private String mockRegprimeCountry(int i) {
		return "REGPRIME COUNTRY " + StringUtils.leftPad(String.valueOf(i), 4, '0');
	}

	private String mockRegprimeCrop(int i) {
		return "REGPRIME CROP " + StringUtils.leftPad(String.valueOf(i), 4, '0');
	}

	private String mockRegprimePlt(int i) {
		return "108XXXXX" + StringUtils.leftPad(String.valueOf(i), 4, '0');
	}

	private Product mockProduct(int i) {
		Product p = new Product();
		p.setBrandName(randomText(df.getNumberBetween(2, 6)));
		p.setSpecNumber("108" + StringUtils.leftPad(String.valueOf(i), 7, '0'));
		p.setProductLineText("Product Line " + i + " - " + df.getRandomWord().toUpperCase());
		return p;
	}

	private ActiveIngrediant mockActiveIngrediant(int i) {
		ActiveIngrediant a = new ActiveIngrediant();
		a.setCode(i + "-" + df.getNumberText(6) + " " + df.getNumberBetween(1, 1000));
		a.setMolName("MOL " + a.getCode());
		a.setEhsSpecNumber("EHS " + a.getCode());
		return a;
	}

	private List<ActiveIngrediant2Product> createActiveIngrediantProducts(Product product,
			List<ActiveIngrediant> ingrediants) {
		int count = df.getNumberBetween(1, 20);
		List<ActiveIngrediant2Product> results = new ArrayList<>(count);
		boolean hasLead = true; // always one lead
		boolean isLeadSet = false;
		for (int j = 0; j < count; j++) {
			ActiveIngrediant2Product a = new ActiveIngrediant2Product();
			a.setProduct(product);
			a.setActiveIngrediant(df.getItem(ingrediants));
			if (hasLead && !isLeadSet) {
				if (j == count - 1) {
					a.setLead(true);
				} else {
					a.setLead(df.chance(30));
					if (a.isLead()) {
						isLeadSet = true;
					}
				}
			}
			results.add(a);
		}
		return results;
	}

	private ProjectQuestionDefinition mockProjectQuestionDefinition(int i) {
		ProjectQuestionDefinition d = new ProjectQuestionDefinition();
		d.setActive(true);
		d.setDtype(df.getItem(ModuleTypeEnum.values()));
		d.setQuestionText("Why " + randomText(df.getNumberBetween(3, 20)) + "?");
		d.setPos(i);
		return d;
	}

	private List<ProjectQuestion> createProjectQuestions(Project project, List<ProjectQuestionDefinition> definitions) {
		int count = definitions.size();
		List<ProjectQuestion> results = new ArrayList<>(count);
		for (ProjectQuestionDefinition questionDefinition : definitions) {
			ProjectQuestion a = new ProjectQuestion();
			a.setProject(project);
			a.setProjectQuestionDefinition(questionDefinition);
			a.setAnswer(df.chance(50));
			results.add(a);
		}
		return results;
	}

	private SegmentQuestionDefinition mockSegmentQuestionDefinition(int i) {
		SegmentQuestionDefinition d = new SegmentQuestionDefinition();
		d.setActive(true);
		d.setDtype(df.getItem(ModuleTypeEnum.values()));
		d.setQuestionText("What " + randomText(df.getNumberBetween(3, 20)) + "?");
		d.setPos(i);
		return d;
	}

	private List<SegmentQuestion> createSegmentQuestions(Segment segment, List<SegmentQuestionDefinition> definitions) {
		int count = definitions.size();
		List<SegmentQuestion> results = new ArrayList<>(count);
		for (SegmentQuestionDefinition questionDefinition : definitions) {
			SegmentQuestion a = new SegmentQuestion();
			a.setSegment(segment);
			a.setSegmentQuestionDefinition(questionDefinition);
			a.setAnswer(df.chance(50));
			results.add(a);
		}
		return results;
	}

	private Project mockProject(int i, List<Product> products) {
		Project p = new Project();
		p.setTechResponsability("FT Monheim");
		p.setTechStatus("FT-work not started");
		p.setTechRecommendation("Continue POC");

		p.setSolObjective("test solution objective");
		p.setSolResult("test solution result");
		p.setSolRecommendation("Continue POC");

		p.setScienceRecommendation("Continue POC");
		p.setNewportProjectId(String.valueOf(20000 + i));
		p.setNewportAreaId("A");
		p.setNewportNewPortNumber("000" + p.getNewportProjectId() + df.getNumberText(2));
		p.setPreciseNewportId(DomainUtil.createPreciseNewportId(p.getNewportAreaId(), p.getNewportNewPortNumber()));

		boolean hasMinimum = i != 1 && df.chance(25);
		if (hasMinimum) {
			return p;
		}

		p.setProduct(df.getItem(products));

		p.setDevelopmentFunctions(randomText(df.getNumberBetween(2, 10)));
		p.setGlobalPortfolioGuidance(randomText(df.getNumberBetween(2, 10)));
		p.setGlobalRegGuidance(randomText(df.getNumberBetween(2, 10)));
		p.setSpecificProjectFramework("Specific Project Framework " + randomText(df.getNumberBetween(2, 6)));
		p.setIntelectualPropertyAssessment("IP " + randomText(df.getNumberBetween(2, 5)));
		p.setLabelForSafeUse(randomText(df.getNumberBetween(2, 10)));
		p.setThirdPartyAiRegCheck("3rd party " + randomText(df.getNumberBetween(2, 6)));
		p.setLumosGlobalProjectId("Lumos Global Project Id " + df.getNumberText(12));
		p.setLumosLocalProjectId("Lumos Local Project Id " + df.getNumberText(12));
		p.setPrioritizationRmk(StringUtils.truncate(randomText(df.getNumberBetween(0, 20)), 60));
		p.setPrioritizationGovernance(df.getItem(LocationTypeEnum.values()));
		p.setPrioritizationType(df.getItem(PrioritizationTypeEnum.values()));
		p.setRsGovernance(randomText(df.getNumberBetween(0, 3)));
		p.setRsPtrsScoreRmk(randomText(df.getNumberBetween(0, 20)));
		p.setStrategicFitRmk("Strategic " + randomText(df.getNumberBetween(2, 5)));

		boolean hasNewportData = i == 1 || df.chance(75);
		if (hasNewportData) {
			p.setNewportArea("Aachen");
			p.setNewportBusinessGroupId(df.getRandomChars(2));
			p.setNewportBusinessGroup(p.getNewportBusinessGroupId() + "x" + df.getRandomText(2, 37));
			p.setNewportBusinessUnitId(df.getRandomChars(2));
			p.setNewportBusinessUnit(p.getNewportBusinessUnitId() + "x" + df.getRandomText(2, 37));
			p.setNewportBusinessSegmentId(df.getRandomChars(3));
			p.setNewportBusinessSegment(p.getNewportBusinessSegmentId() + "x" + df.getRandomText(2, 17));
			p.setNewportBusinessObjectiveNumber("BO " + df.getNumberBetween(1000, 9999999));
			p.setNewportCategory(df.getItem(PROJECT_CATEGORIES));
			p.setNewportCategoryId(p.getNewportCategory().substring(0, 2));
			p.setNewportConcentrationUnitId(df.getNumberText(1));
			p.setNewportConcentrationUnit("Concentration " + p.getNewportConcentrationUnitId());
			p.setNewportCurrency(getRandomCurrency());
			p.setNewportFormulationTypeId(df.getRandomText(1, 3));
			p.setNewportFormulationType("Formulation " + p.getNewportFormulationTypeId());
			p.setNewportFrameworkId(df.getRandomText(1, 2));
			p.setNewportFramework("Framework " + p.getNewportFrameworkId());
			p.setNewportFreeText("Free Project " + randomText(df.getNumberBetween(2, 10)));
			p.setNewportFundingId(df.getNumberText(1));
			p.setNewportFunding("Funding " + p.getNewportFundingId());
			p.setNewportIndicationId(df.getRandomChars(2).toUpperCase());
			p.setNewportIndication("Indication " + p.getNewportIndicationId());
			p.setNewportInitiatorId(mockCwid());
			p.setNewportInitiator(getUserNameFromCwid(p.getNewportInitiatorId()));
			p.setNewportIsGbo(df.chance(50) ? "No" : "Yes");
			p.setNewportIsGboId(p.getNewportIsGbo().substring(0, 1));
			p.setNewportLastModifiedUserCwid(mockCwid());
			p.setNewportLastModifiedUser(getUserNameFromCwid(p.getNewportLastModifiedUserCwid()));
			p.setNewportLastModified(getDateText());
			p.setNewportProjectApprovalDate(getDateText());
			p.setNewportLaunchYear(String.valueOf(df.getNumberBetween(1980, 2030)));
			p.setNewportLeadAi(df.getRandomChars(3).toUpperCase());
			p.setNewportName("Project " + i);
			p.setNewportOriginId(df.getRandomChars(1).toUpperCase());
			p.setNewportOrigin("Origin " + p.getNewportOriginId());
			p.setNewportPlt("Newport PLT is " + StringUtils.truncate(randomText(df.getNumberBetween(5, 20)), 165));
			p.setNewportPrioritizationCategory(p.getPrioritizationGovernance().name().substring(0, 1));
			p.setNewportPrioritizationCommentB(p.getPrioritizationRmk());
			p.setNewportPrioritizationRankingB(p.getPrioritizationType().name().substring(0, 1));
			p.setNewportProductHierarchy(df.getRandomText(3, 18));
			p.setNewportProjectCreated(getDateText());
			p.setNewportPtrs(String.valueOf(df.getNumberUpTo(100)));
			p.setNewportSpg("Newport SPG is " + StringUtils.truncate(randomText(df.getNumberBetween(3, 10)), 45));
			p.setNewportStatus(df.getItem(PROJECT_STATES));
			p.setNewportStatusId(
					"Deleted".equalsIgnoreCase(p.getNewportStatus()) ? "X" : p.getNewportStatus().substring(0, 1));
			boolean hasNewportLongObjectiveTexts = i == 1 || df.chance(30);
			if (hasNewportLongObjectiveTexts) {
				p.setNewportJustification("Jusitified by " + randomText(df.getNumberBetween(3, 50)));
				p.setNewportObjective("Main objective is: " + randomText(df.getNumberBetween(3, 50)));
				p.setNewportProductProfile("Profile " + randomText(df.getNumberBetween(3, 50)));
				p.setNewportSuccessFactors("Success by " + randomText(df.getNumberBetween(3, 50)));
			}
			boolean hasNewportNumbers = i == 1 || df.chance(75);
			if (hasNewportNumbers) {
				p.setNewportGlobalAggregatedVolume(getDouble(10, 2));
				p.setNewportGlobalExpectedNpvYear10(getDouble(10, 2));
				p.setNewportGlobalFutureProjectCost(getDouble(10, 2));
				p.setNewportGlobalIgmPeakYear(getDouble(10, 2));
				p.setNewportGlobalIgmYear4(getDouble(10, 2));
				p.setNewportGlobalIncrementalIgmYear4(getDouble(4, 2));
				p.setNewportGlobalIncrementalNetSales(getDouble(4, 2));
				p.setNewportGlobalNetSales(getDouble(10, 2));
				p.setNewportGlobalNpvYear10(getDouble(10, 2));
				p.setNewportGlobalPeakNetSales(getDouble(10, 2));
				p.setNewportGlobalPeakNetSalesIncremental(getDouble(4, 2));
				p.setNewportGlobalPeakYearIgmIncremental(getDouble(4, 2));
				p.setNewportGlobalPercIgmYear4(getDouble(10, 2));
				p.setNewportGlobalProductivityIndex(getDouble(4, 2));
				p.setNewportGlobalSalesVolume(getDouble(10, 2));

				p.setNewportLocalExpectedNpvYear10(getDouble(10, 2));
				p.setNewportLocalNpvYear10(getDouble(10, 2));
				p.setNewportLocalPeakNetSales(getDouble(10, 2));
				p.setNewportLocalPeakNetSalesIncremental(getDouble(4, 2));
				p.setNewportLocalPeakYearIgm(getDouble(10, 2));
				p.setNewportLocalPeakYearIgmIncremental(getDouble(4, 2));
				p.setNewportLocalPeakYearIgmPercNetSales(getDouble(10, 2));
			}
		}
		boolean hasScores = i == 1 || df.chance(25);
		if (hasScores) {
			p.setFsPtrsScoreRmk(getScoreComment("FS Ptrs Score Remark "));
			p.setFsPtrsScore(getScore());
			p.setFtPtrsScoreRmk(getScoreComment("FT Ptrs Score Remark "));
			p.setFtPtrsScore(getScore());
			p.setRsDietaryPtrsScore(getScore());
			p.setRsDietaryPtrsScoreRmk(getScoreComment("RS Dietary Safety Ptrs Score Remark "));
			p.setRsEnsaPtrsScore(getScore());
			p.setRsEnsaPtrsScoreRmk(getScoreComment("RS Ensa Ptrs Score Remark "));
			p.setRsOperatorPtrsScore(getScore());
			p.setRsOperatorPtrsScoreRmk(getScoreComment("RS Operator Risk Ptrs Score Remark "));
			if (i == 1 || df.chance(50)) {
				p.setRsRegAffairsScore(getScore());
				p.setRsRegAffairsScoreRmk(getScoreComment("RS Regulatory Affairs Score Remark "));
			}
			// Attention: the following properties are calculated
			// p.setOverallPtrsScore(getScore());
			// p.setRsPtrsScore(getScore());
		}

		return p;
	}

	private String getUserNameFromCwid(String cwid) {
		if (cwidToUserMap.containsKey(cwid)) {
			return cwidToUserMap.get(cwid);
		}
		String name = StringUtils.truncate(df.getName(), 52) + " (" + cwid + ")";
		cwidToUserMap.put(cwid, name);
		return name;
	}

	private String getTargetFromId(String id) {
		if (targetMap.containsKey(id)) {
			return targetMap.get(id);
		}
		String name = "Target: " + id;
		targetMap.put(id, name);
		return name;
	}

	private String getRandomCurrency() {
//		int i = df.getNumberBetween(1, 7);
//		if (i == 1) {
		return "EUR"; // NewPort has converted all currency values to Euro
//		} else if (i == 2) {
//			return "USD";
//		} else if (i == 3) {
//			return "AUD"; // Australian Dollar
//		} else if (i == 4) {
//			return "GBP"; // Great Britain Pound
//		} else if (i == 5) {
//			return "JPY"; // Japan Yen
//		} else if (i == 6) {
//			return "CNY"; // China Yuan/Renminbi
//		} else {
//			return "CHF"; // Switzerland Franc
//		}
	}

	private ProjectComment mockProjectComment(int i, Project project) {
		ProjectComment p = new ProjectComment();
		p.setDtype(df.getItem(ModuleTypeEnum.values()));
		p.setProject(project);
		p.setText(randomText(df.getNumberBetween(5, 2000)));
		p.setTimestamp(getTimestampWithTimezone());
		p.setUser(mockCwid());
		return p;
	}

	private Segment mockSegment(int i, Project project, List<Country> countries, List<SubRegion> subRegions,
			List<Region> regions, List<Crop> crops, List<String> regprimeCountries, List<String> regprimeCrops,
			List<String> regprimePlts) {
		Segment s = new Segment();
		s.setProject(project);
		// Country, sub region, region, crop, target and cost center are a combined
		// domain key
		s.setCountry(df.getItem(countries));
		// Attention: there is no relation between county and region i.e. region may be
		// asia but the country from europe
		s.setSubRegion(df.getItem(subRegions));
		s.setRegion(df.getItem(regions));
		s.setCrop(df.getItem(crops));
		s.setNewportDiseasesPestsWeedsId(df.getRandomChars(8).toUpperCase());
		s.setTarget(getTargetFromId(s.getNewportDiseasesPestsWeedsId()));
		s.setCostCenter(CostCenterEnum.LOCAL);

		boolean isFullyFilled = "20001".equals(project.getNewportProjectId()) && i == 1;
		boolean hasMinimum = !isFullyFilled && df.chance(25);
		if (hasMinimum) {
			return s;
		}

		s.setPrioritizationRmk(randomText(df.getNumberBetween(0, 20)));
		s.setPrioritizationGovernance(df.getItem(LocationTypeEnum.values()));
		s.setPrioritizationType(df.getItem(PrioritizationTypeEnum.values()));
		s.setQuickscanAssessmentId(null);
		s.setRegprimeZNumber(null);
		s.setRegprimeSequenceNumber(null);
		s.setRegprimeCountryCode(df.getItem(regprimeCountries, isFullyFilled ? 100 : 30));
		s.setRegprimeCropCode(df.getItem(regprimeCrops, isFullyFilled ? 100 : 30));
		s.setRegprimeProductLineNumber(df.getItem(regprimePlts, isFullyFilled ? 100 : 30));
		s.setStrategicFitRmk("Strategic " + randomText(df.getNumberBetween(2, 5)));

		boolean hasDates = isFullyFilled || df.chance(25);
		if (hasDates) {
			s.setLaunchDate(getLocalDate());
			s.setSubmissionDate(getLocalDate());
		}

		boolean hasScores = isFullyFilled || df.chance(25);
		if (hasScores) {
			s.setFsPtrsScoreRmk(getScoreComment("FS Ptrs Score Remark "));
			s.setFsPtrsScore(getScore());
			s.setRsRegPtrsScoreRmk(getScoreComment("RS Regulatory Ptrs Score Remark "));
			s.setRsRegPtrsScore(getScore());
			// Attention: the following property is calculated
			// s.setPtrsSegmentOverallScore(getScore());
		}

		boolean hasNewportNumbers = isFullyFilled || df.chance(75);
		if (hasNewportNumbers) {
			s.setNewportPtrs("ptr");
			s.setNewportLaunchYearCountry(String.valueOf(df.getNumberBetween(1990, 2030)));
			s.setNewportLaunchYearSegment(String.valueOf(df.getNumberBetween(1990, 2030)));
			s.setNewportLaunchYearNetSales(String.valueOf(df.getNumberBetween(1990, 2030)));
			s.setNewportSubmissionYear(String.valueOf(df.getNumberBetween(1990, 2030)));
			s.setNewportIsLaunched(df.chance(50) ? "N" : "Y");
			s.setNewportWeightUnit(df.getRandomChars(3));
			s.setNewportCurrency(getRandomCurrency());
			s.setNewportGlobalNpvYear10(getDouble(10, 2));
			s.setNewportGlobalExpectedNpvYear10(getDouble(10, 2));
			s.setNewportGlobalNetSales(getDouble(10, 2));
			s.setNewportGlobalPeakNetSales(getDouble(10, 2));
			s.setNewportGlobalPeakNetSalesYear(df.getNumberBetween(2030, 2040));
			s.setNewportGlobalPeakYearIgmPercNetSales(getDouble(10, 2));
			s.setNewportGlobalIgmPercYear4(getDouble(10, 2));
			s.setNewportGlobalIgmYear4(getDouble(10, 2));
			s.setNewportGlobalIgmPeakYear(getDouble(10, 2));
			s.setNewportGlobalFutureProjectCost(getDouble(10, 2));
			s.setNewportGlobalProductivityIndex(getDouble(10, 2));
			s.setNewportGlobalIncrementalNetSales(getDouble(10, 2));
			s.setNewportGlobalPeakNetSalesIncremental(getDouble(10, 2));
			s.setNewportGlobalIncrementalIgmYear4(getDouble(10, 2));
			s.setNewportGlobalPeakYearIgmIncremental(getDouble(10, 2));
			s.setNewportGlobalPaybackYear(df.getNumberBetween(2020, 2050));
			s.setNewportGlobalPaybackTime(getDouble(5, 3));
			s.setNewportGlobalSalesVolume(getDouble(10, 2));
			s.setNewportGlobalAggregatedVolume(getDouble(10, 2));
			s.setNewportLocalNpvYear10(getDouble(10, 2));
			s.setNewportLocalExpectedNpvYear10(getDouble(10, 2));
			s.setNewportLocalPaybackTime(getDouble(5, 3));
			s.setNewportLocalPeakNetSales(getDouble(10, 2));
			s.setNewportLocalPeakNetSalesYear(df.getNumberBetween(2020, 2050));
			s.setNewportLocalPeakYearIgmPercNetSales(getDouble(10, 2));
			s.setNewportLocalPeakYearIgm(getDouble(10, 2));
			s.setNewportLocalPeakNetSalesIncremental(getDouble(10, 2));
			s.setNewportLocalPeakYearIgmIncremental(getDouble(10, 2));
		}

		return s;
	}

	private SegmentComment mockSegmentComment(int i, Segment segment) {
		SegmentComment s = new SegmentComment();
		s.setDtype(df.getItem(ModuleTypeEnum.values()));
		s.setSegment(segment);
		s.setText(randomText(df.getNumberBetween(5, 2000)));
		s.setTimestamp(getTimestampWithTimezone());
		s.setUser(mockCwid());
		return s;
	}

	private String mockCwid() {
		if (df.chance(50)) {
			return DEFAULT_CWID;
		}
		return df.getRandomChars(5).toUpperCase();
	}

	private List<SegmentCost> mockSegmentCosts(Segment segment) {
		List<SegmentCost> results = new ArrayList<>();
		for (int year = 2019; year < 2037; year++) {
			if (df.chance(30)) {
				SegmentCost s = new SegmentCost();
				s.setYear(String.valueOf(year));
				s.setSegment(segment);
				if (df.chance(50)) {
					s.setAgronomicDevelopment(getDouble(6, 2));
					s.setCustomerAdvisory(getDouble(6, 2));
					s.setEnvironmentalSafety(getDouble(6, 2));
					s.setFieldDevelopment(getDouble(6, 2));
					s.setFormulationTechnology(getDouble(6, 2));
				}
				if (df.chance(50)) {
					s.setHumanSafety(getDouble(6, 2));
					s.setLaunchMarketing(getDouble(6, 2));
					s.setOtherCosts(getDouble(6, 2));
					s.setProductSupply(getDouble(6, 2));
				}
				if (df.chance(50)) {
					s.setRegistrationFees(getDouble(6, 2));
					s.setRegulatoryAffairs(getDouble(6, 2));
					s.setResearch(getDouble(6, 2));
					s.setRocsEnvironmentalResearch(getDouble(6, 2));
					s.setTotalProjectCosts(getDouble(6, 2));
				}
				results.add(s);
			}
		}
		return results;
	}

	private static String randomText(int wordCount) {
		if (wordCount < 1) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		for (int n = 0; n < wordCount; n++) {
			if (n > 0) {
				sb.append(" ");
			}
			sb.append(df.getRandomWord());
		}
		return sb.toString();
	}

	// private static String getUniqueText(int max, String prefix, int
	// runningNumber) {
	// String uniquePart = max < 20 ? String.valueOf(runningNumber)
	// : StringUtils.leftPad(String.valueOf(runningNumber), 4, '0');
	// String usedPrefix = StringUtils.left(prefix, max - uniquePart.length());
	// return usedPrefix + uniquePart;
	// }

	private static String getScoreComment(String prefix) {
		return prefix + randomText(df.getNumberBetween(1, 20));
	}

	private static Double getScore() {
		if (df.chance(20)) {
			return Double.valueOf(1.0);
		}
		return Double.valueOf("0." + df.getNumberUpTo(9999));
	}

	private Double getDouble(int maxLeadingDigits, int fixedDecimalPlaces) {
		StringBuffer sb = new StringBuffer();
		sb.append(df.getNumberBetween(1, 9));
		if (maxLeadingDigits > 1) {
			if (maxLeadingDigits > 2) {
				int leadingDigits = df.getNumberBetween(2, maxLeadingDigits);
				sb.append(df.getNumberText(leadingDigits - 1));
			} else {
				if (df.chance(50)) {
					sb.append(df.getNumberText(1));
				}
			}
		}
		sb.append(".");
		if (fixedDecimalPlaces > 0) {
			sb.append(df.getNumberText(fixedDecimalPlaces));
		} else {
			sb.append("0");
		}
		return Double.valueOf(sb.toString());
	}

	private OffsetDateTime getTimestampWithTimezone() {
		@SuppressWarnings("deprecation")
		Date d = df.getDateBetween(new Date(100, 1, 1, 0, 0, 0), new Date());
		return OffsetDateTime.ofInstant(d.toInstant(), ZoneId.systemDefault()).withOffsetSameLocal(ZoneOffset.UTC)
				.withHour(0).withMinute(0).withSecond(0);
	}

	private LocalDate getLocalDate() {
		LocalDate ld = LocalDate.of(df.getNumberBetween(2000, 2020), df.getNumberBetween(1, 12),
				df.getNumberBetween(1, 28));
		return ld;
	}

	private String getDateText() {
		return getLocalDate().format(DATE_TEXT_FORMATTER);
	}

}
