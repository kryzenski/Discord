package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table(name = "ACTIVE_INGREDIANT_2_PRODUCT")
@ToString
@EqualsAndHashCode
public class ActiveIngrediant2Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	// @Version
	// @Column(nullable = false)
	// private Integer version = null;

	@Column(nullable = false)
	private boolean isLead;

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "PRODUCT_ID", referencedColumnName = "ID", nullable = false)
	private Product product;

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "ACTIVE_INGREDIANT_ID", referencedColumnName = "ID", nullable = false)
	private ActiveIngrediant activeIngrediant;

}