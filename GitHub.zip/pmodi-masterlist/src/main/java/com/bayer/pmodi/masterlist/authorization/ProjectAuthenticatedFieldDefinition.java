package com.bayer.pmodi.masterlist.authorization;

import com.bayer.pmodi.masterlist.model.Project;

public class ProjectAuthenticatedFieldDefinition extends AbstractAuthenticatedFieldDefinition {

	private static AuthenticatedFieldDefinition instance = new ProjectAuthenticatedFieldDefinition();

	public static AuthenticatedFieldDefinition getInstance() {
		return instance;
	}

	@Override
	protected Class<?> getCheckedClass() {
		return Project.class;
	}

	@Override
	protected boolean isRelevantGroup(String group) {
		return Groups.isProjectGroup(group);
	}

}
