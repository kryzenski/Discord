package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Crop;

public interface CropRepository extends BaseRepository<Crop> {

	Crop findByNameAndCropGroupNameAndCropGroupCropPlatformName(String name, String cropGroupName,
			String cropPlatformName);

	Crop findBySourceKeyAndCropGroupSourceKeyAndCropGroupCropPlatformSourceKey(String sourceKey,
			String cropGroupSourceKey, String cropPlatformSourceKey);

	Page<Crop> findByCropGroupId(Long id, Pageable page);

}
