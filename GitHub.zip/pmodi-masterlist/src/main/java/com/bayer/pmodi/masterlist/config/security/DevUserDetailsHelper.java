package com.bayer.pmodi.masterlist.config.security;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("!sso")
public class DevUserDetailsHelper implements UserDetailsHelper {

	public static final String DEFAULT_DUMMY_USER = "ENUFB";

	@Value("${spring.precise.security.user:ENUFB}")
	private String currentDummyUser = DEFAULT_DUMMY_USER;

	@Value("${spring.precise.security.roles:#{null}}")
	private String[] currentDummyRoles = null;

	@Override
	public Object getCurrentUserClaim(String claimKey) {
		if (UNIQUE_IDENTIFIER_NAME.equals(claimKey)) {
			return getCurrentUserId();
		} else if ("name".equals(claimKey)) {
			return "Name of '" + getCurrentUserId() + "'";
		} else if (ROLES.equals(claimKey)) {
			return getCurrentUserRoles();
		}
		return null;
	}

	@Override
	public String getCurrentUserId() {
		return currentDummyUser;
	}

	@Override
	public List<String> getCurrentUserRoles() {
		if (currentDummyRoles == null) {
			return Collections.emptyList();
		}
		return Arrays.asList(currentDummyRoles);
	}

}