package com.bayer.pmodi.masterlist.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

import com.bayer.pmodi.masterlist.audit.CustomRevisionListener;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "REVINFO")
@Data
@EqualsAndHashCode(callSuper = false)
@RevisionEntity(CustomRevisionListener.class)
public class EntityRevision extends DefaultRevisionEntity {

	private static final long serialVersionUID = 1L;

	private String modifiedBy;

}