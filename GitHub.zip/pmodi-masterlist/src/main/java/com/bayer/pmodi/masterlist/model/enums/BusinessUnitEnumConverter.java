package com.bayer.pmodi.masterlist.model.enums;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class BusinessUnitEnumConverter implements AttributeConverter<BusinessUnitEnum, String> {

	@Override
	public String convertToDatabaseColumn(BusinessUnitEnum enumWithCode) {
		if (enumWithCode == null) {
			return null;
		}
		return enumWithCode.code();
	}

	@Override
	public BusinessUnitEnum convertToEntityAttribute(String code) {
		return BusinessUnitEnum.fromCode(code);
	}

}