package com.bayer.pmodi.masterlist.model.enums;

public enum CostCenterEnum {

	GLOBAL, //
	REGIONAL, //
	LOCAL;

}
