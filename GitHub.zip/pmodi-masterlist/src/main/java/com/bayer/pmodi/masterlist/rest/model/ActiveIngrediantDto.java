package com.bayer.pmodi.masterlist.rest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class ActiveIngrediantDto {

	private Long id;
	private String code;
	private String molName;
	private String ehsSpecNumber;

}