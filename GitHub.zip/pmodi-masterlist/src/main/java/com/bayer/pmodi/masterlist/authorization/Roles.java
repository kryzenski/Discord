package com.bayer.pmodi.masterlist.authorization;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Roles {

	public static final String ROLE_SUPER_ADMIN = "SuperAdmin";

	public static final String ROLE_GLOBAL_ADMIN = "GlobalAdmin";
	public static final String ROLE_GLOBAL_MARKETING = "GlobalMarketing";
	public static final String ROLE_GLOBAL_DEVELOPMENT = "GlobalDevelopment";

	public static final String ROLE_PREFIX_REGIONAL_ADMIN = "RegionalAdmin";
	public static final String ROLE_PREFIX_REGIONAL_MARKETING = "RegionalMarketing";
	public static final String ROLE_PREFIX_REGIONAL_DEVELOPMENT = "RegionalDevelopment";

	public static final String ROLE_ORCA = "ORCA";

	private Roles() {
		// No instance allowed
	}

	/**
	 * Get complete role names for the given combination of region suffix and
	 * regional role prefix e.g. regions "EMEA" and "LATAM" and role prefix
	 * "RegionalAdmin" would result in roles "RegionalAdminEMEA" and
	 * "RegionalAdminLATAM".
	 * 
	 * @param regionRoleSuffixes Collection of role suffixes (defined in regions);
	 *                           optional
	 * @param role               Role prefix or regional roles; optional (but prefix
	 *                           itself is not checked)
	 * @return Array of roles; never null (but may be empty)
	 */
	public static String[] getPossibleRegionalRoles(Collection<String> regionRoleSuffixes, String... role) {
		Set<String> possibleRoles = new HashSet<>();
		if (regionRoleSuffixes != null && role != null) {
			for (String suffix : regionRoleSuffixes) {
				for (String r : role) {
					String completeRoleName = r + suffix;
					possibleRoles.add(completeRoleName);
				}
			}
		}
		return possibleRoles.toArray(new String[0]);
	}

}
