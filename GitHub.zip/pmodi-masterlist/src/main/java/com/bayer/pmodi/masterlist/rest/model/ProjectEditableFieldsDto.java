package com.bayer.pmodi.masterlist.rest.model;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.EntityWithPrioritization;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.bayer.pmodi.masterlist.repository.ProductRepository;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;
import java.time.LocalDate;

/**
 * This class contains all properties of a project which are allowed to be
 * updated i.e. no primary or foreign keys.
 */
@Data
@ToString
@EqualsAndHashCode
public class ProjectEditableFieldsDto implements EntityWithPrioritization {

	public static ProjectEditableFieldsDto from(Project src) {
		ProjectEditableFieldsDto result = new ProjectEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Project src, ProjectEditableFieldsDto target) {
		BeanUtils.copyProperties(src, target);
		target.setProduct(DtoUtil.toIdDisplayNameDto(src.getProduct()));
	}

	public void applyUpdateablePropertiesTo(Project target, ProductRepository productRepository) {
		BeanUtils.copyProperties(this, target);

		if (this.getProduct() != null && this.getProduct().getId() != null) {
			if (target.getProduct() == null || !this.getProduct().getId().equals(target.getProduct().getId())) {
				Product product = productRepository.getOne(this.getProduct().getId());
				target.setProduct(product);
			}
		} else {
			if (target.getProduct() != null) {
				target.setProduct(null);
			}
		}
	}

    private String techResponsability;

	private String techStatus;

	private String techRecommendation;

	private String techRecommendationModifiedDate;

	private String techRecommendationModifiedBy;

	private String solObjective;

	private String solResult;

	private String solRecommendation;

	private String solRecommendationModifiedDate;

	private String solRecommendationModifiedBy;

	private String scienceRecommendation;

	private String scienceRecommendationModifiedDate;

	private String scienceRecommendationModifiedBy;

	private IdDisplayNameDto product;

	private String fsPtrsScoreRmk;

	private Double fsPtrsScore;

	private String ftPtrsScoreRmk;

	private Double ftPtrsScore;

	private String lumosGlobalProjectId;

	private String lumosLocalProjectId;

	private String preciseNewportId;

	private Double overallPtrsScore;

	private Double rsEnsaPtrsScore;

	private String rsEnsaPtrsScoreRmk;

	private Double rsDietaryPtrsScore;

	private String rsDietaryPtrsScoreRmk;

	private Double rsOperatorPtrsScore;

	private String rsOperatorPtrsScoreRmk;

	private Double rsRegAffairsScore;

	private String rsRegAffairsScoreRmk;

	private Double rsPtrsScore;

	private String sustainabilityAssessment;

	private String rsPtrsScoreRmk;

	private PrioritizationTypeEnum prioritizationType;

	private String prioritizationRmk;

	private LocationTypeEnum prioritizationGovernance;

	private String rsGovernance;

	private String globalPortfolioGuidance;

	private String globalRegGuidance;

	private String specificProjectFramework;

	private String labelForSafeUse;

	private String thirdPartyAiRegCheck;

	private String developmentFunctions;

	private String intelectualPropertyAssessment;

	private String strategicFitRmk;

	private String newportProjectId;

	private String newportSpg;

	private String newportPlt;

	private String newportFreeText;

	private String newportName;

	private String newportLeadAi;

	private String newportCategoryId;

	private String newportCategory;

	private String newportBusinessObjectiveNumber;

	private String newportBusinessGroupId;

	private String newportBusinessGroup;

	private String newportBusinessUnitId;

	private String newportBusinessUnit;

	private String newportBusinessSegmentId;

	private String newportBusinessSegment;

	private String newportConcentrationUnitId;

	private String newportConcentrationUnit;

	private String newportProjectCreated;

	private String newportInitiatorId;

	private String newportInitiator;

	private String newportIndicationId;

	private String newportIndication;

	private String newportFormulationTypeId;

	private String newportFormulationType;

	private String newportFrameworkId;

	private String newportFramework;

	private String newportFundingId;

	private String newportFunding;

	private String newportIsGboId;

	private String newportIsGbo;

	private String newportAreaId;

	private String newportArea;

	private String newportNewPortNumber;

	private String newportOriginId;

	private String newportOrigin;

	private String newportProductHierarchy;

	private String newportLaunchYear;

	private String newportStatusId;

	private String newportStatus;

	private String newportPtrs;

	private String newportLastModified;

	private String newportLastModifiedUserCwid;

	private String newportLastModifiedUser;

	private String newportPrioritizationCategory;

	private String newportPrioritizationRankingB;

	private String newportPrioritizationCommentB;

	private String newportCurrency;

	private Double newportGlobalNpvYear10;

	private Double newportGlobalNetSales;

	private Double newportGlobalPeakNetSales;

	private Double newportGlobalIgmYear4;

	private Double newportGlobalIgmPeakYear;

	private Double newportGlobalFutureProjectCost;

	private Double newportGlobalIncrementalNetSales;

	private Double newportGlobalPeakNetSalesIncremental;

	private Double newportGlobalIncrementalIgmYear4;

	private Double newportGlobalPeakYearIgmIncremental;

	private Double newportGlobalSalesVolume;

	private Double newportGlobalAggregatedVolume;

	private Double newportLocalNpvYear10;

	private Double newportLocalPeakNetSales;

	private Double newportLocalPeakYearIgm;

	private Double newportLocalPeakNetSalesIncremental;

	private Double newportLocalPeakYearIgmIncremental;

	private Double newportGlobalExpectedNpvYear10;

	private Double newportGlobalPercIgmYear4;

	private Double newportGlobalProductivityIndex;

	private Double newportLocalExpectedNpvYear10;

	private Double newportLocalPeakYearIgmPercNetSales;

	private String newportObjective;

	private String newportSuccessFactors;

	private String newportProductProfile;

	private String newportJustification;

	private boolean ptrsFollowUp;

	private String fsPtrsScoreModifiedBy;

	private String fsPtrsScoreModifiedDate;

	private String fsPtrsScoreUpdatedBy;

	private String fsPtrsScoreUpdatedDate;

	private String ftPtrsScoreModifiedBy;

	private String ftPtrsScoreModifiedDate;

	private String rsEnsaPtrsScoreModifiedBy;

	private String rsEnsaPtrsScoreModifiedDate;

	private String rsOperatorPtrsScoreModifiedBy;

	private String rsOperatorPtrsScoreModifiedDate;

	private String rsDietaryPtrsScoreModifiedBy;

	private String rsDietaryPtrsScoreModifiedDate;

	private String rsRegAffairsScoreModifiedBy;

	private String rsRegAffairsScoreModifiedDate;

	private String rsPtrsScoreRmkModifiedBy;

	private  String rsPtrsScoreRmkModifiedDate;

	private LocalDate approvalDate;

	private String newportProjectApprovalDate;

	private LocalDate categoryChangedDateNFPCToFD;

	private LocalDate categoryChangedDateNASToLCM;

}
