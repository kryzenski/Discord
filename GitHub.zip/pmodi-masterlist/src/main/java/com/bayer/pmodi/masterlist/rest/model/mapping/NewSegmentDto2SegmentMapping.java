//package com.bayer.pmodi.masterlist.rest.model.mapping;
//
//import org.modelmapper.PropertyMap;
//import org.springframework.stereotype.Component;
//
//import com.bayer.pmodi.masterlist.model.Segment;
//import com.bayer.pmodi.masterlist.rest.model.NewSegmentDto;
//import com.github.jmnarloch.spring.boot.modelmapper.PropertyMapConfigurerSupport;
//
////modelMapper not used for written entities like project or segment
//@Deprecated
//@Component
//public class NewSegmentDto2SegmentMapping extends PropertyMapConfigurerSupport<NewSegmentDto, Segment> {
//
//	@Override
//	public PropertyMap<NewSegmentDto, Segment> mapping() {
//
//		return new PropertyMap<NewSegmentDto, Segment>() {
//			@Override
//			protected void configure() {
//				// Skip referenced entities to avoid creating them unintentionally
//				skip().setProject(null);
//				skip().setCountry(null);
//				skip().setCrop(null);
//				skip().setRegprimeCountry(null);
//				skip().setRegprimeCrop(null);
//				skip().setRegprimePlt(null);
//			}
//		};
//	}
//}
