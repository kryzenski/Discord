package com.bayer.pmodi.masterlist.rest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RevisionFieldValueDto {

	private String fieldName;
	private String operation;
	private Object revisionValue;

	@Override
	public String toString() {
		return fieldName + ", operation: " + operation + ", value: " + revisionValue + ".";
	}

}
