package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.SegmentComment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentCommentDto extends NewSegmentCommentDto {

	public static SegmentCommentDto from(SegmentComment src) {
		SegmentCommentDto result = new SegmentCommentDto();
		SegmentCommentEditableFieldsDto.mapOwn(src, result);
		NewSegmentCommentDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentComment src, SegmentCommentDto result) {
		result.setId(src.getId());
		result.setVersion(src.getVersion());
		result.setUser(src.getUser());
	}

	@NotNull
	private Long id;

	@NotNull
	private Integer version;

	private String user;

}