package com.bayer.pmodi.masterlist.rest.model;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RevisionInfoDto {

	private String operation;
	private int revisionId;
	private String modifiedBy;
	private Instant modifiedAt;
	private Object revisionValue;

	@Override
	public String toString() {
		return operation + " in revision " + revisionId + " by '" + modifiedBy + "' at " + modifiedAt + " using value "
				+ revisionValue + ".";
	}

}
