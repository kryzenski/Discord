package com.bayer.pmodi.masterlist.search;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@ApiModel
public class SearchCriterion {

	@ApiModelProperty(name = "fieldName", dataType = "string", required = true, example = "fsPtrsScore")
	private String fieldName;

	@ApiModelProperty(name = "operator", dataType = "string", required = true, example = "equals")
	private String operator;

	@ApiModelProperty(name = "operatorOptions", dataType = "string", example = "[\"ignoreCase\"]")
	private List<String> operatorOptions;

	@ApiModelProperty(name = "stringValues", dataType = "string")
	private List<String> stringValues;

	@ApiModelProperty(name = "dateValues", dataType = "string", value = "Date string in format: YYYY-MM-DD")
	private List<String> dateValues;

	@ApiModelProperty(name = "intValues", dataType = "Long")
	private List<Long> intValues;

	@ApiModelProperty(name = "doubleValues", dataType = "Double")
	private List<Double> doubleValues;
}
