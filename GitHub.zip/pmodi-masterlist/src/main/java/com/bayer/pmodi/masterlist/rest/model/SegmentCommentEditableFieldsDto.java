package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.SegmentComment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a segment comment which are allowed to
 * be updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString
@EqualsAndHashCode
public class SegmentCommentEditableFieldsDto {

	public static SegmentCommentEditableFieldsDto from(SegmentComment src) {
		SegmentCommentEditableFieldsDto result = new SegmentCommentEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentComment src, SegmentCommentEditableFieldsDto target) {
		target.setText(src.getText());
	}

	public void applyUpdateablePropertiesTo(SegmentComment target) {
		target.setText(getText());
	}

	private String text;

}
