package com.bayer.pmodi.masterlist.rest.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.authorization.Roles;
import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.model.OrcaProjectCost;
import com.bayer.pmodi.masterlist.repository.OrcaProjectCostRepository;
import com.bayer.pmodi.masterlist.rest.RestUtil;
import com.bayer.pmodi.masterlist.rest.model.OrcaProjectCostDto;
import com.bayer.pmodi.masterlist.rest.model.OrcaProjectCostEditableFieldsDto;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedById;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(OrcaController.ROOT_URL)
public class OrcaController {

	public static final String ROOT_URL = "/orca";

	private static final String LIST_PROJECT_COSTS = "project-costs";

	@Autowired
	private OrcaProjectCostRepository orcaProjectCostRepository;

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@Autowired
	private PermissionService permissionService;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		checkOrcaControllerAllowed();
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get all project costs. Pageable and sortable.")
	@GetMapping(path = LIST_PROJECT_COSTS)
	@ResponseBody
	public Page<OrcaProjectCostDto> getProjectCosts(PageAndSortCriteriaSortedById pageAndSortParameters) {
		checkOrcaControllerAllowed();
		checkOrcaLock();
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<OrcaProjectCost> results = orcaProjectCostRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> OrcaProjectCostDto.from(e));
	}

	@ApiOperation(value = "Create new project costs (mandatory attributes are project name, newport id and product id).")
	@PostMapping(path = LIST_PROJECT_COSTS)
	@ResponseBody
	@Transactional
	public void createProjectCosts(
			@RequestBody @ApiParam("JSON definition of the new entities") @Valid List<OrcaProjectCostEditableFieldsDto> newCostDtos) {
		checkOrcaControllerAllowed();
		checkOrcaLock();

		List<OrcaProjectCost> newCosts = new ArrayList<>(newCostDtos.size());
		for (OrcaProjectCostEditableFieldsDto newCostDto : newCostDtos) {
			OrcaProjectCost newCost = new OrcaProjectCost();
			newCostDto.applyUpdateablePropertiesTo(newCost);
			newCosts.add(newCost);
		}

		orcaProjectCostRepository.saveAll(newCosts);
	}

	@ApiOperation(value = "Delete all project costs.")
	@DeleteMapping(path = LIST_PROJECT_COSTS)
	@Transactional
	public void deleteAllProjectCosts() {
		checkOrcaControllerAllowed();
		checkOrcaLock();
		// Use a native query to avoid loading all entities one by one
		// orcaProjectCostRepository.deleteAll();
		orcaProjectCostRepository.deleteAllCosts();
	}

	@ApiOperation(value = "Set ORCA lock.")
	@PutMapping(path = "lock")
	@Transactional
	public void lock() {
		checkOrcaControllerAllowed();
		String current = permissionService.getOrcaLockHolder();
		if (userDetailsHelper.isCurrentUser(current)) {
			// Nothing to do, lock already set correct
		} else {
			if (current != null) {
				throw new IllegalArgumentException(
						"Another user owns the ORCA lock! Please contact '" + current + "'.");
			}
			permissionService.setOrcaLockHolder(userDetailsHelper.getCurrentUserId());
		}
	}

	@ApiOperation(value = "Remove ORCA lock.")
	@PutMapping(path = "unlock")
	@Transactional
	public void unlock() {
		checkOrcaControllerAllowed();
		checkOrcaLock();
		permissionService.deleteOrcaLockHolder();
	}

	private void checkOrcaLock() {
		String current = permissionService.getOrcaLockHolder();
		if (current == null) {
			throw new IllegalArgumentException("ORCA lock not set! Please first set a lock.");
		}
		if (!userDetailsHelper.isCurrentUser(current)) {
			throw new IllegalArgumentException("Another user owns the ORCA lock! Please contact '" + current + "'.");
		}
	}

	/**
	 * Check if current user has the permission to call the Orca controller. If not
	 * an exception is thrown.
	 */
	// TODO
	private void checkOrcaControllerAllowed() {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		if (roles != null && (roles.contains(Roles.ROLE_ORCA) || roles.contains(Roles.ROLE_SUPER_ADMIN))) {
			return; // allowed
		}
		throw new PmodiForbiddenException("Orca access not allowed for the current user.");
	}

}
