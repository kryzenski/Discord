package com.bayer.pmodi.masterlist.rest.model.newport;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SegmentCost;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class ProjectCostDto {

	/**
	 * Create DTO from the given entity.
	 * 
	 * @param segmentCost Source; mandatory (but not checked)
	 * @return DTO
	 */
	public static ProjectCostDto from(SegmentCost segmentCost) {
		Segment s = segmentCost.getSegment();
		ProjectCostDto dto = new ProjectCostDto(s.getId(), s.getProject().getNewportProjectId(),
				s.getRegion().getSourceKey(), s.getSubRegion().getSourceKey(), s.getCountry().getSourceKey(),
				s.getCrop().getCropGroup().getCropPlatform().getSourceKey(), s.getCrop().getCropGroup().getSourceKey(),
				s.getCrop().getSourceKey(), s.getNewportDiseasesPestsWeedsId(), String.valueOf(segmentCost.getYear()));
		BeanUtils.copyProperties(segmentCost, dto);
		return dto;
	}

	@NonNull
	private Long id;
	@NonNull
	private String newportProjectId;
	@NonNull
	private String newportRegionId;
	@NonNull
	private String newportSubRegionId;
	@NonNull
	private String newportCountryIso;
	@NonNull
	private String newportCropPlatformId;
	@NonNull
	private String newportCropGroupId;
	@NonNull
	private String newportCropId;
	@NonNull
	private String newportDiseasesPestsWeedsId;
	@NonNull
	private String year;

	private Double agronomicDevelopment;

	private Double environmentalSafety;

	private Double formulationTechnology;

	private Double productSupply;

	private Double launchMarketing;

	private Double regulatoryAffairs;

	private Double registrationFees;

	private Double research;

	private Double humanSafety;

	private Double otherCosts;

	private Double totalProjectCosts;

	private Double fieldDevelopment;

	private Double customerAdvisory;

	private Double rocsEnvironmentalResearch;

}