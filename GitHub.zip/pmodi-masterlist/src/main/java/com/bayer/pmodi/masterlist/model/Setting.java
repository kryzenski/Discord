package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@Table
@ToString
@EqualsAndHashCode
public class Setting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@Column(nullable = false)
	private String module;

	@Column(nullable = true)
	private String owner;

	@NotNull
	@Column(nullable = false)
	private String key;

	@Column(nullable = true)
	private String textValue;

	public Setting(@NotNull String module, @NotNull String key, String textValue) {
		this(module, null, key, textValue);
	}

	public Setting(@NotNull String module, String owner, @NotNull String key, String textValue) {
		this.module = module;
		this.owner = owner;
		this.key = key;
		this.textValue = textValue;
	}

}