package com.bayer.pmodi.masterlist.config.webclients;

import javax.net.ssl.SSLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.bayer.pmodi.masterlist.config.security.ExternalApiAccessHelper;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import reactor.netty.http.client.HttpClient;

@Component
@Profile("sso")
public class SsoWebClients implements WebClients {

	@Value("${external-apis.regprime.host}")
	private String regprimeHost;

	@Value("${external-apis.regprime.user}")
	private String regprimeUser;

	@Value("${external-apis.regprime.password}")
	private String regprimePassword;

	@Value("${external-apis.nautilos.host}")
	private String nautilosHost;

	@Value("${external-apis.nautilos.user}")
	private String nautilosUser;

	@Value("${external-apis.nautilos.password}")
	private String nautilosPassword;

	@Value("${external-apis.quickscan.host}")
	private String quickscanHost;

	@Value("${external-apis.quickscan.user}")
	private String quickscanUser;

	@Value("${external-apis.quickscan.password}")
	private String quickscanPassword;

	@Value("${external-apis.newport-connector.host}")
	private String newportConnectorHost;

	@Autowired
	ExternalApiAccessHelper externalApiAccessHelper;

	@Override
	public WebClient getRegprimeWebClient(String token) {
		// TcpClient tcpClient =
		// TcpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 2_000)
		// .doOnConnected(connection -> connection.addHandlerLast(new
		// ReadTimeoutHandler(2)).addHandlerLast(new WriteTimeoutHandler(2)));
		/*
		 * return WebClient.builder().baseUrl(regprimeHost) // .clientConnector(new
		 * ReactorClientHttpConnector(HttpClient.from(tcpClient)))
		 * .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
		 * .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
		 * .defaultHeaders(header -> header.setBasicAuth(regprimeUser,
		 * regprimePassword)) .defaultHeader(HttpHeaders.USER_AGENT,
		 * "I'm a coffee cup").build();
		 */
		try {
			return getTokenWebClient(regprimeHost, externalApiAccessHelper.getRegPrimeAccessToken(token), "I'm a tee cup");
		} catch (Exception e) {
			throw new IllegalStateException("Failed to get RegPrime WebClient: " + e.getMessage());
		}
	}

	@Override
	public WebClient getNautilosWebClient() {
		try {
			return getTokenWebClient(nautilosHost, externalApiAccessHelper.getNautilosAccessToken(), "I'm a tee cup");
		} catch (Exception e) {
			throw new IllegalStateException("Failed to get Nautilos WebClient: " + e.getMessage());
		}
	}

	@Override
	public WebClient getQuickscanWebClient() {
		try {
			return getTokenWebClient(quickscanHost, externalApiAccessHelper.getQuickscanAccessToken(),
					"I'm a lemonade can");
		} catch (Exception e) {
			throw new IllegalStateException("Failed to get Quickscan WebClient: " + e.getMessage());
		}
	}

	@Override
	public WebClient getNewportConnectorWebClient() {
		try {
			return getTokenWebClient(newportConnectorHost, externalApiAccessHelper.getNewportConnectorAccessToken(),
					"I'm a coffee cup");
		} catch (Exception e) {
			throw new IllegalStateException("Failed to get Newport Connector WebClient: " + e.getMessage());
		}
	}

	private WebClient getTokenWebClient(String host, String token, String userAgent) throws SSLException {
		// Disable SSL
		SslContext sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE)
				.build();
		HttpClient httpClient = reactor.netty.http.client.HttpClient.create()
				.secure(sslContextSpec -> sslContextSpec.sslContext(sslContext));
		ClientHttpConnector httpConnector = new ReactorClientHttpConnector(httpClient);

		WebClient webClient = WebClient.builder().baseUrl(host)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				.defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + token)
				.defaultHeader(HttpHeaders.USER_AGENT, userAgent).clientConnector(httpConnector).build();
		return webClient;
	}

}
