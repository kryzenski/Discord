package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class CropSearchCriteria {

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop", example = "Corn: Fodder/Forage")
	private String cropName;

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop group", example = "CORN-TRADITIONAL")
	private String cropGroupName;

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop platform", example = "Corn/Maize")
	private String cropPlatformName;

}
