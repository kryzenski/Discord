package com.bayer.pmodi.masterlist.repository;

import com.bayer.pmodi.masterlist.model.ActiveIngrediant;

public interface ActiveIngrediantRepository extends BaseRepository<ActiveIngrediant> {

	ActiveIngrediant findByCode(String code);

	ActiveIngrediant findByMolName(String molName);

}
