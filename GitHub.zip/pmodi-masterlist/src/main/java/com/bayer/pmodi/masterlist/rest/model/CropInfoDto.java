package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.Crop;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class CropInfoDto extends IdDisplayNameSourceKeyDto {

	public static CropInfoDto from(Crop src) {
		CropInfoDto result = new CropInfoDto();

		result.setId(src.getId());
		result.setDisplayName(src.getName());
		result.setSourceKey(src.getSourceKey());

		result.setCropGroupId(src.getCropGroup().getId());
		result.setCropGroupDisplayName(src.getCropGroup().getName());
		result.setCropGroupSourceKey(src.getCropGroup().getSourceKey());

		result.setCropPlatformId(src.getCropGroup().getCropPlatform().getId());
		result.setCropPlatformDisplayName(src.getCropGroup().getCropPlatform().getName());
		result.setCropPlatformSourceKey(src.getCropGroup().getCropPlatform().getSourceKey());

		return result;
	}

	private Long cropGroupId;
	private String cropGroupSourceKey;
	private String cropGroupDisplayName;

	private Long cropPlatformId;
	private String cropPlatformSourceKey;
	private String cropPlatformDisplayName;

}