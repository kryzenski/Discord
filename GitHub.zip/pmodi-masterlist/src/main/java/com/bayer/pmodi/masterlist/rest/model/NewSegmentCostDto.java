package com.bayer.pmodi.masterlist.rest.model;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.SegmentCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewSegmentCostDto extends SegmentCostUpdateDto {

	public static NewSegmentCostDto from(SegmentCost src) {
		NewSegmentCostDto result = new NewSegmentCostDto();
		SegmentCostUpdateDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentCost src, NewSegmentCostDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public static void applyKeyPropertiesTo(SegmentCost result, String year) {
		result.setYear(year);
	}

	private String year;

}