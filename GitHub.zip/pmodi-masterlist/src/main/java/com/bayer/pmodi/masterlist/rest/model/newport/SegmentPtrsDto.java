package com.bayer.pmodi.masterlist.rest.model.newport;

import com.bayer.pmodi.masterlist.model.Segment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class SegmentPtrsDto {

	/**
	 * Create DTO from the given entity.
	 * 
	 * @param segment Source; mandatory (but not checked)
	 * @return DTO
	 */
	public static SegmentPtrsDto from(Segment segment) {
		SegmentPtrsDto dto = new SegmentPtrsDto(segment.getId(), segment.getProject().getNewportProjectId(),
				segment.getRegion().getSourceKey(), segment.getSubRegion().getSourceKey(),
				segment.getCountry().getSourceKey(), segment.getCrop().getCropGroup().getCropPlatform().getSourceKey(),
				segment.getCrop().getCropGroup().getSourceKey(), segment.getCrop().getSourceKey(),
				segment.getNewportDiseasesPestsWeedsId(), segment.getPtrsSegmentOverallScore());
		return dto;
	}

	@NonNull
	private Long id;
	@NonNull
	private String newportProjectId;
	@NonNull
	private String newportRegionId;
	@NonNull
	private String newportSubRegionId;
	@NonNull
	private String newportCountryIso;
	@NonNull
	private String newportCropPlatformId;
	@NonNull
	private String newportCropGroupId;
	@NonNull
	private String newportCropId;
	@NonNull
	private String newportDiseasesPestsWeedsId;

	private Double overallPtrsScore;

}