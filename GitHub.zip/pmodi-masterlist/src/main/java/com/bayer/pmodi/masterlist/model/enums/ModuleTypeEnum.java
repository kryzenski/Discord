package com.bayer.pmodi.masterlist.model.enums;

public enum ModuleTypeEnum {

	PRIO, //
	OVERALL, //
	PTRS;

}
