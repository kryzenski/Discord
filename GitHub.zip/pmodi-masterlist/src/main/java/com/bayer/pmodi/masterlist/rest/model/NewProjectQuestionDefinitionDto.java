package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewProjectQuestionDefinitionDto extends ProjectQuestionDefinitionEditableFieldsDto {

	public static NewProjectQuestionDefinitionDto from(ProjectQuestionDefinition src) {
		NewProjectQuestionDefinitionDto result = new NewProjectQuestionDefinitionDto();
		ProjectQuestionDefinitionEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(ProjectQuestionDefinition src, NewProjectQuestionDefinitionDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public static void applyKeyPropertiesTo(ProjectQuestionDefinition result, ModuleTypeEnum dtype) {
		result.setDtype(dtype);
	}

	@NotNull
	private ModuleTypeEnum dtype;

}