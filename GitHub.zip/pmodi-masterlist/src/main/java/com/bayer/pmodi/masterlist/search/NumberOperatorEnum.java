package com.bayer.pmodi.masterlist.search;

import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.bayer.pmodi.masterlist.model.enums.CodeEnum;

public enum NumberOperatorEnum implements CodeEnum<NumberOperatorEnum> {

	EQUALS("equals", "equals"), //
	NOT_EQUALS("notEquals", "not equals"), //
	IS_NULL("isNull", "is null"), //
	IS_NOT_NULL("isNotNull", "is not null"), //
	GREATER_OR_EQUAL("greaterThanOrEqualTo", "greater than or equal to"), //
	LESS_OR_EQUAL("lessThanOrEqualTo", "less than or equal to"), //
	GREATER("greaterThan", "greater than"), //
	LESS("lessThan", "less than"), //
	BETWEEN("between", "between"), //
	IN("in", "in");

	private String label;
	private String code;
	private static Map<String, NumberOperatorEnum> CODE_MAP = new LinkedHashMap<String, NumberOperatorEnum>();

	static {
		for (NumberOperatorEnum e : EnumSet.allOf(NumberOperatorEnum.class)) {
			CODE_MAP.put(e.code(), e);
		}
	}

	/**
	 * Constructor.
	 * 
	 * @param code  The code
	 * @param label The display label
	 */
	NumberOperatorEnum(final String code, final String label) {
		this.code = code;
		this.label = label;
	}

	/**
	 * @return The code
	 */
	@Override
	public String code() {
		return this.code;
	}

	/**
	 * @return The display label
	 */
	@Override
	public String label() {
		return this.label;
	}

	/**
	 * Returns enumeration value for the given database code
	 * 
	 * @param code The code
	 * @return the enumeration or null if code is null
	 * @throws IllegalArgumentException if code is invalid
	 */
	public static NumberOperatorEnum fromCode(final String code) {
		if (code == null) {
			return null;
		}
		NumberOperatorEnum en = CODE_MAP.get(code);
		if (en == null) {
			throw new IllegalArgumentException("code \"" + code + "\" does not exist in domain");
		}
		return en;
	}

	/**
	 * Returns the set of all valid database codes
	 * 
	 * @return all codes
	 */
	public static Set<String> codes() {
		return Collections.unmodifiableSet(CODE_MAP.keySet());
	}

}
