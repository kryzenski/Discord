package com.bayer.pmodi.masterlist.rest;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriBuilder;

import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteria;

public final class RestUtil {

	/** Only defines the return type */
	@SuppressWarnings("serial")
	public static class TypedMap extends LinkedHashMap<String, Object> {
	};

	private RestUtil() {
		// No instance allowed
	}

	/**
	 * Create a {@link Sort} entity from the given values.
	 * 
	 * @param sortBy  Name of the fields used for sorting the results, comma
	 *                separated; optional (but then null is returned)
	 * @param sortDir Sorting direction, either ASC or DESC; optional (but then the
	 *                default is used)
	 * @return New Sort entity or null (if no sorting takes place)
	 */
	public static Sort createSort(String sortBy, String sortDir) {
		if (StringUtils.isEmpty(sortBy)) {
			return Sort.unsorted();
		}

		Optional<Direction> parsedDir = Direction.fromOptionalString(sortDir);
		Direction dir = parsedDir.isPresent() ? parsedDir.get() : Direction.ASC;

		String[] sortByParts = null;
		if (sortBy != null) {
			sortByParts = sortBy.split("[,;]");
			for (int i = 0; i < sortByParts.length; i++) {
				sortByParts[i] = sortByParts[i].trim();
			}
		}

		return Sort.by(dir, sortByParts);
	}

	/**
	 * Create a {@link PageRequest} with the given values.
	 * 
	 * @param criteria A {@link PageAndSortCriteria} with paging and sorting
	 *                 parameters
	 * @return New PageRequest; never null
	 */
	public static PageRequest createPageRequest(PageAndSortCriteria criteria) {
		return createPageRequest(criteria.getPage(), criteria.getSize(), criteria.getSortBy(), criteria.getSortDir());
	}

	/**
	 * Create a {@link PageRequest} with the given values.
	 * 
	 * @param page    The page number is an integer between 0 (first page) and
	 *                Integer.MAX_VALUE; optional (but then the first page is used)
	 * @param size    Size of a page, must be a positive number; optional (but then
	 *                Integer.MAX_VALUE is used)
	 * @param sortBy  Name of the fields used for sorting the results, comma
	 *                separated; optional (but then no sorting takes place)
	 * @param sortDir Sorting direction, either ASC or DESC; optional (but then the
	 *                default is used)
	 * @return New PageRequest; never null
	 */
	public static PageRequest createPageRequest(Integer page, Integer size, String sortBy, String sortDir) {
		int pageNumber = Optional.ofNullable(page).orElse(0).intValue();
		int pageSize = Optional.ofNullable(size).orElse(Integer.MAX_VALUE).intValue();
		if (pageNumber < 0 || pageSize < 0) {
			throw new IllegalArgumentException("Page number and size have to be positive numbers!");
		}
		return PageRequest.of(pageNumber, pageSize, createSort(sortBy, sortDir));
	}

	/**
	 * Convert entity page to DTo page.
	 * 
	 * @param entityPage Page with entity elements as content; optional (but then
	 *                   null is returned)
	 * @return Page with DTO contents (or null, but only if the given page was null)
	 */
	public static <T, P> Page<P> toDtoPage(Page<T> entityPage, Function<T, P> map) {
		if (entityPage != null) {

			List<P> content = entityPage.getContent().stream().map(e -> map.apply(e)).collect(Collectors.toList());
			Pageable pageable = PageRequest.of(entityPage.getNumber(), entityPage.getSize(), entityPage.getSort());
			Page<P> dtoPage = new PageImpl<P>(content, pageable, entityPage.getTotalElements());
			return dtoPage;
		}
		return null;
	}

	/**
	 * Get results from the given client.
	 * 
	 * @param webClient             WebClient; mandatory (but not checked)
	 * @param uri                   URI; mandatory (but not checked)
	 * @param pageAndSortParameters Page and sort parameters; optional
	 * @return Map with result entities
	 */
	public static Map<String, Object> getResults(WebClient webClient, String uri,
			PageAndSortCriteria pageAndSortParameters) {
		Map<String, Object> results = webClient.get()
				.uri(uriBuilder -> buildUri(pageAndSortParameters, uri, uriBuilder)) //
				.retrieve() //
				.bodyToMono(TypedMap.class) //
				.block();
		return results;
	}

	public static Map<String, Object> getResult(WebClient webClient, String uri, String keyName, String keyValue) {
		Map<String, Object> results = webClient.get()
				.uri(uriBuilder -> uriBuilder.path(uri).queryParam(keyName, keyValue).build()) //
				.retrieve() //
				.bodyToMono(TypedMap.class) //
				.block();
		return results;
	}

	public static Map<String, Object> getResult(WebClient webClient, String uri, MultiValueMap<String, String> params) {
		Map<String, Object> results = webClient.get()
				.uri(uriBuilder -> uriBuilder.path(uri).queryParams(params).build()) //
				.retrieve() //
				.bodyToMono(TypedMap.class) //
				.block();
		return results;
	}

	public static Map<String, Object> getResult(WebClient webClient, String uri) {
		Map<String, Object> results = webClient.get().uri(uriBuilder -> uriBuilder.path(uri).build()) //
				.retrieve() //
				.bodyToMono(TypedMap.class) //
				.block();
		return results;
	}

	static URI buildUri(PageAndSortCriteria pageAndSortParameters, String url, UriBuilder uriBuilder) {
		uriBuilder.path(url);
		if (pageAndSortParameters != null) {
			if (pageAndSortParameters.getPage() != null) {
				uriBuilder.queryParam("page", pageAndSortParameters.getPage());
			}
			if (pageAndSortParameters.getSize() != null) {
				uriBuilder.queryParam("size", pageAndSortParameters.getSize());
			}
			if (pageAndSortParameters.getSortBy() != null) {
				uriBuilder.queryParam("sortBy", pageAndSortParameters.getSortBy());
			}
			if (pageAndSortParameters.getSortDir() != null) {
				uriBuilder.queryParam("sortDir", pageAndSortParameters.getSortDir());
			}
		}
		URI uri = uriBuilder.build();
		return uri;
	}

}
