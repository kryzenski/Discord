package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class ProjectQuestionDefinitionDto {

	public static ProjectQuestionDefinitionDto from(ProjectQuestionDefinition src) {
		ProjectQuestionDefinitionDto result = new ProjectQuestionDefinitionDto();
		result.setId(src.getId());
		result.setActive(src.isActive());
		result.setDtype(src.getDtype());
		result.setQuestionText(src.getQuestionText());
		result.setPos(src.getPos());
		return result;
	}

	@NotNull
	private Long id;

	@NotNull
	private ModuleTypeEnum dtype;

	private boolean isActive;

	private String questionText;

	@NotNull
	private Integer pos;

}