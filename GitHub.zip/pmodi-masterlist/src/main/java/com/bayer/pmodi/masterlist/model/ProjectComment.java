package com.bayer.pmodi.masterlist.model;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString
@EqualsAndHashCode
public class ProjectComment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Version
	@Column(nullable = false)
	private int version = 1;

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private ModuleTypeEnum dtype;

	@NotNull
	@Column(name = "TIMESTMP", nullable = false)
	private OffsetDateTime timestamp;

	@NotNull
	@Column(name = "USR", nullable = false)
	private String user;

	@Column(nullable = true)
	private String text;

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "PROJECT_ID", referencedColumnName = "ID", nullable = false)
	private Project project;

}