package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import com.bayer.pmodi.masterlist.model.SegmentQuestionDefinition;

public interface SegmentQuestionDefinitionRepository extends BaseRepository<SegmentQuestionDefinition> {

	List<SegmentQuestionDefinition> findByIsActive(boolean isActive);

}
