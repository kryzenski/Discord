package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import com.bayer.pmodi.masterlist.model.ActiveIngrediant2Product;
import com.bayer.pmodi.masterlist.model.Product;

public interface ActiveIngrediant2ProductRepository extends BaseRepository<ActiveIngrediant2Product> {

	List<ActiveIngrediant2Product> findByProduct(Product product);

}
