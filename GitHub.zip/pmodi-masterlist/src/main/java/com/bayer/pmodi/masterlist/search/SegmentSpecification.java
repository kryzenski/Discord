package com.bayer.pmodi.masterlist.search;

import java.util.List;

import com.bayer.pmodi.masterlist.model.Segment;

public class SegmentSpecification extends AbstractSpecification<Segment> {

	private static final long serialVersionUID = 509953123800585900L;

	public SegmentSpecification() {
		super();
	}

	public SegmentSpecification(List<SearchCriterion> searchCriteria) {
		super(searchCriteria);
	}

}
