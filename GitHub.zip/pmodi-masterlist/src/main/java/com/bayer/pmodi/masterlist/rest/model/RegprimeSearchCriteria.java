package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class RegprimeSearchCriteria {

	@NotNull
	@ApiModelProperty(required = true, value = "Key of the crop used by Regprime e.g. 'BRSNW' for 'Rape, winter' or 'TRZSS' for 'Wheat'", example = "TRZSS")
	private String cropKey;

	@NotNull
	@ApiModelProperty(required = true, value = "Key of the country used by Regprime e.g. 'GBR' for 'United Kingdom' or 'DEU' for 'Germany'", example = "DEU")
	private String countryKey;

	@NotNull
	@ApiModelProperty(required = true, value = "Key of the product line used by Regprime i.e. the product line number (starting with 108)", example = "108000004711")
	private String pltKey;

}
