package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Country;

public interface CountryRepository extends BaseRepository<Country> {

	Country findByName(String name);

	Country findBySourceKey(String sourceKey);

	Page<Country> findByIsPlaceholder(boolean isPlaceholder, Pageable pageInfo);

}
