package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.search.ProjectSpecification;
import com.bayer.pmodi.masterlist.search.SearchCriterion;

public class ProjectRepositoryImpl implements CustomProjectRepository {

	@Autowired
	private EntityManager em;

	@Autowired
	private ProjectRepository projectRepository;

	@Override
	public Page<Project> search(List<SearchCriterion> searchCriteria, Pageable pageable) {
		Pageable pageInfo = pageable == null ? Pageable.unpaged() : pageable;
		if (searchCriteria == null || searchCriteria.isEmpty()) {
			return projectRepository.findAll(pageInfo);
		} else {
			ProjectSpecification spec = new ProjectSpecification(searchCriteria);
			return projectRepository.findAll(spec, pageInfo);
		}
	}

	@Override
	public List<String> findDistinctValuesStartingWith(String columnName, String valueStartsWith, Integer limit,
			boolean isCaseSensitive) {
		return JpaQueryUtil.getDistinctFieldWithValueQuery(em, Project.class, columnName,
				valueStartsWith == null ? null : valueStartsWith + "%", limit, isCaseSensitive).getResultList();
	}

}
