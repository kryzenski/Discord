package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.ProjectQuestion;
import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class ProjectQuestionDto {

	public static ProjectQuestionDto from(ProjectQuestion src) {
		ProjectQuestionDto result = new ProjectQuestionDto();
		result.setId(src.getId());
		result.setVersion(src.getVersion());
		result.setAnswer(src.isAnswer());
		ProjectQuestionDefinition def = src.getProjectQuestionDefinition();
		result.setDtype(def.getDtype());
		result.setQuestionText(def.getQuestionText());
		return result;
	}

	@NotNull
	private Long id;

	private int version;

	private boolean answer;

	@NotNull
	private ModuleTypeEnum dtype;

	@NotNull
	private String questionText;

}