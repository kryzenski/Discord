package com.bayer.pmodi.masterlist.model;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import com.bayer.pmodi.masterlist.authorization.CheckedField;
import com.bayer.pmodi.masterlist.authorization.Groups;
import com.bayer.pmodi.masterlist.authorization.Roles;
import com.bayer.pmodi.masterlist.authorization.SpecialTreatment;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class Project extends AbstractVersionedEntity implements Comparable {

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String fsPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double fsPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String ftPtrsScoreRmk;

    @Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String techResponsability;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String techStatus;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String techRecommendation;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String solObjective;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String solResult;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String solRecommendation;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String scienceRecommendation;
	
	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double ftPtrsScore;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN })
	private String lumosGlobalProjectId;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN })
	private String lumosLocalProjectId;

	@NotNull
	@Column(nullable = false)
	private String preciseNewportId;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	private Double overallPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double rsEnsaPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String rsEnsaPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double rsDietaryPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String rsDietaryPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double rsOperatorPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String rsOperatorPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private Double rsRegAffairsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String rsRegAffairsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	private Double rsPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT }, group = Groups.GROUP_PROJECT_PTRS)
	private String rsPtrsScoreRmk;

	@Column(nullable = true)
	@Enumerated(EnumType.STRING)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = {
			Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_PROJECT_PRIO, specialTreatment = SpecialTreatment.PRIORITIZATION_TYPE_BY_GOVERNANCE)
	private PrioritizationTypeEnum prioritizationType;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING,
			Roles.ROLE_PREFIX_REGIONAL_MARKETING }, group = Groups.GROUP_PROJECT_PRIO)
	private String prioritizationRmk;

	@Column(nullable = true)
	@Enumerated(EnumType.STRING)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_PROJECT_PRIO)
	private LocationTypeEnum prioritizationGovernance;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN })
	private String rsGovernance;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String globalPortfolioGuidance;


	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = {Roles.ROLE_GLOBAL_ADMIN}, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String sustainabilityAssessment; //In application it is by Sustainability Assessment

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN,
			Roles.ROLE_GLOBAL_DEVELOPMENT 
			}, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String globalRegGuidance;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN,
			Roles.ROLE_GLOBAL_DEVELOPMENT 
			}, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String specificProjectFramework;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN,
			Roles.ROLE_GLOBAL_DEVELOPMENT 
			}, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String labelForSafeUse;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN,
			Roles.ROLE_GLOBAL_DEVELOPMENT 
			}, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String thirdPartyAiRegCheck;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String developmentFunctions;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_PROJECT_GUIDANCE_IP)
	private String intelectualPropertyAssessment;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING })
	private String strategicFitRmk;

	@NotNull
	@Column(nullable = false)
	private String newportProjectId;

	@Column(nullable = true)
	private String newportSpg;

	@Column(nullable = true)
	private String newportPlt;

	@Column(nullable = true)
	private String newportFreeText;

	@Column(nullable = true)
	private String newportName;

	@Column(nullable = true)
	private String newportLeadAi;

	@Column(nullable = true)
	private String newportCategoryId;

	@Column(nullable = true)
	private String newportCategory;

	@Column(name = "NEWPORT_BUSINESS_OBJECTIVE_NUMB", nullable = true)
	private String newportBusinessObjectiveNumber;

	@Column(nullable = true)
	private String newportBusinessGroupId;

	@Column(nullable = true)
	private String newportBusinessGroup;

	@Column(nullable = true)
	private String newportBusinessUnitId;

	@Column(nullable = true)
	private String newportBusinessUnit;

	@Column(nullable = true)
	private String newportBusinessSegmentId;

	@Column(nullable = true)
	private String newportBusinessSegment;

	@Column(nullable = true)
	private String newportConcentrationUnitId;

	@Column(nullable = true)
	private String newportConcentrationUnit;

	@Column(nullable = true)
	private String newportProjectCreated;

	@Column(nullable = true)
	private String newportInitiatorId;

	@Column(nullable = true)
	private String newportInitiator;

	@Column(nullable = true)
	private String newportIndicationId;

	@Column(nullable = true)
	private String newportIndication;

	@Column(nullable = true)
	private String newportFormulationTypeId;

	@Column(nullable = true)
	private String newportFormulationType;

	@Column(nullable = true)
	private String newportFrameworkId;

	@Column(nullable = true)
	private String newportFramework;

	@Column(nullable = true)
	private String newportFundingId;

	@Column(nullable = true)
	private String newportFunding;

	@Column(nullable = true)
	private String newportIsGboId;

	@Column(nullable = true)
	private String newportIsGbo;

	@NotNull
	@Column(nullable = false)
	private String newportAreaId;

	@Column(nullable = true)
	private String newportArea;

	@NotNull
	@Column(nullable = false)
	private String newportNewPortNumber;

	@Column(nullable = true)
	private String newportOriginId;

	@Column(nullable = true)
	private String newportOrigin;

	@Column(nullable = true)
	private String newportProductHierarchy;

	@Column(nullable = true)
	private String newportLaunchYear;

	@Column(nullable = true)
	private String newportStatusId;

	@Column(nullable = true)
	private String newportStatus;

	@Column(nullable = true)
	private String newportPtrs;

	@Column(nullable = true)
	private String newportLastModified;

	@Column(nullable = true)
	private String newportLastModifiedUserCwid;

	@Column(nullable = true)
	private String newportLastModifiedUser;

	@Column(name = "NEWPORT_PRIO_CATEGORY", nullable = true)
	private String newportPrioritizationCategory;

	@Column(name = "NEWPORT_PRIO_RANKING_B", nullable = true)
	private String newportPrioritizationRankingB;

	@Column(name = "NEWPORT_PRIO_COMMENT_B", nullable = true)
	private String newportPrioritizationCommentB;

	@Column(nullable = true)
	private String newportCurrency;

	@Column(name = "NEWPORT_GLOBAL_NPV_YEAR_10", nullable = true)
	private Double newportGlobalNpvYear10;

	@Column(nullable = true)
	private Double newportGlobalNetSales;

	@Column(nullable = true)
	private Double newportGlobalPeakNetSales;

	@Column(name = "NEWPORT_GLOBAL_IGM_YEAR_4", nullable = true)
	private Double newportGlobalIgmYear4;

	@Column(nullable = true)
	private Double newportGlobalIgmPeakYear;

	@Column(name = "NEWPORT_GLOBAL_FUTURE_PRO_COST", nullable = true)
	private Double newportGlobalFutureProjectCost;

	@Column(name = "NEWPORT_GLOBAL_INC_NET_SALES", nullable = true)
	private Double newportGlobalIncrementalNetSales;

	@Column(name = "NEWPORT_GLOBAL_PEAK_NET_SALES_I", nullable = true)
	private Double newportGlobalPeakNetSalesIncremental;

	@Column(name = "NEWPORT_GLOBAL_INC_IGM_YEAR_4", nullable = true)
	private Double newportGlobalIncrementalIgmYear4;

	@Column(name = "NEWPORT_GLOBAL_PEAK_YEAR_IGM_IN", nullable = true)
	private Double newportGlobalPeakYearIgmIncremental;

	@Column(nullable = true)
	private Double newportGlobalSalesVolume;

	@Column(name = "NEWPORT_GLOBAL_AGGREGATED_VOLUM", nullable = true)
	private Double newportGlobalAggregatedVolume;

	@Column(name = "NEWPORT_LOCAL_NPV_YEAR_10", nullable = true)
	private Double newportLocalNpvYear10;

	@Column(nullable = true)
	private Double newportLocalPeakNetSales;

	@Column(nullable = true)
	private Double newportLocalPeakYearIgm;

	@Column(name = "NEWPORT_LOCAL_PEAK_NET_SALES_IN", nullable = true)
	private Double newportLocalPeakNetSalesIncremental;

	@Column(name = "NEWPORT_LOCAL_PEAK_YEAR_IGM_INC", nullable = true)
	private Double newportLocalPeakYearIgmIncremental;

	@Column(name = "NEWPORT_GLOBAL_EXP_NPV_YEAR_10", nullable = true)
	private Double newportGlobalExpectedNpvYear10;

	@Column(name = "NEWPORT_GLOBAL_PERC_IGM_YEAR_4", nullable = true)
	private Double newportGlobalPercIgmYear4;

	@Column(name = "NEWPORT_GLOBAL_PRODUCTIVITY_IND", nullable = true)
	private Double newportGlobalProductivityIndex;

	@Column(name = "NEWPORT_LOCAL_EXP_NPV_YEAR_10", nullable = true)
	private Double newportLocalExpectedNpvYear10;

	@Column(name = "NEWPORT_LOCAL_PEAK_YEAR_IGM_PER", nullable = true)
	private Double newportLocalPeakYearIgmPercNetSales;

	@Column(nullable = true)
	private String newportObjective;

	@Column(nullable = true)
	private String newportSuccessFactors;

	@Column(nullable = true)
	private String newportProductProfile;

	@Column(nullable = true)
	private String newportJustification;

	@Column(nullable = true)
	private String fsPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String fsPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String fsPtrsScoreUpdatedBy;

	@Column(nullable = true)
	private String fsPtrsScoreUpdatedDate;

	@Column(nullable = true)
	private String ftPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String ftPtrsScoreModifiedDate;

    @Column(nullable = true)
	private String rsPtrsScoreRmkModifiedBy;

	@Column(nullable = true)
	private String rsPtrsScoreRmkModifiedDate;

	@Column(nullable = true)
	private String rsEnsaPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsEnsaPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsOperatorPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsOperatorPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsDietaryPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsDietaryPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsRegAffairsScoreModifiedBy;

	@Column(nullable = true)
	private String rsRegAffairsScoreModifiedDate;

	@Column(nullable = true)
	private String techRecommendationModifiedBy;

	@Column(nullable = true)
	private String techRecommendationModifiedDate;

	@Column(nullable = true)
	private String solRecommendationModifiedBy;

	@Column(nullable = true)
	private String solRecommendationModifiedDate;

	@Column(nullable = true)
	private String scienceRecommendationModifiedBy;

	@Column(nullable = true)
	private String scienceRecommendationModifiedDate;

	@Column(nullable = true)
	private String newportProjectApprovalDate;

	@Column(name = "categoryChangedDateNfpctofd", nullable = true)
	private LocalDate categoryChangedDateNFPCToFD;

	@Column(name = "categoryChangedDateNastolcm", nullable = true)
	private LocalDate categoryChangedDateNASToLCM;


	//this will have the full date
	@Column(nullable = true)
	private LocalDate approvalDate;

	//this will have the year
	@Column(nullable = true)
	private String approvalYear;

	//this will have the month
	@Column(nullable = true)
	private String approvalYearMonth;

	//draft year is saved
	@Column(nullable = true)
	private String draftYear;

	//draft momnth for filter
	@Column(nullable = true)
	private String draftYearMonth;

	@NotNull
	@Column(nullable = false)
	private boolean ptrsFollowUp;

	@ManyToOne(optional = true)
	@JoinColumn(name = "PRODUCT_ID", referencedColumnName = "ID", nullable = true)
	private Product product;

	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Segment> segments; //// = new ArrayList<Segment>();

	@Column
	private String isSegmentPresent;

	@Column(nullable = true)
	private String isUpdate;

	@Column
	private String consolidatedRegion;

	@PrePersist
	@PreUpdate
	public void calculateDepzendentScores() {
		Double rs = null;
		Double rsRegAffairsScoret = 100d;
		Double rsDietaryPtrsScoret = 100d;
		Double rsEnsaPtrsScoret = 100d;
		Double rsOperatorPtrsScoret = 100d;
		if (getRsRegAffairsScore() != null && getRsRegAffairsScore() > 0) {
			rsRegAffairsScoret = getRsRegAffairsScore().doubleValue();
		}
		if (getRsDietaryPtrsScore() != null && getRsDietaryPtrsScore() > 0) {
			rsDietaryPtrsScoret = getRsDietaryPtrsScore().doubleValue();
		}
		if (getRsEnsaPtrsScore() != null && getRsEnsaPtrsScore() > 0) {
			rsEnsaPtrsScoret = getRsEnsaPtrsScore().doubleValue();
		}
		if (getRsOperatorPtrsScore() != null && getRsOperatorPtrsScore() > 0) {
			rsOperatorPtrsScoret = getRsOperatorPtrsScore().doubleValue();
		}

		rs = Math.min(Math.min(rsDietaryPtrsScoret, rsEnsaPtrsScoret),
				Math.min(rsOperatorPtrsScoret, rsRegAffairsScoret));
		if (getRsRegAffairsScore() == null && getRsDietaryPtrsScore() == null && getRsEnsaPtrsScore() == null && getRsOperatorPtrsScore() == null) {
				rs = null;
		}

		if(getIsUpdate()!=null && (getIsUpdate().equals("RSScoreByUser") || getIsUpdate().equals("RSScoreByImport") || getIsUpdate().equals("create")) ) {
			setRsPtrsScore(rs);
		}

		if(getFsPtrsScore()==null || getFsPtrsScore()==0.0 || getRsPtrsScore()==null || getRsPtrsScore()==0.0) {
			if(getNewportCategory() !=null  && (getNewportCategory().equals("Label Expansion") || getNewportCategory().equals("Country Extension") )) {
				if(getIsUpdate()!=null && (getIsUpdate().equals("RSScoreByUser") || getIsUpdate().equals("FSScoreByUser"))) {

					set_rs_fs_scores_if_null(getIsUpdate());
				}

			}
		}

		Double overall = null;
		if (getFsPtrsScore() != null && getFtPtrsScore() != null && getRsPtrsScore() != null) {
			overall = DomainUtil.roundScore(
					getFsPtrsScore().doubleValue() * getFtPtrsScore().doubleValue() * getRsPtrsScore().doubleValue());

					}


		setOverallPtrsScore(DomainUtil.getMaxOverallScore(overall));
		setIsUpdate("false");
		//to check the count of the segment
		int count =0;
		if(getSegments()!=null)
			count=getSegments().size();
		if(count > 0)
			setIsSegmentPresent("Yes");
		else
			setIsSegmentPresent("No");
	}
	public void set_rs_fs_scores_if_null(String isFSScore){
		if(null!=getSegments()) {
			Double weightedFs = 0d;
			Double weightedRs = 0d;
			Double totalWeightedFs = 0d;
			Double totalWeightedRs = 0d;
			Double weight = 0d;
			Double totalWeight = 0d;
			for (Segment seg : getSegments()) {
				weight = seg.getNewportGlobalPeakNetSales();
				if (seg.getRsRegPtrsScore() != null && seg.getRsRegPtrsScore() > 0) {
					weightedRs += seg.getRsRegPtrsScore() * weight;
				}
				if (seg.getFsPtrsScore() != null && seg.getFsPtrsScore() > 0) {
					weightedFs += seg.getFsPtrsScore() * weight;
				}
				totalWeight += weight;
			}
			DecimalFormat df = new DecimalFormat("0.00");
			int rs = 0;
			int fs = 0;
			if (totalWeight > 0) {
				totalWeightedFs = (weightedFs / totalWeight) * 100 ;
				totalWeightedRs = (weightedRs / totalWeight) * 100 ;
				rs = (int)Math.round(totalWeightedRs);
				fs = (int) Math.round(totalWeightedFs);
			}

			if(isFSScore!=null && isFSScore.equals("FSScoreByUser") && (fs!=0.0) && (getFsPtrsScore()==null || getFsPtrsScore()==0.0)) {
				setFsPtrsScore(fs/100.0);
				setFsPtrsScoreRmk("The weighted Segment FS score becomes Project FS PTRS score by default, as Project FS PTRS was empty.");
				setFsPtrsScoreUpdatedBy("data-projects.sql");
			}

			if(isFSScore!=null && isFSScore.equals("RSScoreByUser") && (rs!=0.0) && (getRsPtrsScore()==null || getRsPtrsScore()==0.0)) {
				setRsPtrsScore(rs/100.0);
				setRsPtrsScoreRmk("The weighted Segment RS score becomes Project RS PTRS score by default, as Project RS PTRS was empty.");
				setRsPtrsScoreRmkModifiedBy("data-projects.sql");
			}
		}

	}

	@Override
	public int compareTo(Object o) {
		Project project = (Project) o;
		Long id1 = getId();
		Long id2 = project.getId();

		return id1.compareTo(id2);
	}
}
