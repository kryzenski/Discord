package com.bayer.pmodi.masterlist.rest.model.nautilos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class AprsDto {

	private Long id;
	private String scoreComment;
	private Double scoreValue;
	private String region;
	private String activeIngrediant;
	@Override
	public String toString() {
		String result = getActiveIngrediant() + getRegion();
		return result;
	}
}
