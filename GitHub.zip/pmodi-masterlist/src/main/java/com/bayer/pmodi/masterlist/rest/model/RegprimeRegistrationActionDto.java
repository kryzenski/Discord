package com.bayer.pmodi.masterlist.rest.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class RegprimeRegistrationActionDto {

	private String registrationZNumber;
	private String registrationPhaseCode;
	private String registrationBusinessGroupCode;
	private String actionStatusCode;
	private String actionTypeCode;
	private String actionComment;
	private Long actionSequenceNumber;
	private LocalDate actionActualSubmission;
	private LocalDate actionRegistrationExpected;
	private LocalDate actionRegistrationGrated;
	private LocalDate actionSubmissionPlanned;

}