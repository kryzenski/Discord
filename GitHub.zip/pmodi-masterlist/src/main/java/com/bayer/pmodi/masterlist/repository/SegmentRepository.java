package com.bayer.pmodi.masterlist.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.NoResultException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.bayer.pmodi.masterlist.model.Segment;

public interface SegmentRepository
		extends CustomSegmentRepository, JpaRepository<Segment, Long>, JpaSpecificationExecutor<Segment> {

	Page<Segment> findByProjectId(Long id, Pageable pageInfo);

	List<Segment> findByProjectIdAndQuickscanAssessmentIdIsNotNull(Long id);

	List<Segment> findByProjectIdAndRegprimeZNumberIsNotNull(Long id);

	/**
	 * Get an entity for a given ID. Throws an exception if none is found (or the
	 * given id was null).
	 * 
	 * @param id Primary key; mandatory
	 * @return Entity; never null
	 */
	@Override
	public default Segment getOne(Long id) {
		if (id == null) {
			throw new IllegalArgumentException("ID missing!");
		}
		Optional<Segment> result = findById(id);
		if (!result.isPresent()) {
			throw new NoResultException("No result found for id " + id + "!");
		}
		return result.get();
	}

}
