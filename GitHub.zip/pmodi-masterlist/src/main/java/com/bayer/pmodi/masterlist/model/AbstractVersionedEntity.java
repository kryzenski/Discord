package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.Version;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@MappedSuperclass
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public abstract class AbstractVersionedEntity extends AbstractAuditedEntity {

	public static final Integer INITIAL_VERSION = Integer.valueOf(1);

	@Version
	@Column(nullable = false)
	private Integer version = null;

	@PrePersist
	public void beforePersist() {
		if (version == null || version.intValue() < INITIAL_VERSION) {
			version = INITIAL_VERSION;
		}
	}

}
