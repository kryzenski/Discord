package com.bayer.pmodi.masterlist.model;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

public final class DomainUtil {

	private static final int SCORE_SCALE = 8;
	private static final double MIN_SCORE = 0.01;
	private static final double MAX_SCORE = 0.99;

	private DomainUtil() {
		// No instance allowed
	}

	public static String createPreciseNewportId(String newportAreaId, String newportNewPortNumber) {
		if (StringUtils.isBlank(newportAreaId) || StringUtils.isBlank(newportNewPortNumber)) {
			throw new IllegalArgumentException("Unable to create Newport ID from the given information!");
		}
		String trimmedNumber = StringUtils.stripStart(newportNewPortNumber.trim(), "0");
		return newportAreaId + "-" + (StringUtils.isBlank(trimmedNumber) ? "0" : trimmedNumber);
	}

	/**
	 * Round the given score.
	 * 
	 * @param score Score to round; optional
	 * @return Rounded score or null (if given)
	 */
	public static Double roundScore(Double score) {
		if (score == null) {
			return null;
		}
		BigDecimal decimal = BigDecimal.valueOf(score).setScale(SCORE_SCALE, BigDecimal.ROUND_HALF_UP);
		return decimal.doubleValue();
	}

	/**
	 * Limit the given score to the allowed maximum for overall scores.
	 * 
	 * @param score Score to (possibly) limit; optional
	 * @return Rounded score or null (if given)
	 */
	public static Double getMaxOverallScore(Double score) {
		if (score == null) {
			return null;
		}
		if (score < MIN_SCORE) {
			return MIN_SCORE;
		}
		if (score > MAX_SCORE) {
			return MAX_SCORE;
		}
		return score;
	}

}
