package com.bayer.pmodi.masterlist.audit;

import java.util.Optional;

import org.hibernate.envers.RevisionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;

import com.bayer.pmodi.masterlist.model.EntityRevision;

public class CustomRevisionListener implements RevisionListener {

	@Autowired
	private AuditorAware<String> auditorAware;

	@Override
	public void newRevision(Object revisionEntity) {
		// AutowireHelper.autowire(this, this.auditorAware);
		EntityRevision exampleRevEntity = (EntityRevision) revisionEntity;
		Optional<String> currentAuditor = auditorAware.getCurrentAuditor();
		if (currentAuditor.isPresent()) {
			exampleRevEntity.setModifiedBy(currentAuditor.get());
		} else {
			exampleRevEntity.setModifiedBy("UNKNOWN");
		}
	}
}
