package com.bayer.pmodi.masterlist.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.bayer.pmodi.masterlist.config.webclients.WebClients;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteria;
import com.bayer.pmodi.masterlist.rest.model.nautilos.AprsDto;

@Service
public class NautilosService {

	public static final String PARAM_REGION = "region";
	public static final String PARAM_ACTIVE_INGREDIANT = "activeIngrediant";

	private static final String PATH_APRS_LIST = "/aprs/aprs";
	private static final String PATH_APRS_BY_KEY = "/aprs/aprs/by-region-and-active-ingrediant";

	private static final Map<String, String> MAPPING_REGION = createRegionMapping();

	@Autowired
	private WebClients webClients;

	private WebClient getWebClient() {
		return webClients.getNautilosWebClient();
	}

	public Map<String, Object> getAprsList(PageAndSortCriteria pageAndSortParameters) {
		return RestUtil.getResults(getWebClient(), PATH_APRS_LIST, pageAndSortParameters);
	}

	public AprsDto findAprsByRegionAndActiveIngrediant(String region, String activeIngrediant) {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add(PARAM_REGION, region);
		params.add(PARAM_ACTIVE_INGREDIANT, activeIngrediant);

		final List<AprsDto> results;
		try {
			results = getWebClient().get()
					.uri(uriBuilder -> uriBuilder.path(PATH_APRS_BY_KEY).queryParams(params).build()) //
					.retrieve() //
					.bodyToFlux(AprsDto.class).collectList() //
					.block();
		} catch (Exception wex) {
			if (wex instanceof WebClientResponseException) {
				if (((WebClientResponseException) wex).getStatusCode() == HttpStatus.NOT_FOUND) {
					throw new IllegalArgumentException("No APRS found for region '" + region
							+ "' and active ingrediant '" + activeIngrediant + "'!");
				}
			}
			throw wex;
		}
		if (results.isEmpty()) {
			return null;
		} else if (results.size() > 1) {
			throw new IllegalStateException("Too many APRS entities returned");
		}
		return results.get(0);
	}

	public String getNautilosRegion(String regionName) {
		String result = MAPPING_REGION.get(regionName);
		if (result == null) {
			throw new IllegalArgumentException("No matching Nautilos region found for '" + regionName + "'!");
		}
		return result;
	}

	private static Map<String, String> createRegionMapping() {
		Map<String, String> map = new HashMap<>();
		map.put("Asia", "APAC");
		map.put("Asia 2", "APAC");
		map.put("EMEA 1", "EMEA");
		map.put("EMEA", "EMEA");
		map.put("EMEA 3", "EMEA");
		map.put("Latin America", "LATAM1");
		map.put("Latin America 2", "LATAM2");
		map.put("North America & Australia/New Zealand", "NA");
		return map;
	}

}
