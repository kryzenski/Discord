package com.bayer.pmodi.masterlist.rest.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class RevisionDataDto {

	public static RevisionDataDto from(RevisionInfoDto dto) {
		return new RevisionDataDto(dto.getRevisionId(), dto.getModifiedBy(), dto.getModifiedAt());
	}

	public RevisionDataDto(int revisionId, String modifiedBy, Instant modifiedAt) {
		this.revisionId = revisionId;
		this.modifiedBy = modifiedBy;
		this.modifiedAt = modifiedAt;
	}

	private int revisionId;
	private String modifiedBy;
	private Instant modifiedAt;

	List<RevisionFieldValueDto> changes = new ArrayList<>();

	public void addChange(RevisionFieldValueDto change) {
		changes.add(change);
	}

	@Override
	public String toString() {
		return "Revision " + revisionId + " by '" + modifiedBy + "' at " + modifiedAt + ".";
	}

}
