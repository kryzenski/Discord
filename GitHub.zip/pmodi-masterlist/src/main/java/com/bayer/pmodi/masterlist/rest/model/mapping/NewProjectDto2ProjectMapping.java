//package com.bayer.pmodi.masterlist.rest.model.mapping;
//
//import org.modelmapper.PropertyMap;
//import org.springframework.stereotype.Component;
//
//import com.bayer.pmodi.masterlist.model.Project;
//import com.bayer.pmodi.masterlist.rest.model.NewProjectDto;
//import com.github.jmnarloch.spring.boot.modelmapper.PropertyMapConfigurerSupport;
//
//// modelMapper not used for written entities like project or segment
//@Deprecated
//@Component
//public class NewProjectDto2ProjectMapping extends PropertyMapConfigurerSupport<NewProjectDto, Project> {
//
//	@Override
//	public PropertyMap<NewProjectDto, Project> mapping() {
//
//		return new PropertyMap<NewProjectDto, Project>() {
//			@Override
//			protected void configure() {
//				// Skip referenced entities to avoid creating them unintentionally
//				skip().setProduct(null);
//			}
//		};
//	}
//}
