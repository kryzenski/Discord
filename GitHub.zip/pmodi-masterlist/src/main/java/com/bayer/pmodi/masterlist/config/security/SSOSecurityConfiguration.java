package com.bayer.pmodi.masterlist.config.security;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.microsoft.azure.spring.autoconfigure.aad.AADAppRoleStatelessAuthenticationFilter;

import lombok.extern.java.Log;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Log
@Profile("sso")
@ConfigurationProperties("cors")
public class SSOSecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	AADAppRoleStatelessAuthenticationFilter aadAuthFilter;

	// cors properties
	private List<String> urls;

	public void setUrls(List<String> urls) {
		this.urls = urls;
	}

	public List<String> getUrls() {
		return this.urls;
	}

	@Bean
	public OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService() {
		return new OidcUserService();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().cors().and().authorizeRequests()
				.antMatchers("/", "/webjars/**", "/swagger-ui.html", "/swagger-ui.html/**", "/swagger-resources/**",
						"/v2/api-docs", "/configuration/**", "/csrf")
				.permitAll() // allow health check and swagger
				.anyRequest().authenticated().and()
				// .sessionManagement(cust ->
				// cust.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.addFilterBefore(aadAuthFilter, UsernamePasswordAuthenticationFilter.class);
		log.info("Initalizing aadAuthFilter");
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		log.info("Allowed CORS Domains: " + getUrls());
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(getUrls());
		configuration.setAllowedMethods(Arrays.asList("*"));
		configuration.setAllowedHeaders(Arrays.asList("*"));
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

	/**
	 * Disable default user creation
	 */
	@Override
	@Bean
	public UserDetailsService userDetailsService() {
		return new UserDetailsService() {
			@Override
			public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
				throw new UsernameNotFoundException("no user configured");
			}
		};
	};
}
