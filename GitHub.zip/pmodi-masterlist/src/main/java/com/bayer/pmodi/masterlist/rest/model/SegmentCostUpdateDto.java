package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.SegmentCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a segment cost which are allowed to be
 * updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentCostUpdateDto extends SegmentCostEditableFieldsDto implements VersionedEntity {

	public static SegmentCostUpdateDto from(SegmentCost src) {
		SegmentCostUpdateDto result = new SegmentCostUpdateDto();
		SegmentCostEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentCost src, SegmentCostUpdateDto target) {
		target.setVersion(src.getVersion());
	}

	private Integer version;

}
