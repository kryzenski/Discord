package com.bayer.pmodi.masterlist.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.bayer.pmodi.masterlist.config.webclients.WebClients;
import com.bayer.pmodi.masterlist.rest.model.MilestoneRegprimeDto;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteria;
import com.bayer.pmodi.masterlist.rest.model.RegprimeRegistrationActionDto;
import com.bayer.pmodi.masterlist.rest.model.RegprimeSearchCriteria;
import com.bayer.pmodi.masterlist.rest.model.regprime.MilestoneDto;
import com.bayer.pmodi.masterlist.rest.model.regprime.RegulatoryActionDto;

@Service
@Data
public class RegprimeService {

	private static final String PLACEHOLDER_PRODUCT_LINE_NUMBER = "{PLN}";

	private static final String PATH_ACTIONS_BY_CODES = "/milestone/regulatory-actions/by-codes";
	private static final String PATH_ACTIONS_BY_NUMBERS = "/precise/regprime-milestones";
	private static final String PATH_CROPS = "/masterdata/crops";
	private static final String PATH_CROP_BY_CODE = "/masterdata/crops/by-code";
	private static final String PATH_COUNTRIES = "/masterdata/territories/by-type/COUNTRY";
	private static final String PATH_COUNTRY_BY_CODE = "/masterdata/territories/by-code";
	private static final String PATH_PRODUCT_LINES = "/masterdata/product-lines";
	private static final String PATH_PRODUCT_LINE_BY_NUMBER = "/masterdata/product-lines/"
			+ PLACEHOLDER_PRODUCT_LINE_NUMBER;

	public static final String PARAM_CODE = "code";
	public static final String PARAM_PRODUCT_LINE_NUMBER = "productLineNumber";

	private static final String PARAM_TERRITORY_CODE = "territoryCode";
	private static final String PARAM_CROP_CODE = "cropCode";
	private static final String PARAM_SEQUENCE_NUMBER = "sequenceNumber";
	private static final String PARAM_Z_NUMBER = "zNumber";
	private String token;


	@Autowired
	private WebClients webClients;

	private WebClient getWebClient() {
		return webClients.getRegprimeWebClient(getToken());
	}

	public List<RegprimeRegistrationActionDto> getMilestoneCandidates(@Valid RegprimeSearchCriteria criteria) {
		List<RegulatoryActionDto> regprimeResults = getWebClient().get()
				.uri(uriBuilder -> uriBuilder.path(PATH_ACTIONS_BY_CODES)
						.queryParam(PARAM_CROP_CODE, criteria.getCropKey())
						.queryParam(PARAM_PRODUCT_LINE_NUMBER, criteria.getPltKey())
						.queryParam(PARAM_TERRITORY_CODE, criteria.getCountryKey()).build())
				.retrieve() //
				.bodyToFlux(RegulatoryActionDto.class).collectList().block();

		List<RegprimeRegistrationActionDto> results = new ArrayList<>();
		if (regprimeResults != null) {
			for (RegulatoryActionDto regprimeDto : regprimeResults) {
				RegprimeRegistrationActionDto dto = new RegprimeRegistrationActionDto();
				dto.setActionComment(regprimeDto.getRegulatoryActionComment());
				dto.setActionSequenceNumber(regprimeDto.getRegulatoryActionSequenceNumber());
				dto.setActionStatusCode(regprimeDto.getRegulatoryActionStatusCode());
				dto.setActionTypeCode(regprimeDto.getRegulatoryActionTypeCode());
				dto.setRegistrationBusinessGroupCode(regprimeDto.getRegistrationBusinessGroupCode());
				dto.setRegistrationPhaseCode(regprimeDto.getRegistrationPhaseCode());
				dto.setRegistrationZNumber(regprimeDto.getRegistrationZNumber());
				dto.setActionActualSubmission(regprimeDto.getActualSubmission());
				dto.setActionRegistrationExpected(regprimeDto.getRegistrationExpected());
				dto.setActionRegistrationGrated(regprimeDto.getRegistrationGranted());
				dto.setActionSubmissionPlanned(regprimeDto.getSubmissionPlanned());
				results.add(dto);
			}
		}
		return results;
	}

	public MilestoneRegprimeDto getMilestone(String registrationZNumber, Integer actionSequenceNumber, String token) {
		if(token != null){
			setToken(token);
		}
		String uri = PATH_ACTIONS_BY_NUMBERS+"/"+registrationZNumber+"/"+actionSequenceNumber;
		MilestoneRegprimeDto regprimeResult = getWebClient().get()
				.uri(uriBuilder -> uriBuilder.path(uri)
						.build())
				.retrieve() //
				.bodyToMono(MilestoneRegprimeDto.class).block();
		if (regprimeResult != null) {
			return regprimeResult;
		}
		return null;
	}

	public Map<String, Object> getCrops(PageAndSortCriteria pageAndSortParameters) {
		return RestUtil.getResults(getWebClient(), PATH_CROPS, pageAndSortParameters);
	}

	public Map<String, Object> getCrop(String code) {
		return RestUtil.getResult(getWebClient(), PATH_CROP_BY_CODE, PARAM_CODE, code);
	}

	public Map<String, Object> getCountries(PageAndSortCriteria pageAndSortParameters) {
		return RestUtil.getResults(getWebClient(), PATH_COUNTRIES, pageAndSortParameters);
	}

	public Map<String, Object> getCountry(String code) {
		return RestUtil.getResult(getWebClient(), PATH_COUNTRY_BY_CODE, PARAM_CODE, code);
	}

	public Map<String, Object> getProductLines(PageAndSortCriteria pageAndSortParameters) {
		return RestUtil.getResults(getWebClient(), PATH_PRODUCT_LINES, pageAndSortParameters);
	}

	public Map<String, Object> getProductLine(String productLineNumber) {
		return RestUtil.getResult(getWebClient(),
				StringUtils.replace(PATH_PRODUCT_LINE_BY_NUMBER, PLACEHOLDER_PRODUCT_LINE_NUMBER, productLineNumber));
	}

}
