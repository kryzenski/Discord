package com.bayer.pmodi.masterlist.rest.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.validation.Valid;
import javax.xml.bind.SchemaOutputResolver;

import com.bayer.pmodi.masterlist.model.*;
import com.bayer.pmodi.masterlist.repository.*;
import com.bayer.pmodi.masterlist.rest.model.*;
import lombok.extern.java.Log;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.BatchSize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.bayer.pmodi.masterlist.authorization.AuthorizationUtil;
import com.bayer.pmodi.masterlist.authorization.ProjectAuthenticatedFieldDefinition;
import com.bayer.pmodi.masterlist.authorization.Roles;
import com.bayer.pmodi.masterlist.authorization.SegmentAuthenticatedFieldDefinition;
import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.model.enums.CostCenterEnum;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;
import com.bayer.pmodi.masterlist.rest.NautilosService;
import com.bayer.pmodi.masterlist.rest.NewportConnectorService;
import com.bayer.pmodi.masterlist.rest.QuickScanService;
import com.bayer.pmodi.masterlist.rest.RegprimeService;
import com.bayer.pmodi.masterlist.rest.RestConstants;
import com.bayer.pmodi.masterlist.rest.RestUtil;
import com.bayer.pmodi.masterlist.rest.model.nautilos.AprsDto;
import com.bayer.pmodi.masterlist.search.ExportUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(ProjectController.ROOT_URL)
@Log
public class ProjectController {

	public static final String ROOT_URL = "/project";

	private static final String PARAM_DTYPE = "dtype";

	private static final String LIST_COMMENTS = "comments";
	private static final String LIST_COSTS = "costs";
	private static final String LIST_QUESTIONS = "questions";

	private static final String LIST_PROJECTS = "projects";
	private static final String ONE_PROJECT = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String UPDATE_PROJECT = LIST_PROJECTS + "/{" + RestConstants.BY_USER + "}"+"/{" + RestConstants.PARAM_ID + "}";
	private static final String LIST_ONE_PROJECT_COMMENTS = ONE_PROJECT + "/" + LIST_COMMENTS;
	private static final String LIST_ONE_PROJECT_QUESTIONS = ONE_PROJECT + "/" + LIST_QUESTIONS;
	private static final String LIST_PROJECT_QUESTIONS = LIST_PROJECTS + "/" + LIST_QUESTIONS;
	private static final String LIST_ONE_PROJECT_QUESTIONS_BY_DTYPE = LIST_ONE_PROJECT_QUESTIONS + "/by-dtype/{"
			+ PARAM_DTYPE + "}";
	private static final String LIST_SEGMENTS = "segments";
	private static final String LIST_ONE_PROJECT_SEGMENTS = ONE_PROJECT + "/" + LIST_SEGMENTS;
	private static final String ONE_PROJECT_COMMENT = LIST_PROJECTS + "/" + LIST_COMMENTS + "/{"
			+ RestConstants.PARAM_ID + "}";;
	private static final String LIST_ONE_PROJECT_COMMENTS_BY_DTYPE = ONE_PROJECT + "/" + LIST_COMMENTS + "/by-dtype/{"
			+ PARAM_DTYPE + "}";

	private static final String ONE_SEGMENT = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID + "}";
	private static final String LIST_ONE_SEGMENT_COMMENTS = ONE_SEGMENT + "/" + LIST_COMMENTS;
	private static final String ONE_SEGMENT_COMMENT = LIST_SEGMENTS + "/" + LIST_COMMENTS + "/{"
			+ RestConstants.PARAM_ID + "}";;
	private static final String LIST_ONE_SEGMENT_COMMENTS_BY_DTYPE = ONE_SEGMENT + "/" + LIST_COMMENTS + "/by-dtype/{"
			+ PARAM_DTYPE + "}";
	private static final String LIST_ONE_SEGMENT_QUESTIONS = ONE_SEGMENT + "/" + LIST_QUESTIONS;
	private static final String LIST_SEGMENT_QUESTIONS = LIST_SEGMENTS + "/" + LIST_QUESTIONS;
	private static final String LIST_ONE_SEGMENT_QUESTIONS_BY_DTYPE = LIST_ONE_SEGMENT_QUESTIONS + "/by-dtype/{"
			+ PARAM_DTYPE + "}";

	private static final String LIST_ONE_SEGMENT_COSTS = ONE_SEGMENT + "/" + LIST_COSTS;
	private static final String ONE_SEGMENT_COST = LIST_SEGMENTS + "/" + LIST_COSTS + "/{" + RestConstants.PARAM_ID
			+ "}";
	private static final String LIST_ONE_SEGMENT_COSTS_EXPORT = ONE_SEGMENT + "/" + LIST_COSTS + "/export";

	private static final String REGPRIME_MILESTONE = "/regprime-milestones";

	private static final String ONE_SEGMENT_MILESTONES = ONE_SEGMENT + REGPRIME_MILESTONE;

	private static final String ONE_PROJECT_MILESTONES = ONE_PROJECT + REGPRIME_MILESTONE;
	private static final String LIST_APRS = "aprs";
	private static final String LIST_ONE_PROJECT_APRS = ONE_PROJECT + "/" + LIST_APRS;
	private static final String LIST_ONE_SEGMENT_APRS = ONE_SEGMENT + "/" + LIST_APRS;

	private static final String LIST_NEWPORT_COSTS = "newport-costs";
	private static final String LIST_ONE_SEGMENT_NEWPORT_COSTS = ONE_SEGMENT + "/" + LIST_NEWPORT_COSTS;

	private static final String LIST_QUICKSCAN_ASSESSMENT = "quickscan-assessments";
	private static final String LIST_ONE_SEGMENT_QUICKSCAN_ASSESSMENT = ONE_SEGMENT + "/" + LIST_QUICKSCAN_ASSESSMENT;

	private static final String QUICKSCAN_MITIGATION = "mitigation-module";
	private static final String LIST_ONE_SEGMENT_QUICKSCAN_MITIGATION_MODULE = ONE_SEGMENT + "/" + QUICKSCAN_MITIGATION;
	private static final String LIST_ONE_PROJECT_QUICKSCAN_ASSESSMENTS = ONE_PROJECT + "/" + LIST_QUICKSCAN_ASSESSMENT;

	private static final String LIST_ONE_PROJECT_QUICKSCAN_MITIGATION_MODULE = ONE_PROJECT + "/" + QUICKSCAN_MITIGATION;
	private static final String ONE_PROJECT_EDITABLE_FIELDS = ONE_PROJECT + "/editable-fields";
	private static final String ONE_SEGMENT_EDITABLE_FIELDS = ONE_SEGMENT + "/editable-fields";

	private static final String LIST_PROJECT_QUESTION_DEFINITIONS = "project-question-definitions";
	private static final String ONE_PROJECT_QUESTION_DEFINITION = LIST_PROJECT_QUESTION_DEFINITIONS + "/{"
			+ RestConstants.PARAM_ID + "}";;

	private static final String FIND_PROJECTS = LIST_PROJECTS + "/search";
	private static final String FIND_SEGMENTS = LIST_SEGMENTS + "/search";

	private static final String EXPORT_SEGMENTS = LIST_SEGMENTS + "/export";

	static final String CONTENT_DISPOSITION = "Content-Disposition";
	static final String ATTACHMENT = "attachment; filename=\"{0}\"";

	private static final int DEFAULT_VERSION = 1;

	private static final Boolean DEFAULT_QUICKSCAN_NA_STATUS=true;

	private static final String DEFAULT_QUICKSCAN_NA_REASON="Country out of scope";

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectCommentRepository projectCommentRepository;

	@Autowired
	private ProjectQuestionDefinitionRepository projectQuestionDefinitionRepository;

	@Autowired
	private ProjectQuestionRepository projectQuestionRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@Autowired
	private SegmentCommentRepository segmentCommentRepository;

	@Autowired
	private SegmentQuestionDefinitionRepository segmentQuestionDefinitionRepository;

	@Autowired
	private SegmentQuestionRepository segmentQuestionRepository;

	@Autowired
	private SegmentCostRepository segmentCostRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private RegprimeService regprimeService;

	@Autowired
	private ActiveIngrediant2ProductRepository activeIngrediant2ProductRepository;

	@Autowired
	private ActiveIngrediantRepository activeIngrediantRepository;

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@Autowired
	private NautilosService nautilosService;

	@Autowired
	private QuickScanService quickscanService;

	@Autowired
	private NewportConnectorService newportConnectorService;

	@Autowired
	private ProjectService projectService;

	@Autowired
	private PermissionService permissionService;

	@Autowired
	private Environment environment;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get list of project entities. Pageable and sortable.")
	@GetMapping(path = LIST_PROJECTS)
	@ResponseBody
	public Page<ProjectDto> getProjects(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Project> results = projectRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> ProjectDto.from(e));
	}

	@ApiOperation(value = "Retrieve a single project entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_PROJECT)
	@ResponseBody
	public ProjectDto getProject(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Project result = projectRepository.getOne(id);
		ProjectDto resultDto = ProjectDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Create a new project (mandatory attributes are project name, newport id and product id).")
	@PostMapping(path = LIST_PROJECTS)
	@ResponseBody
	@Transactional
	public ProjectDto createProject(@RequestBody @ApiParam("JSON definition of the new entity") NewProjectDto dto) {
		checkProjectOrSegmentCreationAllowed();
		if (StringUtils.isBlank(dto.getNewportProjectId()) || StringUtils.isBlank(dto.getNewportAreaId())
				|| StringUtils.isBlank(dto.getNewportNewPortNumber())) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		ProjectService.checkScores(dto);
		Project newEntity = new Project();
		dto.applyUpdateablePropertiesTo(newEntity, productRepository);
		NewProjectDto.applyKeyPropertiesTo(newEntity, dto.getNewportProjectId(), dto.getNewportAreaId(),
				dto.getNewportNewPortNumber());
		newEntity.setVersion(DEFAULT_VERSION);


			setNewportCeationYear(newEntity);
			projectService.setNewportProjectApprovalYear(newEntity);

		//if no segment is present to set isSegmentPresent NO
		if(newEntity != null  && newEntity.getSegments() != null && (newEntity.getSegments().isEmpty()))
			newEntity.setIsSegmentPresent("No");

        newEntity.setIsUpdate("create");
		Project result = projectRepository.save(newEntity);

		List<ProjectQuestionDefinition> projectQuestionDefinitions = projectQuestionDefinitionRepository
				.findByIsActive(true);
		if (!projectQuestionDefinitions.isEmpty()) {
			List<ProjectQuestion> projectQuestions = new ArrayList<>(projectQuestionDefinitions.size());
			for (ProjectQuestionDefinition def : projectQuestionDefinitions) {
				ProjectQuestion q = new ProjectQuestion();
				q.setProject(result);
				q.setProjectQuestionDefinition(def);
				q.setAnswer(false);
				q.setVersion(DEFAULT_VERSION);
				projectQuestions.add(q);
			}
			projectQuestionRepository.saveAll(projectQuestions);
		}

		ProjectDto resultDto = ProjectDto.from(result);
		return resultDto;
	}


	// to update Newport project created date in correct format
	public void setNewportCeationYear(Project newEntity){
      try{
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			LocalDate date = LocalDate.parse(newEntity.getNewportProjectCreated(), formatter);
			newEntity.setNewportProjectCreated(String.valueOf(date));
			newEntity.setDraftYear(String.valueOf(date.getYear()));
		  String str = date.getMonth().toString();
		  String draftMonthAndYear = String.valueOf(date.getYear())+'-'+str.substring(0,3);
		  newEntity.setDraftYearMonth(draftMonthAndYear);
		}

		catch(Exception e){
			log.warning("Exception in NewportProjectCreation "+e.getMessage());
		}
			}
	@ApiOperation(value = "Update an existing project (given by {" + RestConstants.PARAM_ID
			+ "}). All provided properties are updated (also when set to null). Not supported properties (and properties acting as alternate key) are ignored.")
	@PatchMapping(path = ONE_PROJECT)
	@ResponseBody
	public ProjectDto updateProject( //
									 @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
									 @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		// This (like all other writing methods) is encapsulated to return the updated
		// version which is only done when flushing the context. On create methods this
		// encapsulation isn't needed because there the version is set manually.
		Project result = projectService.updateProjectTransactional(id, httpEntity , "true");

		// Create result
		ProjectDto resultDto = ProjectDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Get editable fields of a project (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_PROJECT_EDITABLE_FIELDS)
	@ResponseBody
	public List<String> getProjectEditableFields( //
												  @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id)
			throws IOException {
		Project original = projectRepository.getOne(id);
		ProjectUpdateDto dto = ProjectUpdateDto.from(original);
		Collection<String> regionRoleSuffixes = projectService.getRoleSuffixes(id);
		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, dto,
				ProjectAuthenticatedFieldDefinition.getInstance(), regionRoleSuffixes, f -> true,
				permissionService.getLockedGroups());
		addCommentToEditableFieldsIfCreationAllowed(results);
		return results;
	}

	/**
	 * Check if the current user is allowed to create comments and if so, add the
	 * "comments" field (which is not part of the DTO!) to the given list of
	 * editable fields.
	 *
	 * @param results List of field names which are editable; mandatory (but not
	 *                checked)
	 */
	private void addCommentToEditableFieldsIfCreationAllowed(List<String> results) {
		boolean isCommentCreationAllowed = userDetailsHelper.hasWriteAccess();
		if (isCommentCreationAllowed) {
			results.add("comments");
		}
	}

	@ApiOperation(value = "Get list of comments for a given project (given by {" + RestConstants.PARAM_ID
			+ "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_PROJECT_COMMENTS)
	@ResponseBody
	public Page<ProjectCommentDto> getProjectCommentsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<ProjectComment> results = projectCommentRepository.findByProjectId(id, pageInfo);
		return RestUtil.toDtoPage(results, e -> ProjectCommentDto.from(e));
	}

	@ApiOperation(value = "Get list of comments for a given project (given by {" + RestConstants.PARAM_ID
			+ "}) and of a given comment type (given by {" + PARAM_DTYPE + "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_PROJECT_COMMENTS_BY_DTYPE)
	@ResponseBody
	public Page<ProjectCommentDto> getProjectCommentsOfParentByType(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@PathVariable(name = PARAM_DTYPE, required = true) @ApiParam(name = PARAM_DTYPE, required = true, allowEmptyValue = false, allowableValues = "PRIO,OVERALL,PTRS") String dtype,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<ProjectComment> results = projectCommentRepository.findByProjectIdAndDtype(id,
				ModuleTypeEnum.valueOf(dtype), pageInfo);
		return RestUtil.toDtoPage(results, e -> ProjectCommentDto.from(e));
	}

	@ApiOperation(value = "Create a new project comment for a given project (given by {" + RestConstants.PARAM_ID
			+ "}). Mandatory attributes are type, user and text. The timestamp is set by this method.")
	@PostMapping(path = LIST_ONE_PROJECT_COMMENTS)
	@ResponseBody
	@Transactional
	public ProjectCommentDto createProjectComment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestBody @ApiParam("JSON definition of the new entity") NewProjectCommentDto dto) {
		checkWriteAccess();
		if (dto == null || dto.getDtype() == null || StringUtils.isBlank(dto.getText())) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		String userId = userDetailsHelper.getCurrentUserId();
		Project project = projectRepository.getOne(id);
		ProjectComment newEntity = new ProjectComment();
		dto.applyUpdateablePropertiesTo(newEntity);
		NewProjectCommentDto.applyKeyPropertiesTo(newEntity, dto.getDtype(), OffsetDateTime.now(), userId);
		newEntity.setProject(project);
		newEntity.setVersion(DEFAULT_VERSION);

		ProjectComment result = projectCommentRepository.save(newEntity);
		ProjectCommentDto resultDto = ProjectCommentDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Update an existing project comment (given by {" + RestConstants.PARAM_ID
			+ "}). This does not change the timestamp.")
	@PatchMapping(path = ONE_PROJECT_COMMENT)
	@ResponseBody
	public ProjectCommentDto updateProjectComment( //
												   @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
												   @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		ProjectComment result = projectService.updateProjectCommentTransactional(id, httpEntity);

		// Create result
		ProjectCommentDto resultDto = ProjectCommentDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Delete a single project comment (given by {" + RestConstants.PARAM_ID
			+ "}). Illegal ids lead to an error.")
	@DeleteMapping(path = ONE_PROJECT_COMMENT)
	@Transactional
	public void deleteProjectComment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		checkWriteAccess();
		ProjectComment original = projectCommentRepository.getOne(id);
		checkCurrentUser(original.getUser());

		projectCommentRepository.deleteById(id);
	}

	@ApiOperation(value = "Get list of project question definitions. Pageable and sortable.")
	@GetMapping(path = LIST_PROJECT_QUESTION_DEFINITIONS)
	@ResponseBody
	public Page<ProjectQuestionDefinitionDto> getProjectQuestionDefinitions(
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<ProjectQuestionDefinition> results = projectQuestionDefinitionRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> ProjectQuestionDefinitionDto.from(e));
	}

	@ApiOperation(value = "Get a project question definition (given by {" + RestConstants.PARAM_ID
			+ "}). Illegal ids lead to an error.")
	@GetMapping(path = ONE_PROJECT_QUESTION_DEFINITION)
	@ResponseBody
	public ProjectQuestionDefinitionDto getProjectQuestionDefinition(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		ProjectQuestionDefinition result = projectQuestionDefinitionRepository.getOne(id);
		return ProjectQuestionDefinitionDto.from(result);
	}

	@ApiOperation(value = "Create a new project question definition. Mandatory attribute is type.")
	@PostMapping(path = LIST_PROJECT_QUESTION_DEFINITIONS)
	@ResponseBody
	@Transactional
	public ProjectQuestionDefinitionDto createProjectQuestionDefinition(
			@RequestBody @ApiParam("JSON definition of the new entity") NewProjectQuestionDefinitionDto dto) {
		checkWriteAccess();
		if (dto.getDtype() == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}

		ProjectQuestionDefinition newEntity = new ProjectQuestionDefinition();
		dto.applyUpdateablePropertiesTo(newEntity);
		NewProjectQuestionDefinitionDto.applyKeyPropertiesTo(newEntity, dto.getDtype());

		ProjectQuestionDefinition result = projectQuestionDefinitionRepository.save(newEntity);
		ProjectQuestionDefinitionDto resultDto = ProjectQuestionDefinitionDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Update an existing project question definition (given by {" + RestConstants.PARAM_ID + "}).")
	@PatchMapping(path = ONE_PROJECT_QUESTION_DEFINITION)
	@ResponseBody
	public ProjectQuestionDefinitionDto updateProjectQuestionDefinition( //
																		 @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
																		 @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		ProjectQuestionDefinition result = projectService.updateProjectQuestionDefinitionTransactional(id, httpEntity);

		// Create result
		ProjectQuestionDefinitionDto resultDto = ProjectQuestionDefinitionDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Delete a single project question definition (given by {" + RestConstants.PARAM_ID
			+ "}). Illegal ids lead to an error.")
	@DeleteMapping(path = ONE_PROJECT_QUESTION_DEFINITION)
	@Transactional
	public void deleteProjectQuestionDefinition(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		checkWriteAccess();
		projectQuestionDefinitionRepository.deleteById(id);
	}

	@ApiOperation(value = "Get list of questions for a given project (given by {" + RestConstants.PARAM_ID
			+ "}) and of a given type (given by {" + PARAM_DTYPE + "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_PROJECT_QUESTIONS_BY_DTYPE)
	@ResponseBody
	public Page<ProjectQuestionDto> getProjectQuestionsOfParentByType(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@PathVariable(name = PARAM_DTYPE, required = true) @ApiParam(name = PARAM_DTYPE, required = true, allowEmptyValue = false, allowableValues = "PRIO,OVERALL,PTRS") String dtype,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<ProjectQuestion> results = projectQuestionRepository
				.findByProjectIdAndProjectQuestionDefinitionDtypeOrderByProjectQuestionDefinitionPos(id,
						ModuleTypeEnum.valueOf(dtype), pageInfo);
		return RestUtil.toDtoPage(results, e -> ProjectQuestionDto.from(e));
	}

	@ApiOperation(value = "Update existing project questions.")
	@PatchMapping(path = LIST_PROJECT_QUESTIONS)
	@ResponseBody
	public List<ProjectQuestionDto> updateProjectQuestions( //
															@RequestBody @ApiParam(type = "JSON with a list of answers") List<AnswerDto> answers) throws IOException {
		checkWriteAccess();

		Iterable<ProjectQuestion> results = projectService.updateProjectQuestionsTransactional(answers);

		List<ProjectQuestionDto> returned = new ArrayList<>();
		results.forEach(r -> returned.add(ProjectQuestionDto.from(r)));
		return returned;
	}

	@ApiOperation(value = "Get list of segments for a given project (given by {" + RestConstants.PARAM_ID
			+ "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_PROJECT_SEGMENTS)
	@ResponseBody
	public Page<SegmentWithCropDto> getProjectSegmentsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		pageAndSortParameters.setSize(500);
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<Segment> results = segmentRepository.findByProjectId(id, pageInfo);


		return RestUtil.toDtoPage(results, e -> SegmentWithCropDto.from(e));
	}

	@ApiOperation(value = "Create a new segment for a project  (given by {" + RestConstants.PARAM_ID
			+ "}). Mandatory attributes are country, subRegion, region, crop, target, newportDiseasesPestsWeedsId and costCenter.")
	@PostMapping(path = LIST_ONE_PROJECT_SEGMENTS)
	@ResponseBody
	@Transactional
	public SegmentDto createSegment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestBody @ApiParam("JSON definition of the new entity") NewSegmentDto dto) {
		checkProjectOrSegmentCreationAllowed();
		if (dto.getCountry() == null || dto.getCountry().getId() == null || dto.getSubRegion() == null
				|| dto.getSubRegion().getId() == null || dto.getRegion() == null || dto.getRegion().getId() == null
				|| dto.getCrop() == null || dto.getCrop().getId() == null || StringUtils.isBlank(dto.getTarget())
				|| StringUtils.isBlank(dto.getNewportDiseasesPestsWeedsId()) || dto.getCostCenter() == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		if (dto.getQuickscanAssessmentId() != null) {
			throw new IllegalArgumentException("Quickscan Assessment Id not allowed here! Update only.");
		}
		Project project = projectRepository.getOne(id);
		Country country = countryRepository.getOne(dto.getCountry().getId());
		SubRegion subRegion = subRegionRepository.getOne(dto.getSubRegion().getId());
		Region region = regionRepository.getOne(dto.getRegion().getId());
		Crop crop = cropRepository.getOne(dto.getCrop().getId());


		// checkSegmentAlternateKeyProperties(dto.getCostCenter(), country, subRegion,
		// region, crop);
		ProjectService.checkScores(dto);

		Segment newEntity = new Segment();
		dto.applyUpdateablePropertiesTo(newEntity);
		NewSegmentDto.applyKeyPropertiesTo(newEntity, country, subRegion, region, crop, dto.getTarget(),
				dto.getNewportDiseasesPestsWeedsId(), dto.getCostCenter());
		newEntity.setProject(project);
		newEntity.setVersion(DEFAULT_VERSION);

		newEntity.setCountryType(country.getFlag()==true?"High Regulation":"L4SU");
		newEntity.setCountryName(country.getName());
		newEntity.setPreciseNewportId(project.getPreciseNewportId());
		newEntity.setNewportFreeText(project.getNewportFreeText());
		newEntity.setNewportName(project.getNewportName());
		newEntity.setSubRegionName(subRegion.getName());
		newEntity.setCropName(crop.getName());
		newEntity.setCropGroupName(crop.getCropGroup().getName());
		newEntity.setCropPlatformName(crop.getCropGroup().getCropPlatform().getName());
		newEntity.setRegionName(region.getName());
		//creation year, date and month of segment
		projectService.setNewportSegmentCreationDate(newEntity);


		newEntity.setNewportCategory(project.getNewportCategory());
		newEntity.setNewportBusinessUnit(project.getNewportBusinessUnit());
		newEntity.setNewportStatus(project.getNewportStatus());


		if(country.getFlag()){
			newEntity.setIsQuickScanNotApplicable(DEFAULT_QUICKSCAN_NA_STATUS);
			newEntity.setQuickScanNotApplicableReason(DEFAULT_QUICKSCAN_NA_REASON);
		}

		//to set the projects with segments
		if( newEntity != null && newEntity.getProject() != null){
			newEntity.getProject().setIsSegmentPresent("Yes");
		}

		Segment result = segmentRepository.save(newEntity);

		List<SegmentQuestionDefinition> segmentQuestionDefinitions = segmentQuestionDefinitionRepository
				.findByIsActive(true);
		if (!segmentQuestionDefinitions.isEmpty()) {
			List<SegmentQuestion> segmentQuestions = new ArrayList<>(segmentQuestionDefinitions.size());
			for (SegmentQuestionDefinition def : segmentQuestionDefinitions) {
				SegmentQuestion q = new SegmentQuestion();
				q.setSegment(result);
				q.setSegmentQuestionDefinition(def);
				q.setAnswer(false);
				q.setVersion(DEFAULT_VERSION);
				segmentQuestions.add(q);
			}
			segmentQuestionRepository.saveAll(segmentQuestions);
		}

		SegmentDto resultDto = SegmentDto.from(result);
		return resultDto;
	}

	/**
	 * Check combination of the alternate key properties.
	 *
	 * @param costCenter Cost center; mandatory (but not checked)
	 * @param country    Country; mandatory (but not checked)
	 * @param subRegion  Sub region; mandatory (but not checked)
	 * @param region     Region; mandatory (but not checked)
	 * @param crop       Crop; mandatory (but not checked)
	 */
	private void checkSegmentAlternateKeyProperties(CostCenterEnum costCenter, Country country, SubRegion subRegion,
													Region region, Crop crop) {
		if (CostCenterEnum.GLOBAL.equals(costCenter)) {
			if (crop.isPlaceholder() == false || !"GLOBAL".equalsIgnoreCase(crop.getPlaceholderType())) {
				throw new IllegalArgumentException(
						"Global cost center and crop do not match! Crop has unexpected properties.");
			}
			boolean isTerritoryPlaceholder = country.isPlaceholder() || subRegion.isPlaceholder()
					|| region.isPlaceholder();
			if (isTerritoryPlaceholder == false) {
				throw new IllegalArgumentException(
						"Global cost center and country do not match! Country has unexpected properties.");
			}
		} else if (CostCenterEnum.REGIONAL.equals(costCenter)) {
			// May allow specific crops and countries
			if ("GLOBAL".equalsIgnoreCase(crop.getPlaceholderType())) {
				throw new IllegalArgumentException(
						"Regional cost center and crop do not match! Crop is a placeholer for global costs.");
			}
		} else if (CostCenterEnum.LOCAL.equals(costCenter)) {
			if ("GLOBAL".equalsIgnoreCase(crop.getPlaceholderType())) {
				throw new IllegalArgumentException(
						"Local cost center and crop do not match! Crop is a placeholer for global costs.");
			}
			// Country.isPlaceholder() not checked. Global placeholder is NOT allowed, but
			// regional may be. Model does not distinguish between both.
		}
	}

	@ApiOperation(value = "Retrieve a single segment entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_SEGMENT)
	@ResponseBody
	public SegmentDto getSegment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Segment result = segmentRepository.getOne(id);
		SegmentDto resultDto = SegmentDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Update an existing segment (given by {" + RestConstants.PARAM_ID
			+ "}). All provided properties are updated (also when set to null). Not supported properties (and properties acting as alternate key) are ignored.")
	@PatchMapping(path = ONE_SEGMENT)
	@ResponseBody
	public SegmentDto updateSegment( //
									 @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
									 @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		Segment result = projectService.updateSegmentTransactional(id, httpEntity);

		// Create result
		SegmentDto resultDto = SegmentDto.from(result);
		return resultDto;
	}


	@ApiOperation(value = "Delete a single segment (given by {" + RestConstants.PARAM_ID
			+ "}). Illegal ids lead to an error.")
	@DeleteMapping(path = ONE_SEGMENT)
	@Transactional
	public void deleteSegment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		checkWriteAccess();
		segmentCommentRepository.deleteBySegmentId(id);
		segmentCostRepository.deleteBySegmentId(id);
		segmentQuestionRepository.deleteBySegmentId(id);
		segmentRepository.deleteById(id);
	}

	@ApiOperation(value = "Get editable fields of a segment (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_SEGMENT_EDITABLE_FIELDS)
	@ResponseBody
	public List<String> getSegmentEditableFields( //
												  @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id)
			throws IOException {
		Segment original = segmentRepository.getOne(id);
		SegmentUpdateDto dto = SegmentUpdateDto.from(original);
		Collection<String> regionRoleSuffixes = ProjectService.getRoleSuffixes(original);
		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, dto,
				SegmentAuthenticatedFieldDefinition.getInstance(), regionRoleSuffixes, f -> true,
				permissionService.getLockedGroups());
		addCommentToEditableFieldsIfCreationAllowed(results);
		return results;
	}

	@ApiOperation(value = "Get list of comments for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_SEGMENT_COMMENTS)
	@ResponseBody
	public Page<SegmentCommentDto> getSegmentCommentsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<SegmentComment> results = segmentCommentRepository.findBySegmentId(id, pageInfo);
		return RestUtil.toDtoPage(results, e -> SegmentCommentDto.from(e));
	}

	@ApiOperation(value = "Get list of comments for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}) and of a given comment type (given by {" + PARAM_DTYPE + "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_SEGMENT_COMMENTS_BY_DTYPE)
	@ResponseBody
	public Page<SegmentCommentDto> getSegmentCommentsOfParentByType(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@PathVariable(name = PARAM_DTYPE, required = true) @ApiParam(name = PARAM_DTYPE, required = true, allowEmptyValue = false, allowableValues = "PRIO,OVERALL,PTRS") String dtype,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<SegmentComment> results = segmentCommentRepository.findBySegmentIdAndDtype(id,
				ModuleTypeEnum.valueOf(dtype), pageInfo);
		return RestUtil.toDtoPage(results, e -> SegmentCommentDto.from(e));
	}

	@ApiOperation(value = "Create a new segment comment for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}). Mandatory attributes are type, user and text. The timestamp is set by this method.")
	@PostMapping(path = LIST_ONE_SEGMENT_COMMENTS)
	@ResponseBody
	@Transactional
	public SegmentCommentDto createSegmentComment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestBody @ApiParam("JSON definition of the new entity") NewSegmentCommentDto dto) {
		checkWriteAccess();
		if (dto == null || dto.getDtype() == null || StringUtils.isBlank(dto.getText())) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		Segment segment = segmentRepository.getOne(id);
		String userId = userDetailsHelper.getCurrentUserId();
		SegmentComment newEntity = new SegmentComment();
		dto.applyUpdateablePropertiesTo(newEntity);
		NewSegmentCommentDto.applyKeyPropertiesTo(newEntity, dto.getDtype(), OffsetDateTime.now(), userId);
		newEntity.setSegment(segment);
		newEntity.setVersion(DEFAULT_VERSION);

		SegmentComment result = segmentCommentRepository.save(newEntity);
		SegmentCommentDto resultDto = SegmentCommentDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Update an existing segment comment (given by {" + RestConstants.PARAM_ID
			+ "}). This does not change the timestamp.")
	@PatchMapping(path = ONE_SEGMENT_COMMENT)
	@ResponseBody
	public SegmentCommentDto updateSegmentComment( //
												   @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
												   @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		SegmentComment result = projectService.updateSegmentCommentTransactional(id, httpEntity);

		// Create result
		SegmentCommentDto resultDto = SegmentCommentDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Delete a single segment comment (given by {" + RestConstants.PARAM_ID
			+ "}). Illegal ids lead to an error.")
	@DeleteMapping(path = ONE_SEGMENT_COMMENT)
	@Transactional
	public void deleteSegmentComment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		checkWriteAccess();
		SegmentComment original = segmentCommentRepository.getOne(id);
		checkCurrentUser(original.getUser());

		segmentCommentRepository.deleteById(id);
	}

	@ApiOperation(value = "Get list of questions for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}) and of a given type (given by {" + PARAM_DTYPE + "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_SEGMENT_QUESTIONS_BY_DTYPE)
	@ResponseBody
	public Page<SegmentQuestionDto> getSegmentQuestionsOfParentByType(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@PathVariable(name = PARAM_DTYPE, required = true) @ApiParam(name = PARAM_DTYPE, required = true, allowEmptyValue = false, allowableValues = "PRIO,OVERALL,PTRS") String dtype,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<SegmentQuestion> results = segmentQuestionRepository
				.findBySegmentIdAndSegmentQuestionDefinitionDtypeOrderBySegmentQuestionDefinitionPos(id,
						ModuleTypeEnum.valueOf(dtype), pageInfo);
		return RestUtil.toDtoPage(results, e -> SegmentQuestionDto.from(e));
	}

	@ApiOperation(value = "Update existing segment questions.")
	@PatchMapping(path = LIST_SEGMENT_QUESTIONS)
	@ResponseBody
	public List<SegmentQuestionDto> updateSegmentQuestions( //
															@RequestBody @ApiParam(type = "JSON with a list of answers") List<AnswerDto> answers) throws IOException {
		checkWriteAccess();

		Iterable<SegmentQuestion> results = projectService.updateSegmentQuestionsTransactional(answers);

		List<SegmentQuestionDto> returned = new ArrayList<>();
		results.forEach(r -> returned.add(SegmentQuestionDto.from(r)));
		return returned;
	}

	@ApiOperation(value = "Get list of costs for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}). Pageable and sortable.")
	@GetMapping(path = LIST_ONE_SEGMENT_COSTS)
	@ResponseBody
	public Page<SegmentCostDto> getSegmentCostsOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<SegmentCost> results = segmentCostRepository.findBySegmentId(id, pageInfo);
		return RestUtil.toDtoPage(results, e -> SegmentCostDto.from(e));
	}

	@ApiOperation(value = "Retrieve REGPRIME milestones for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}). Returns nothing if REGPRIME data (country, crop and product line) was not available for the given segment or REGPRIME delivers no data.")
	@GetMapping(path = ONE_SEGMENT_MILESTONES)
	@ResponseBody
	public MilestoneRegprimeDto getRegprimeMilestones(HttpServletRequest request,
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Segment segment = segmentRepository.getOne(id);
		String header = request.getHeader("Authorization");
		String token="";
		if(header !=null && header.startsWith("Bearer")){
			token = header.substring(7);
		}
		if (StringUtils.isNotBlank(segment.getRegprimeZNumber()) && segment.getRegprimeSequenceNumber() != null) {
			return regprimeService.getMilestone(segment.getRegprimeZNumber(), segment.getRegprimeSequenceNumber(),token);
		}
		return null;
	}

	@ApiOperation(value="Retrieve REGPRIME milestones for a given project (given by {" + RestConstants.PARAM_ID +
			"}). Returns nothing if REGPRIME data (country, crop and product line) was not available for the given project or REGPRIME delivers no data.")
	@GetMapping(path=ONE_PROJECT_MILESTONES)
	@ResponseBody
	public List<SegmentRegprimeDTO> getSegmentsRegprimeMilestone(HttpServletRequest request,
                 @PathVariable(name= RestConstants.PARAM_ID, required = true) @ApiParam(name= RestConstants.PARAM_ID, value = "id", required = true, allowEmptyValue = false, type="long", example = "1") Long id) {
		List<Segment> segments = segmentRepository.findByProjectIdAndRegprimeZNumberIsNotNull(id);
		String header = request.getHeader("Authorization");
		String token="";
		if(header !=null && header.startsWith("Bearer")){
			token = header.substring(7);
		}
		List<SegmentRegprimeDTO> regprimeList = new ArrayList<>();
		if (segments != null) {
			for (Segment segment : segments) {
				if (StringUtils.isNotBlank(segment.getRegprimeZNumber()) && segment.getRegprimeSequenceNumber() != null) {
					MilestoneRegprimeDto regprimeResult = regprimeService.getMilestone(segment.getRegprimeZNumber(), segment.getRegprimeSequenceNumber(), token);
					if (regprimeResult != null) {
						regprimeList.add(new SegmentRegprimeDTO(segment.getId(), regprimeResult));
					}
				}
			}
		}
		if(!regprimeList.isEmpty()) {
			return regprimeList;
		}
		return null;
	}

	@ApiOperation(value = "Create a new segment cost entity for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}). Mandatory attribute is year.")
	@PostMapping(path = LIST_ONE_SEGMENT_COSTS)
	@ResponseBody
	@Transactional
	public SegmentCostDto createSegmentCost(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestBody @ApiParam("JSON definition of the new entity") NewSegmentCostDto dto) {
		checkWriteAccess();
		if (StringUtils.isBlank(dto.getYear())) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		Segment segment = segmentRepository.getOne(id);
		SegmentCost newEntity = new SegmentCost();
		dto.applyUpdateablePropertiesTo(newEntity);
		NewSegmentCostDto.applyKeyPropertiesTo(newEntity, dto.getYear());
		newEntity.setSegment(segment);
		newEntity.setVersion(DEFAULT_VERSION);

		SegmentCost result = segmentCostRepository.save(newEntity);
		SegmentCostDto resultDto = SegmentCostDto.from(result);
		return resultDto;
	}

	@ApiOperation(value = "Update an existing segment cost (given by {" + RestConstants.PARAM_ID
			+ "}). Changes only the cost values. It does not change the year (given value is silently ignored).")
	@PatchMapping(path = ONE_SEGMENT_COST)
	@ResponseBody
	public SegmentCostDto updateSegmentCost( //
											 @PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
											 @ApiParam(type = "JSON") HttpEntity<String> httpEntity) throws IOException {
		checkWriteAccess();

		SegmentCost result = projectService.updateSegmentCostTransactional(id, httpEntity);

		// Create result
		SegmentCostDto resultDto = SegmentCostDto.from(result);
		return resultDto;
	}

//	@ApiOperation(value = "Delete a single segment cost (given by {" + RestConstants.PARAM_ID
//			+ "}). Illegal ids lead to an error.")
//	@DeleteMapping(path = ONE_SEGMENT_COST)
//	public void deleteSegmentCost(
//			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
//		checkWriteAccess();
//		segmentCostRepository.deleteById(id);
//	}

	@ApiOperation(value = "Retrieve Nautilos APRS entities of the given project (given by {" + RestConstants.PARAM_ID
			+ "}).")
	@GetMapping(path = LIST_ONE_PROJECT_APRS)
	@ResponseBody
	public Collection<AprsDto> getProjectAprs(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Page<Segment> page = segmentRepository.findByProjectId(id, Pageable.unpaged());
		if (page.getContent().isEmpty()) {
			return Collections.emptyList();
		}
		HashMap<Long, AprsDto> map = new HashMap<Long, AprsDto>();
		HashMap<Long, Integer> map2 = new HashMap<Long, Integer>();
		List<AprsDto> results = new ArrayList<>();
		for (Segment segment : page.getContent()) {
			if (!map2.containsKey(segment.getRegion().getId().longValue())) {
				List<AprsDto> segmentResults = getAprsScoresOfSegment(segment);
				map2.put(segment.getRegion().getId().longValue(), 1);
				// Avoid duplicates by using a map
				results.addAll(segmentResults);
				segmentResults.forEach(s -> map.put(s.getId(), s));
			}
		}

		results.sort(Comparator.comparing(AprsDto::toString));
		return results;
	}

	@ApiOperation(value = "Retrieve Nautilos APRS entities of the given segment (given by {" + RestConstants.PARAM_ID
			+ "}).")
	@GetMapping(path = LIST_ONE_SEGMENT_APRS)
	@ResponseBody
	public List<AprsDto> getSegmentAprs(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Segment segment = segmentRepository.getOne(id);
		List<AprsDto> results = new ArrayList<>();
		results=getAprsScoresOfSegment(segment);
		results.sort(Comparator.comparing(AprsDto::toString));
		return results;
	}

	private List<AprsDto> getAprsScoresOfSegment(Segment segment) {
		Region region = segment.getRegion();
		if (region.isPlaceholder()) {
			return Collections.emptyList();
		}
		if (isMock() && region.getName().startsWith("EMEA")) {
			List<AprsDto> results = new ArrayList<>();
			for (int i = 1; i < 7; i++) {
				AprsDto a = new AprsDto(Long.valueOf(i), "score comment " + i, 1.234 * i, "EMEA", "AI" + i);
				results.add(a);
			}
			return results;
		}
		List<AprsDto> results = new ArrayList<>();
		String nautilosRegion = nautilosService.getNautilosRegion(region.getName());
		Product product = segment.getProject().getProduct();
		String newportName=segment.getProject().getNewportName();
		String[] activeIngredints=newportName.split("&");
		int noOfActiveIngridients=activeIngredints.length;
		int count=0;
		if (product == null) {
			for (String ai : activeIngredints) {
				ActiveIngrediant activeIngrediant = null;
				count++;
				if (noOfActiveIngridients == count) {
					String[] lastai = ai.split("\\s[A-Z][A-Z]\\s");
					activeIngrediant = activeIngrediantRepository.findByMolName(lastai[0].trim());
					if (activeIngrediant != null) {
						AprsDto aprs = null;
						AprsDto aprsApac = null;
						AprsDto aprsLatam2 = null;
						if(!region.getRoleSuffix().startsWith("LATAM")) {
							try {
								aprs = nautilosService.findAprsByRegionAndActiveIngrediant(nautilosRegion,
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprs != null) {
								if (region.getName().startsWith("EMEA")) {
									aprs.setRegion("EMEA:EU");
								}
								results.add(aprs);
							}
						}
						if(region.getName().startsWith("EMEA")){
							try {
								aprsApac = nautilosService.findAprsByRegionAndActiveIngrediant("APAC",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprsApac != null) {
								aprsApac.setRegion("EMEA:Outside EU");
								results.add(aprsApac);
							}
						}
						if(region.getRoleSuffix().startsWith("LATAM")){
							try {
								aprs = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM1",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprs != null) {
								results.add(aprs);
							}
							try {
								aprsLatam2 = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM2",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprsLatam2 != null) {
								results.add(aprsLatam2);
							}
						}
					}
				} else {
					activeIngrediant = activeIngrediantRepository.findByMolName(ai.trim());
					if (activeIngrediant != null) {
						AprsDto aprs = null;
						AprsDto aprsApac = null;
						AprsDto aprsLatam2 = null;
						if(!region.getRoleSuffix().startsWith("LATAM")) {
							try {
								aprs = nautilosService.findAprsByRegionAndActiveIngrediant(nautilosRegion,
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprs != null) {
								if (region.getName().startsWith("EMEA")) {
									aprs.setRegion("EMEA:EU");
								}
								results.add(aprs);
							}
						}
						if(region.getName().startsWith("EMEA")){
							try {
								aprsApac = nautilosService.findAprsByRegionAndActiveIngrediant("APAC",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprsApac != null) {
								aprsApac.setRegion("EMEA:Outside EU");
								results.add(aprsApac);
							}
						}
						if(region.getRoleSuffix().startsWith("LATAM")){
							try {
								aprs = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM1",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprs != null) {
								results.add(aprs);
							}
							try {
								aprsLatam2 = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM2",
										activeIngrediant.getCode());
							} catch (Exception e) {
								log.warning(e.getMessage());
							}
							if (aprsLatam2 != null) {
								results.add(aprsLatam2);
							}
						}

					}
				}

			}
			return results;
		}else{
			List<ActiveIngrediant2Product> aiList = activeIngrediant2ProductRepository.findByProduct(product);

			for (ActiveIngrediant2Product ai : aiList) {
				AprsDto aprs = null;
				AprsDto aprsApac = null;
				AprsDto aprsLatam2 = null;
				if(!region.getRoleSuffix().startsWith("LATAM")) {
					try {
						aprs = nautilosService.findAprsByRegionAndActiveIngrediant(nautilosRegion,
								ai.getActiveIngrediant().getCode());

					} catch (Exception e) {
						log.warning(e.getMessage());
					}
					if (aprs != null) {
						if (region.getName().startsWith("EMEA")) {

							aprs.setRegion("EMEA:EU");
						}
						results.add(aprs);
					}
				}
				if(region.getName().startsWith("EMEA")){
					try {
						aprsApac = nautilosService.findAprsByRegionAndActiveIngrediant("APAC",
								ai.getActiveIngrediant().getCode());

					} catch (Exception e) {
						log.warning(e.getMessage());
					}
					if (aprsApac != null) {
						aprsApac.setRegion("EMEA:Outside EU");
						results.add(aprsApac);
					}
				}
				if(region.getRoleSuffix().startsWith("LATAM")){
					try {
						aprs = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM1",
								ai.getActiveIngrediant().getCode());
					} catch (Exception e) {
						log.warning(e.getMessage());
					}
					if (aprs != null) {
						results.add(aprs);
					}
					try {
						aprsLatam2 = nautilosService.findAprsByRegionAndActiveIngrediant("LATAM2",
								ai.getActiveIngrediant().getCode());
					} catch (Exception e) {
						log.warning(e.getMessage());
					}
					if (aprsLatam2 != null) {
						results.add(aprsLatam2);
					}
				}
			}
			return results;
		}

	}

	@ApiOperation(value = "Retrieve Newport project costs of the given segment (given by {" + RestConstants.PARAM_ID
			+ "}).")
	@GetMapping(path = LIST_ONE_SEGMENT_NEWPORT_COSTS)
	@ResponseBody
	public Map<String, Object> getSegmentNewportProjectCosts(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Segment segment = segmentRepository.getOne(id);
		if (StringUtils.isBlank(segment.getNewportDiseasesPestsWeedsId())) {
			throw new IllegalArgumentException("NewportDiseasesPestsWeedsId not set!");
		}
		Map<String, Object> results = newportConnectorService.findProjectCosts(
				segment.getProject().getNewportProjectId(),
				segment.getCrop().getCropGroup().getCropPlatform().getSourceKey(),
				segment.getCrop().getCropGroup().getSourceKey(), segment.getCrop().getSourceKey(),
				segment.getRegion().getSourceKey(), segment.getSubRegion().getSourceKey(),
				segment.getCountry().getSourceKey(), segment.getNewportDiseasesPestsWeedsId());
		return results;
	}

	private boolean isMock() {
		return environment.acceptsProfiles(Profiles.of("mock"));
	}

	@ApiOperation(value = "Retrieve Quickscan assessment entity of the given segment (given by {"
			+ RestConstants.PARAM_ID + "}). May be null.")
	@GetMapping(path = LIST_ONE_SEGMENT_QUICKSCAN_ASSESSMENT)
	@ResponseBody
	public List< Map<String, Object>> getSegmentQuickscanAssessment(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		Segment segment = segmentRepository.getOne(id);
		if (segment.getQuickscanAssessmentId() == null) {
			return null;
		}
		List<Map<String, Object>> quickScanList= new ArrayList<>();

		String asementIdString=segment.getQuickscanAssessmentId();
		String[] assementIds=    StringUtils.split(asementIdString, ',');
		for(String s:assementIds){
			Map<String, Object> result= quickscanService.getAssessmentById(Long.valueOf(s));
			if(result!=null) {
				quickScanList.add(result);
			}
		}

		return quickScanList;
	}

	@ApiOperation(value = "Retrive the mitigation details from the Quickscan application for segment id { "+ RestConstants.PARAM_ID+"  }. May be NULL")
	@GetMapping(path = LIST_ONE_SEGMENT_QUICKSCAN_MITIGATION_MODULE )
	@ResponseBody
	public List<Map<String,Object>> getSegmentQuickscanAssessmentMitigatioModule(@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, value = "ID", type = "long", example = "1")Long id) {
		Segment segment = segmentRepository.getOne(id);
		if(segment.getQuickscanAssessmentId() == null){
			return null;
		}
		String[] quickScanAssessmentIDs = StringUtils.split(segment.getQuickscanAssessmentId(), ',');
		List<Map<String, Object>> quickscanMitagationDetails = new ArrayList<>(quickScanAssessmentIDs.length);
		for (String quickscanId : quickScanAssessmentIDs) {
			Map<String, Object> result = quickscanService.getAssessmentMitigationById(Long.valueOf(quickscanId));
			if (quickscanMitagationDetails != null) {
				quickscanMitagationDetails.add(result);
			}
		}
		return quickscanMitagationDetails;
	}

	@ApiOperation(value= "Retrive all Quickscan assessment Mitigation entities of all segments of the given Project given by { "+RestConstants.PARAM_ID + "}). ")
	@GetMapping(path = LIST_ONE_PROJECT_QUICKSCAN_MITIGATION_MODULE)
	@ResponseBody
	public List<SegmentAssessmentDto> getProjectQuickscanAssessmentMitigationModule(@PathVariable(name=RestConstants.PARAM_ID, required = true) @ApiParam(name=RestConstants.PARAM_ID,required = true, allowEmptyValue = false, value = "id", type = "long", example = "1")Long id){
		List<Segment> segments = segmentRepository.findByProjectIdAndQuickscanAssessmentIdIsNotNull(id);
		List<SegmentAssessmentDto> assessmentMitigation = new ArrayList<>(segments.size());
		for(Segment segment:segments) {
            String[] quickScan = StringUtils.split(segment.getQuickscanAssessmentId(), ",");
            List<Map<String, Object>> assessmentForOneSegment = new ArrayList<>();
            for (String assessmentID : quickScan) {
				Map<String, Object> map = quickscanService.getAssessmentMitigationById(Long.valueOf(assessmentID));
				if (map != null) {
					assessmentForOneSegment.add(map);
				}
			}
                assessmentMitigation.add(new SegmentAssessmentDto(segment.getId(),assessmentForOneSegment));
        }
        return assessmentMitigation;
	}


	@ApiOperation(value = "Retrieve all Quickscan assessment entities of all segments of the given project (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_ONE_PROJECT_QUICKSCAN_ASSESSMENTS)
	@ResponseBody
	public List<SegmentAssessmentDto> getProjectQuickscanAssessments(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		List<Segment> segments = segmentRepository.findByProjectIdAndQuickscanAssessmentIdIsNotNull(id);
		List<SegmentAssessmentDto> results = new ArrayList<SegmentAssessmentDto>(segments.size());
		for (Segment segment : segments) {
			List<Map<String, Object>> assessment=new ArrayList<>();
			String assessmentIdString= segment.getQuickscanAssessmentId();
			String[] assessmentId= StringUtils.split(assessmentIdString, ',');
			for(String s:assessmentId) {
				Map<String, Object> result= quickscanService.getAssessmentById(Long.valueOf(s));
				if(result!=null){
					assessment.add(result);
				}
			}
			SegmentAssessmentDto dto = new SegmentAssessmentDto(segment.getId(), assessment);
			results.add(dto);
		}
		return results;
	}

	@ApiOperation(value = "Find project entities. Pageable and sortable.")
	@PostMapping(path = FIND_PROJECTS)
	@ResponseBody
	public Page<ProjectDto> findProjects(
			@ApiParam(value = "The search request.") @Valid @RequestBody SearchRequest searchRequest) {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		if(roles.isEmpty())
			return null;
		Page<Project> projects = projectRepository.search(searchRequest.getFilterConditions(),
				getPageRequest(searchRequest));
		return RestUtil.toDtoPage(projects, e -> ProjectDto.from(e));
	}

	@ApiOperation(value = "Find segment entities. Pageable and sortable.")
	@PostMapping(path = FIND_SEGMENTS)
	@ResponseBody
	public Page<SegmentDto> findSegments(
			@ApiParam(value = "The search request.") @Valid @RequestBody SearchRequest searchRequest) {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		if(roles.isEmpty())
			return null;
		Page<Segment> segments = segmentRepository.search(searchRequest.getFilterConditions(),
				getPageRequest(searchRequest));




		return RestUtil.toDtoPage(segments, e -> SegmentDto.from(e));

	}

	@ApiOperation(value = "Get export of costs for a given segment (given by {" + RestConstants.PARAM_ID
			+ "}) in a fixed format as Excel file.")
	@GetMapping(path = LIST_ONE_SEGMENT_COSTS_EXPORT)
	@ResponseBody
	public ResponseEntity<StreamingResponseBody> getSegmentCostsExportOfParent(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id)
			throws IOException {
		List<SegmentCost> costs = segmentCostRepository.findBySegmentId(id, Pageable.unpaged()).getContent();
		return downloadCostExportInternal(costs, id);
	}

	@ApiOperation(value = "Export segment entities. Works the same as the search but returns an Excel file with additional project properties. Pageable and sortable.")
	@PostMapping(path = EXPORT_SEGMENTS)
	@ResponseBody
	public ResponseEntity<StreamingResponseBody> exportSegments(
			@ApiParam(value = "The search request.") @Valid @RequestBody SearchRequest searchRequest)
			throws IOException {
//		boolean flag = false;
//		List<String> role = userDetailsHelper.getCurrentUserRoles();
//		for(String roleList:role){
//			if (roleList.equalsIgnoreCase("SuperAdmin") || roleList.equalsIgnoreCase("GlobalAdmin") || roleList.equalsIgnoreCase("RegionalAdmin"))
//				flag = true;
//		}
//		if(flag) {

		Page<Project> projects = projectRepository.search(searchRequest.getFilterConditions(), getPageRequest(searchRequest));



			Page<Segment> segments = segmentRepository.search(searchRequest.getFilterConditionSegment(),
					getPageRequest(searchRequest));
			return downloadInternal(projects,segments);
//		}
//		return null;
	}

	private ResponseEntity<StreamingResponseBody> downloadInternal(Page<Project> page,Page<Segment> pageSegment) throws IOException {
		if (!page.hasContent()) {
			return null;
		}

		StreamingResponseBody responseBody = new StreamingResponseBody() {

			@Override
			public void writeTo(OutputStream outputStream) throws IOException {
				ExportUtil.createFileAndStreamTo(outputStream, page.getContent(),pageSegment.getContent());
			}
		};

		String fileName = "export.xlsx";
		return ResponseEntity.ok().header(CONTENT_DISPOSITION, MessageFormat.format(ATTACHMENT, fileName))
				.body(responseBody);
	}

	private ResponseEntity<StreamingResponseBody> downloadCostExportInternal(List<SegmentCost> costs, Long segmentId)
			throws IOException {
		if (costs.isEmpty()) {
			return null;
		}

		StreamingResponseBody responseBody = new StreamingResponseBody() {

			@Override
			public void writeTo(OutputStream outputStream) throws IOException {
				ExportUtil.createCostsFileAndStreamTo(outputStream, costs);
			}
		};

		String fileName = "cost_export_segment_" + segmentId + ".xlsx";
		return ResponseEntity.ok().header(CONTENT_DISPOSITION, MessageFormat.format(ATTACHMENT, fileName))
				.body(responseBody);
	}

	private PageRequest getPageRequest(SearchRequest searchRequest) {
		PageAndSortCriteria pageInfo = searchRequest.getPageable();
		if (pageInfo == null) {
			return null;
		}
		return RestUtil.createPageRequest(pageInfo);
	}

	/**
	 * Check if current user id matches the given one. If not an exception is
	 * thrown.
	 *
	 * @param user User ID e.g. used in comments; optional (but then an exception is
	 *             thrown)
	 */
	private void checkCurrentUser(String user) {
		// Check if current user's id matches the comment owner's id
		if (userDetailsHelper.isCurrentUser(user) == false) {
			throw new PmodiForbiddenException("Operation performed not by the current user. Not allowed.");
		}
	}

	/**
	 * Check if current user has the general permission to edit/write. If not an
	 * exception is thrown.
	 */
	private void checkWriteAccess() {
		if (!userDetailsHelper.hasWriteAccess()) {
			throw new PmodiForbiddenException("User has no write access.");
		}
	}

	/**
	 * Check if current user has the permission to create projects or segments. If
	 * not an exception is thrown.
	 */
	private void checkProjectOrSegmentCreationAllowed() {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		if (roles != null && roles.contains(Roles.ROLE_SUPER_ADMIN)) {
			return; // allowed
		}
		throw new PmodiForbiddenException("Creation not allowed for current user.");
	}

}
