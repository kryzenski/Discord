package com.bayer.pmodi.masterlist.config.security;

/**
 * @author juergen.panser
 *
 */
public interface ExternalApiAccessHelper {

	/**
	 * Get Nautilos REST end point access token
	 * 
	 * @return Nautilos access token
	 * @throws Exception
	 */
	String getNautilosAccessToken() throws Exception;

	/**
	 * Get Quickscan access token. Only used to pass through the gateways!
	 * 
	 * @return Access token
	 * @throws Exception
	 */
	String getQuickscanAccessToken() throws Exception;

	/**
	 * Get RegPrime REST end point access token
	 * 
	 * @return RegPrime access token
	 * @throws Exception
	 */
	String getRegPrimeAccessToken(String token) throws Exception;

	/**
	 * @return Newport connector access token
	 * @throws Exception
	 */
	String getNewportConnectorAccessToken() throws Exception;

}