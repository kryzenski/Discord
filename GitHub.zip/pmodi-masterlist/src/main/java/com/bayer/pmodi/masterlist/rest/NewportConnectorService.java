package com.bayer.pmodi.masterlist.rest;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;

import com.bayer.pmodi.masterlist.config.webclients.WebClients;
import com.bayer.pmodi.masterlist.rest.RestUtil.TypedMap;

@Service
public class NewportConnectorService {

	public static final String PARAM_PROJECT_ID = "newportProjectId";
	public static final String PARAM_REGION = "regionId";
	public static final String PARAM_SUBREGION = "subRegionId";
	public static final String PARAM_COUNTRY = "countryISO";
	public static final String PARAM_CROP_PLATFORM = "cropPlatformId";
	public static final String PARAM_CROP_GROUP = "cropGroupId";
	public static final String PARAM_CROP = "cropId";
	public static final String PARAM_TARGET = "diseasesPestsWeedsId";

	private static final String PLACEHOLDER_ID = "{" + RestConstants.PARAM_ID + "}";

	private static final String PATH_PROJECT_COSTS = "/project/project/" + PLACEHOLDER_ID + "/segment/projectCosts";

	@Autowired
	private WebClients webClients;

	private WebClient getWebClient() {
		return webClients.getNewportConnectorWebClient();
	}

	public Map<String, Object> findProjectCosts(String newportProjectId, String cropPlatformId, String cropGroupId,
			String cropId, //
			String region, String subRegion, String country, String target) {
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add(PARAM_REGION, region);
		params.add(PARAM_SUBREGION, subRegion);
		params.add(PARAM_COUNTRY, country);
		params.add(PARAM_CROP_PLATFORM, cropPlatformId);
		params.add(PARAM_CROP_GROUP, cropGroupId);
		params.add(PARAM_CROP, cropId);
		params.add(PARAM_TARGET, target);

		final Map<String, Object> results;
		try {
			String uri = StringUtils.replace(PATH_PROJECT_COSTS, PLACEHOLDER_ID, newportProjectId);
			results = getWebClient().get().uri(uriBuilder -> uriBuilder.path(uri).queryParams(params).build()) //
					.retrieve() //
					.bodyToMono(TypedMap.class) //
					.block();
		} catch (Exception wex) {
			// TODO: do we need special error handling?
			// if (wex instanceof WebClientResponseException) {
			// if (((WebClientResponseException) wex).getStatusCode() ==
			// HttpStatus.NOT_FOUND) {
			// throw new IllegalArgumentException("No project costs found!");
			// }
			// }
			throw wex;
		}
		return results;
	}

}
