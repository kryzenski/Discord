package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a project question definition which are
 * allowed to be updated.
 */
@Data
@ToString
@EqualsAndHashCode
public class ProjectQuestionDefinitionEditableFieldsDto {

	public static ProjectQuestionDefinitionEditableFieldsDto from(ProjectQuestionDefinition src) {
		ProjectQuestionDefinitionEditableFieldsDto result = new ProjectQuestionDefinitionEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(ProjectQuestionDefinition src, ProjectQuestionDefinitionEditableFieldsDto target) {
		target.setActive(src.isActive());
		target.setQuestionText(src.getQuestionText());
		target.setPos(src.getPos());
	}

	public void applyUpdateablePropertiesTo(ProjectQuestionDefinition target) {
		target.setActive(isActive());
		target.setQuestionText(getQuestionText());
		target.setPos(getPos());
	}

	private boolean isActive;

	private String questionText;

	private Integer pos;

}
