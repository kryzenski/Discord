package com.bayer.pmodi.masterlist.rest.model;

import java.time.OffsetDateTime;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.SegmentCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a segment cost which are allowed to be
 * updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString
@EqualsAndHashCode
public class SegmentCostEditableFieldsDto {

	public static SegmentCostEditableFieldsDto from(SegmentCost src) {
		SegmentCostEditableFieldsDto result = new SegmentCostEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentCost src, SegmentCostEditableFieldsDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public void applyUpdateablePropertiesTo(SegmentCost target) {
		BeanUtils.copyProperties(this, target);
	}

	private Double agronomicDevelopment;

	private Double environmentalSafety;

	private Double formulationTechnology;

	private Double productSupply;

	private Double launchMarketing;

	private Double regulatoryAffairs;

	private Double registrationFees;

	private Double research;

	private Double humanSafety;

	private Double otherCosts;

	private Double totalProjectCosts;

	private Double fieldDevelopment;

	private Double customerAdvisory;

	private Double rocsEnvironmentalResearch;

	private OffsetDateTime lastModifiedOn;

}
