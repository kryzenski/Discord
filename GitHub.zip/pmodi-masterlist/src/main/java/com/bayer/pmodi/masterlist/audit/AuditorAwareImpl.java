package com.bayer.pmodi.masterlist.audit;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;

@Component("auditorProvider")
public class AuditorAwareImpl implements AuditorAware<String> {

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@Override
	public Optional<String> getCurrentAuditor() {
		return Optional.of(userDetailsHelper.getCurrentUserId());
	}

}
