package com.bayer.pmodi.masterlist.rest.controller;

import java.sql.Date;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.audit.AuditUtil;
import com.bayer.pmodi.masterlist.model.AbstractVersionedEntity;
import com.bayer.pmodi.masterlist.model.EntityRevision;
import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.ProjectQuestion;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SegmentCost;
import com.bayer.pmodi.masterlist.model.SegmentQuestion;
import com.bayer.pmodi.masterlist.rest.RestConstants;
import com.bayer.pmodi.masterlist.rest.model.ProjectDto;
import com.bayer.pmodi.masterlist.rest.model.ProjectQuestionDto;
import com.bayer.pmodi.masterlist.rest.model.RevisionDataDto;
import com.bayer.pmodi.masterlist.rest.model.RevisionFieldValueDto;
import com.bayer.pmodi.masterlist.rest.model.RevisionInfoDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentCostDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentQuestionDto;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(AuditLogController.ROOT_URL)
public class AuditLogController {

	public static final String ROOT_URL = "/history";

	private static final String LIST_PROJECTS = "projects";
	private static final String LIST_SEGMENTS = "segments";
	private static final String LIST_MODIFIED_FIELD_REVISIONS = "modified-field/revisions";
	private static final String LIST_MODIFIED_FIELD_REVISIONS_GROUPED = "modified-field/grouped-revisions";
	private static final String REVISION_AT_DATE = "at-date";

	private static final String PARAM_FIELD_NAME = "fieldName";
	private static final String PARAM_DATE = "date";

	private static final String LIST_PROJECT_MODIFIED_FIELD = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID + "}/"
			+ LIST_MODIFIED_FIELD_REVISIONS;
	private static final String LIST_PROJECT_MODIFIED_FIELD_GROUPED = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID
			+ "}/" + LIST_MODIFIED_FIELD_REVISIONS_GROUPED;
	private static final String PROJECT_AT_DATE = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID + "}/"
			+ REVISION_AT_DATE;

	private static final String LIST_PROJECT_QUESTION_MODIFIED_FIELD = LIST_PROJECTS + "/questions/{"
			+ RestConstants.PARAM_ID + "}/" + LIST_MODIFIED_FIELD_REVISIONS;
	private static final String PROJECT_QUESTIONS_AT_DATE = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID
			+ "}/questions/" + REVISION_AT_DATE;
	private static final String PROJECT_SEGMENTS_AT_DATE = LIST_PROJECTS + "/{" + RestConstants.PARAM_ID + "}/"
			+ LIST_SEGMENTS + "/" + REVISION_AT_DATE;

	private static final String LIST_SEGMENT_MODIFIED_FIELD = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID + "}/"
			+ LIST_MODIFIED_FIELD_REVISIONS;
	private static final String LIST_SEGMENT_MODIFIED_FIELD_GROUPED = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID
			+ "}/" + LIST_MODIFIED_FIELD_REVISIONS_GROUPED;
	private static final String SEGMENT_AT_DATE = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID + "}/"
			+ REVISION_AT_DATE;

	private static final String LIST_SEGMENT_QUESTION_MODIFIED_FIELD = LIST_SEGMENTS + "/questions/{"
			+ RestConstants.PARAM_ID + "}/" + LIST_MODIFIED_FIELD_REVISIONS;
	private static final String SEGMENT_QUESTIONS_AT_DATE = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID
			+ "}/questions/" + REVISION_AT_DATE;

	private static final String SEGMENT_COSTS_AT_DATE = LIST_SEGMENTS + "/{" + RestConstants.PARAM_ID + "}/costs/"
			+ REVISION_AT_DATE;

	// Hint: use AuditUtilTest to generate the strings
	private static final String AUDITED_PROJECT_FIELDS_WITH_MODIFIED_FLAG = "fsPtrsScoreRmk,fsPtrsScore,ftPtrsScoreRmk,ftPtrsScore,overallPtrsScore,rsEnsaPtrsScore,rsEnsaPtrsScoreRmk,rsDietaryPtrsScore,rsDietaryPtrsScoreRmk,rsOperatorPtrsScore,rsOperatorPtrsScoreRmk,rsRegAffairsScore,rsRegAffairsScoreRmk,rsPtrsScore,rsPtrsScoreRmk,prioritizationType,prioritizationRmk,prioritizationGovernance,rsGovernance,globalPortfolioGuidance,globalRegGuidance,specificProjectFramework,labelForSafeUse,thirdPartyAiRegCheck,developmentFunctions,intelectualPropertyAssessment,strategicFitRmk";
	private static final String AUDITED_PROJECT_QUESTION_FIELDS_WITH_MODIFIED_FLAG = "answer";
	private static final String AUDITED_SEGMENT_FIELDS_WITH_MODIFIED_FLAG = "fsPtrsScoreRmk,fsPtrsScore,rsRegPtrsScoreRmk,rsRegPtrsScore,ptrsSegmentOverallScore,prioritizationType,prioritizationRmk,prioritizationGovernance,strategicFitRmk,launchDate,submissionDate";
	private static final String AUDITED_SEGMENT_QUESTION_FIELDS_WITH_MODIFIED_FLAG = "answer";

	private static final List<String> ALLOWED_PROJECT_FIELDS = AuditUtil
			.getAuditedFieldsWithModifiedFlag(Project.class);
	private static final List<String> ALLOWED_PROJECT_QUESTION_FIELDS = AuditUtil
			.getAuditedFieldsWithModifiedFlag(ProjectQuestion.class);
	private static final List<String> ALLOWED_SEGMENT_FIELDS = AuditUtil
			.getAuditedFieldsWithModifiedFlag(Segment.class);
	private static final List<String> ALLOWED_SEGMENT_QUESTION_FIELDS = AuditUtil
			.getAuditedFieldsWithModifiedFlag(SegmentQuestion.class);

	private static List<String> fieldNameAllowList = Arrays.asList("globalPortfolioGuidance", "globalRegGuidance",
			"labelForSafeUse", "developmentFunctions", "specificProjectFramework", "thirdPartyAiRegCheck",
			"sustainabilityAssessment", "intelectualPropertyAssessment", "strategicFitRmk", "prioritizationGovernance",
			"prioritizationType", "prioritizationRmk", "techResponsability", "techRecommendation", "solRecommendation",
			"scienceRecommendation", "ftPtrsScore", "ftPtrsScoreRmk", "rsPtrsScoreRmk", "fsPtrsScore", "fsPtrsScoreRmk",
			"rsEnsaPtrsScore", "rsEnsaPtrsScoreRmk", "rsOperatorPtrsScore", "rsOperatorPtrsScoreRmk", "rsDietaryPtrsScore",
			"rsDietaryPtrsScoreRmk", "rsRegAffairsScore", "rsRegAffairsScoreRmk",
			"submissionDate", "launchDate", "rsRegPtrsScore", "rsRegPtrsScoreRmk", "rsOccupationalResidentialExposurePtrsScore",
			"rsOccupationalResidentialExposurePtrsScoreRmk", "rsRegDietaryPtrsScore", "rsRegDietaryPtrsScoreRmk",
			"rsToxicologyPtrsScore", "rsToxicologyPtrsScoreRmk", "rsEcotoxPtrsScore", "rsEcotoxPtrsScoreRmk",
			"rsEfatePtrsScore", "rsEfatePtrsScoreRmk", "rsRegistrationPtrsScore", "rsRegistrationPtrsScoreRmk","techStatus");



	@PersistenceContext
	private EntityManager entityManager;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get list of revisions of several given field of a given project (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_PROJECT_MODIFIED_FIELD_GROUPED)
	@ResponseBody
	public Collection<RevisionDataDto> getModifiedProjectFieldRevisionsGrouped(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name") String[] fieldName) {
		return getModifiedFieldsGrouped(Project.class, id, fieldName, ALLOWED_PROJECT_FIELDS);
	}

	@ApiOperation(value = "Get list of revisions of a given field of a given project (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_PROJECT_MODIFIED_FIELD)
	@ResponseBody
	public List<RevisionInfoDto> getModifiedProjectFieldRevisions(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name", example = "fsPtrsScoreRmk", allowableValues = AUDITED_PROJECT_FIELDS_WITH_MODIFIED_FLAG) String fieldName) {
		return getModifiedFields(Project.class, id, fieldName, ALLOWED_PROJECT_FIELDS);
	}

	@ApiOperation(value = "Get list of revisions of a given field of a given project question (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_PROJECT_QUESTION_MODIFIED_FIELD)
	@ResponseBody
	public List<RevisionInfoDto> getModifiedProjectQuestionFieldRevisions(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name", example = "answer", allowableValues = AUDITED_PROJECT_QUESTION_FIELDS_WITH_MODIFIED_FLAG) String fieldName) {
		return getModifiedFields(ProjectQuestion.class, id, fieldName, ALLOWED_PROJECT_QUESTION_FIELDS);
	}

	@ApiOperation(value = "Get list of revisions of several given field of a given segment (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_SEGMENT_MODIFIED_FIELD_GROUPED)
	@ResponseBody
	public Collection<RevisionDataDto> getModifiedSegmentFieldRevisionsGrouped(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name") String[] fieldName) {
		return getModifiedFieldsGrouped(Segment.class, id, fieldName, ALLOWED_SEGMENT_FIELDS);
	}

	@ApiOperation(value = "Get list of revisions of a given field of a given segment (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_SEGMENT_MODIFIED_FIELD)
	@ResponseBody
	public List<RevisionInfoDto> getModifiedSegmentFieldRevisions(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name", example = "fsPtrsScoreRmk", allowableValues = AUDITED_SEGMENT_FIELDS_WITH_MODIFIED_FLAG) String fieldName) {
		return getModifiedFields(Segment.class, id, fieldName, ALLOWED_SEGMENT_FIELDS);
	}

	@ApiOperation(value = "Get list of revisions of a given field of a given segment question (given by {"
			+ RestConstants.PARAM_ID + "}).")
	@GetMapping(path = LIST_SEGMENT_QUESTION_MODIFIED_FIELD)
	@ResponseBody
	public List<RevisionInfoDto> getModifiedSegmentQuestionFieldRevisions(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, value = "Field name", example = "answer", allowableValues = AUDITED_SEGMENT_QUESTION_FIELDS_WITH_MODIFIED_FLAG) String fieldName) {
		return getModifiedFields(SegmentQuestion.class, id, fieldName, ALLOWED_SEGMENT_QUESTION_FIELDS);
	}

	@ApiOperation(value = "Get the project (given by {" + RestConstants.PARAM_ID + "}) as it was at the given date.")
	@GetMapping(path = PROJECT_AT_DATE)
	@ResponseBody
	public ProjectDto getProjectAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		Project result = getRevisionAtDate(Project.class, id, date);
		return ProjectDto.from(result);
	}

	@ApiOperation(value = "Get the questions of a project (given by {" + RestConstants.PARAM_ID
			+ "}) as they were at the given date.")
	@GetMapping(path = PROJECT_QUESTIONS_AT_DATE)
	@ResponseBody
	public List<ProjectQuestionDto> getProjectQuestionsAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		List<ProjectQuestion> results = getEntitiesAtRevision(ProjectQuestion.class, "project_id", id, date);
		return results.stream()
				.sorted((p1, p2) -> p1.getProjectQuestionDefinition().getPos()
						.compareTo(p2.getProjectQuestionDefinition().getPos()))
				.map(e -> ProjectQuestionDto.from(e)).collect(Collectors.toList());
	}

	@ApiOperation(value = "Get the segments of a project (given by {" + RestConstants.PARAM_ID
			+ "}) as they were at the given date.")
	@GetMapping(path = PROJECT_SEGMENTS_AT_DATE)
	@ResponseBody
	public List<SegmentDto> getProjectSegmentsAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		List<Segment> results = getEntitiesAtRevision(Segment.class, "project_id", id, date);
		return results.stream().sorted((s1, s2) -> s1.getId().compareTo(s2.getId())).map(e -> SegmentDto.from(e))
				.collect(Collectors.toList());
	}

	@ApiOperation(value = "Get the segment (given by {" + RestConstants.PARAM_ID + "}) as it was at the given date.")
	@GetMapping(path = SEGMENT_AT_DATE)
	@ResponseBody
	public SegmentDto getSegmentAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		Segment result = getRevisionAtDate(Segment.class, id, date);
		return SegmentDto.from(result);
	}

	@ApiOperation(value = "Get the questions of a segment (given by {" + RestConstants.PARAM_ID
			+ "}) as they were at the given date.")
	@GetMapping(path = SEGMENT_QUESTIONS_AT_DATE)
	@ResponseBody
	public List<SegmentQuestionDto> getSegmentQuestionsAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		List<SegmentQuestion> results = getEntitiesAtRevision(SegmentQuestion.class, "segment_id", id, date);
		return results.stream()
				.sorted((p1, p2) -> p1.getSegmentQuestionDefinition().getPos()
						.compareTo(p2.getSegmentQuestionDefinition().getPos()))
				.map(e -> SegmentQuestionDto.from(e)).collect(Collectors.toList());
	}

	@ApiOperation(value = "Get the segment costs of a segment (given by {" + RestConstants.PARAM_ID
			+ "}) as they were at the given date.")
	@GetMapping(path = SEGMENT_COSTS_AT_DATE)
	@ResponseBody
	public List<SegmentCostDto> getSegmentCostsAtDate(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id,
			@RequestParam(required = true) @ApiParam(name = PARAM_DATE, required = true, value = "Date", example = "2020-12-31T23:59:59Z") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime date) {
		List<SegmentCost> results = getEntitiesAtRevision(SegmentCost.class, "segment_id", id, date);
		return results.stream().map(e -> SegmentCostDto.from(e)).collect(Collectors.toList());
	}

	private <T> List<T> getEntitiesAtRevision(Class<T> clazz, String property, Long projectId, OffsetDateTime date) {
		java.util.Date dateAsOldJavaDate = Date.from(date.toInstant());
		AuditReader reader = AuditReaderFactory.get(entityManager);
		AuditQuery query = reader.createQuery()
				.forEntitiesAtRevision(clazz, reader.getRevisionNumberForDate(dateAsOldJavaDate))
				.add(AuditEntity.property(property).eq(projectId));
		@SuppressWarnings("unchecked")
		List<T> revisions = query.getResultList();
		return revisions;
	}

	private <T extends AbstractVersionedEntity> T getRevisionAtDate(Class<T> clazz, Long id, OffsetDateTime date) {
		java.util.Date dateAsOldJavaDate = Date.from(date.toInstant());
		AuditReader reader = AuditReaderFactory.get(entityManager);
		AuditQuery query = reader.createQuery().forRevisionsOfEntity(clazz, false, true)
				.add(AuditEntity.revisionNumber().maximize().computeAggregationInInstanceContext()
						.add(AuditEntity.id().eq(id))
						.add(AuditEntity.revisionNumber().le(reader.getRevisionNumberForDate(dateAsOldJavaDate))));
		Object[] revision = (Object[]) query.getSingleResult();
		// Handle deleted entity as if it never exists -> return 404
		RevisionType type = (RevisionType) revision[2];
		if (RevisionType.DEL.equals(type)) {
			throw new NoResultException("No result found for id " + id + "!");
		}
		@SuppressWarnings("unchecked")
		T entity = (T) revision[0];
		return entity;
	}

	private Collection<RevisionDataDto> getModifiedFieldsGrouped(Class<?> clazz, Long id, String[] fieldName,
			List<String> allowedFields) {
		if (fieldName == null || fieldName.length == 0) {
			throw new IllegalArgumentException("Mandatory parameter (field name) missing!");
		}
		SortedMap<Integer, RevisionDataDto> map = new TreeMap<>();
		for (String fn : fieldName) {
			List<RevisionInfoDto> revs = getModifiedFields(clazz, id, fn, allowedFields);
			for (RevisionInfoDto rev : revs) {
				RevisionDataDto entry = map.get(Integer.valueOf(rev.getRevisionId()));
				RevisionFieldValueDto change = new RevisionFieldValueDto(fn, rev.getOperation(),
						rev.getRevisionValue());
				if (entry == null) {
					entry = RevisionDataDto.from(rev);
					map.put(Integer.valueOf(rev.getRevisionId()), entry);
				}
				entry.addChange(change);
			}
		}
		return map.values();
	}

	private List<RevisionInfoDto> getModifiedFields(Class<?> clazz, Long id, String fieldName,
			List<String> allowedFields) {
		if (clazz == null || id == null || fieldName == null) {
			throw new IllegalArgumentException("Mandatory parameter missing!");
		}
		if (allowedFields != null && !allowedFields.contains(fieldName)) {
			throw new IllegalArgumentException("Field name '" + fieldName + "' is not supported for class '"
					+ clazz.getSimpleName() + "'! Allowed values are: " + StringUtils.join(allowedFields, ',') + ".");
		}

		AuditReader reader = AuditReaderFactory.get(entityManager);
		AuditQuery query = reader.createQuery().forRevisionsOfEntity(clazz, false, true).add(AuditEntity.id().eq(id))
				.add(AuditEntity.property(fieldName).hasChanged());
		@SuppressWarnings("unchecked")
		List<Object[]> revisions = query.getResultList();

		List<RevisionInfoDto> results = new ArrayList<>();
		for (Object[] o : revisions) {
			AbstractVersionedEntity entity = (AbstractVersionedEntity) o[0];
			EntityRevision revision = (EntityRevision) o[1];
			RevisionType revType = (RevisionType) o[2];
			String refTypeDescription = getRefTypeDescription(revType);
			Object propText = getFieldValue(entity, fieldName);
			RevisionInfoDto r = new RevisionInfoDto(refTypeDescription, revision.getId(), revision.getModifiedBy(),
					revision.getRevisionDate().toInstant(), propText);
			results.add(r);
		}
		return results;
	}

	private static Object getFieldValue(Object p, String fieldName) {
		try {
//			if(!fieldNameAllowList.contains(fieldName)){
//				throw new IllegalArgumentException("Field'" + fieldName + "' not supported.");
//			}
			Object prop = PropertyUtils.getSimpleProperty(p, fieldName);
			return prop;
		} catch (Exception e) {
			throw new IllegalArgumentException("Field name '" + fieldName + "' not supported.", e);
		}
	}

	private static String getRefTypeDescription(RevisionType revType) {
		if (RevisionType.ADD.equals(revType)) {
			return "Created";
		} else if (RevisionType.MOD.equals(revType)) {
			return "Modified";
		} else if (RevisionType.DEL.equals(revType)) {
			return "Deleted";
		}
		throw new IllegalArgumentException("RevisionType not supported.");
	}
}
