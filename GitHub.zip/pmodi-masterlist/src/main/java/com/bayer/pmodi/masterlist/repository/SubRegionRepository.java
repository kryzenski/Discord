package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.SubRegion;

public interface SubRegionRepository extends BaseRepository<SubRegion> {

	SubRegion findByName(String name);

	Page<SubRegion> findByIsPlaceholder(boolean isPlaceholder, Pageable pageInfo);

}
