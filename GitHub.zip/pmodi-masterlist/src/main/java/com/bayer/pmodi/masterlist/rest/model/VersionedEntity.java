package com.bayer.pmodi.masterlist.rest.model;

public interface VersionedEntity {

	Integer getVersion();

	void setVersion(Integer newVersion);

}
