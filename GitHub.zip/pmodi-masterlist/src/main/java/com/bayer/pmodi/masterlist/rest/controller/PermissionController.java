package com.bayer.pmodi.masterlist.rest.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.authorization.Groups;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(PermissionController.ROOT_URL)
public class PermissionController {

	public static final String ROOT_URL = "/permission";

	private static final String LIST_LOCKED_GROUPS = "locked-groups";
	private static final String LOCK_GROUPS = LIST_LOCKED_GROUPS + "/lock";
	private static final String UNLOCK_GROUPS = LIST_LOCKED_GROUPS + "/unlock";

	@Autowired
	private PermissionService permissionService;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get locked groups.")
	@GetMapping(path = LIST_LOCKED_GROUPS)
	@ResponseBody
	public Collection<String> getLockedGroups() {
		return permissionService.getLockedGroups();
	}

	@ApiOperation(value = "Lock the given groups. Other groups stay untouched.")
	@PatchMapping(path = LOCK_GROUPS)
	@ResponseBody
	public void lockGroups( //
			@RequestBody @ApiParam("JSON definition of the groups to lock. Available groups are: "
					+ Groups.DESCRIPTION_ALL_GROUPS) List<String> groups) {
		permissionService.lockGroups(groups);
	}

	@ApiOperation(value = "Unlock the given groups. Other groups stay untouched.")
	@PatchMapping(path = UNLOCK_GROUPS)
	@ResponseBody
	public void unlockGroups( //
			@RequestBody @ApiParam("JSON definition of the groups to unlock. Available groups are: "
					+ Groups.DESCRIPTION_ALL_GROUPS) List<String> groups) {
		permissionService.unlockGroups(groups);
	}

}
