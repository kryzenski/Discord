package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.Segment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentWithCropDto extends SegmentDto {

	public static SegmentWithCropDto from(Segment src) {
		SegmentWithCropDto result = new SegmentWithCropDto();
		SegmentDto.mapOwn(src, result);
		SegmentEditableFieldsDto.mapOwn(src, result);
		NewSegmentDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Segment src, SegmentWithCropDto result) {
		result.setCrop(CropInfoDto.from(src.getCrop()));
	}

}