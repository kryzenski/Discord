package com.bayer.pmodi.masterlist.search;

import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.bayer.pmodi.masterlist.model.enums.CodeEnum;

public enum TextOperatorEnum implements CodeEnum<TextOperatorEnum> {

	EQUALS("equals", "equals"), //
	IS_NULL("isNull", "is null"), //
	CONTAINS("contains", "contains"), //
	IN("in", "in");

	private String label;
	private String code;
	private static Map<String, TextOperatorEnum> CODE_MAP = new LinkedHashMap<String, TextOperatorEnum>();

	static {
		for (TextOperatorEnum e : EnumSet.allOf(TextOperatorEnum.class)) {
			CODE_MAP.put(e.code(), e);
		}
	}

	/**
	 * Constructor.
	 * 
	 * @param code  The code
	 * @param label The display label
	 */
	TextOperatorEnum(final String code, final String label) {
		this.code = code;
		this.label = label;
	}

	/**
	 * @return The code
	 */
	@Override
	public String code() {
		return this.code;
	}

	/**
	 * @return The display label
	 */
	@Override
	public String label() {
		return this.label;
	}

	/**
	 * Returns enumeration value for the given database code
	 * 
	 * @param code The code
	 * @return the enumeration or null if code is null
	 * @throws IllegalArgumentException if code is invalid
	 */
	public static TextOperatorEnum fromCode(final String code) {
		if (code == null) {
			return null;
		}
		TextOperatorEnum en = CODE_MAP.get(code);
		if (en == null) {
			throw new IllegalArgumentException("code \"" + code + "\" does not exist in domain");
		}
		return en;
	}

	/**
	 * Returns the set of all valid database codes
	 * 
	 * @return all codes
	 */
	public static Set<String> codes() {
		return Collections.unmodifiableSet(CODE_MAP.keySet());
	}

}
