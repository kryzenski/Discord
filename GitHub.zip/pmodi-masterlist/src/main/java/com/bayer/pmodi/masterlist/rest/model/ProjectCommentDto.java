package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.ProjectComment;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties()
public class ProjectCommentDto extends NewProjectCommentDto {

	public static ProjectCommentDto from(ProjectComment src) {
		ProjectCommentDto result = new ProjectCommentDto();
		ProjectCommentEditableFieldsDto.mapOwn(src, result);
		NewProjectCommentDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(ProjectComment src, ProjectCommentDto result) {
		result.setId(src.getId());
		result.setVersion(src.getVersion());
		result.setUser(src.getUser());
	}

	@NotNull
	private Long id;

	@NotNull
	private Integer version;

	private String user;

}