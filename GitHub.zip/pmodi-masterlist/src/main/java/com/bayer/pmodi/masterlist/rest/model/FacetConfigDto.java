package com.bayer.pmodi.masterlist.rest.model;

import java.util.List;
import java.util.stream.Collectors;

import com.bayer.pmodi.masterlist.model.FacetConfig;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class FacetConfigDto {

	public static FacetConfigDto from(FacetConfig src) {
		FacetConfigDto result = new FacetConfigDto();
		result.setDataType(src.getDataType());
		result.setEndpointAddress(src.getEndpointAddress());
		result.setEntityType(src.getEntityType());
		result.setFacetName(src.getFacetName());
		result.setFacetType(src.getFacetType());
		result.setFieldName(src.getFieldName());
		result.setGroupName(src.getGroupName());
		result.setId(src.getId());
		result.setMultiSelect(src.isMultiSelect());
		if (src.getValues() != null) {
			List<String> val = src.getValues().stream().map(av -> av.getValue()).collect(Collectors.toList());
			result.setValues(val);
		}
		return result;
	}

	private Long id;

	private String facetName;

	private String entityType;

	private String fieldName;

	private String dataType;

	private String facetType;

	private String groupName;

	private boolean multiSelect;

	private String endpointAddress;

	private List<String> values;

}