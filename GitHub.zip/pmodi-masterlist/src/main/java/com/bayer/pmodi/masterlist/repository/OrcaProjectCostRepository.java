package com.bayer.pmodi.masterlist.repository;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.bayer.pmodi.masterlist.model.OrcaProjectCost;

public interface OrcaProjectCostRepository extends BaseRepository<OrcaProjectCost> {

	Page<OrcaProjectCost> findByProjectId(String projectId, Pageable page);

	@Modifying
	@Transactional
	@Query("delete from OrcaProjectCost o")
	void deleteAllCosts();

}
