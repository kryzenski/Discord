package com.bayer.pmodi.masterlist.repository;

import com.bayer.pmodi.masterlist.model.Product;

public interface ProductRepository extends BaseRepository<Product> {

	Product findBySpecNumber(String specNumber);

	Product findByProductLineText(String plt);

	Product findByProductLineTextIgnoreCase(String plt);

}
