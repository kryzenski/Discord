package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class ProjectQuestion extends AbstractVersionedEntity {

	@Column(nullable = false)
	@Audited(withModifiedFlag = true)
	private boolean answer;

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "PROJECT_ID", referencedColumnName = "ID", nullable = false)
	private Project project;

	@JsonIgnore
	@ManyToOne(optional = false)
	@JoinColumn(name = "PROJECT_QUESTION_DEFINITION_ID", referencedColumnName = "ID", nullable = false)
	private ProjectQuestionDefinition projectQuestionDefinition;

}