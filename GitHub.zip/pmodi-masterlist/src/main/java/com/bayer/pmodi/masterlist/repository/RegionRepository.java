package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.Region;

public interface RegionRepository extends BaseRepository<Region> {

	Region findByName(String name);

	Page<Region> findByIsPlaceholder(boolean isPlaceholder, Pageable pageInfo);

}
