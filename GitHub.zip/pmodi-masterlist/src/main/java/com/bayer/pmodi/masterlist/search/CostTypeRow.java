package com.bayer.pmodi.masterlist.search;

import java.util.HashMap;

public class CostTypeRow {

	private String costTypeName;
	private HashMap<String, Double> values = new HashMap<String, Double>();

	public CostTypeRow(String name) {
		this.costTypeName = name;
	}

	public String getCostTypeName() {
		return costTypeName;
	}

	public Double getCostValueForYear(String year) {
		return values.get(year);
	}

	public void add(String year, Double value) {
		values.put(year, value);
	}

}
