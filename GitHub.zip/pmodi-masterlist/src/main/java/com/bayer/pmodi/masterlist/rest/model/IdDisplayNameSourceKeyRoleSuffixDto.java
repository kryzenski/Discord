package com.bayer.pmodi.masterlist.rest.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class IdDisplayNameSourceKeyRoleSuffixDto {

    private Long id;
    private String displayName;
    private String sourceKey;
    private String roleSuffix;

}
