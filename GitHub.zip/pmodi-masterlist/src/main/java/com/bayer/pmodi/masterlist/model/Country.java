package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class Country extends AbstractAuditedEntity {

	@NotNull
	@Column(nullable = false)
	private String sourceKey;

	@NotNull
	@Column(nullable = false)
	private String name;

	@Column(nullable = false)
	private boolean isPlaceholder;

	@Column(nullable = true)
	private boolean flag;

	public boolean getFlag() {
		return flag;
	}
}