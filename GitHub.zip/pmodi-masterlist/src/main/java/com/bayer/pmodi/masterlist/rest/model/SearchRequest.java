package com.bayer.pmodi.masterlist.rest.model;

import java.util.List;

import com.bayer.pmodi.masterlist.search.SearchCriterion;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class SearchRequest {
	private PageAndSortCriteriaSortedById pageable;
	private List<SearchCriterion> filterConditions = null;
	private List<SearchCriterion> filterConditionSegment = null;
}
