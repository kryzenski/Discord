package com.bayer.pmodi.masterlist.rest.model.regprime;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class RegulatoryActionDto {

	private String registrationZNumber;
	private String registrationBusinessGroupCode;
	private String registrationPhaseCode;
	private Long regulatoryActionSequenceNumber;
	private String regulatoryActionTypeCode;
	private String regulatoryActionStatusCode;
	private String regulatoryActionComment;
	private LocalDate actualSubmission;
	private LocalDate registrationExpected;
	private LocalDate registrationGranted;
	private LocalDate submissionPlanned;

}
