package com.bayer.pmodi.masterlist.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.model.FacetConfig;
import com.bayer.pmodi.masterlist.repository.FacetConfigRepository;
import com.bayer.pmodi.masterlist.repository.ProjectRepository;
import com.bayer.pmodi.masterlist.repository.SegmentRepository;
import com.bayer.pmodi.masterlist.rest.RestConstants;
import com.bayer.pmodi.masterlist.rest.RestUtil;
import com.bayer.pmodi.masterlist.rest.model.FacetConfigDto;
import com.bayer.pmodi.masterlist.rest.model.PageAndSortCriteriaSortedById;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(UiController.ROOT_URL)
public class UiController {

	public static final String ROOT_URL = "/ui";

	private static final String PARAM_ENTITY_TYPE = "entityType";
	private static final String PARAM_FIELD_NAME = "fieldName";
	private static final String PARAM_LIMIT = "limit";
	private static final String PARAM_STARTS_WITH = "startsWith";
	private static final String PARAM_IS_CASE_SENSITIVE = "isCaseSensitive";

	private static final String LIST_FACET_CONFIGS = "facet-configs";
	private static final String ONE_FACET_CONFIG = LIST_FACET_CONFIGS + "/{" + RestConstants.PARAM_ID + "}";

	private static final String LIST_DISTINCT_BY_FIELD = "distinct-properties";;

	private static final String USER_INFO = "current-user";;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@Autowired
	private FacetConfigRepository facetConfigRepository;

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@ApiOperation(value = "Ping method.")
	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong " + System.currentTimeMillis();
	}

	@ApiOperation(value = "Get list of facet config entities. Pageable and sortable.")
	@GetMapping(path = LIST_FACET_CONFIGS)
	@ResponseBody
	public Page<FacetConfigDto> getFacetConfigs(PageAndSortCriteriaSortedById pageAndSortParameters) {
		PageRequest pageInfo = RestUtil.createPageRequest(pageAndSortParameters);
		Page<FacetConfig> results = facetConfigRepository.findAll(pageInfo);
		return RestUtil.toDtoPage(results, e -> FacetConfigDto.from(e));
	}

	@ApiOperation(value = "Retrieve a single facet config entity (given by {" + RestConstants.PARAM_ID + "}).")
	@GetMapping(path = ONE_FACET_CONFIG)
	@ResponseBody
	public FacetConfigDto getFacetConfig(
			@PathVariable(name = RestConstants.PARAM_ID, required = true) @ApiParam(name = RestConstants.PARAM_ID, required = true, allowEmptyValue = false, value = "ID", type = "long", example = "1") Long id) {
		FacetConfig result = facetConfigRepository.getOne(id);
		return FacetConfigDto.from(result);
	}

	@ApiOperation(value = "Get ordered list of distinct values of a given entity property. Only values used in projects or segments are returned (i.e. only used products and not the complete list).")
	@GetMapping(path = LIST_DISTINCT_BY_FIELD)
	@ResponseBody
	public List<String> getDistinctProperties(
			@RequestParam(name = PARAM_ENTITY_TYPE, required = true) @ApiParam(name = PARAM_ENTITY_TYPE, required = true, allowEmptyValue = false, value = "EntityType from FacetConfig", allowableValues = "PROJECT,SEGMENT") String entityType,
			@RequestParam(name = PARAM_FIELD_NAME, required = true) @ApiParam(name = PARAM_FIELD_NAME, required = true, allowEmptyValue = false, value = "FieldName from FacetConfig", allowableValues = "preciseNewportId, newportInitiator, newportName, newportLaunchYear, rsGovernance, product.productLineText, newportSpg, target, region.name, subRegion.name, country.name, crop.cropGroup.cropPlatform.name, crop.cropGroup.name, crop.name") String fieldName,
			@RequestParam(name = PARAM_STARTS_WITH, required = false) @ApiParam(name = PARAM_STARTS_WITH, value = "The starting text the list items should be restricted to. May be null.", allowEmptyValue = true) String startsWith,
			@RequestParam(name = PARAM_LIMIT, required = false) @ApiParam(name = PARAM_LIMIT, value = "Restricts results to the given number of results.", example = "10") Integer limit,
			@RequestParam(name = PARAM_IS_CASE_SENSITIVE, required = false) @ApiParam(name = PARAM_IS_CASE_SENSITIVE, value = "True if query should be case sensitive.", example = "false") Boolean isCaseSensitive) {
		boolean caseSensitive = Boolean.TRUE.equals(isCaseSensitive);
		if ("PROJECT".equalsIgnoreCase(entityType)) {
			return projectRepository.findDistinctValuesStartingWith(fieldName, startsWith, limit, caseSensitive);
		} else if ("SEGMENT".equalsIgnoreCase(entityType)) {
			return segmentRepository.findDistinctValuesStartingWith(fieldName, startsWith, limit, caseSensitive);
		}
		throw new IllegalArgumentException("Illegal entity type!");
	}

	@ApiOperation(value = "Get information about the current user.")
	@GetMapping(path = USER_INFO)
	@ResponseBody
	public Map<String, Object> getCurrentUserInfo(ServletRequest request) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", userDetailsHelper.getCurrentUserId());
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		map.put("roles", roles);
		map.put("name", userDetailsHelper.getCurrentUserClaim("name"));
		map.put("sourceType", "User Details Helper: " + userDetailsHelper.getClass().getSimpleName());
		return map;
	}

}
