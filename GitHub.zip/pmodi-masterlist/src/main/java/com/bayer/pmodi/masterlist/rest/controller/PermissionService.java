package com.bayer.pmodi.masterlist.rest.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bayer.pmodi.masterlist.authorization.Groups;
import com.bayer.pmodi.masterlist.authorization.Roles;
import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.model.Setting;
import com.bayer.pmodi.masterlist.repository.SettingRepository;

@Service
public class PermissionService {

	private static final String LOCKED_GROUP = "LOCKED_GROUP";
	private static final String ORCA_LOCK = "ORCA_LOCK";

	private static final String TRUE = "true";

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@Autowired
	private SettingRepository settingRepository;

	public Collection<String> getLockedGroups() {
		List<Setting> settings = settingRepository.findByModuleAndOwnerIsNull(LOCKED_GROUP);
		List<String> results = settings.stream().filter(s -> TRUE.equalsIgnoreCase(s.getTextValue()))
				.map(s -> s.getKey()).collect(Collectors.toList());
		return results;
	}

	@Transactional
	public void lockGroups(Collection<String> groups) {
		checkLockGroupAccess();
		Groups.checkGroups(groups);

		if (groups != null) {
			List<Setting> settings = settingRepository.findByModuleAndOwnerIsNull(LOCKED_GROUP);
			List<Setting> settingsToBeSaved = new ArrayList<Setting>();
			for (String group : groups) {
				Optional<Setting> existing = settings.stream().filter(s -> group.equalsIgnoreCase(s.getKey()))
						.findFirst();
				if (existing.isPresent()) {
					Setting updateable = existing.get();
					if (updateable.getOwner() != null) {
						throw new IllegalStateException("Module '" + LOCKED_GROUP
								+ "' expects the owner to be null but there was an owner set!");
					}
					if (!TRUE.equals(updateable.getTextValue())) {
						updateable.setKey(TRUE);
						settingsToBeSaved.add(updateable);
					}
				} else {
					settingsToBeSaved.add(new Setting(LOCKED_GROUP, null, group, TRUE));
				}
			}
			if (!settingsToBeSaved.isEmpty()) {
				settingRepository.saveAll(settingsToBeSaved);
			}
		}
	}

	@Transactional
	public void unlockGroups(Collection<String> groups) {
		checkLockGroupAccess();
		Groups.checkGroups(groups);

		if (groups != null) {
			for (String group : groups) {
				settingRepository.deleteByModuleAndOwnerAndKey(LOCKED_GROUP, null, group);
			}
		}
	}

	public String getOrcaLockHolder() {
		List<Setting> settings = settingRepository.findByModuleAndOwnerIsNull(ORCA_LOCK);
		if (settings.isEmpty()) {
			return null;
		}
		return settings.get(0).getKey();
	}

	@Transactional
	public void setOrcaLockHolder(String lockHolder) {
		checkOrcaLockAccess();
		settingRepository.deleteByModuleAndOwnerIsNull(ORCA_LOCK);
		settingRepository.save(new Setting(ORCA_LOCK, lockHolder, "true"));
	}

	@Transactional
	public void deleteOrcaLockHolder() {
		checkOrcaLockAccess();
		settingRepository.deleteByModuleAndOwnerIsNull(ORCA_LOCK);
	}

	/**
	 * Check if current user has the permission to lock/unlock. If not an exception
	 * is thrown.
	 */
	private void checkLockGroupAccess() {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		if (roles != null && (roles.contains(Roles.ROLE_GLOBAL_ADMIN) || roles.contains(Roles.ROLE_SUPER_ADMIN))) {
			return; // allowed
		}
		throw new PmodiForbiddenException("Updating locked groups not allowed for current user.");

	}

	/**
	 * Check if current user has the permission to lock/unlock ORCA. If not an
	 * exception is thrown.
	 */
	private void checkOrcaLockAccess() {
		List<String> roles = userDetailsHelper.getCurrentUserRoles();
		// TODO: clarify roles
		if (roles != null && (roles.contains(Roles.ROLE_ORCA) || roles.contains(Roles.ROLE_SUPER_ADMIN))) {
			return; // allowed
		}
		throw new PmodiForbiddenException("Updating the ORCA lock is not allowed for current user.");

	}

}
