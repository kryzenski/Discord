package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class Crop extends AbstractAuditedEntity {

	@NotNull
	@Column(nullable = false)
	private String sourceKey;

	@NotNull
	@Column(nullable = false)
	private String name;

	@Column(nullable = true)
	private String uri;

	@Column(nullable = false)
	private boolean isPlaceholder;

	@Column(nullable = true)
	private String placeholderType;

	@ManyToOne(optional = false)
	@JoinColumn(name = "CROP_GROUP_ID", referencedColumnName = "ID", nullable = false)
	private CropGroup cropGroup;

}