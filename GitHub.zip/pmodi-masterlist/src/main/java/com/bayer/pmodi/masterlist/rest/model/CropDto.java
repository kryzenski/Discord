package com.bayer.pmodi.masterlist.rest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class CropDto {

	private Long id;
	private String sourceKey;
	private String name;
	private String uri;
	private boolean isPlaceholder;
	private String placeholderType;

}