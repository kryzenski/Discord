package com.bayer.pmodi.masterlist.rest.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.OptimisticLockException;
import javax.transaction.Transactional;

import com.bayer.pmodi.masterlist.model.*;
import com.bayer.pmodi.masterlist.repository.*;
import com.google.gson.Gson;
import lombok.extern.java.Log;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import com.bayer.pmodi.masterlist.authorization.AuthorizationUtil;
import com.bayer.pmodi.masterlist.authorization.ProjectAuthenticatedFieldDefinition;
import com.bayer.pmodi.masterlist.authorization.SegmentAuthenticatedFieldDefinition;
import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.config.security.exception.PmodiForbiddenException;
import com.bayer.pmodi.masterlist.rest.QuickScanService;
import com.bayer.pmodi.masterlist.rest.model.AnswerDto;
import com.bayer.pmodi.masterlist.rest.model.ProjectCommentUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.ProjectEditableFieldsDto;
import com.bayer.pmodi.masterlist.rest.model.ProjectQuestionDefinitionUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.ProjectUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentCommentUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentCostUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentEditableFieldsDto;
import com.bayer.pmodi.masterlist.rest.model.SegmentUpdateDto;
import com.bayer.pmodi.masterlist.rest.model.VersionedEntity;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is needed for two reasons:
 * <ul>
 * <li>Return the proper version number on returned JSON. Therefore we have to
 * flush the context on update methods (whereas create methods sets the version
 * explicitly).</li>
 * <li>Correct rollback and transaction handling with proxies. Therefore we have
 * to extract the transactional behavior to an own class which can be proxied.
 * This can't be done in the controller class itself (transactional annotated
 * caller would deliver wrong version number or non transactional annotated
 * caller would lead to the proxy issue that the transaction annotation would be
 * ignored)!</li>
 * </ul>
 * Therefore this only handles update methods and contains common methods which
 * are used here and in other places.
 * 
 * @author juergen.panser
 *
 */
@Service
@Log
public class ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectCommentRepository projectCommentRepository;

	@Autowired
	private ProjectQuestionDefinitionRepository projectQuestionDefinitionRepository;

	@Autowired
	private ProjectQuestionRepository projectQuestionRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@Autowired
	private SegmentCommentRepository segmentCommentRepository;

	@Autowired
	private SegmentQuestionRepository segmentQuestionRepository;

	@Autowired
	private SegmentCostRepository segmentCostRepository;

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private UserDetailsHelper userDetailsHelper;

	@Autowired
	private QuickScanService quickscanService;

	@Autowired
	private PermissionService permissionService;

	@Transactional
	public Project updateProjectTransactional(Long id, HttpEntity<String> httpEntity ,String byUser) throws IOException {
		// Read original
		Project original = projectRepository.getOne(id);
		//checking the original newportstatus
		String newportStatus = "";
		if (original != null && original.getNewportStatus() != null) {
			newportStatus = original.getNewportStatusId();
		}
		//checking the original category
		String newportCategory = "";
		if(original != null && original.getNewportCategory() != null){
			newportCategory = original.getNewportCategory();
		}
		// Update properties (on a copy to not yet change the original)
		ProjectUpdateDto updateDto = ProjectUpdateDto.from(original);
		boolean updateFSPTRSScoreFlag = false;
		boolean updateRSPTRSScoreFlag = false;
		boolean deleteFSPTRSScoreFlag = false;
		boolean deleteRSPTRSScoreFlag = false;
		boolean updateOfRSPtrsScores = false;

		Map<String, String> map = new Gson().fromJson(httpEntity.getBody(), Map.class);

		if (map.containsKey("fsPtrsScore") && map.get("fsPtrsScore") != null) {
			updateFSPTRSScoreFlag = true;
		}

		if ((map.containsKey("rsDietaryPtrsScore")) ||
				(map.containsKey("rsEnsaPtrsScore")) ||
				(map.containsKey("rsOperatorPtrsScore")) ||
				(map.containsKey("rsRegAffairsScore"))) {

			updateOfRSPtrsScores = true;
		}

		if ((map.containsKey("rsDietaryPtrsScore") && map.get("rsDietaryPtrsScore") != null) ||
				(map.containsKey("rsEnsaPtrsScore") && map.get("rsEnsaPtrsScore") != null) ||
				(map.containsKey("rsOperatorPtrsScore") && map.get("rsOperatorPtrsScore") != null) ||
				(map.containsKey("rsRegAffairsScore") && map.get("rsRegAffairsScore") != null)) {
			updateRSPTRSScoreFlag = true;
		}

		if (map.containsKey("fsPtrsScore") && map.get("fsPtrsScore") == null) {
			deleteFSPTRSScoreFlag = true;
		}

		if ((map.containsKey("rsDietaryPtrsScore") && map.get("rsDietaryPtrsScore") == null) ||
				(map.containsKey("rsEnsaPtrsScore") && map.get("rsEnsaPtrsScore") == null) ||
				(map.containsKey("rsOperatorPtrsScore") && map.get("rsOperatorPtrsScore") == null) ||
				(map.containsKey("rsRegAffairsScore") && map.get("rsRegAffairsScore") == null)) {
			deleteRSPTRSScoreFlag = true;
		}


		prepareToEnsureRequestSendsVersion(updateDto);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());

		// Check if the user is allowed to change the entity
		Collection<String> regionRoleSuffixes = getRoleSuffixes(id);
		Predicate<String> hasChangedPredicate = createHasChangedPrediate(original, updateDto);
		AuthorizationUtil.checkFields(userDetailsHelper, true, updateDto,
				ProjectAuthenticatedFieldDefinition.getInstance(), regionRoleSuffixes, hasChangedPredicate,
				permissionService.getLockedGroups());

		// Sanity checks
		checkVersion(original.getVersion(), updateDto.getVersion());
		checkScores(updateDto);

		// Check if ftPtrsScore has changed and trigger Segment update as segment
		// now uses this project property for score calculation.
		boolean segmentUpdateNeeded = !java.util.Objects.equals(original.getFtPtrsScore(), updateDto.getFtPtrsScore());

		// Apply changes to original and save
		updateDto.applyUpdateablePropertiesTo(original, productRepository);

		if (updateFSPTRSScoreFlag && original.getFsPtrsScoreRmk() != null &&
				original.getFsPtrsScoreRmk().equals("The weighted Segment FS score becomes Project FS PTRS score by default, as Project FS PTRS was empty.")) {
			original.setFsPtrsScoreRmk("");
		}

		if (updateRSPTRSScoreFlag && original.getRsPtrsScoreRmk() != null &&
				original.getRsPtrsScoreRmk().equals("The weighted Segment RS score becomes Project RS PTRS score by default, as Project RS PTRS was empty.")) {
			original.setRsPtrsScoreRmk("");
		}

		if (map.containsKey("byUser")) {
			byUser = "true";
		} else {
			byUser = "false";
		}
		if (byUser != null && byUser.equals("true")) {
			if (deleteFSPTRSScoreFlag) {
				original.setIsUpdate("FSScoreByUser");
			}
			if (updateOfRSPtrsScores) {
				original.setIsUpdate("RSScoreByUser");
			}

		} else {
			if (deleteFSPTRSScoreFlag) {
				original.setIsUpdate("FSScoreByImport");
			}
			if (updateOfRSPtrsScores) {
				original.setIsUpdate("RSScoreByImport");
			}
		}

		setNewportCreationYear(original);
		setNewportProjectApprovalYear(original);

		// Making recommendation empty on category change
		if(original != null && original.getNewportCategory() != null && original.getNewportCategory().equals("Formulation Development")
				&& newportCategory.equals("New Formulation Proof of Concept")){
			original.setTechRecommendation(null);
			original.setTechRecommendationModifiedBy(null);
			original.setTechRecommendationModifiedDate(null);
			original.setSolRecommendation(null);
			original.setSolRecommendationModifiedBy(null);
			original.setSolRecommendationModifiedDate(null);
			original.setScienceRecommendation(null);
			original.setScienceRecommendationModifiedBy(null);
			original.setScienceRecommendationModifiedDate(null);
		}

		//Capturing date for the category change from new active substance to LCM category
		if(original != null && original.getNewportCategory() != null && (original.getNewportCategory().equalsIgnoreCase("Formulation Development")
				|| original.getNewportCategory().equalsIgnoreCase("New Formulation proof of Concept") || original.getNewportCategory().equalsIgnoreCase("Country Extension")
				|| original.getNewportCategory().equalsIgnoreCase("Label Expansion"))
				&& newportCategory.equalsIgnoreCase("New Active Substance Developments"))
		{
			if (original.getNewportStatusId() != null && original.getNewportStatusId().equals("I")) {
				LocalDate approvalDate = LocalDate.now();
				original.setCategoryChangedDateNASToLCM(approvalDate);
			}
		}

		//Capturing date for the category change from New Formulation Proof of Concept to Formulation Development
		if(original != null && original.getNewportCategory() != null && (original.getNewportCategory().equalsIgnoreCase("Formulation Development"))
				&& newportCategory.equalsIgnoreCase("New Formulation proof of Concept"))
		{
			if (original.getNewportStatusId() != null && original.getNewportStatusId().equals("I")) {
				LocalDate localDate = LocalDate.now();
				original.setCategoryChangedDateNFPCToFD(localDate);
			}
		}
		//to set the projects with segments
		if( original != null  && !original.getSegments().isEmpty()){
			original.setIsSegmentPresent("Yes");
		}
		//if no segment is present to set isSegmentPresent NO
		if(original != null  && original.getSegments().isEmpty())
			original.setIsSegmentPresent("No");


		Project result = projectRepository.save(original);

		if (segmentUpdateNeeded) {
			// Make segment updates after project has been saved to allow the segments to
			// use the new project data (ftPtrsScore)
			List<Segment> allSegments = segmentRepository.findByProjectId(id, Pageable.unpaged()).getContent();
			allSegments.forEach(s -> s.calculateDependentScores());
			segmentRepository.saveAll(allSegments);
		}

		List<Segment> allSegments = segmentRepository.findByProjectId(id, Pageable.unpaged()).getContent();
		allSegments.forEach(s -> s.setPreciseNewportId(original.getPreciseNewportId()));
		allSegments.forEach(s -> s.setNewportFreeText(original.getNewportFreeText()));
		allSegments.forEach(s -> s.setNewportName(original.getNewportName()));
		allSegments.forEach(s -> s.setNewportBusinessUnit(original.getNewportBusinessUnit()));
		allSegments.forEach(s -> s.setNewportCategory(original.getNewportCategory()));
		allSegments.forEach(s -> s.setNewportStatus(original.getNewportStatus()));

		segmentRepository.saveAll(allSegments);
		return result;
	}

	//Setting Newport Project created date in correct format
	public void setNewportCreationYear(Project originalData) {
		if (originalData != null && originalData.getNewportProjectCreated() != null) {
			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
				LocalDate date = LocalDate.parse(originalData.getNewportProjectCreated(), formatter);
				originalData.setNewportProjectCreated(String.valueOf(date));
				originalData.setDraftYear(String.valueOf(date.getYear()));
				String str = date.getMonth().toString();
				String draftMonthAndYear = String.valueOf(date.getYear()) + '-' + str.substring(0, 3);
				originalData.setDraftYearMonth(draftMonthAndYear);
			} catch (Exception e) {
				log.warning("Exception in NewportProjectCreation " + e.getMessage());
			}
		}
	}

	//Setting Newport Project Approval date in correct format
	public void setNewportProjectApprovalYear(Project originalData){
     if(originalData != null && originalData.getNewportProjectApprovalDate() != null) {
		 try {
				 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
				 LocalDate approvalDate = LocalDate.parse(originalData.getNewportProjectApprovalDate(), formatter);
				 originalData.setApprovalDate(approvalDate);
				 originalData.setApprovalYear(String.valueOf(approvalDate.getYear()));
				 String str = approvalDate.getMonth().toString();
				 String approvalMonthAndYear = String.valueOf(approvalDate.getYear()) + '-' + str.substring(0, 3);
				 originalData.setApprovalYearMonth(approvalMonthAndYear);
		 } catch (Exception e) {
			 log.warning("Exception in NewportProjectApprovalYear " + e.getMessage());
			 e.printStackTrace();
		 }
	 }
	}

	public void setNewportSegmentCreationDate(Segment originalData){
    if(originalData != null && originalData.getNewportSegmentCreationDate() != null) {
		try {
			if (originalData.getNewportSegmentCreationDate() != null) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
				LocalDate date = LocalDate.parse(originalData.getNewportSegmentCreationDate(), formatter);
				originalData.setCreationDate(date);
				originalData.setCreationYear(String.valueOf(date.getYear()));
				String str = date.getMonth().toString();
				String approvalMonthAndYear = String.valueOf(date.getYear()) + '-' + str.substring(0, 3);
				originalData.setCreationDateMonth(approvalMonthAndYear);
			}
		} catch (Exception e) {
			log.warning("Exception in NewportSegmentCreation " + e.getMessage());
			e.printStackTrace();
		}
	}
	}


	@Transactional
	public ProjectComment updateProjectCommentTransactional(Long id, HttpEntity<String> httpEntity) throws IOException {
		// Read original and check user
		ProjectComment original = projectCommentRepository.getOne(id);
		checkCurrentUser(original.getUser());
		// Update properties (on a copy to not yet change the original)
		ProjectCommentUpdateDto updateDto = ProjectCommentUpdateDto.from(original);
		prepareToEnsureRequestSendsVersion(updateDto);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());
		// Sanity checks
		checkVersion(original.getVersion(), updateDto.getVersion());
		// Apply changes to original, handle references and save
		updateDto.applyUpdateablePropertiesTo(original);
		ProjectComment result = projectCommentRepository.save(original);
		return result;
	}

	@Transactional
	public ProjectQuestionDefinition updateProjectQuestionDefinitionTransactional(Long id,
																				  HttpEntity<String> httpEntity) throws IOException {
		// Read original and check user
		ProjectQuestionDefinition original = projectQuestionDefinitionRepository.getOne(id);
		// Update properties (on a copy to not yet change the original)
		ProjectQuestionDefinitionUpdateDto updateDto = ProjectQuestionDefinitionUpdateDto.from(original);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());
		// Apply changes to original, handle references and save
		updateDto.applyUpdateablePropertiesTo(original);
		ProjectQuestionDefinition result = projectQuestionDefinitionRepository.save(original);
		return result;
	}

	@Transactional
	public Iterable<ProjectQuestion> updateProjectQuestionsTransactional(List<AnswerDto> answers) {
		List<ProjectQuestion> updatedQuestions = new ArrayList<>(answers.size());
		for (AnswerDto answerDto : answers) {
			ProjectQuestion originalAnswer = projectQuestionRepository.getOne(answerDto.getId());
			// Sanity checks
			checkVersion(originalAnswer.getVersion(), answerDto.getVersion());
			originalAnswer.setAnswer(answerDto.isAnswer());
			updatedQuestions.add(originalAnswer);
		}

		Iterable<ProjectQuestion> results = projectQuestionRepository.saveAll(updatedQuestions);
		return results;
	}

	@Transactional
	public Segment updateSegmentTransactional(Long id, HttpEntity<String> httpEntity) throws IOException {
		// Read original
		Segment original = segmentRepository.getOne(id);
		if(original.getQuickscanAssessmentId()!=null && original.getQuickscanAssessmentId().length()==0){
			original.setQuickscanAssessmentId(null);
		}
		String originalAssessmentId =original.getQuickscanAssessmentId();
		// Update properties (on a copy to not yet change the original)
		SegmentUpdateDto updateDto = SegmentUpdateDto.from(original);
		prepareToEnsureRequestSendsVersion(updateDto);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());

		// Check if the user is allowed to change the entity
		Collection<String> regionRoleSuffixes = getRoleSuffixes(original);
		Predicate<String> hasChangedPredicate = createHasChangedPrediate(original, updateDto);
		AuthorizationUtil.checkFields(userDetailsHelper, true, updateDto,
				SegmentAuthenticatedFieldDefinition.getInstance(), regionRoleSuffixes, hasChangedPredicate,
				permissionService.getLockedGroups());

		// Sanity checks
		checkVersion(original.getVersion(), updateDto.getVersion());
		boolean hasZNumber = StringUtils.isNotBlank(updateDto.getRegprimeZNumber());
		boolean hasSequenceNumber = updateDto.getRegprimeSequenceNumber() != null;
		if ((!hasZNumber && hasSequenceNumber) || (hasZNumber && !hasSequenceNumber)) {
			throw new IllegalArgumentException(
					"RegprimeSequenceNumber and RegprimeZNumber have both to be set or both null!");
		}
		checkScores(updateDto);

		// Apply changes to original, handle references and save
		updateDto.applyUpdateablePropertiesTo(original);

		Project project = projectRepository.getOne(original.getProject().getId());
		Country country = countryRepository.getOne(original.getCountry().getId());
		SubRegion subRegion = subRegionRepository.getOne(original.getSubRegion().getId());
		Region region = regionRepository.getOne(original.getRegion().getId());
		Crop crop = cropRepository.getOne(original.getCrop().getId());
		//creation year, date and month of segment
		setNewportSegmentCreationDate(original);


		original.setCountryName(country.getName());
		original.setPreciseNewportId(project.getPreciseNewportId());
		original.setNewportFreeText(project.getNewportFreeText());
		original.setNewportName(project.getNewportName());
		original.setSubRegionName(subRegion.getName());
		original.setCropName(crop.getName());
		original.setCropGroupName(crop.getCropGroup().getName());
		original.setCropPlatformName(crop.getCropGroup().getCropPlatform().getName());
		original.setRegionName(region.getName());

		//to set the projects with segments
		if( original != null && original.getProject() != null){
				original.getProject().setIsSegmentPresent("Yes");
		}


		Segment result = segmentRepository.save(original);

		// Call other REST endpoints to lock/unlock assessments. If these throw an
		// exception this will roll back our previous save.

		List<String> quickscanOld =new ArrayList<>();
		List<String> quickscanNew =new ArrayList<>();
		if(originalAssessmentId!=null && originalAssessmentId.length()!=0){
			quickscanOld = Stream.of(originalAssessmentId.split(",")).collect(Collectors.toList());
		}


		if(updateDto.getQuickscanAssessmentId()!=null){
			quickscanNew = Stream.of(updateDto.getQuickscanAssessmentId().split(",")).collect(Collectors.toList());
		}

		if (originalAssessmentId != null && updateDto.getQuickscanAssessmentId() == null) {
			for(String s:quickscanOld){
				quickscanService.lockAssessment(s, false);
			}
		} else if(updateDto.getQuickscanAssessmentId()!=null){
			for (String assemnetId : quickscanNew) {
				if (originalAssessmentId==null || !originalAssessmentId.contains(assemnetId)) {
					// Lock new
					quickscanService.lockAssessment(assemnetId, true);
					//quickscanService.lockAssessment(assemnetId, false);
				}
			}
			for (String assemnetId : quickscanOld) {
				if (!updateDto.getQuickscanAssessmentId().contains(assemnetId)) {
					// Unlock old
					quickscanService.lockAssessment(assemnetId, false);
				}
			}
		}

		return result;
	}

	@Transactional
	public SegmentComment updateSegmentCommentTransactional(Long id, HttpEntity<String> httpEntity) throws IOException {
		// Read original and check user
		SegmentComment original = segmentCommentRepository.getOne(id);
		checkCurrentUser(original.getUser());
		// Update properties (on a copy to not yet change the original)
		SegmentCommentUpdateDto updateDto = SegmentCommentUpdateDto.from(original);
		prepareToEnsureRequestSendsVersion(updateDto);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());
		// Sanity checks
		checkVersion(original.getVersion(), updateDto.getVersion());
		// Apply changes to original, handle references and save
		updateDto.applyUpdateablePropertiesTo(original);
		SegmentComment result = segmentCommentRepository.save(original);
		return result;
	}

	@Transactional
	public Iterable<SegmentQuestion> updateSegmentQuestionsTransactional(List<AnswerDto> answers) {
		List<SegmentQuestion> updatedQuestions = new ArrayList<>(answers.size());
		for (AnswerDto answerDto : answers) {
			SegmentQuestion originalAnswer = segmentQuestionRepository.getOne(answerDto.getId());
			// Sanity checks
			checkVersion(originalAnswer.getVersion(), answerDto.getVersion());
			originalAnswer.setAnswer(answerDto.isAnswer());
			updatedQuestions.add(originalAnswer);
		}

		Iterable<SegmentQuestion> results = segmentQuestionRepository.saveAll(updatedQuestions);
		return results;
	}

	// TODO: either use @Transactional or save as the entities in a transactional
	// method are managed ones (also check other methods)
	@Transactional
	public SegmentCost updateSegmentCostTransactional(Long id, HttpEntity<String> httpEntity) throws IOException {
		// Read original
		SegmentCost original = segmentCostRepository.getOne(id);
		// Update properties (on a copy to not yet change the original)
		SegmentCostUpdateDto updateDto = SegmentCostUpdateDto.from(original);
		prepareToEnsureRequestSendsVersion(updateDto);
		objectMapper.readerForUpdating(updateDto).readValue(httpEntity.getBody());
		// Sanity checks
		checkVersion(original.getVersion(), updateDto.getVersion());
		// Apply changes to original, handle references and save
		updateDto.applyUpdateablePropertiesTo(original);
		SegmentCost result = segmentCostRepository.save(original);
		return result;
	}

	public Collection<String> getRoleSuffixes(Long projectId) {
		Set<String> results = new HashSet<>();
		List<Segment> segments = segmentRepository.findByProjectId(projectId, null).getContent();
		for (Segment s : segments) {
			String roleSuffix = s.getRegion().getRoleSuffix();
			if (roleSuffix != null) {
				results.add(roleSuffix);
			}
		}
		return results;
	}

	public static Collection<String> getRoleSuffixes(Segment segment) {
		String roleSuffix = segment.getRegion().getRoleSuffix();
		if (roleSuffix != null) {
			return Arrays.asList(roleSuffix);
		}
		return Collections.emptyList();
	}

	private Predicate<String> createHasChangedPrediate(Object original, Object updateDto) {
		Predicate<String> hasChangedPredicate = fieldName -> {
			try {
				Object originalValue = PropertyUtils.getProperty(original, fieldName);
				Object updatedValue = PropertyUtils.getProperty(updateDto, fieldName);
				return !java.util.Objects.equals(originalValue, updatedValue);
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException pEx) {
				throw new IllegalStateException("Edit right check failed to extract field value!", pEx);
			}
		};
		return hasChangedPredicate;
	}

	/**
	 * Check if current user id matches the given one. If not an exception is
	 * thrown.
	 *
	 * @param user User ID e.g. used in comments; optional (but then an exception is
	 *             thrown)
	 */
	private void checkCurrentUser(String user) {
		// Check if current user's id matches the comment owner's id
		if (userDetailsHelper.isCurrentUser(user) == false) {
			throw new PmodiForbiddenException("Operation performed not by the current user. Not allowed.");
		}
	}

	/**
	 * Prepare the given entity so that the version check detects missing version
	 * properties. This can be done if this method is called before the ObjectMapper
	 * reads the JSON request and updates the entity. The version in the entity is
	 * set to null, so the JSON has to contain a version no field.
	 *
	 * @param updateDto
	 */
	private static void prepareToEnsureRequestSendsVersion(VersionedEntity updateDto) {
		updateDto.setVersion(null);
	}

	public static void checkVersion(int versionInDb, Integer checkVersion) {
		if (checkVersion == null) {
			throw new IllegalArgumentException("Version missing!");
		}
		if (versionInDb != checkVersion.intValue()) {
			throw new OptimisticLockException("Version out of sync. Reload the entity before updating.");
		}
	}

	public static void checkScores(ProjectEditableFieldsDto project) {
		checkScore(project.getFsPtrsScore());
		checkScore(project.getFtPtrsScore());
		checkScore(project.getRsDietaryPtrsScore());
		checkScore(project.getRsEnsaPtrsScore());
		checkScore(project.getRsOperatorPtrsScore());
		checkScore(project.getRsRegAffairsScore());
		// Calculated scores like RsPtrsScore and OverallPtrsScore are not checked
	}

	public static void checkScores(SegmentEditableFieldsDto segment) {
		checkScore(segment.getFsPtrsScore());
		checkScore(segment.getRsRegPtrsScore());
		// Calculated score PtrsSegmentOverallScore is not checked
	}

	public static void checkScore(Double score) {
		if (score != null) {
			if (score.doubleValue() < 0.0 || score.doubleValue() > 1.0) {
				throw new IllegalArgumentException("Illegal score detected!");
			}
		}
	}

}
