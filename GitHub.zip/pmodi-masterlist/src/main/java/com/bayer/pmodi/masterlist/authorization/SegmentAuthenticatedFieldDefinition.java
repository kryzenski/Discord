package com.bayer.pmodi.masterlist.authorization;

import com.bayer.pmodi.masterlist.model.Segment;

public class SegmentAuthenticatedFieldDefinition extends AbstractAuthenticatedFieldDefinition {

	private static AuthenticatedFieldDefinition instance = new SegmentAuthenticatedFieldDefinition();

	public static AuthenticatedFieldDefinition getInstance() {
		return instance;
	}

	@Override
	protected Class<?> getCheckedClass() {
		return Segment.class;
	}

	@Override
	protected boolean isRelevantGroup(String group) {
		return Groups.isSegmentGroup(group);
	}

}
