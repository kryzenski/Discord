package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class CropValidationDto {

	@NotNull
	@ApiModelProperty(required = true, value = "Source key of the crop platform", example = "02")
	private String cropPlatformId;

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop platform", example = "Cereals")
	private String cropPlatform;

	@NotNull
	@ApiModelProperty(required = true, value = "Source key of the crop group", example = "001")
	private String cropGroupId;

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop group", example = "BARLEY")
	private String cropGroup;

	@NotNull
	@ApiModelProperty(required = true, value = "Source key of the crop", example = "004")
	private String cropId;

	@NotNull
	@ApiModelProperty(required = true, value = "Name of the crop", example = "Barley: Fodder/Forage")
	private String crop;

}
