package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import com.bayer.pmodi.masterlist.model.ProjectQuestionDefinition;

public interface ProjectQuestionDefinitionRepository extends BaseRepository<ProjectQuestionDefinition> {

	List<ProjectQuestionDefinition> findByIsActive(boolean isActive);

}
