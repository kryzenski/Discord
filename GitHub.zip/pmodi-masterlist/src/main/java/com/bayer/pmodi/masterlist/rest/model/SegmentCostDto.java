package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.SegmentCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentCostDto extends NewSegmentCostDto {

	public static SegmentCostDto from(SegmentCost src) {
		SegmentCostDto result = new SegmentCostDto();
		SegmentCostUpdateDto.mapOwn(src, result);
		NewSegmentCostDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(SegmentCost src, SegmentCostDto result) {
		result.setId(src.getId());
	}

	@NotNull
	private Long id;

}