package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.Segment;
import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.DomainUtil;
import com.bayer.pmodi.masterlist.model.Project;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewProjectDto extends ProjectEditableFieldsDto {

	public static NewProjectDto from(Project src) {
		NewProjectDto result = new NewProjectDto();
		ProjectEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Project src, NewProjectDto result) {
		BeanUtils.copyProperties(src, result);
		result.setProduct(DtoUtil.toIdDisplayNameDto(src.getProduct()));
		Map<String, Double> map=calculateWeightedScores(src);
		if(null!=src.getSegments()) {

			Double rs = 0d;
			Double fs = 0d;
			Double totalWeight = 0d;
            fs=map.containsKey("fsScore")? map.get("fsScore"):0d;
			rs=map.containsKey("rsScore")? map.get("rsScore"):0d;
			totalWeight=map.containsKey("totalWeight")? (double)map.get("totalWeight"):0d;

			Integer fsScore = 0;
			Integer rsScore = 0;
			if(totalWeight > 0){
				fsScore = (int) Math.round(fs);
				rsScore = (int) Math.round(rs);
			}

			result.setWeightedFsScore(fsScore.toString());
			result.setWeightedRsScore(rsScore.toString());
		}
	}

	public static Map<String, Double> calculateWeightedScores(Project src){
		Map<String, Double> map = new HashMap<>();
		if(null!=src.getSegments()) {
			Double weightedFs = 0d;
			Double weightedRs = 0d;
			Double totalWeightedFs = 0d;
			Double totalWeightedRs = 0d;
			Double weight = 0d;
			Double totalWeight = 0d;
			for (Segment seg : src.getSegments()) {
				weight = seg.getNewportGlobalPeakNetSales();
				if (seg.getRsRegPtrsScore() != null && seg.getRsRegPtrsScore() > 0) {
					weightedRs += seg.getRsRegPtrsScore() * weight;
				}
				if (seg.getFsPtrsScore() != null && seg.getFsPtrsScore() > 0) {
					weightedFs += seg.getFsPtrsScore() * weight;
				}
				totalWeight += weight;
			}
			DecimalFormat df = new DecimalFormat("0.00");
			if (totalWeight > 0) {
				totalWeightedFs = (weightedFs / totalWeight) * 100;
				totalWeightedRs = (weightedRs / totalWeight) * 100;
				map.put("fsScore",totalWeightedFs);
				map.put("rsScore",totalWeightedRs);
				map.put("totalWeight",totalWeight);
			}

		}
		return  map;
	}
	public static void applyKeyPropertiesTo(Project result, String newportProjectId, String newportAreaId,
			String newportNewPortNumber) {
		result.setNewportProjectId(newportProjectId);
		result.setNewportAreaId(newportAreaId);
		result.setNewportNewPortNumber(newportNewPortNumber);
		result.setPreciseNewportId(DomainUtil.createPreciseNewportId(newportAreaId, newportNewPortNumber));
	}

	@NotNull
	private String newportProjectId;

	@NotNull
	private String newportAreaId;

	@NotNull
	private String newportNewPortNumber;

	private String weightedRsScore;

	private String weightedFsScore;

}