package com.bayer.pmodi.masterlist.repository;

import java.util.List;

import com.bayer.pmodi.masterlist.model.Setting;

public interface SettingRepository extends BaseRepository<Setting> {

	Setting findByModuleAndOwnerAndKey(String module, String owner, String key);

	List<Setting> findByModuleAndOwner(String module, String owner);

	List<Setting> findByModuleAndOwnerIsNull(String module);

	Long deleteByModuleAndOwnerAndKey(String module, String owner, String key);

	Long deleteByModuleAndOwner(String module, String owner);

	Long deleteByModuleAndOwnerIsNull(String module);

}
