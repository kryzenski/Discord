package com.bayer.pmodi.masterlist.authorization;

import java.util.Collection;

import org.apache.commons.lang3.ArrayUtils;

public class Groups {

	public static final String GROUP_PROJECT_PTRS = "PROJECT_PTRS";
	public static final String GROUP_SEGMENT_PTRS = "SEGMENT_PTRS";
	public static final String GROUP_PROJECT_PRIO = "PROJECT_PRIO";
	public static final String GROUP_SEGMENT_PRIO = "SEGMENT_PRIO";
	public static final String GROUP_PROJECT_GUIDANCE_IP = "PROJECT_GUIDANCE_IP";

	public static final String DESCRIPTION_ALL_GROUPS = GROUP_PROJECT_PTRS + ", " + GROUP_SEGMENT_PTRS + ", "
			+ GROUP_PROJECT_PRIO + ", " + GROUP_SEGMENT_PRIO + ", " + GROUP_PROJECT_GUIDANCE_IP;

	public static final String[] ALL_GROUPS = new String[] { GROUP_PROJECT_PTRS, GROUP_SEGMENT_PTRS, GROUP_PROJECT_PRIO,
			GROUP_SEGMENT_PRIO, GROUP_PROJECT_GUIDANCE_IP };

	private static final String[] PROJECT_GROUPS = new String[] { GROUP_PROJECT_PTRS, GROUP_PROJECT_PRIO,
			GROUP_PROJECT_GUIDANCE_IP };
	private static final String[] SEGMENT_GROUPS = new String[] { GROUP_SEGMENT_PTRS, GROUP_SEGMENT_PRIO };

	private Groups() {
		// No instance allowed
	}

	public static boolean isProjectGroup(String group) {
		return ArrayUtils.contains(PROJECT_GROUPS, group);
	}

	public static boolean isSegmentGroup(String group) {
		return ArrayUtils.contains(SEGMENT_GROUPS, group);
	}

	public static void checkGroups(Collection<String> groups) {
		if (groups != null) {
			for (String group : groups) {
				if (!ArrayUtils.contains(ALL_GROUPS, group)) {
					throw new IllegalArgumentException("Unknown group '" + group + "' detected.");
				}
			}
		}
	}

}
