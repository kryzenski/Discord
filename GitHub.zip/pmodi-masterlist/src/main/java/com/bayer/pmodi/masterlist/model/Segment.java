package com.bayer.pmodi.masterlist.model;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.rest.model.NewProjectDto;
import lombok.extern.java.Log;
import org.hibernate.envers.Audited;

import com.bayer.pmodi.masterlist.authorization.CheckedField;
import com.bayer.pmodi.masterlist.authorization.Groups;
import com.bayer.pmodi.masterlist.authorization.Roles;
import com.bayer.pmodi.masterlist.authorization.SpecialTreatment;
import com.bayer.pmodi.masterlist.model.enums.CostCenterEnum;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
@Log
public class Segment extends AbstractVersionedEntity implements Comparable {

	@NotNull
	@Column(nullable = false)
	@Enumerated(EnumType.STRING)
	private CostCenterEnum costCenter = CostCenterEnum.LOCAL;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
			 }, group = Groups.GROUP_SEGMENT_PTRS)
	private String fsPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
			 }, group = Groups.GROUP_SEGMENT_PTRS)
	private Double fsPtrsScore;

	@NotNull
	@Column(nullable = false)
	private String target;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
			 }, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsRegPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
			 }, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsRegPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
    private String rsRegProductPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsRegProductPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsRegDietaryPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsRegDietaryPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsOccupationalResidentialExposurePtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsOccupationalResidentialExposurePtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsToxicologyPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsToxicologyPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsEcotoxPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsEcotoxPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsEfatePtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsEfatePtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsLocalRestrictionPolicyPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsLocalRestrictionPolicyPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsLocalRestrictionOthersPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsLocalRestrictionOthersPtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private Double rsForeignInfluencePtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsForeignInfluencePtrsScoreRmk;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
    private Double rsRegistrationPtrsScore;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT
	}, group = Groups.GROUP_SEGMENT_PTRS)
	private String rsRegistrationPtrsScoreRmk;



	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	private Double ptrsSegmentOverallScore;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING,
			Roles.ROLE_GLOBAL_DEVELOPMENT,Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT }, group = Groups.GROUP_SEGMENT_PTRS)
	private String quickscanAssessmentId;

	@Column(nullable=true)
	private Boolean isQuickScanNotApplicable;

	@Column(nullable=true)
	private String quickScanNotApplicableReason;

	@Column(name = "REGPRIME_Z_NUMBER", nullable = true)
	@CheckedField(roles = {Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING,
			Roles.ROLE_GLOBAL_DEVELOPMENT,Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT}, group = Groups.GROUP_SEGMENT_PTRS)
	private String regprimeZNumber;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING,
			Roles.ROLE_GLOBAL_DEVELOPMENT,Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT}, group = Groups.GROUP_SEGMENT_PTRS)
	private Integer regprimeSequenceNumber;

	@Column(nullable = true)
	@Enumerated(EnumType.STRING)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = {
			Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_SEGMENT_PRIO, specialTreatment = SpecialTreatment.PRIORITIZATION_TYPE_BY_GOVERNANCE)
	private PrioritizationTypeEnum prioritizationType;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_PREFIX_REGIONAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING,
			Roles.ROLE_PREFIX_REGIONAL_MARKETING }, group = Groups.GROUP_SEGMENT_PRIO)
	private String prioritizationRmk;

	@Column(nullable = true)
	@Enumerated(EnumType.STRING)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN }, group = Groups.GROUP_SEGMENT_PRIO)
	private LocationTypeEnum prioritizationGovernance;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING })
	private String strategicFitRmk;

	@JsonIgnore
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@ManyToOne(optional = false, fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "PROJECT_ID", referencedColumnName = "ID", nullable = false)
	private Project project;

	@ManyToOne(optional = false)
	@JoinColumn(name = "COUNTRY_ID", referencedColumnName = "ID", nullable = false)
	private Country country;

	@Column(nullable = true)
	private  String countryName;

	@Column(nullable = true)
	private  String cropName;

	@Column(nullable = true)
	private  String newportName;

	@Column(nullable = true)
	private  String newportFreeText;

	@Column(nullable = true)
	private  String preciseNewportId;

	@Column(nullable = true)
	private  String subRegionName;

	@Column(nullable = true)
	private  String cropPlatformName;

	@Column(nullable = true)
	private  String cropGroupName;

	@Column(nullable = true)
	private  String regionName;

	@Column(nullable = true)
	private  String creationYear;

	//complete date of creationYear
	@Column(nullable = true)
	private  LocalDate creationDate;

    //segmentCreation
	@Column(nullable = true)
	private  String newportSegmentCreationDate;

	@ManyToOne(optional = false)
	@JoinColumn(name = "SUB_REGION_ID", referencedColumnName = "ID", nullable = false)
	private SubRegion subRegion;

	@ManyToOne(optional = false)
	@JoinColumn(name = "REGION_ID", referencedColumnName = "ID", nullable = false)
	private Region region;

	@ManyToOne(optional = false)
	@JoinColumn(name = "CROP_ID", referencedColumnName = "ID", nullable = false)
	private Crop crop;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING, Roles.ROLE_GLOBAL_DEVELOPMENT })
	private String regprimeCropCode;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING, Roles.ROLE_GLOBAL_DEVELOPMENT })
	private String regprimeProductLineNumber;

	@Column(nullable = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_MARKETING, Roles.ROLE_GLOBAL_DEVELOPMENT })
	private String regprimeCountryCode;

	@NotNull
	@Column(nullable = false)
	private String newportDiseasesPestsWeedsId;

	@Column(nullable = true)
	private String newportPtrs;

	@Column(nullable = true)
	private String newportLaunchYearCountry;

	@Column(nullable = true)
	private String newportLaunchYearSegment;

	@Column(nullable = true)
	private String newportLaunchYearNetSales;

	@Column(nullable = true)
	private String newportSubmissionYear;

	@Column(nullable = true)
	private String newportIsLaunched;

	@Column(nullable = true)
	private String newportWeightUnit;

	@Column(nullable = true)
	private String newportCurrency;

	@Column(nullable = true)
	private String newportBusinessUnit;

	@Column(nullable = true)
	private String newportStatus;

	@Column(nullable = true)
	private String newportCategory;

	@Column(name = "NEWPORT_GLOBAL_NPV_YEAR_10", nullable = true)
	private Double newportGlobalNpvYear10;

	@Column(name = "NEWPORT_GLOBAL_EXP_NPV_YEAR_10", nullable = true)
	private Double newportGlobalExpectedNpvYear10;

	@Column(nullable = true)
	private Double newportGlobalNetSales;

	@Column(nullable = true)
	private Double newportGlobalPeakNetSales;

	@Column(name = "NEWPORT_GLOBAL_PEAK_NET_SALES_Y", nullable = true)
	private Integer newportGlobalPeakNetSalesYear;

	@Column(name = "NEWPORT_GLOBAL_PEAK_YEAR_IGM_PE", nullable = true)
	private Double newportGlobalPeakYearIgmPercNetSales;

	@Column(name = "NEWPORT_GLOBAL_IGM_PERC_YEAR_4", nullable = true)
	private Double newportGlobalIgmPercYear4;

	@Column(name = "NEWPORT_GLOBAL_IGM_YEAR_4", nullable = true)
	private Double newportGlobalIgmYear4;

	@Column(nullable = true)
	private Double newportGlobalIgmPeakYear;

	@Column(name = "NEWPORT_GLOBAL_FUTURE_PRO_COST", nullable = true)
	private Double newportGlobalFutureProjectCost;

	@Column(name = "NEWPORT_GLOBAL_PRODUCTIVITY_IND", nullable = true)
	private Double newportGlobalProductivityIndex;

	@Column(name = "NEWPORT_GLOBAL_INC_NET_SALES", nullable = true)
	private Double newportGlobalIncrementalNetSales;

	@Column(name = "NEWPORT_GLOBAL_PEAK_NET_SALES_I", nullable = true)
	private Double newportGlobalPeakNetSalesIncremental;

	@Column(name = "NEWPORT_GLOBAL_INC_IGM_YEAR_4", nullable = true)
	private Double newportGlobalIncrementalIgmYear4;

	@Column(name = "NEWPORT_GLOBAL_PEAK_YEAR_IGM_IN", nullable = true)
	private Double newportGlobalPeakYearIgmIncremental;

	@Column(nullable = true)
	private Integer newportGlobalPaybackYear;

	@Column(nullable = true)
	private Double newportGlobalPaybackTime;

	@Column(nullable = true)
	private Double newportGlobalSalesVolume;

	@Column(name = "NEWPORT_GLOBAL_AGGREGATED_VOLUM", nullable = true)
	private Double newportGlobalAggregatedVolume;

	@Column(name = "NEWPORT_LOCAL_NPV_YEAR_10", nullable = true)
	private Double newportLocalNpvYear10;

	@Column(name = "NEWPORT_LOCAL_EXP_NPV_YEAR_10", nullable = true)
	private Double newportLocalExpectedNpvYear10;

	@Column(nullable = true)
	private Double newportLocalPaybackTime;

	@Column(nullable = true)
	private Double newportLocalPeakNetSales;

	@Column(name = "NEWPORT_LOCAL_PEAK_NET_SALES_YE", nullable = true)
	private Integer newportLocalPeakNetSalesYear;

	@Column(name = "NEWPORT_LOCAL_PEAK_YEAR_IGM_PER", nullable = true)
	private Double newportLocalPeakYearIgmPercNetSales;

	@Column(nullable = true)
	private Double newportLocalPeakYearIgm;

	@Column(name = "NEWPORT_LOCAL_PEAK_NET_SALES_IN", nullable = true)
	private Double newportLocalPeakNetSalesIncremental;

	@Column(name = "NEWPORT_LOCAL_PEAK_YEAR_IGM_INC", nullable = true)
	private Double newportLocalPeakYearIgmIncremental;

	@NotNull
	@Column(nullable = false)
	private boolean ptrsFollowUp;

	@Column(nullable = true)
	private String fsPtrsScoreUpdatedDate;

	@Column(nullable = true)
	private String fsPtrsScoreUpdatedBy;

	@Column(nullable = true)
	private String rsRegProductPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsRegProductPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsOccupationalResidentialExposurePtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsOccupationalResidentialExposurePtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsRegDietaryPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsRegDietaryPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsToxicologyPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsToxicologyPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsEcotoxPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsEcotoxPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsEfatePtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsEfatePtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsRegistrationPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsRegistrationPtrsScoreModifiedDate;


	@Column(nullable = true)
	private String rsLocalRestrictionPolicyPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsLocalRestrictionPolicyPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsLocalRestrictionOthersPtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsLocalRestrictionOthersPtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsForeignInfluencePtrsScoreModifiedBy;

	@Column(nullable = true)
	private String rsForeignInfluencePtrsScoreModifiedDate;

	@Column(nullable = true)
	private String rsPtrsScoreUpdatedDate;

	@Column(nullable = true)
	private String rsPtrsScoreUpdatedBy;

	@Column(nullable = true)
	private String creationDateMonth;

	@Column(nullable = true)
	private String countryType;


	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT })
	private LocalDate launchDate;

	@Column(nullable = true)
	@Audited(withModifiedFlag = true)
	@CheckedField(roles = { Roles.ROLE_GLOBAL_ADMIN, Roles.ROLE_GLOBAL_DEVELOPMENT, Roles.ROLE_PREFIX_REGIONAL_ADMIN,
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT })
	private LocalDate submissionDate;

	@PrePersist
	@PreUpdate
	public void calculateDependentScores() {


		Double overall = null;
		ArrayList<Double> rsSubscore = new ArrayList<Double>();
		if (getRsRegDietaryPtrsScore() != null && getRsRegDietaryPtrsScore() > 0) {
			rsSubscore.add(getRsRegDietaryPtrsScore());
		}

		if (getRsOccupationalResidentialExposurePtrsScore() != null && getRsOccupationalResidentialExposurePtrsScore() > 0) {
			rsSubscore.add(getRsOccupationalResidentialExposurePtrsScore());
		}

		if (getRsEcotoxPtrsScore() != null && getRsEcotoxPtrsScore() > 0) {
			rsSubscore.add(getRsEcotoxPtrsScore());
		}

		if (getRsForeignInfluencePtrsScore() != null && getRsForeignInfluencePtrsScore() > 0) {
			rsSubscore.add(getRsForeignInfluencePtrsScore());
		}
		if (getRsLocalRestrictionOthersPtrsScore() != null && getRsLocalRestrictionOthersPtrsScore() > 0) {
			rsSubscore.add(getRsLocalRestrictionOthersPtrsScore());
		}
		if (getRsLocalRestrictionPolicyPtrsScore() != null && getRsLocalRestrictionPolicyPtrsScore() > 0) {
			rsSubscore.add(getRsLocalRestrictionPolicyPtrsScore());
		}
		if (getRsEfatePtrsScore() != null && getRsEfatePtrsScore() > 0) {
			rsSubscore.add(getRsEfatePtrsScore());
		}
		if (getRsRegistrationPtrsScore() != null && getRsRegistrationPtrsScore() > 0) {
			rsSubscore.add(getRsRegistrationPtrsScore());
		}
		if (getRsRegProductPtrsScore() != null && getRsRegProductPtrsScore() > 0) {
			rsSubscore.add(getRsRegProductPtrsScore());
		}
		if (getRsToxicologyPtrsScore() != null && getRsToxicologyPtrsScore() > 0) {
			rsSubscore.add(getRsToxicologyPtrsScore());
		}
		if (rsSubscore != null && rsSubscore.isEmpty() && region.getRoleSuffix() != null && region.getRoleSuffix().equals("NA")) {
			setRsRegPtrsScore(null);
		} else if ((region.getRoleSuffix() != null && region.getRoleSuffix().equals("APAC"))) {  // remove the APAC check later when subScores are implented for it
			setRsRegPtrsScore(getRsRegPtrsScore());
		} else if (region.getRoleSuffix() != null && region.getRoleSuffix().equals("NA")) {
			setRsRegPtrsScore(Collections.min(rsSubscore));
		}
		//else if (region.getRoleSuffix()!=null && region.getRoleSuffix().equals("APAC") && rsSubscore.size()>=9) {
		// 	setRsRegPtrsScore(Collections.min(rsSubscore));
		// } Future use for APAC SubScore.
		else {
			setRsRegPtrsScore(getRsRegPtrsScore());
		}
		if (getProject() != null &&
				getProject().getNewportCategory() != null && (getProject().getNewportCategory().equals("Country Extension") || getProject().getNewportCategory().equals("Label Expansion"))) {
			Map<String, Double> map = NewProjectDto.calculateWeightedScores(getProject());
			LocalDate date = LocalDate.now();
			Double rs = 0d;
			Double fs = 0d;
			Integer fsScore = 0;
			Integer rsScore = 0;
			fs = map.containsKey("fsScore") ? (double) map.get("fsScore") : 0;
			rs = map.containsKey("rsScore") ? (double) map.get("rsScore") : 0;
			fsScore = (int) Math.round(fs);
			rsScore = (int) Math.round(rs);

			if (fsScore != 0.0 && (getProject().getFsPtrsScore() == null || getProject().getFsPtrsScore() == 0.0)) {
				getProject().setFsPtrsScore(fsScore / 100.0);
				getProject().setFsPtrsScoreRmk("The weighted Segment FS score becomes Project FS PTRS score by default, as Project FS PTRS was empty.");
				getProject().setFsPtrsScoreUpdatedBy("data-projects.sql");
				getProject().setFsPtrsScoreUpdatedDate(date.toString());
			} else if (fsScore != 0.0 && getProject().getFsPtrsScoreRmk() != null &&
					getProject().getFsPtrsScoreRmk().equals("The weighted Segment FS score becomes Project FS PTRS score by default, as Project FS PTRS was empty.")) {
				getProject().setFsPtrsScore(fsScore / 100.0);
				getProject().setFsPtrsScoreUpdatedBy("data-projects.sql");
				getProject().setFsPtrsScoreUpdatedDate(date.toString());

			}
			if (rsScore != 0.0 && (getProject().getRsPtrsScore() == null || project.getRsPtrsScore() == 0.0)) {
				getProject().setRsPtrsScore(rsScore / 100.0);
				getProject().setRsPtrsScoreRmk("The weighted Segment RS score becomes Project RS PTRS score by default, as Project RS PTRS was empty.");
				getProject().setRsPtrsScoreRmkModifiedBy("data-projects.sql");
				getProject().setRsPtrsScoreRmkModifiedDate(date.toString());
			} else if (rsScore != 0.0 && getProject().getRsPtrsScoreRmk() != null &&
					getProject().getRsPtrsScoreRmk().equals("The weighted Segment RS score becomes Project RS PTRS score by default, as Project RS PTRS was empty.")) {
				getProject().setRsPtrsScore(rsScore / 100.0);
				getProject().setRsPtrsScoreRmkModifiedBy("data-projects.sql");
				getProject().setRsPtrsScoreRmkModifiedDate(date.toString());
			}
		}

		if (getFsPtrsScore() != null && getProject().getFtPtrsScore() != null && getRsRegPtrsScore() != null) {
			overall = DomainUtil.roundScore(getFsPtrsScore().doubleValue() * getProject().getFtPtrsScore().doubleValue()
					* getRsRegPtrsScore().doubleValue());
		}
		setPtrsSegmentOverallScore(DomainUtil.getMaxOverallScore(overall));

		//To create consolidated region in project
		// to check if only region "Adjustment world"
		if (getRegion() != null && getRegion().getName() != null && getRegion().getName().equalsIgnoreCase("Adjustments World")) {
			if (getProject().getConsolidatedRegion() == null && getProject().getConsolidatedRegion() == "") {
				getProject().setConsolidatedRegion("Global");
			}
		}
		//if project consolidated region is coming in empty
		if (getProject() != null && getProject().getConsolidatedRegion() == null && getRegion().getRoleSuffix() != null) {
			getProject().setConsolidatedRegion(getRegion().getRoleSuffix());
		}
		//if project consolidated region already has a value
		if (getProject() != null && getProject().getConsolidatedRegion() != null && getRegion().getRoleSuffix() != null) {
			if (!getProject().getConsolidatedRegion().contains(getRegion().getRoleSuffix())) {
				String regionText = getProject().getConsolidatedRegion() + "," + getRegion().getRoleSuffix();
				getProject().setConsolidatedRegion(regionText);
			}
		}
		//if project has Global and other segments logic to remove Global
		if(getProject() != null && getProject().getConsolidatedRegion() != null && getProject().getConsolidatedRegion().contains("Global")
		&& getProject().getConsolidatedRegion().contains(",")){
			List<String> regionSuffixes =Arrays.asList(getProject().getConsolidatedRegion().split(","));
			String modifiedRegionRoleSuffix =regionSuffixes.stream().filter(region->!region.equalsIgnoreCase("Global")).collect(Collectors.joining(","));
			getProject().setConsolidatedRegion(modifiedRegionRoleSuffix);

		}
	}
	
	@Override
	public int compareTo(Object o) {
		Segment segment = (Segment) o;
		Long id1 = getId();
		Long id2 = segment.getId();

		return id1.compareTo(id2);
	}
}
