package com.bayer.pmodi.masterlist.search;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.bayer.pmodi.masterlist.model.Project;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SegmentCost;
import com.bayer.pmodi.masterlist.model.enums.CodeEnum;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ExportUtil {

	private ExportUtil() {
		// No instance allowed
	}

	public static String dateFromattingFields(String strDate){
		try{
			DateTimeFormatterBuilder dateTimeFormatterBuilder = new DateTimeFormatterBuilder().append(
					DateTimeFormatter.ofPattern("[M/d/yyyy]"+ "[M/dd/yyyy]" + "[[MM/d/yyyy]]" + "[yyyyMMdd]" + "[MM/dd/yyyy]"  + "[dd/MM/yyyy]" + "[yyyy/MM/dd]" +
							"[yyyy/MM/d]"+ "[dd-MM-yyyy]" + "[yyyy-MM-dd]" + "[yyyy-dd-MM]" + "[dd.MM.yyyy]" + "[d.M.yyyy]"+ "[dd.M.yyyy]" + "[d.MM.yyyy]"));
			DateTimeFormatter formatter  =  dateTimeFormatterBuilder.toFormatter();
			DateTimeFormatter formatting = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(strDate, formatter);
			String formattedDate = formatting.format(date);
			return formattedDate;
		} catch (Exception e) {
			return strDate;

		}

	}

	public static void createFileAndStreamTo(OutputStream outputStream, List<Project> list,List<Segment> listSegment) throws IOException {
		// keep 100 rows in memory, exceeding rows will be flushed to disk
		SXSSFWorkbook wb = new SXSSFWorkbook(100);
		// Create a CellStyle object for no border

		XSSFCellStyle style = wb.getXSSFWorkbook().createCellStyle();
		XSSFCellStyle style1 = wb.getXSSFWorkbook().createCellStyle();
		Font font = wb.createFont();

		try {
			Sheet projectSheet = wb.createSheet("Projects");
			Sheet segmentSheet = wb.createSheet("Segments");
			//projectSheet.setDefaultColumnWidth(50);
			//segmentSheet.setDefaultColumnWidth(50);
			createProjectSheet(projectSheet, list, style, font, style1);
			createSegmentSheet(segmentSheet, listSegment, style, font, style1);
			wb.write(outputStream);
		} finally {
			if (wb != null) {
				try {
					// dispose of temporary files backing this workbook on disk
					wb.dispose();
					wb.close();
				} catch (Exception e) {
					// ignored
				}
			}
		}
	}

	public static String projectCreatedDateFormatting(String newportProjectCreatedDate) {
		DateTimeFormatter formats = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String newportFormattedProjectCreatedDate="";
		try{
			LocalDate originalDate = LocalDate.parse(newportProjectCreatedDate, formats);
			newportFormattedProjectCreatedDate = dateTimeFormatter.format(originalDate);
			return newportFormattedProjectCreatedDate;
		} catch(Exception e){
			return newportFormattedProjectCreatedDate;
		}
	}

// Method for Newport Project Approval Date to format YYYY-MMM-DD
	public static String dateTypeFormattingApprovalProjectCreation(LocalDate date){
		String formattedDate="";
		try {
			DateTimeFormatter formats = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
			formattedDate = formats.format(date);
			return formattedDate;
		} catch (Exception e) {
			return formattedDate;
		}
	}

	private static void createSegmentSheet(Sheet segmentSheet, List<Segment> list, XSSFCellStyle style, Font font, XSSFCellStyle style1) {
		int rownum = 0;
		String[] headers = new String[]{"NP Number",
				"NP Project Name", "NP Free Text", "NP Status", "NP Category", "Product Spec Number",
				"NP SPG", "NP PLT", "NP Business Unit",
				"NP Lead AI", //
				"NP Project Concentration Unit", "NP Project Creation Date","NP Project Approval Date", "NP Segment Creation Date",
				"NP Project Initiator Id", "NP Project Initiator",
				"NP Project Formulation Type",
				"NP Project Is GBO", "NP Project Origin", "NP Project Product Hierarchy",
				"NP Project Launch Year", "NP Project Last Modified",
				"NP Project Last Modified User CWID", "NP Project Last Modified User",
				"Crop", "Crop Group", "Crop Platform", "Country", "Country Type", "Sub Region", "Region", "Target", "Cost Center",

				"NP Launch Year Country", "NP Launch Year Segment",
				"NP Launch Year Net Sales", "NP Submission Year", "NP Segment PTRS",
				"NP Segment Weight Unit",  //
				"NP Segment NPV 10 Years", "NP Segment Expected NPV 10 Years",
				"NP Segment Net Sales Year 4", "NP Segment Peak Net Sales",
				"NP Segment Peak Net Sales Year", "NP Segment % Igm at Peak Year",
				"NP Segment % Igm Year 4", "NP Segment Igm Year 4",
				"NP Segment Igm at Peak Year", "NP Segment Future Project Cost",
				"NP Segment Productivity Index", "NP Segment Incremental Net Sales Year 4",
				"NP Segment Incremental Net Sales at Peak Year",
				"NP Segment Incremental Igm Year 4", "NP Segment Incremental IGM Peak Year",
				"NP Segment Payback Year", "NP Segment Payback Time",
				"NP Segment Sales Volume Year 4", "NP Segment Aggregated Volume Year 1-10",
				"NP Local Segment NPV 10 Years", "NP Local Segment Expected NPV 10 Years",
				"NP Local Segment Payback Time", "NP Local Segment Peak Net Sales",
				"NP Local Segment Peak Net Sales Year", "NP Local Segment % IGM at Peak Year",
				"NP Local Segment IGM at Peak Year", "NP Local Segment Incremental Net Sales at Peak Year ",
				"NP Local Segment Incremental IGM at Peak Year",
				"Segment Strategic Fit Remark",
				"Segment A/B Categorization Governance", "Segment A/B Category Assignment", "Segment A/B Remarks",
				"Segment PTRS (%)", "Segment FS PTRS", "Segment FS PTRS Rationale","Segment FS PTRS/Rationale last modified by", "Segment FS PTRS/Rationale last modified date",
				"Segment RS PTRS", "Segment RS PTRS Rationale", "Segment RS PTRS/Rationale last modified by", "Segment RS PTRS/Rationale last modified date",

				"NA Segment RS Occupational Residential Exposure PTRS","NA Segment RS Occupational Residential Exposure Rationale",
				"NA Segment RS Occupational Residential Exposure PTRS/Rationale last modified by", "NA Segment RS Occupational Residential Exposure PTRS/Rationale last modified date",
				"NA Segment RS Dietary PTRS","NA Segment RS Dietary Rationale",
				"NA Segment RS Dietary PTRS/Rationale last modified by", "NA Segment RS Dietary PTRS/Rationale last modified date",
				"NA Segment RS Toxicology PTRS","NA Segment RS Toxicology Rationale",
				"NA Segment RS Toxicology PTRS/Rationale last modified by", "NA Segment RS Toxicology PTRS/Rationale last modified date",
				"NA Segment RS Ecotox PTRS","NA Segment RS Ecotox Rationale",
				"NA Segment RS Ecotox PTRS/Rationale last modified by", "NA Segment RS Ecotox PTRS/Rationale last modified date",
				"NA Segment RS Efate PTRS", "NA Segment RS Efate Rationale",
				"NA Segment RS Efate PTRS/Rationale last modified by", "NA Segment RS Efate PTRS/Rationale last modified date",
				"NA Segment RS Registration PTRS", "NA Segment RS Registration Rationale",
				"NA Segment RS Registration PTRS/Rationale last modified by", "NA Segment RS Registration PTRS/Rationale last modified date",
//				"APAC Segment RS Product PTRS", "APAC Segment RS Product Rationale",
//				"APAC Segment RS Product PTRS/Rationale last modified by", "APAC Segment RS Product PTRS/Rationale last modified date",
//				"APAC Segment RS Local Restriction_Policy PTRS", "APAC Segment RS Local Restriction_Policy Rationale",
//				"APAC Segment RS Local Restriction_Policy PTRS/Rationale last modified by", " APAC Segment RS Local Restriction_Policy PTRS/Rationale last modified date",
//				"APAC Segment RS Local Restriction_Others PTRS", "APAC Segment RS Local Restriction_Others Rationale",
//				"APAC Segment RS Local Restriction_Others PTRS/Rationale last modified by", "APAC Segment RS Local Restriction_Others PTRS/Rationale last modified date",
//				"APAC Segment RS Foreign Influence PTRS", "APAC Segment RS Foreign Influence Rationale",
//				"APAC Segment RS Foreign Influence PTRS/Rationale last modified by", "APAC Segment RS Foreign Influence PTRS/Rationale last modified date",

				"QuickScan Assessment Id", "Quickscan Applicable", "Quickscan Not Applicable Reason",
				"Regprime Z Number", "Regprime Sequence Number"
				//"Regprime Product Line Number",
				//"Regprime Crop Code", "Regprime Country Code"

		};


		//excel formatting

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		formatter.format(date);

		Row infoRow = segmentSheet.createRow(rownum);

		addCell(infoRow,0,"Date: "+formatter.format(date));
		addCell(infoRow,1,"Area unit 1000 ha");
		addCell(infoRow,2,"NP = NewPort");
		rownum = rownum + 1;
		Row currencyRow = segmentSheet.createRow(rownum);
		addCell(currencyRow,0,"Currency: 1000 Euro");
		addCell(currencyRow,1,"Weight/Volume unit: 1000 kg");
		rownum = rownum + 2;

		Row headerRow = segmentSheet.createRow(rownum);
		//segmentSheet.
		//excel
		//segmentSheet.trackAllColumnsForAutoSizing();
		segmentSheet.setDisplayGridlines(false);
		font.setBold(true);
		XSSFColor customColor = new XSSFColor(new java.awt.Color(153,204,255),null);
		style1.setFont(font);
		style1.setBorderTop(BorderStyle.THIN);
		style1.setTopBorderColor(customColor);
		style1.setBorderBottom (BorderStyle.THIN); style1.setBottomBorderColor(customColor);
		style1.setBorderLeft(BorderStyle.THIN);
		style1.setLeftBorderColor(customColor);
		style1.setBorderRight(BorderStyle.THIN);
		style1.setRightBorderColor(customColor);
		segmentSheet.setColumnWidth(0,(18)*256);
		Cell cell1 = addCell(headerRow, 0, headers[0]);
		cell1.setCellStyle(style1);
		for (int headerCellIndex = 1; headerCellIndex < headers.length; headerCellIndex++) {
			Cell cell = addCell(headerRow, headerCellIndex, headers[headerCellIndex]);
			cell.setCellStyle(style1);
			//if(headerCellIndex)
			if(Arrays.asList(1,2,4,6,7,9,24,25,26,27,29,30,31,67,73,74,77,78,104,106).contains(headerCellIndex)){
				segmentSheet.setColumnWidth(headerCellIndex,(30)*256);
			}else{
				segmentSheet.setColumnWidth(headerCellIndex,(headers[headerCellIndex].length())*256);
			}

		}
		style.setTopBorderColor(customColor);
		style.setBorderBottom (BorderStyle.THIN); style.setBottomBorderColor(customColor);
		style.setBorderLeft(BorderStyle.THIN);
		style.setLeftBorderColor(customColor);
		style.setBorderRight(BorderStyle.THIN);
		style.setRightBorderColor(customColor);
        /*for(int i=0;i<headers.length;i++){
			//segmentSheet.trackColumnForAutoSizing(i);
			segmentSheet.autoSizeColumn(i);
		}*/
		//any new column added will take this default column width
		segmentSheet.setDefaultColumnWidth(100);
		for (Segment segment : list) {


			rownum++;
			Row row = segmentSheet.createRow(rownum);
			int cellnum = 0;

			addCell(row, cellnum++, segment.getProject().getPreciseNewportId()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getNewportNewPortNumber()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportFreeText()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportStatus()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportCategory()).setCellStyle(style);
			if (segment.getProject().getProduct() != null) {
				addCell(row, cellnum++, segment.getProject().getProduct().getSpecNumber()).setCellStyle(style);
			} else {
				addCell(row, cellnum++, (String) null).setCellStyle(style);
			}
			addCell(row, cellnum++, segment.getProject().getNewportSpg()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportPlt()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportBusinessUnit()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getNewportBusinessGroup()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getNewportBusinessObjectiveNumber()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportLeadAi()).setCellStyle(style);

			addCell(row, cellnum++, segment.getProject().getNewportConcentrationUnit()).setCellStyle(style);
			addCell(row, cellnum++, projectCreatedDateFormatting(segment.getProject().getNewportProjectCreated())).setCellStyle(style);
			addCell(row, cellnum++, dateTypeFormattingApprovalProjectCreation(segment.getProject().getApprovalDate())).setCellStyle(style);
			addCell(row, cellnum++, dateTypeFormattingApprovalProjectCreation(segment.getCreationDate())).setCellStyle(style);

			addCell(row, cellnum++, segment.getProject().getNewportInitiatorId()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportInitiator()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportFormulationType()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getNewportFramework()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportIsGbo()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportOrigin()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportProductHierarchy()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportLaunchYear()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(segment.getProject().getNewportLastModified())).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportLastModifiedUserCwid()).setCellStyle(style);
			addCell(row, cellnum++, segment.getProject().getNewportLastModifiedUser()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getNewportCurrency()).setCellStyle(style);

			//addCell(row, cellnum++, segment.getProject().getNewportJustification()).setCellStyle(style);

			addCell(row, cellnum++, segment.getCrop().getName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getCrop().getCropGroup().getName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getCrop().getCropGroup().getCropPlatform().getName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getCountry().getName()).setCellStyle(style);
			addCell(row, cellnum++, (segment.getCountry().getFlag()==true?"High Regulation":"L4SU")).setCellStyle(style);
			addCell(row, cellnum++, segment.getSubRegion().getName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getRegion().getName()).setCellStyle(style);
			addCell(row, cellnum++, segment.getTarget()).setCellStyle(style);
			addCell(row, cellnum++, segment.getCostCenter()).setCellStyle(style);


			//addCell(row, cellnum++, segment.getNewportIsLaunched()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLaunchYearCountry()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLaunchYearSegment()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLaunchYearNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportSubmissionYear()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportPtrs()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportWeightUnit()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getNewportCurrency()).setCellStyle(style);

			//addCell(row, cellnum++, segment.getProject().getLumosGlobalProjectId()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getProject().getLumosLocalProjectId()).setCellStyle(style);

			addCell(row, cellnum++, segment.getNewportGlobalNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalExpectedNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPeakNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPeakNetSalesYear()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPeakYearIgmPercNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalIgmPercYear4()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalIgmYear4()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalIgmPeakYear()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalFutureProjectCost()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalProductivityIndex()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalIncrementalNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPeakNetSalesIncremental()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalIncrementalIgmYear4()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPeakYearIgmIncremental()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPaybackYear()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalPaybackTime()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalSalesVolume()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportGlobalAggregatedVolume()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalExpectedNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPaybackTime()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakNetSalesYear()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakYearIgmPercNetSales()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakYearIgm()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakNetSalesIncremental()).setCellStyle(style);
			addCell(row, cellnum++, segment.getNewportLocalPeakYearIgmIncremental()).setCellStyle(style);

			addCell(row, cellnum++, segment.getStrategicFitRmk()).setCellStyle(style);
			addCell(row, cellnum++, segment.getPrioritizationGovernance()).setCellStyle(style);
			addCell(row, cellnum++, segment.getPrioritizationType()).setCellStyle(style);
			addCell(row, cellnum++, segment.getPrioritizationRmk()).setCellStyle(style);
			addCell(row, cellnum++, segment.getPtrsSegmentOverallScore()).setCellStyle(style);
			addCell(row, cellnum++, segment.getFsPtrsScore()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getFsPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, segment.getFsPtrsScoreRmk() != null?  segment.getFsPtrsScoreRmk() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, segment.getFsPtrsScoreUpdatedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(segment.getFsPtrsScoreUpdatedDate())).setCellStyle(style);
			addCell(row, cellnum++, segment.getRsRegPtrsScore()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getRsRegPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, segment.getRsRegPtrsScoreRmk() != null?  segment.getRsRegPtrsScoreRmk() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, segment.getRsPtrsScoreUpdatedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(segment.getRsPtrsScoreUpdatedDate())).setCellStyle(style);

//			if(segment.getRegion()!=null && segment.getRegion().getRoleSuffix()!=null && (segment.getRegion().getRoleSuffix().equals("NA") || segment.getRegion().getRoleSuffix().equals("APAC"))) {
			if(segment.getRegion()!=null && segment.getRegion().getRoleSuffix()!=null && (segment.getRegion().getRoleSuffix().equals("NA"))) {
				addCell(row, cellnum++, segment.getRsOccupationalResidentialExposurePtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsOccupationalResidentialExposurePtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsOccupationalResidentialExposurePtrsScoreRmk() != null?  segment.getRsOccupationalResidentialExposurePtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsOccupationalResidentialExposurePtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsOccupationalResidentialExposurePtrsScoreModifiedBy() != null?  segment.getRsOccupationalResidentialExposurePtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsOccupationalResidentialExposurePtrsScoreModifiedDate())).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegDietaryPtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsRegDietaryPtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegDietaryPtrsScoreRmk() != null?  segment.getRsRegDietaryPtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsRegDietaryPtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegDietaryPtrsScoreModifiedBy() != null?  segment.getRsRegDietaryPtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsRegDietaryPtrsScoreModifiedDate())).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsToxicologyPtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsToxicologyPtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsToxicologyPtrsScoreRmk() != null?  segment.getRsToxicologyPtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsToxicologyPtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsToxicologyPtrsScoreModifiedBy() != null?  segment.getRsToxicologyPtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsToxicologyPtrsScoreModifiedDate())).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEcotoxPtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsEcotoxPtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEcotoxPtrsScoreRmk() != null?  segment.getRsEcotoxPtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsEcotoxPtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEcotoxPtrsScoreModifiedBy() != null?  segment.getRsEcotoxPtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsEcotoxPtrsScoreModifiedDate())).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEfatePtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsEfatePtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEfatePtrsScoreRmk() != null?  segment.getRsEfatePtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsEfatePtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsEfatePtrsScoreModifiedBy() != null?  segment.getRsEfatePtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsEfatePtrsScoreModifiedDate())).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegistrationPtrsScore()).setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsRegistrationPtrsScoreRmk()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegistrationPtrsScoreRmk() != null?  segment.getRsRegistrationPtrsScoreRmk() : "")
						.setCellStyle(style);
				//addCell(row, cellnum++, segment.getRsRegistrationPtrsScoreModifiedBy()).setCellStyle(style);
				addCell(row, cellnum++, segment.getRsRegistrationPtrsScoreModifiedBy() != null?  segment.getRsRegistrationPtrsScoreModifiedBy() : "")
						.setCellStyle(style);
				addCell(row, cellnum++, dateFromattingFields(segment.getRsRegistrationPtrsScoreModifiedDate())).setCellStyle(style);

//				addCell(row, cellnum++, segment.getRsRegProductPtrsScore());
//				addCell(row, cellnum++, segment.getRsRegProductPtrsScoreRmk());
//				addCell(row, cellnum++, segment.getRsRegProductPtrsScoreModifiedBy());
//				addCell(row, cellnum++, segment.getRsRegProductPtrsScoreModifiedDate());
//
//
//				addCell(row,cellnum++, segment.getRsLocalRestrictionPolicyPtrsScore());
//				addCell(row,cellnum++, segment.getRsLocalRestrictionPolicyPtrsScoreRmk());
//				addCell(row,cellnum++, segment.getRsLocalRestrictionPolicyPtrsScoreModifiedBy());
//				addCell(row,cellnum++, dateFromattingFields(segment.getRsLocalRestrictionPolicyPtrsScoreModifiedDate()));
//
//				addCell(row, cellnum++, segment.getRsLocalRestrictionOthersPtrsScore());
//				addCell(row, cellnum++, segment.getRsLocalRestrictionOthersPtrsScoreRmk());
//				addCell(row, cellnum++, segment.getRsLocalRestrictionOthersPtrsScoreModifiedBy());
//				addCell(row, cellnum++, dateFromattingFields(segment.getRsLocalRestrictionOthersPtrsScoreModifiedDate()));
//
//				addCell(row, cellnum++, segment.getRsForeignInfluencePtrsScore());
//				addCell(row, cellnum++, segment.getRsForeignInfluencePtrsScoreRmk());
//				addCell(row, cellnum++, segment.getRsForeignInfluencePtrsScoreModifiedBy());
//				addCell(row, cellnum++, dateFromattingFields(segment.getRsForeignInfluencePtrsScoreModifiedDate()));


			}else{
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);

				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);

				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);

				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);

				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);
				addCell(row, cellnum++, "").setCellStyle(style);

//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");
//				addCell(row, cellnum++, "");


			}


			addCell(row, cellnum++, segment.getQuickscanAssessmentId()).setCellStyle(style);
			if(segment.getIsQuickScanNotApplicable()!=null)
				addCell(row, cellnum++, (segment.getIsQuickScanNotApplicable()==true?"No":"Yes")).setCellStyle(style);
			else{
				addCell(row, cellnum++,"").setCellStyle(style);
			}
			addCell(row, cellnum++, segment.getQuickScanNotApplicableReason()).setCellStyle(style);
			addCell(row, cellnum++, segment.getRegprimeZNumber()).setCellStyle(style);
			addCell(row, cellnum++, segment.getRegprimeSequenceNumber()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getRegprimeProductLineNumber()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getRegprimeCropCode()).setCellStyle(style);
			//addCell(row, cellnum++, segment.getRegprimeCountryCode()).setCellStyle(style);

		}

	}


	private static void createProjectSheet(Sheet projectSheet, List<Project> list, XSSFCellStyle style, Font font, XSSFCellStyle style1) {
		int rownum = 0;
		// Header
		String[] headers = new String[]{"NP Number",
				"NP Project Name", "NP Free Text", "NP Status", "NP Category","Project with Segments", "Product Spec Number",
				"NP SPG", "NP PLT", "NP Business Unit",
				"NP Lead AI", //
				"NP Project Concentration Unit", "NP Project Creation Date","NP Project Approval Date",
				"NP Project Initiator Id", "NP Project Initiator",
				"NP Project Formulation Type",
				"NP Project Is GBO", "NP Project Origin", "NP Project Product Hierarchy",
				"NP Project Launch Year", "NP Project PTRS", "NP Project Last Modified",
				"NP Project Last Modified User CWID", "NP Project Last Modified User",
				//
				"NP Objective", "NP Product Profile", "NP Success Factors",  //
				"LUMOS Global Project Id",  //
				"NP Project Npv 10 Years", "NP Project Expected Npv 10 Years",
				"NP Project Net Sales", "NP Project Incremental Net Sales",
				"NP Project Peak Net Sales", "NP Project Incremental Net Sales at Peak Year",
				"NP Project IGM at Peak Year", "NP Project Incremental IGM at Peak Year",
				"NP Project IGM Year 4", "NP Project % IGM Year 4",
				"NP Project Incremental Igm Year 4", "NP Project Sales Volume",
				"NP Project Aggregated Volume", "NP Project Future Project Cost",
				"NP Project Productivity Index", "NP Local Project NPV 10 Years",
				"NP Local Project Expected NPV 10 Years", "NP Local Project Peak Net Sales",
				"NP Local Project Incremental Net Sales at Peak Year", "NP Local Project IGM at Peak Year",
				"NP Local Project Incremental IGM at Peak Year",
				"NP Local Project % IGM at Peak Year",
				"Project PTRS Overall", "FT Responsibility", "FT Status NF-PoC (Only NF-PoC Project)",
				"FT Recommendation", "FT Recommendation Modified By", "FT Recommendation Modified Date", "Project FT PTRS",
				"Project FT PTRS Rationale", "Project FT PTRS/Rationale last modified by", "Project FT PTRS/Rationale last modified date",
				"FS Objective (Only NF-PoC Project)",
				"FS Result (Only NF-PoC Project)", "FS Recommendation", "FS Recommendation Modified By", "FS Recommendation Modified Date", "Project FS PTRS", "Project FS PTRS Rationale", "Project FS PTRS/Rationale last modified by", "Project FS PTRS/Rationale last modified date",
				"RS Recommendation", "RS Recommendation Modified By", "RS Recommendation Modified Date",
				"Project RS PTRS", "Project RS PTRS Rationale", "Project RS PTRS Rationale last Modified By", "Project RS PTRS Rationale last Modified Date",
				"Project RS Dietary Safety PTRS", "Project RS Dietary Safety PTRS Rationale", "Project RS Dietary Safety PTRS/Rationale last modified by", "Project RS Dietary Safety PTRS last modified date",
				"Project RS Ensa PTRS", "Project RS Ensa PTRS Rationale", "Project RS Ensa PTRS/Rationale last modified by", "Project RS Ensa PTRS/Rationale last modified date",
				"Project RS Operator Risk PTRS", "Project RS Operator Risk PTRS Rationale", "Project RS Operator Risk PTRS/Rationale last modified by", "Project RS Operator Risk PTRS/Rationale last modified date",
				"Project RS Regulatory Affairs PTRS", "Project RS Regulatory Affairs PTRS Rationale", "Project RS Regulatory Affairs PTRS/Rationale last modified by", "Project RS Regulatory Affairs PTRS/Rationale last modified date",
				"Project Strategic Fit Remark", "Project A/B Categorization Governance",
				"Project A/B Category Assignment", "Project A/B Remarks", "NP Project Prioritization Category",
				"Portfolio Guidance (Non-Core A.I. & Financial Hurdles)", "Regulatory Guidance ('No Go' and IT/MRL)",
				"L4SU/QuickScan Check Outcome", "Specific Project Framework",
				"3rd Party AI Regulatory Check", "Development Functions Position", "Sustainability Assessment",
				"Intellectual Property Assessment"};

		//excel formatting

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		formatter.format(date);

		Row infoRow = projectSheet.createRow(rownum);
		addCell(infoRow, 0, "Date: " + formatter.format(date));
		addCell(infoRow, 1, "Area unit 1000 ha");
		addCell(infoRow, 2, "NP = NewPort");
		rownum = rownum + 1;
		Row currencyRow = projectSheet.createRow(rownum);
		addCell(currencyRow, 0, "Currency: 1000 Euro");
		addCell(currencyRow, 1, "Weight/Volume unit: 1000 kg");
		rownum = rownum + 2;

		Row headerRow = projectSheet.createRow(rownum);
		projectSheet.setDisplayGridlines(false);
		font.setBold(true);
		style1.setFont(font);
		style1.setBorderTop(BorderStyle.THIN);
		XSSFColor customColor = new XSSFColor(new java.awt.Color(153,204,255),null);
		style1.setTopBorderColor(customColor);
		style1.setBorderBottom (BorderStyle.THIN); style1.setBottomBorderColor(customColor);
		style1.setBorderLeft(BorderStyle.THIN);
		style1.setLeftBorderColor(customColor);
		style1.setBorderRight(BorderStyle.THIN);
		style1.setRightBorderColor(customColor);
		projectSheet.setColumnWidth(0,(18)*256);
		Cell cell1 = addCell(headerRow, 0, headers[0]);
		cell1.setCellStyle(style1);
		for (int headerCellIndex = 1; headerCellIndex < headers.length; headerCellIndex++) {
			Cell cell = addCell(headerRow, headerCellIndex, headers[headerCellIndex]);
			cell.setCellStyle(style1);
			if(Arrays.asList(1,2,4,6,7,9,24,25,26,62,66,69,73,77,81,85,89,92,95,
					98,99,101,102,104).contains(headerCellIndex)){
				projectSheet.setColumnWidth(headerCellIndex,(30)*256);
			}else{
				projectSheet.setColumnWidth(headerCellIndex,(headers[headerCellIndex].length())*256);
			}
		}
		style.setTopBorderColor(customColor);
		style.setBorderBottom (BorderStyle.THIN); style.setBottomBorderColor(customColor);
		style.setBorderLeft(BorderStyle.THIN);
		style.setLeftBorderColor(customColor);
		style.setBorderRight(BorderStyle.THIN);
		style.setRightBorderColor(customColor);

		ArrayList<String> projectIdList = new ArrayList<String>();
		// Content
		//projectSheet.
		//excel
		//projectSheet.trackAllColumnsForAutoSizing();
        /*for(int i=0;i<headers.length;i++){
			//projectSheet.trackColumnForAutoSizing(i);
			projectSheet.autoSizeColumn(i);
		}*/

		for (Project project : list) {
			//Boolean flag = checkProjectId(projectIdList, project.getPreciseNewportId());


			//if(!flag){
			rownum++;
			Row row = projectSheet.createRow(rownum);
			int cellnum = 0;
			addCell(row, cellnum++, project.getPreciseNewportId()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportNewPortNumber()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportName()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportFreeText()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportStatus()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportCategory()).setCellStyle(style);
			addCell(row, cellnum++, ( project.getIsSegmentPresent() != null && project.getIsSegmentPresent().equalsIgnoreCase("Yes"))? "Yes":"No")
					.setCellStyle(style);
			if (project.getProduct() != null) {
				addCell(row, cellnum++, project.getProduct().getSpecNumber()).setCellStyle(style);
			} else {
				addCell(row, cellnum++, (String) null).setCellStyle(style);
			}
			addCell(row, cellnum++, project.getNewportSpg()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportPlt()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportBusinessUnit()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportBusinessGroup()).setCellStyle(style)
			addCell(row, cellnum++, project.getNewportLeadAi()).setCellStyle(style);

			addCell(row, cellnum++, project.getNewportConcentrationUnit()).setCellStyle(style);
			addCell(row, cellnum++, projectCreatedDateFormatting(project.getNewportProjectCreated())).setCellStyle(style);
			addCell(row, cellnum++, dateTypeFormattingApprovalProjectCreation(project.getApprovalDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportInitiatorId()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportInitiator()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportFormulationType()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportFramework()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportIsGbo()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportOrigin()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportProductHierarchy()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLaunchYear()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportPtrs()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getNewportLastModified())).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLastModifiedUserCwid()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLastModifiedUser()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportCurrency()).setCellStyle(style);

			addCell(row, cellnum++, project.getNewportObjective()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportProductProfile()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportSuccessFactors()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportJustification()).setCellStyle(style);

			//addCell(row, cellnum++, project.getLumosGlobalProjectId()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportBusinessObjectiveNumber()).setCellStyle(style);
			//addCell(row, cellnum++, project.getLumosLocalProjectId()).setCellStyle(style);


			addCell(row, cellnum++, project.getNewportGlobalNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalExpectedNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalNetSales()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalIncrementalNetSales()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalPeakNetSales()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalPeakNetSalesIncremental()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalIgmPeakYear()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalPeakYearIgmIncremental()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalIgmYear4()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalPercIgmYear4()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalIncrementalIgmYear4()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalSalesVolume()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalAggregatedVolume()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalFutureProjectCost()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportGlobalProductivityIndex()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalExpectedNpvYear10()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalPeakNetSales()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalPeakNetSalesIncremental()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalPeakYearIgm()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalPeakYearIgmIncremental()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportLocalPeakYearIgmPercNetSales()).setCellStyle(style);

			addCell(row, cellnum++, project.getOverallPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getTechResponsability()).setCellStyle(style);
			addCell(row, cellnum++, project.getTechStatus()).setCellStyle(style);
			addCell(row, cellnum++, project.getTechRecommendation()).setCellStyle(style);
			addCell(row, cellnum++, project.getTechRecommendationModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, project.getTechRecommendationModifiedDate()).setCellStyle(style);
			addCell(row, cellnum++, project.getFtPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getFtPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getFtPtrsScoreModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getFtPtrsScoreModifiedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getSolObjective()).setCellStyle(style);
			addCell(row, cellnum++, project.getSolResult()).setCellStyle(style);
			addCell(row, cellnum++, project.getSolRecommendation()).setCellStyle(style);
			addCell(row, cellnum++, project.getSolRecommendationModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, project.getSolRecommendationModifiedDate()).setCellStyle(style);
			addCell(row, cellnum++, project.getFsPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getFsPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getFsPtrsScoreUpdatedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getFsPtrsScoreUpdatedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getScienceRecommendation()).setCellStyle(style);
			addCell(row, cellnum++, project.getScienceRecommendationModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, project.getScienceRecommendationModifiedDate()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsPtrsScoreRmkModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getRsPtrsScoreRmkModifiedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getRsDietaryPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsDietaryPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsDietaryPtrsScoreModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getRsDietaryPtrsScoreModifiedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getRsEnsaPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsEnsaPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsEnsaPtrsScoreModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getRsEnsaPtrsScoreModifiedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getRsOperatorPtrsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsOperatorPtrsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsOperatorPtrsScoreModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getRsOperatorPtrsScoreModifiedDate())).setCellStyle(style);
			addCell(row, cellnum++, project.getRsRegAffairsScore()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsRegAffairsScoreRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getRsRegAffairsScoreModifiedBy()).setCellStyle(style);
			addCell(row, cellnum++, dateFromattingFields(project.getRsRegAffairsScoreModifiedDate())).setCellStyle(style);

			addCell(row, cellnum++, project.getStrategicFitRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getPrioritizationGovernance()).setCellStyle(style);
			addCell(row, cellnum++, project.getPrioritizationType()).setCellStyle(style);
			addCell(row, cellnum++, project.getPrioritizationRmk()).setCellStyle(style);
			addCell(row, cellnum++, project.getNewportPrioritizationCategory()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportPrioritizationRankingB()).setCellStyle(style);
			//addCell(row, cellnum++, project.getNewportPrioritizationCommentB()).setCellStyle(style);
			addCell(row, cellnum++, project.getGlobalPortfolioGuidance()).setCellStyle(style);
			addCell(row, cellnum++, project.getGlobalRegGuidance()).setCellStyle(style);
			addCell(row, cellnum++, project.getLabelForSafeUse() != null ? project.getLabelForSafeUse() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, project.getSpecificProjectFramework() != null ? project.getSpecificProjectFramework() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, project.getThirdPartyAiRegCheck() != null ? project.getThirdPartyAiRegCheck() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, project.getDevelopmentFunctions() != null ? project.getDevelopmentFunctions() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, project.getSustainabilityAssessment() != null ? project.getSustainabilityAssessment() : "").
					setCellStyle(style);
			addCell(row, cellnum++, project.getIntelectualPropertyAssessment() != null ? project.getIntelectualPropertyAssessment() : "")
					.setCellStyle(style);
			addCell(row, cellnum++, "");
	//	}
	 }

   }

	private static Boolean checkProjectId(List<String> projectIdList,String preciseNewportId) {
		if(projectIdList.isEmpty()) {
			projectIdList.add(preciseNewportId);
			return false;
		} else {
			if(projectIdList.contains(preciseNewportId))
				return true;
			else {
				projectIdList.add(preciseNewportId);
				return false;
			}
		}
	}

	public static void createCostsFileAndStreamTo(OutputStream outputStream, List<SegmentCost> costs)
			throws IOException {
		// keep 100 rows in memory, exceeding rows will be flushed to disk
		SXSSFWorkbook wb = new SXSSFWorkbook(100);
		try {
			Sheet sh = wb.createSheet("SegmentCosts");
			int rownum = 0;
			// Header
			Row headerRow = sh.createRow(rownum);
			addCell(headerRow, 0, "Cost Type");
			List<String> years = costs.stream().map(c -> c.getYear()).distinct().sorted().collect(Collectors.toList());
			for (int yearIndex = 0; yearIndex < years.size(); yearIndex++) {
				addCell(headerRow, yearIndex + 1, years.get(yearIndex));
			}
			// Content
			List<CostTypeRow> contentRows = toCostTypeRows(costs);
			for (CostTypeRow contentRow : contentRows) {
				rownum++;
				Row row = sh.createRow(rownum);
				int cellnum = 0;
				addCell(row, cellnum++, contentRow.getCostTypeName());
				for (int yearIndex = 0; yearIndex < years.size(); yearIndex++) {
					String year = years.get(yearIndex);
					addCell(row, yearIndex + 1, contentRow.getCostValueForYear(year));
				}
			}
			// Column widths
			sh.setColumnWidth(0, 24 * 256);
			for (int yearIndex = 0; yearIndex < years.size(); yearIndex++) {
				sh.setColumnWidth(yearIndex + 1, 8 * 256);
			}

			wb.write(outputStream);
		} finally {
			if (wb != null) {
				try {
					// dispose of temporary files backing this workbook on disk
					wb.dispose();
					wb.close();
				} catch (Exception e) {
					// ignored
				}
			}
		}
	}

	private static List<CostTypeRow> toCostTypeRows(List<SegmentCost> costs) {
		List<CostTypeRow> rows = new ArrayList<>();
		rows.add(Create("Formulation Technology", costs, c -> c.getFormulationTechnology()));
		rows.add(Create("Regulatory Affairs", costs, c -> c.getRegulatoryAffairs()));
		rows.add(Create("Registration Fees", costs, c -> c.getRegistrationFees()));
		rows.add(Create("Launch Marketing", costs, c -> c.getLaunchMarketing()));
		rows.add(Create("Human Safety", costs, c -> c.getHumanSafety()));
		rows.add(Create("Environmental Safety", costs, c -> c.getEnvironmentalSafety()));
		rows.add(Create("Field Development", costs, c -> c.getFieldDevelopment()));
		rows.add(Create("Customer Advisory", costs, c -> c.getCustomerAdvisory()));
		rows.add(Create("Other Costs", costs, c -> c.getOtherCosts()));
		rows.add(Create("Total Project Costs", costs, c -> c.getTotalProjectCosts()));
		return rows;
	}

	private static CostTypeRow Create(String name, List<SegmentCost> costs, Function<SegmentCost, Double> map) {
		CostTypeRow row = new CostTypeRow(name);
		for (SegmentCost cost : costs) {
			Double value = map.apply(cost);
			row.add(cost.getYear(), value);
		}
		return row;
	}

	private static Cell addCell(Row row, int cellnum, Number numberCellValue) {
		Cell cell = row.createCell(cellnum);
		if (numberCellValue == null) {
			cell.setBlank();
		} else {
			cell.setCellValue(numberCellValue.doubleValue());
		}
		return cell;
	}

	private static Cell addCell(Row row, int cellIndex, Enum<?> enumCellValue) {
		if (enumCellValue == null) {
			return addCell(row, cellIndex, (String) null);

		} else {
			if (enumCellValue instanceof CodeEnum) {

				return addCell(row, cellIndex, ((CodeEnum<?>) enumCellValue).code());
			} else {
				return addCell(row, cellIndex, enumCellValue.name());
			}
		}
	}

	private static Cell addCell(Row row, int cellIndex, String cellValue) {
		Cell cell = row.createCell(cellIndex);
		cell.setCellValue(cellValue);
		return cell;
	}



}
