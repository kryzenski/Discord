package com.bayer.pmodi.masterlist.config.security.exception;

public class PmodiForbiddenException extends RuntimeException {

	private static final long serialVersionUID = 568363298102123598L;

	public PmodiForbiddenException(String msg) {
		super(msg);
	}

	public PmodiForbiddenException(String msg, Throwable t) {
		super(msg, t);
	}
}