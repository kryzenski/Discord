package com.bayer.pmodi.masterlist.authorization;

public class SpecialTreatment {

	public static final String PRIORITIZATION_TYPE_BY_GOVERNANCE = "prioritizationTypeByGovernance";

	private SpecialTreatment() {
		// No instance allowed
	}

}
