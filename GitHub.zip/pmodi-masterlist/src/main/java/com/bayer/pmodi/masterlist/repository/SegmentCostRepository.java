package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.SegmentCost;

public interface SegmentCostRepository extends BaseRepository<SegmentCost> {

	Page<SegmentCost> findBySegmentId(Long id, Pageable pageInfo);

	long deleteBySegmentId(Long id);

}
