package com.bayer.pmodi.masterlist.authorization;

import java.util.List;
import java.util.Map;

public interface AuthenticatedFieldDefinition {

	List<String> getEditableFields();

	List<String> getGlobalAdminFields();

	List<String> getGlobalMarketingFields();

	List<String> getGlobalDevelopmentFields();

	List<String> getRegionalAdminFields();

	List<String> getRegionalMarketingFields();

	List<String> getRegionalDevelopmentFields();

	Map<String, String> getSpecialFields();

	/**
	 * @param group Group
	 * @return List of group fields; never null
	 */
	List<String> getGroupFields(String group);

}