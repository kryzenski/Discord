package com.bayer.pmodi.masterlist.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum RevisionTypeDto {

	@JsonProperty("add")
	ADD, //
	@JsonProperty("mod")
	MOD, //
	@JsonProperty("del")
	DEL

}
