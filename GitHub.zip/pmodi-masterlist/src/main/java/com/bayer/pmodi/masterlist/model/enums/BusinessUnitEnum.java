package com.bayer.pmodi.masterlist.model.enums;

import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public enum BusinessUnitEnum implements CodeEnum<BusinessUnitEnum> {

	HERBICIDES("CP Herbicides", "CP Herbicides"), //
	FUNGICIDES("CP Fungicides", "CP Fungicides"), //
	SEED_GROWTH("CP SeedGrowth", "CP SeedGrowth"), //
	INSECTICIDES("CP Insecticides", "CP Insecticides");

	private String label;
	private String code;
	private static Map<String, BusinessUnitEnum> CODE_MAP = new LinkedHashMap<String, BusinessUnitEnum>();

	static {
		for (BusinessUnitEnum e : EnumSet.allOf(BusinessUnitEnum.class)) {
			CODE_MAP.put(e.code(), e);
		}
	}

	/**
	 * Constructor.
	 * 
	 * @param code  The code
	 * @param label The display label
	 */
	BusinessUnitEnum(final String code, final String label) {
		this.code = code;
		this.label = label;
	}

	/**
	 * @return The code
	 */
	public String code() {
		return this.code;
	}

	/**
	 * @return The display label
	 */
	public String label() {
		return this.label;
	}

	/**
	 * Returns enumeration value for the given database code
	 * 
	 * @param code The code
	 * @return the enumeration or null if code is null
	 * @throws IllegalArgumentException if code is invalid
	 */
	public static BusinessUnitEnum fromCode(final String code) {
		if (code == null) {
			return null;
		}
		BusinessUnitEnum en = CODE_MAP.get(code);
		if (en == null) {
			throw new IllegalArgumentException("code \"" + code + "\" does not exist in domain");
		}
		return en;
	}

	/**
	 * Returns the set of all valid database codes
	 * 
	 * @return all codes
	 */
	public static Set<String> codes() {
		return Collections.unmodifiableSet(CODE_MAP.keySet());
	}

}
