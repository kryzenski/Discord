package com.bayer.pmodi.masterlist.config.security;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.microsoft.azure.spring.autoconfigure.aad.UserPrincipal;

import net.minidev.json.JSONArray;

@Service
@Profile("sso")
public class SSOUserDetailsHelper implements UserDetailsHelper {

	@Override
	public Object getCurrentUserClaim(String claimKey) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null && !(auth instanceof AnonymousAuthenticationToken)) {
			if (auth.getPrincipal() instanceof UserPrincipal) {
				Map<String, Object> claims = ((UserPrincipal) auth.getPrincipal()).getClaims();
				return claims == null ? null : claims.get(claimKey);
			}
			return null;
		}
		throw new IllegalStateException("Authentication not set in SecurityContext!");
	}

	@Override
	public String getCurrentUserId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null && !(auth instanceof AnonymousAuthenticationToken)) {
			String userId = null;
			if (auth.getPrincipal() instanceof UserPrincipal) {
				Map<String, Object> claims = ((UserPrincipal) auth.getPrincipal()).getClaims();
				if (claims != null) {
					userId = (String) claims.get(UNIQUE_IDENTIFIER_NAME);
					if (StringUtils.isBlank(userId)) {
						userId = (String) claims.get(UNIQUE_APP_IDENTIFIER_NAME);
					}
				}
			} else {
				userId = auth.getName();
			}
			if (StringUtils.isBlank(userId)) {
				if (auth.getPrincipal() instanceof UserPrincipal) {
					throw new IllegalStateException("Authentication contains no user ID!");
				} else {
					throw new IllegalStateException(
							"Authentication is not an AZURE UserPrincipal and contains no user ID!");
				}
			}
			return userId;
		}
		throw new IllegalStateException("Authentication not set in SecurityContext!");
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> getCurrentUserRoles() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null && !(auth instanceof AnonymousAuthenticationToken)) {
			List<String> roles = null;
			if (auth.getPrincipal() instanceof UserPrincipal) {
				Map<String, Object> claims = ((UserPrincipal) auth.getPrincipal()).getClaims();
				Object claim = claims == null ? null : claims.get(ROLES);
				if (claim instanceof JSONArray) {
					roles = new ArrayList<>();
					JSONArray roleArray = (JSONArray) claim;
					if (roleArray != null) {
						for (Object role : roleArray) {
							roles.add(String.valueOf(role));
						}
					}
				} else if (claim instanceof Iterable) {
					final List<String> claimRoles = new ArrayList<>();
					((Iterable) claim).forEach(r -> claimRoles.add(String.valueOf(r)));
					roles = new ArrayList<>(claimRoles);
				}
			} else {
				if (auth.getAuthorities() != null) {
					roles = auth.getAuthorities().stream().map(a -> a.getAuthority()).collect(Collectors.toList());
				}
			}
			if (roles == null) {
				return Collections.emptyList();
			}
			return roles;
		}
		throw new IllegalStateException("Authentication not set in SecurityContext!");
	}

}