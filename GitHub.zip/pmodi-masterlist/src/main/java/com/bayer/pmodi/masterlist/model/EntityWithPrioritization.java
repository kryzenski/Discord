package com.bayer.pmodi.masterlist.model;

import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;

public interface EntityWithPrioritization {

	LocationTypeEnum getPrioritizationGovernance();

	PrioritizationTypeEnum getPrioritizationType();

	String getPrioritizationRmk();

}
