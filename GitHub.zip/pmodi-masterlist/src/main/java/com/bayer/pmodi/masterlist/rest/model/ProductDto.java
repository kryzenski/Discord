package com.bayer.pmodi.masterlist.rest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class ProductDto {

	private Long id;
	private String specNumber;
	private String productLineText;
	private String brandName;

}