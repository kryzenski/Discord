package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.Segment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SegmentDto extends NewSegmentDto {

	public static SegmentDto from(Segment src) {
		if (src == null) {
			return null;
		}
		SegmentDto result = new SegmentDto();
		SegmentEditableFieldsDto.mapOwn(src, result);
		NewSegmentDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Segment src, SegmentDto result) {
		result.setId(src.getId());
		result.setVersion(src.getVersion());
		result.setProject(ProjectShortInfoDto.from(src.getProject()));

	}

	@NotNull
	private Long id;

	@NotNull
	private Integer version;

	private ProjectShortInfoDto project;

}