package com.bayer.pmodi.masterlist.profile;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
@Profile({ "demo" })
public class DemoDataLoader implements CommandLineRunner {

//	@Autowired
//	private RegionRepository regionRepository;
//
//	@Autowired
//	private SubRegionRepository subRegionRepository;
//
//	@Autowired
//	private CountryRepository countryRepository;

	@Override
	public void run(String... args) throws Exception {
//		List<Region> listRegion = new ArrayList<>();
//		Region r1 = new Region();
//		r1.setName("North America");
//		listRegion.add(r1);
//		Region r2 = new Region();
//		r2.setName("South America");
//		listRegion.add(r2);
//		Region r3 = new Region();
//		r3.setName("Asia");
//		listRegion.add(r3);
//		Region r4 = new Region();
//		r4.setName("Europe");
//		listRegion.add(r4);
//		regionRepository.saveAll(listRegion);
//
//		List<SubRegion> listSubRegion = new ArrayList<>();
//		SubRegion sr1 = new SubRegion();
//		sr1.setName("North America Main");
//		sr1.setRegion(r1);
//		listSubRegion.add(sr1);
//		SubRegion sr2 = new SubRegion();
//		sr2.setName("South America Central");
//		sr2.setRegion(r2);
//		listSubRegion.add(sr2);
//		SubRegion sr2b = new SubRegion();
//		sr2b.setName("South America Coastal");
//		sr2b.setRegion(r2);
//		listSubRegion.add(sr2b);
//		SubRegion sr3 = new SubRegion();
//		sr3.setName("Asia Main");
//		sr3.setRegion(r3);
//		listSubRegion.add(sr3);
//		SubRegion sr4 = new SubRegion();
//		sr4.setName("Europe");
//		sr4.setRegion(r4);
//		listSubRegion.add(sr4);
//		subRegionRepository.saveAll(listSubRegion);
//
//		List<Country> listCountry = new ArrayList<>();
//		Country c1 = new Country();
//		c1.setName("USA");
//		c1.setSubRegion(sr1);
//		listCountry.add(c1);
//		Country c2 = new Country();
//		c2.setName("Canada");
//		c2.setSubRegion(sr1);
//		Country c3 = new Country();
//		c3.setName("Brazil");
//		c3.setSubRegion(sr2b);
//		listCountry.add(c3);
//		Country c4 = new Country();
//		c4.setName("Bolivia");
//		c4.setSubRegion(sr2);
//		listCountry.add(c4);
//		Country c5 = new Country();
//		c5.setName("Germany");
//		c5.setSubRegion(sr4);
//		listCountry.add(c5);
//		Country cPlaceholder = new Country();
//		cPlaceholder.setName("Placeholder North America");
//		cPlaceholder.setSubRegion(sr1);
//		cPlaceholder.setPlaceholder(true);
//		listCountry.add(cPlaceholder);
//		countryRepository.saveAll(listCountry);

	}

}
