package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.rest.RestConstants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Class which bundles page and sort parameters. Name is used as example (and as
 * default value) for sorting.<br>
 * <ul>
 * <li><b>page</b> The page number is an integer between 0 (first page) and
 * Integer.MAX_VALUE; optional (but then the first page is used)</li>
 * <li><b>size</b> Size of a page, must be a positive number; optional (but then
 * Integer.MAX_VALUE is used)</li>
 * <li><b>sortBy</b> Name of the fields used for sorting the results, comma
 * separated; optional (but then no sorting takes place)</li>
 * <li><b>sortDir</b> Sorting direction, either ASC or DESC; optional (but then
 * the default is used)</li>
 * </ul>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class PageAndSortCriteriaSortedByName implements PageAndSortCriteria {

	@ApiParam(value = RestConstants.PAGE_NUMBER, type = "int", example = "0")
	@ApiModelProperty(value = RestConstants.PAGE_NUMBER, example = "0")
	Integer page = 0;

	@ApiParam(value = RestConstants.PAGE_SIZE, type = "int", example = "50")
	@ApiModelProperty(value = RestConstants.PAGE_SIZE, example = "50")
	Integer size = Integer.MAX_VALUE;

	@ApiParam(value = RestConstants.SORT_BY, example = "name")
	@ApiModelProperty(value = RestConstants.SORT_BY, example = "name")
	String sortBy = "name";

	@ApiParam(value = RestConstants.SORT_DIR, allowableValues = "ASC, DESC", example = "ASC")
	@ApiModelProperty(value = RestConstants.SORT_DIR, allowableValues = "ASC, DESC", example = "ASC")
	String sortDir = "ASC";

}
