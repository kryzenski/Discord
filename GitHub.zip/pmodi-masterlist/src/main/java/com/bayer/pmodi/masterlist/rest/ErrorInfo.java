package com.bayer.pmodi.masterlist.rest;

import org.springframework.http.HttpStatus;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ErrorInfo {

	private int status;
	private String message;
	private String[] details;

	public ErrorInfo() {
	}

	public ErrorInfo(String message) {
		this(HttpStatus.INTERNAL_SERVER_ERROR.value(), message);
	}

	public ErrorInfo(int status, String message, String... details) {
		this.status = status;
		this.message = message;
		this.details = details;
	}

}
