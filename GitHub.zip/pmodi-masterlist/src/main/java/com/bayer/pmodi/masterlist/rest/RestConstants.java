package com.bayer.pmodi.masterlist.rest;

public final class RestConstants {

	public static final String PAGE_NUMBER = "The page number is an integer between 0 (first page) and infinity";
	public static final String PAGE_SIZE = "Size of a page, must be a positive number";
	public static final String SORT_BY = "Name of the fields used for sorting the results, comma separated";
	public static final String SORT_DIR = "Sorting direction, either ASC or DESC";

	public static final String PARAM_ID = "id";
	public static final String PARAM_NAME = "name";;
	public static final String BY_USER = "byUser";

	private RestConstants() {
		// No instance allowed
	}

}
