package com.bayer.pmodi.masterlist.rest.model;

import com.bayer.pmodi.masterlist.model.ProjectComment;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of a project comment which are allowed to
 * be updated i.e. no primary or foreign keys. It also contains the version
 * attribute to allow concurrent modification checks.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ProjectCommentUpdateDto extends ProjectCommentEditableFieldsDto implements VersionedEntity {

	public static ProjectCommentUpdateDto from(ProjectComment src) {
		ProjectCommentUpdateDto result = new ProjectCommentUpdateDto();
		ProjectCommentEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(ProjectComment src, ProjectCommentUpdateDto result) {
		result.setVersion(src.getVersion());
	}

	private Integer version;

}
