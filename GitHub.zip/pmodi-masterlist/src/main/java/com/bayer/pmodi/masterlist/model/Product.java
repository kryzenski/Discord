package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Audited
public class Product extends AbstractAuditedEntity {

	@NotNull
	@Column(nullable = false)
	private String specNumber;

	@NotNull
	@Column(nullable = false)
	private String productLineText;

	@Column(nullable = true)
	private String brandName;

}