package com.bayer.pmodi.masterlist.config.security.exception;

public class PmodiUnauthorizedException extends RuntimeException {

	private static final long serialVersionUID = -8342624326480291543L;

	public PmodiUnauthorizedException(String message) {
		super(message);
	}

	public PmodiUnauthorizedException(String message, Throwable cause) {
		super(message, cause);
	}

}
