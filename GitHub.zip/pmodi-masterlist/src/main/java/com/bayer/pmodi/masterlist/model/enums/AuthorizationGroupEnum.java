package com.bayer.pmodi.masterlist.model.enums;

public enum AuthorizationGroupEnum {

	PROJECT_PTRS, //
	SEGMENT_PTRS, //
	PROJECT_PRIO, //
	SEGMENT_PRIO, //
	PROJECT_GUIDANCE_IP;

}
