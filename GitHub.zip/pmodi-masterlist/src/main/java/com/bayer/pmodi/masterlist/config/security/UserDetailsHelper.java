package com.bayer.pmodi.masterlist.config.security;

import java.util.List;

public interface UserDetailsHelper {

	final String UNIQUE_IDENTIFIER_NAME = "preferred_username";
	final String UNIQUE_APP_IDENTIFIER_NAME = "appid";
	final String ROLES = "roles";

	/**
	 * @param claimKey Key of the claim
	 * @return Claim or null
	 */
	Object getCurrentUserClaim(String claimKey);

	/**
	 * Get the user id of the current user. Throws an exception if no user id can be
	 * determined.
	 * 
	 * @return User id; never null
	 */
	String getCurrentUserId();

	/**
	 * @return List of roles; never null (but may be empty)
	 */
	List<String> getCurrentUserRoles();

	/**
	 * Check if the given user is the current user.
	 * 
	 * @param id ID to compare to the ID of the current user; optional (but then
	 *           false is returned)
	 * @return
	 */
	default boolean isCurrentUser(String id) {
		return id != null && id.equals(getCurrentUserId());
	}

	/**
	 * @return True if the calling user has general write access
	 */
	default boolean hasWriteAccess() {
		List<String> roles = getCurrentUserRoles();
		return roles != null && !roles.isEmpty();
	}

	/**
	 * @param roleToCheck Role to check
	 * @return True if the current user has one of the given roles
	 */
	default boolean hasRole(String... roleToCheck) {
		if (roleToCheck != null && roleToCheck.length > 0) {
			List<String> roles = getCurrentUserRoles();
			for (String r : roleToCheck) {
				// Check is done case insensitive for regional role check because the
				// roles are not defined as expected in AZURE
				if (roles.stream().anyMatch(role -> role.equalsIgnoreCase(r))) {
					return true;
				}
			}
		}
		return false;
	}

}