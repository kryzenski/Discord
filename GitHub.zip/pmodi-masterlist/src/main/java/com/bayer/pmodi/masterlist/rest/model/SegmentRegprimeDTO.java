package com.bayer.pmodi.masterlist.rest.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode
public class SegmentRegprimeDTO {

    private Long segmentId;

    private MilestoneRegprimeDto milestoneRegprimeDto;
}
