package com.bayer.pmodi.masterlist.search;

import java.util.List;

import com.bayer.pmodi.masterlist.model.Project;

public class ProjectSpecification extends AbstractSpecification<Project> {

	private static final long serialVersionUID = 3729329748257644910L;

	public ProjectSpecification() {
		super();
	}

	public ProjectSpecification(List<SearchCriterion> searchCriteria) {
		super(searchCriteria);
	}

}
