package com.bayer.pmodi.masterlist.rest.model;

public interface PageAndSortCriteria {

	Integer getPage();

	Integer getSize();

	String getSortBy();

	String getSortDir();

}
