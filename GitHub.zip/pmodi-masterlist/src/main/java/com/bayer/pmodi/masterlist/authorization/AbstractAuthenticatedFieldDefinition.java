package com.bayer.pmodi.masterlist.authorization;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractAuthenticatedFieldDefinition implements AuthenticatedFieldDefinition {

	private List<String> editableFields = AuthorizationUtil.getCheckedFields(getCheckedClass());

	private List<String> globalAdminFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_GLOBAL_ADMIN);
	private List<String> globalDevelopmentFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_GLOBAL_DEVELOPMENT);
	private List<String> globalMarketingFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_GLOBAL_MARKETING);

	private List<String> localAdminFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_PREFIX_REGIONAL_ADMIN);
	private List<String> localDevelopmentFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT);
	private List<String> localMarketingFields = AuthorizationUtil.getCheckedFieldsOfRole(getCheckedClass(),
			Roles.ROLE_PREFIX_REGIONAL_MARKETING);

	private Map<String, String> specialFields = AuthorizationUtil
			.getCheckedFieldsWithSpecialTreatment(getCheckedClass());

	private Map<String, List<String>> groupFieldMap = initGroupMap();

	private Map<String, List<String>> initGroupMap() {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		for (String group : Groups.ALL_GROUPS) {
			if (isRelevantGroup(group)) {
				List<String> fields = AuthorizationUtil.getCheckedFieldsOfGroup(getCheckedClass(), group);
				map.put(group, fields);
			}
		}
		return map;
	}

	protected abstract Class<?> getCheckedClass();

	protected abstract boolean isRelevantGroup(String group);

	@Override
	public List<String> getEditableFields() {
		return editableFields;
	}

	@Override
	public List<String> getGlobalAdminFields() {
		return globalAdminFields;
	}

	@Override
	public List<String> getGlobalMarketingFields() {
		return globalMarketingFields;
	}

	@Override
	public List<String> getGlobalDevelopmentFields() {
		return globalDevelopmentFields;
	}

	@Override
	public List<String> getRegionalAdminFields() {
		return localAdminFields;
	}

	@Override
	public List<String> getRegionalMarketingFields() {
		return localMarketingFields;
	}

	@Override
	public List<String> getRegionalDevelopmentFields() {
		return localDevelopmentFields;
	}

	@Override
	public Map<String, String> getSpecialFields() {
		return specialFields;
	}

	@Override
	public List<String> getGroupFields(String group) {
		List<String> fields = groupFieldMap.get(group);
		if (fields == null) {
			return Collections.emptyList();
		}
		return fields;
	}

}
