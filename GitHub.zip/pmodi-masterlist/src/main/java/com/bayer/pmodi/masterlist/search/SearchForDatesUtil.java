package com.bayer.pmodi.masterlist.search;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import java.util.*;
import javax.persistence.criteria.Root;

public final class SearchForDatesUtil {



    public static <T> Predicate toFormPredicate(SearchCriterion criterion, Root<T> root, CriteriaBuilder builder){

        List<Predicate> predicate = new ArrayList<>();

        if (criterion == null)
            throw new IllegalArgumentException("Search criterion may not be null!");



            if (criterion.getFieldName().equals("draftYear") || criterion.getFieldName().equals("project.draftYear")) {
                if (criterion.getStringValues() != null && criterion.getStringValues().size() > 0) {
                    List<String>  val = criterion.getStringValues();
                    for (String values :val) {
                        List<String> stringValue = new ArrayList<>();
                        stringValue.add(values);
                        criterion.setStringValues(stringValue);
                        predicate.add((Predicate) SearchUtil.predicateFrom(criterion, root, builder));
                    }
                    criterion.getStringValues().clear();
                    criterion.getStringValues().addAll(val);
                }
            } else if (criterion.getFieldName().equals("approvalYear") || criterion.getFieldName().equals("project.approvalYear")) {
                if (criterion.getDateValues() != null && criterion.getDateValues().size() > 0){
                    List<String> val = criterion.getDateValues();
                    for (String values :val) {
                        List<String> stringValue = new ArrayList<>();
                        stringValue.add(values);
                        criterion.setDateValues(stringValue);
                        predicate.add((Predicate) SearchUtil.predicateFrom(criterion, root, builder));
                    }
                    criterion.getDateValues().clear();
                    criterion.getDateValues().addAll(val);
                }
            } else if (criterion.getFieldName().equals("creationYear") || criterion.getFieldName().equals("segments.creationYear")) {
                if (criterion.getDateValues() != null && criterion.getDateValues().size() > 0){
                    List<String> val = criterion.getDateValues();
                    for (String values :val) {
                        List<String> stringValue = new ArrayList<>();
                        stringValue.add(values);
                        criterion.setDateValues(stringValue);
                        predicate.add((Predicate) SearchUtil.predicateFrom(criterion, root, builder));
                    }
                    criterion.getDateValues().clear();
                    criterion.getDateValues().addAll(val);
                }
        }

            if((criterion.getStringValues() != null &&  criterion.getStringValues().size() > 0) || (criterion.getDateValues() != null && criterion.getDateValues().size() > 0)){
              return builder.or(predicate.toArray(new Predicate[0]));
            }


            return null;

    }




}
