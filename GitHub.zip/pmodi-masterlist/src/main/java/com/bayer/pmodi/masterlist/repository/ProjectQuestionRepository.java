package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.ProjectQuestion;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

public interface ProjectQuestionRepository extends BaseRepository<ProjectQuestion> {

	Page<ProjectQuestion> findByProjectId(Long id, Pageable pageInfo);

	Page<ProjectQuestion> findByProjectIdAndProjectQuestionDefinitionDtypeOrderByProjectQuestionDefinitionPos(Long id,
			ModuleTypeEnum dtype, Pageable pageInfo);

}
