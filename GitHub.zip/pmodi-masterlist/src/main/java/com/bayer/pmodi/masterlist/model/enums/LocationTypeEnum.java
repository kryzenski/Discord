package com.bayer.pmodi.masterlist.model.enums;

public enum LocationTypeEnum {

	GLOBAL, //
	REGIONAL;

}
