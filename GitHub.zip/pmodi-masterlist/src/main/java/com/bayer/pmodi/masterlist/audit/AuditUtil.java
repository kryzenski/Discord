package com.bayer.pmodi.masterlist.audit;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.envers.Audited;

public final class AuditUtil {

	private AuditUtil() {
		// No instance allowed
	}

	/**
	 * Get a list of fields for a given class which have the modified flag set to
	 * true.
	 * 
	 * @param clazz Class to check: mandatory (but not checked)
	 * @return List of audited fields which have the modified flag set
	 */
	public static List<String> getAuditedFieldsWithModifiedFlag(Class<?> clazz) {
		List<String> fields = Stream.of(clazz.getDeclaredFields())
				.filter(field -> field.isAnnotationPresent(Audited.class)
						&& field.getAnnotation(Audited.class).withModifiedFlag())
				.map(field -> field.getName()).collect(Collectors.toList());
		return fields;
	}

}
