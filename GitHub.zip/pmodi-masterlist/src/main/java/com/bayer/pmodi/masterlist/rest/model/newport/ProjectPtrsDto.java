package com.bayer.pmodi.masterlist.rest.model.newport;

import com.bayer.pmodi.masterlist.model.Project;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class ProjectPtrsDto {

	/**
	 * Create DTO from the given entity.
	 * 
	 * @param project Source; mandatory (but not checked)
	 * @return DTO
	 */
	public static ProjectPtrsDto from(Project project) {
		ProjectPtrsDto dto = new ProjectPtrsDto(project.getId(), project.getNewportProjectId(),
				project.getOverallPtrsScore());
		return dto;
	}

	@NonNull
	private Long id;
	@NonNull
	private String newportProjectId;

	private Double overallPtrsScore;

}