package com.bayer.pmodi.masterlist.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Data
@Table
@ToString
@EqualsAndHashCode
public class ActiveIngrediant {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	// @Version
	// @Column(nullable = false)
	// private Integer version = null;

	@NotNull
	@Column(nullable = false)
	private String code;

	@NotNull
	@Column(nullable = false)
	private String molName;

	@Column(nullable = true)
	private String ehsSpecNumber;

}