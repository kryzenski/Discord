package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SubRegion;
import com.bayer.pmodi.masterlist.model.enums.CostCenterEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class NewSegmentDto extends SegmentEditableFieldsDto {

	public static NewSegmentDto from(Segment src) {
		NewSegmentDto result = new NewSegmentDto();
		SegmentEditableFieldsDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Segment src, NewSegmentDto result) {
		BeanUtils.copyProperties(src, result);
		result.setCountry(DtoUtil.toIdDisplayNameSourceKeyDto(src.getCountry()));
		result.setSubRegion(DtoUtil.toIdDisplayNameSourceKeyDto(src.getSubRegion()));
		result.setRegion(DtoUtil.toIdDisplayNameSourceKeyRoleSuffixDto(src.getRegion()));
		result.setCrop(DtoUtil.toIdDisplayNameSourceKeyDto(src.getCrop()));
		result.setCropGroup(DtoUtil.toIdDisplayNameSourceKeyDto(src.getCrop().getCropGroup()));
		result.setCropPlatform(DtoUtil.toIdDisplayNameSourceKeyDto(src.getCrop().getCropGroup().getCropPlatform()));

	}

	public static void applyKeyPropertiesTo(Segment result, Country country, SubRegion subRegion, Region region,
			Crop crop, String target, String newportDiseasesPestsWeedsId, CostCenterEnum costCenter) {
		result.setCountry(country);
		result.setSubRegion(subRegion);
		result.setRegion(region);
		result.setCrop(crop);
		result.setNewportDiseasesPestsWeedsId(newportDiseasesPestsWeedsId);
		result.setTarget(target);
		result.setCostCenter(costCenter);

	}

	@NotNull
	private CostCenterEnum costCenter;

	@NotNull
	private String target;

	@NotNull
	private String newportDiseasesPestsWeedsId;

	@NotNull
	private IdDisplayNameSourceKeyDto country;

	@NotNull
	private IdDisplayNameSourceKeyDto subRegion;

	@NotNull
	private IdDisplayNameSourceKeyRoleSuffixDto region;

	@NotNull
	private IdDisplayNameSourceKeyDto crop;

	@NotNull
	private IdDisplayNameSourceKeyDto cropPlatform;

	@NotNull
	private IdDisplayNameSourceKeyDto cropGroup;

}