package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.SegmentQuestion;
import com.bayer.pmodi.masterlist.model.enums.ModuleTypeEnum;

public interface SegmentQuestionRepository extends BaseRepository<SegmentQuestion> {

	Page<SegmentQuestion> findBySegmentId(Long id, Pageable pageInfo);

	Page<SegmentQuestion> findBySegmentIdAndSegmentQuestionDefinitionDtypeOrderBySegmentQuestionDefinitionPos(Long id,
			ModuleTypeEnum dtype, Pageable pageInfo);

	long deleteBySegmentId(Long id);

}
