package com.bayer.pmodi.masterlist.config.security;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.CompletableFuture;


import com.microsoft.aad.msal4j.*;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
@Service
@Profile("sso")
@Data
public class SSOExternalApiAccessHelper implements ExternalApiAccessHelper {

	// Precise vars
	@Value("${msal.precise.tenant-id}")
	private String confidentialTenantId;
	@Value("${msal.precise.client-id}")
	private String confidentialClientId;
	@Value("${msal.precise.client-secret}")
	private String confidentialClientSecret;

	// Nautilos vars
	@Value("${msal.nautilos.tenant-id}")
	private String nautilosTenantId;
	@Value("${msal.nautilos.client-id}")
	private String nautilosClientId;

	// RegPrime vars
	@Value("${msal.regprime.tenant-id}")
	private String regprimeTenantId;
	@Value("${msal.regprime.client-id}")
	private String regprimeClientId;

	@Value("${msal.quickscan.client-id}")
	private String quickscanClientId;

	private String regprimeUserToken;


	@Override
	public String getNautilosAccessToken() throws Exception {
		final String scope = nautilosClientId + "/.default";
		return getAccessToken(scope);
	}

	@Override
	public String getRegPrimeAccessToken(String token) throws Exception {
		setRegprimeUserToken(token);
		final  String scope= regprimeClientId+"/.default";
		return getAccessToken(scope);
	}

	@Override
	public String getQuickscanAccessToken() throws Exception {
		final String scope = quickscanClientId + "/.default";
		return getAccessToken(scope);
	}

	@Override
	public String getNewportConnectorAccessToken() throws Exception {
		final String scope = confidentialClientId + "/.default";
		return getAccessToken(scope);
	}

	// ============== Private Functions ================= //

	private String getAccessToken(final String scope) throws Exception {
		IAuthenticationResult result = getAccessTokenByClientCredentialGrant(scope);
		return result.accessToken();
	}

	private IAuthenticationResult getAccessTokenByClientCredentialGrant(final String scope) throws Exception {

		final String tenantSpecificAuthority = "https://login.microsoftonline.com/" + confidentialTenantId + "/";

		ConfidentialClientApplication app = ConfidentialClientApplication
				.builder(confidentialClientId, ClientCredentialFactory.createFromSecret(confidentialClientSecret)).
				authority(tenantSpecificAuthority).build();


		ClientCredentialParameters clientCredentialParam = ClientCredentialParameters.builder(Collections.singleton(scope)).build();
		UserAssertion assertion=null;
		OnBehalfOfParameters onBehalfOfParameters=null;
		CompletableFuture<IAuthenticationResult> future;
		if(getRegprimeUserToken() !=null) {
			 assertion = new UserAssertion(getRegprimeUserToken());
			 onBehalfOfParameters = OnBehalfOfParameters.builder(Collections.singleton(scope), assertion).build();

		}
		if(scope.startsWith(regprimeClientId))
			future= app.acquireToken(onBehalfOfParameters);
                 else
			future= app.acquireToken(clientCredentialParam);
		return future.get();
	}

}
