package com.bayer.pmodi.masterlist.rest.model;

import java.time.LocalDate;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.EntityWithPrioritization;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;

/**
 * This class contains all properties of a segment which are allowed to be
 * updated i.e. no primary or foreign keys.
 */
@Data
@ToString
@EqualsAndHashCode
public class SegmentEditableFieldsDto implements EntityWithPrioritization {

	public static SegmentEditableFieldsDto from(Segment src) {
		SegmentEditableFieldsDto result = new SegmentEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Segment src, SegmentEditableFieldsDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public void applyUpdateablePropertiesTo(Segment target) {
		BeanUtils.copyProperties(this, target);
	}

	private String fsPtrsScoreRmk;

	private Double fsPtrsScore;

	private String rsRegPtrsScoreRmk;

	private Double rsRegPtrsScore;

	private String rsRegProductPtrsScoreRmk;

	private Double rsRegProductPtrsScore;

	private String rsRegDietaryPtrsScoreRmk;

	private Double rsRegDietaryPtrsScore;

	private String rsOccupationalResidentialExposurePtrsScoreRmk;

	private Double rsOccupationalResidentialExposurePtrsScore;

	private String rsToxicologyPtrsScoreRmk;

	private Double rsToxicologyPtrsScore;

	private String rsEcotoxPtrsScoreRmk;

	private Double rsEcotoxPtrsScore;

	private String rsEfatePtrsScoreRmk;

	private Double rsEfatePtrsScore;

	private String rsLocalRestrictionPolicyPtrsScoreRmk;

	private Double rsLocalRestrictionPolicyPtrsScore;

	private String rsLocalRestrictionOthersPtrsScoreRmk;

	private Double rsLocalRestrictionOthersPtrsScore;

	private String rsForeignInfluencePtrsScoreRmk;

	private Double rsForeignInfluencePtrsScore;

	private String rsRegistrationPtrsScoreRmk;

	private Double rsRegistrationPtrsScore;

	private Double ptrsSegmentOverallScore;

	private String quickscanAssessmentId;

	private Boolean isQuickScanNotApplicable;

	private String quickScanNotApplicableReason;

	private String regprimeCropCode;

	private String regprimeProductLineNumber;

	private String regprimeCountryCode;

	private String regprimeZNumber;

	private Integer regprimeSequenceNumber;

	private PrioritizationTypeEnum prioritizationType;

	private String prioritizationRmk;

	private LocationTypeEnum prioritizationGovernance;

	private String strategicFitRmk;

	private String newportPtrs;

	private String newportLaunchYearCountry;

	private String newportLaunchYearSegment;

	private String newportLaunchYearNetSales;

	private String newportSubmissionYear;

	private String newportIsLaunched;

	private String newportWeightUnit;

	private String newportCurrency;

	private Double newportGlobalNpvYear10;

	private Double newportGlobalExpectedNpvYear10;

	private Double newportGlobalNetSales;

	private Double newportGlobalPeakNetSales;

	private Integer newportGlobalPeakNetSalesYear;

	private Double newportGlobalPeakYearIgmPercNetSales;

	private Double newportGlobalIgmPercYear4;

	private Double newportGlobalIgmYear4;

	private Double newportGlobalIgmPeakYear;

	private Double newportGlobalFutureProjectCost;

	private Double newportGlobalProductivityIndex;

	private Double newportGlobalIncrementalNetSales;

	private Double newportGlobalPeakNetSalesIncremental;

	private Double newportGlobalIncrementalIgmYear4;

	private Double newportGlobalPeakYearIgmIncremental;

	private Integer newportGlobalPaybackYear;

	private Double newportGlobalPaybackTime;

	private Double newportGlobalSalesVolume;

	private Double newportGlobalAggregatedVolume;

	private Double newportLocalNpvYear10;

	private Double newportLocalExpectedNpvYear10;

	private Double newportLocalPaybackTime;

	private Double newportLocalPeakNetSales;

	private Integer newportLocalPeakNetSalesYear;

	private Double newportLocalPeakYearIgmPercNetSales;

	private Double newportLocalPeakYearIgm;

	private Double newportLocalPeakNetSalesIncremental;

	private Double newportLocalPeakYearIgmIncremental;

	private boolean ptrsFollowUp;

	private String fsPtrsScoreUpdatedDate;

	private String fsPtrsScoreUpdatedBy;

	private String rsPtrsScoreUpdatedDate;

	private String rsPtrsScoreUpdatedBy;

	private LocalDate launchDate;

	private LocalDate submissionDate;

	private  String  countryName;

	private String countryType;

	private  String cropName;


	private  String newportName;


	private  String newportFreeText;


	private  String preciseNewportId;


	private  String subRegionName;


	private  String cropPlatformName;


	private  String cropGroupName;

	private  String regionName;

	private String rsOccupationalResidentialExposurePtrsScoreModifiedBy;

	private String rsOccupationalResidentialExposurePtrsScoreModifiedDate;

	private String rsRegDietaryPtrsScoreModifiedBy;

	private String rsRegDietaryPtrsScoreModifiedDate;

	private String rsToxicologyPtrsScoreModifiedBy;

	private String rsToxicologyPtrsScoreModifiedDate;

	private String rsEcotoxPtrsScoreModifiedBy;

	private String rsEcotoxPtrsScoreModifiedDate;

	private String rsEfatePtrsScoreModifiedBy;

	private String rsEfatePtrsScoreModifiedDate;

	private String rsRegistrationPtrsScoreModifiedBy;

	private String rsRegistrationPtrsScoreModifiedDate;

	private String rsRegProductPtrsScoreModifiedBy;

	private String rsRegProductPtrsScoreModifiedDate;

	private String rsLocalRestrictionPolicyPtrsScoreModifiedBy;

	private String rsLocalRestrictionPolicyPtrsScoreModifiedDate;

	private String rsLocalRestrictionOthersPtrsScoreModifiedBy;

	private String rsLocalRestrictionOthersPtrsScoreModifiedDate;

	private String rsForeignInfluencePtrsScoreModifiedBy;

	private String rsForeignInfluencePtrsScoreModifiedDate;


	private String creationYear;

	private  LocalDate creationDate;

	private String newportBusinessUnit;

	private String newportStatus;

	private String newportCategory;

	private String newportSegmentCreationDate;
}
