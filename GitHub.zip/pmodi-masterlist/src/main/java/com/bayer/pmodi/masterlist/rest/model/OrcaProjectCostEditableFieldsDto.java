package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;

import com.bayer.pmodi.masterlist.model.OrcaProjectCost;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * This class contains all properties of ORCA project costs which are allowed to
 * be updated.
 */
@Data
@ToString
@EqualsAndHashCode
public class OrcaProjectCostEditableFieldsDto {

	public static OrcaProjectCostEditableFieldsDto from(OrcaProjectCost src) {
		OrcaProjectCostEditableFieldsDto result = new OrcaProjectCostEditableFieldsDto();
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(OrcaProjectCost src, OrcaProjectCostEditableFieldsDto target) {
		BeanUtils.copyProperties(src, target);
	}

	public void applyUpdateablePropertiesTo(OrcaProjectCost target) {
		BeanUtils.copyProperties(this, target);
	}

	@NotNull
	private String projectId;

	private String spgName;

	@NotNull
	private String newportArea;

	@NotNull
	private String newportNumber;

	private String freeText;

	@NotNull
	private String projectName;

	private String projectStatus;

	private String projectCategory;

	private String leadAi;

	private String pltName;

	private String projectFramework;

	private String businessGroup;

	private String businessUnit;

	private String businessSegment;

	private String businessObjectNumber;

	private String formulationType;

	private String concentrationUnit;

	private String region;

	private String subregion;

	@NotNull
	private String country;

	private String cropPlatform;

	private String cropGroup;

	@NotNull
	private String crop;

	@NotNull
	private String diseasesPestsWeeds;

	private String excelTemplate;

	@NotNull
	private String calendarYear;

	private Double agronomicDev;

	private Double environment;

	private Double fieldDev;

	private Double formulationDev;

	private Double globalResourceConsumption;

	private Double productSupply;

	private Double launchMarket;

	private Double customerAdvisory;

	private Double regulationAffair;

	private Double research;

	private Double registrationFees;

	private Double humanSafety;

	private Double other;

	private Double totalProjectCosts;

}
