package com.bayer.pmodi.masterlist.rest.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class MilestoneRegprimeDto {

	private int sequenceNumber;
	private String regulatoryActionStatus;
	private String regulatoryActionType;
	private  String registrationStatus;
	private  String country;
	private String[] cropNames;
	private String tradeName;
	private String productLineText;
	private String actualSubmissionDate;
	private String plannedSubmissionDate;
	private  String expectedRegistrationDate;
	private String grantedRegistrationDate;
	private String znumber;
	private String localRegActionTypeText;
	private String regActionCommentText;
}