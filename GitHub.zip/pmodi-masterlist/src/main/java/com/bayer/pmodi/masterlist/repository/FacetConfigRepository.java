package com.bayer.pmodi.masterlist.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bayer.pmodi.masterlist.model.FacetConfig;

public interface FacetConfigRepository extends BaseRepository<FacetConfig> {

	FacetConfig findByFieldNameAndEntityType(String fieldName, String entityType);

	Page<FacetConfig> findByGroupName(String groupName, Pageable page);

}
