package com.bayer.pmodi.masterlist.rest.model;

import javax.validation.constraints.NotNull;

import com.bayer.pmodi.masterlist.model.Project;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ProjectDto extends NewProjectDto {

	public static ProjectDto from(Project src) {
		ProjectDto result = new ProjectDto();
		ProjectEditableFieldsDto.mapOwn(src, result);
		NewProjectDto.mapOwn(src, result);
		mapOwn(src, result);
		return result;
	}

	public static void mapOwn(Project src, ProjectDto result) {
		result.setId(src.getId());
		result.setVersion(src.getVersion());
	}

	@NotNull
	private Long id;

	@NotNull
	private Integer version;

}