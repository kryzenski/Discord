/*==============================================================*/
/* DBMS name:      PostgreSQL 8                                 */
/* Created on:     05.11.2020 14:44:11                          */
/*==============================================================*/


DROP TABLE IF EXISTS ACTIVE_INGREDIANT CASCADE;

DROP TABLE IF EXISTS ACTIVE_INGREDIANT_2_PRODUCT CASCADE;

DROP TABLE IF EXISTS ALLOWED_VALUE CASCADE;

-- TODO: remove later when schema is stable and established
DROP TABLE IF EXISTS APRS CASCADE;

DROP INDEX IF EXISTS COUNTRY_NAME;

DROP TABLE IF EXISTS COUNTRY CASCADE;

DROP INDEX IF EXISTS CROP_SOURCE_KEY;

DROP INDEX IF EXISTS CROP_NAME;

DROP TABLE IF EXISTS CROP CASCADE;

DROP INDEX IF EXISTS CROP_GROUP_SOURCE_KEY;

DROP INDEX IF EXISTS CROP_GROUP_NAME;

DROP TABLE IF EXISTS CROP_GROUP CASCADE;

DROP INDEX IF EXISTS CROP_PLATFORM_SOURCE_KEY;

DROP INDEX IF EXISTS CROP_PLATFORM_NAME;

DROP TABLE IF EXISTS CROP_PLATFORM CASCADE;

DROP TABLE IF EXISTS FACET_CONFIG CASCADE;

DROP TABLE IF EXISTS ORCA_PROJECT_COST CASCADE;

DROP TABLE IF EXISTS PRODUCT CASCADE;

DROP INDEX IF EXISTS PROJECT_NEWPORT_ID;

DROP TABLE IF EXISTS PROJECT CASCADE;

DROP TABLE IF EXISTS PROJECT_COMMENT CASCADE;

DROP TABLE IF EXISTS PROJECT_QUESTION CASCADE;

DROP TABLE IF EXISTS PROJECT_QUESTION_DEFINITION CASCADE;

DROP INDEX IF EXISTS REGION_NAME;

DROP TABLE IF EXISTS REGION CASCADE;

DROP TABLE IF EXISTS SEGMENT CASCADE;

DROP TABLE IF EXISTS SEGMENT_COMMENT CASCADE;

DROP TABLE IF EXISTS SEGMENT_COST CASCADE;

DROP TABLE IF EXISTS SEGMENT_QUESTION CASCADE;

DROP TABLE IF EXISTS SEGMENT_QUESTION_DEFINITION CASCADE;

DROP TABLE IF EXISTS SETTING CASCADE;

DROP INDEX IF EXISTS SUB_REGION_NAME;

DROP TABLE IF EXISTS SUB_REGION CASCADE;

DROP DOMAIN IF EXISTS IDENTIFIER;

DROP DOMAIN IF EXISTS PERCENT;

DROP DOMAIN IF EXISTS YEAR4;

/*==============================================================*/
/* Domain: IDENTIFIER                                           */
/*==============================================================*/
CREATE DOMAIN IDENTIFIER AS INT8;

/*==============================================================*/
/* Domain: PERCENT                                              */
/*==============================================================*/
CREATE DOMAIN PERCENT AS NUMERIC;

/*==============================================================*/
/* Domain: YEAR4                                                */
/*==============================================================*/
CREATE DOMAIN YEAR4 AS INT4;

/*==============================================================*/
/* Table: ACTIVE_INGREDIANT                                     */
/*==============================================================*/
CREATE TABLE ACTIVE_INGREDIANT (
   ID                   SERIAL NOT NULL,
   CODE                 VARCHAR              NOT NULL,
   MOL_NAME             VARCHAR              NOT NULL,
   EHS_SPEC_NUMBER      VARCHAR              NULL,
   CONSTRAINT PK_ACTIVE_INGREDIANT PRIMARY KEY (ID),
   CONSTRAINT AK_CODE_ACTIVE_I UNIQUE (CODE)
);

/*==============================================================*/
/* Table: ACTIVE_INGREDIANT_2_PRODUCT                           */
/*==============================================================*/
CREATE TABLE ACTIVE_INGREDIANT_2_PRODUCT (
   ID                   SERIAL NOT NULL,
   PRODUCT_ID           INT8                 NOT NULL,
   ACTIVE_INGREDIANT_ID INT8                 NOT NULL,
   IS_LEAD              BOOL                 NOT NULL,
   CONSTRAINT PK_ACTIVE_INGREDIANT_2_PRODUCT PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: ALLOWED_VALUE                                         */
/*==============================================================*/
CREATE TABLE ALLOWED_VALUE (
   ID                   SERIAL NOT NULL,
   FACET_CONFIG_ID      INT8                 NULL,
   VALUE                VARCHAR              NOT NULL,
   CONSTRAINT PK_ALLOWED_VALUE PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: COUNTRY                                               */
/*==============================================================*/
CREATE TABLE COUNTRY (
   ID                   SERIAL NOT NULL,
   SOURCE_KEY           VARCHAR              NULL,
   NAME                 VARCHAR              NOT NULL,
   IS_PLACEHOLDER       BOOL                 NOT NULL,
    FLAG                 BOOL      NULL,
   CONSTRAINT PK_COUNTRY PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_COUNTRY UNIQUE (NAME)
);

/*==============================================================*/
/* Index: COUNTRY_NAME                                          */
/*==============================================================*/
CREATE UNIQUE INDEX COUNTRY_NAME ON COUNTRY (
NAME
);

/*==============================================================*/
/* Table: CROP                                                  */
/*==============================================================*/
CREATE TABLE CROP (
   ID                   SERIAL NOT NULL,
   CROP_GROUP_ID        INT8                 NOT NULL,
   SOURCE_KEY           VARCHAR              NOT NULL,
   NAME                 VARCHAR              NOT NULL,
   URI                  VARCHAR              NULL,
   IS_PLACEHOLDER       BOOL                 NOT NULL,
   PLACEHOLDER_TYPE     VARCHAR              NULL,
   CONSTRAINT PK_CROP PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_PER_GROUP_CROP UNIQUE (CROP_GROUP_ID, NAME)
);

/*==============================================================*/
/* Index: CROP_NAME                                             */
/*==============================================================*/
CREATE  INDEX CROP_NAME ON CROP (
NAME
);

/*==============================================================*/
/* Index: CROP_SOURCE_KEY                                       */
/*==============================================================*/
CREATE  INDEX CROP_SOURCE_KEY ON CROP (
SOURCE_KEY
);

/*==============================================================*/
/* Table: CROP_GROUP                                            */
/*==============================================================*/
CREATE TABLE CROP_GROUP (
   ID                   SERIAL NOT NULL,
   CROP_PLATFORM_ID     INT8                 NOT NULL,
   SOURCE_KEY           VARCHAR              NOT NULL,
   NAME                 VARCHAR              NOT NULL,
   CONSTRAINT PK_CROP_GROUP PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_PER_PLATFORM_CROP_GRO UNIQUE (CROP_PLATFORM_ID, NAME)
);

/*==============================================================*/
/* Index: CROP_GROUP_NAME                                       */
/*==============================================================*/
CREATE  INDEX CROP_GROUP_NAME ON CROP_GROUP (
NAME
);

/*==============================================================*/
/* Index: CROP_GROUP_SOURCE_KEY                                 */
/*==============================================================*/
CREATE  INDEX CROP_GROUP_SOURCE_KEY ON CROP_GROUP (
SOURCE_KEY
);

/*==============================================================*/
/* Table: CROP_PLATFORM                                         */
/*==============================================================*/
CREATE TABLE CROP_PLATFORM (
   ID                   SERIAL NOT NULL,
   SOURCE_KEY           VARCHAR              NOT NULL,
   NAME                 VARCHAR              NOT NULL,
   CONSTRAINT PK_CROP_PLATFORM PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_CROP_PLA UNIQUE (NAME)
);

/*==============================================================*/
/* Index: CROP_PLATFORM_NAME                                    */
/*==============================================================*/
CREATE UNIQUE INDEX CROP_PLATFORM_NAME ON CROP_PLATFORM (
NAME
);

/*==============================================================*/
/* Index: CROP_PLATFORM_SOURCE_KEY                              */
/*==============================================================*/
CREATE UNIQUE INDEX CROP_PLATFORM_SOURCE_KEY ON CROP_PLATFORM (
SOURCE_KEY
);

/*==============================================================*/
/* Table: FACET_CONFIG                                          */
/*==============================================================*/
CREATE TABLE FACET_CONFIG (
   ID                   SERIAL NOT NULL,
   FACET_NAME           VARCHAR              NOT NULL,
   ENTITY_TYPE          VARCHAR              NOT NULL
      CONSTRAINT CKC_ENTITY_TYPE_FACET_CO CHECK (ENTITY_TYPE IN ('PROJECT','SEGMENT') AND ENTITY_TYPE = UPPER(ENTITY_TYPE)),
   FIELD_NAME           VARCHAR              NOT NULL,
   DATA_TYPE            VARCHAR              NOT NULL,
   FACET_TYPE           VARCHAR              NOT NULL,
   GROUP_NAME           VARCHAR              NULL,
   MULTI_SELECT         BOOL                 NOT NULL DEFAULT FALSE,
   ENDPOINT_ADDRESS     VARCHAR              NULL,
   CONSTRAINT PK_FACET_CONFIG PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: ORCA_PROJECT_COST                                     */
/*==============================================================*/
CREATE TABLE ORCA_PROJECT_COST (
   ID                   SERIAL NOT NULL,
   PROJECT_ID           VARCHAR              NOT NULL,
   SPG_NAME             VARCHAR              NULL,
   NEWPORT_AREA         VARCHAR              NOT NULL,
   NEWPORT_NUMBER       VARCHAR              NOT NULL,
   FREE_TEXT            VARCHAR              NULL,
   PROJECT_NAME         VARCHAR              NOT NULL,
   PROJECT_STATUS       VARCHAR              NULL,
   PROJECT_CATEGORY     VARCHAR              NULL,
   LEAD_AI              VARCHAR              NULL,
   PLT_NAME             VARCHAR              NULL,
   PROJECT_FRAMEWORK    VARCHAR              NULL,
   BUSINESS_GROUP       VARCHAR              NULL,
   BUSINESS_UNIT        VARCHAR              NULL,
   BUSINESS_SEGMENT     VARCHAR              NULL,
   BUSINESS_OBJECT_NUMBER VARCHAR              NULL,
   FORMULATION_TYPE     VARCHAR              NULL,
   CONCENTRATION_UNIT   VARCHAR              NULL,
   REGION               VARCHAR              NULL,
   SUBREGION            VARCHAR              NULL,
   COUNTRY              VARCHAR              NOT NULL,
   CROP_PLATFORM        VARCHAR              NULL,
   CROP_GROUP           VARCHAR              NULL,
   CROP                 VARCHAR              NOT NULL,
   DISEASES_PESTS_WEEDS VARCHAR              NULL,
   EXCEL_TEMPLATE       VARCHAR              NULL,
   CALENDAR_YEAR        VARCHAR              NOT NULL,
   AGRONOMIC_DEV        NUMERIC              NULL,
   ENVIRONMENT          NUMERIC              NULL,
   FIELD_DEV            NUMERIC              NULL,
   FORMULATION_DEV      NUMERIC              NULL,
   GLOBAL_RESOURCE_CONSUMPTION NUMERIC              NULL,
   PRODUCT_SUPPLY       NUMERIC              NULL,
   LAUNCH_MARKET        NUMERIC              NULL,
   CUSTOMER_ADVISORY    NUMERIC              NULL,
   REGULATION_AFFAIR    NUMERIC              NULL,
   RESEARCH             NUMERIC              NULL,
   REGISTRATION_FEES    NUMERIC              NULL,
   HUMAN_SAFETY         NUMERIC              NULL,
   OTHER                NUMERIC              NULL,
   TOTAL_PROJECT_COSTS  NUMERIC              NULL,
   CONSTRAINT PK_ORCA_PROJECT_COST PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: PRODUCT                                               */
/*==============================================================*/
CREATE TABLE PRODUCT (
   ID                   SERIAL NOT NULL,
   SPEC_NUMBER          VARCHAR              NOT NULL,
   PRODUCT_LINE_TEXT    VARCHAR              NOT NULL,
   BRAND_NAME           VARCHAR              NULL,
   CONSTRAINT PK_PRODUCT PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: PROJECT                                               */
/*==============================================================*/
CREATE TABLE PROJECT (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   PRODUCT_ID           INT8                 NULL,
   FS_PTRS_SCORE_RMK    VARCHAR              NULL,
   FS_PTRS_SCORE        PERCENT              NULL,
   FT_PTRS_SCORE_RMK    VARCHAR              NULL,
   FT_PTRS_SCORE        PERCENT              NULL,
   LUMOS_GLOBAL_PROJECT_ID VARCHAR              NULL,
   LUMOS_LOCAL_PROJECT_ID VARCHAR              NULL,
   PRECISE_NEWPORT_ID   VARCHAR              NOT NULL,
   OVERALL_PTRS_SCORE   NUMERIC              NULL,
   RS_ENSA_PTRS_SCORE   PERCENT              NULL,
   RS_ENSA_PTRS_SCORE_RMK VARCHAR              NULL,
   RS_DIETARY_PTRS_SCORE PERCENT              NULL,
   RS_DIETARY_PTRS_SCORE_RMK VARCHAR              NULL,
   RS_OPERATOR_PTRS_SCORE PERCENT              NULL,
   RS_OPERATOR_PTRS_SCORE_RMK VARCHAR              NULL,
   RS_REG_AFFAIRS_SCORE PERCENT              NULL,
   RS_REG_AFFAIRS_SCORE_RMK VARCHAR              NULL,
   RS_PTRS_SCORE        PERCENT              NULL,
   RS_PTRS_SCORE_RMK    VARCHAR              NULL,
   PRIORITIZATION_TYPE  VARCHAR              NULL
      CONSTRAINT CKC_PRIORITIZATION_TY_PROJECT CHECK (PRIORITIZATION_TYPE IS NULL OR (PRIORITIZATION_TYPE IN ('A','B','Cancelled'))),
   PRIORITIZATION_RMK   VARCHAR              NULL,
   PRIORITIZATION_GOVERNANCE VARCHAR              NULL
      CONSTRAINT CKC_PRIORITIZATION_GO_PROJECT CHECK (PRIORITIZATION_GOVERNANCE IS NULL OR (PRIORITIZATION_GOVERNANCE IN ('REGIONAL','GLOBAL') AND PRIORITIZATION_GOVERNANCE = UPPER(PRIORITIZATION_GOVERNANCE))),
   RS_GOVERNANCE        VARCHAR              NULL,
   GLOBAL_PORTFOLIO_GUIDANCE VARCHAR              NULL,
    sustainability_Assessment VARCHAR NULL,
   GLOBAL_REG_GUIDANCE  VARCHAR              NULL,
   SPECIFIC_PROJECT_FRAMEWORK VARCHAR              NULL,
   LABEL_FOR_SAFE_USE   VARCHAR              NULL,
   THIRD_PARTY_AI_REG_CHECK VARCHAR              NULL,
   DEVELOPMENT_FUNCTIONS VARCHAR              NULL,
   INTELECTUAL_PROPERTY_ASSESSMENT VARCHAR              NULL,
   STRATEGIC_FIT_RMK    VARCHAR              NULL,
   NEWPORT_PROJECT_ID   VARCHAR              NOT NULL,
   NEWPORT_SPG          VARCHAR              NULL,
   NEWPORT_PLT          VARCHAR              NULL,
   NEWPORT_FREE_TEXT    VARCHAR              NULL,
   NEWPORT_NAME         VARCHAR              NULL,
   NEWPORT_LEAD_AI      VARCHAR              NULL,
   NEWPORT_CATEGORY_ID  VARCHAR              NULL,
   NEWPORT_CATEGORY     VARCHAR              NULL,
   NEWPORT_BUSINESS_OBJECTIVE_NUMB VARCHAR              NULL,
   NEWPORT_BUSINESS_GROUP_ID VARCHAR              NULL,
   NEWPORT_BUSINESS_GROUP VARCHAR              NULL,
   NEWPORT_BUSINESS_UNIT_ID VARCHAR              NULL,
   NEWPORT_BUSINESS_UNIT VARCHAR              NULL,
   NEWPORT_BUSINESS_SEGMENT_ID VARCHAR              NULL,
   NEWPORT_BUSINESS_SEGMENT VARCHAR              NULL,
   NEWPORT_CONCENTRATION_UNIT_ID VARCHAR              NULL,
   NEWPORT_CONCENTRATION_UNIT VARCHAR              NULL,
   NEWPORT_PROJECT_CREATED VARCHAR              NULL,
   NEWPORT_INITIATOR_ID VARCHAR              NULL,
   NEWPORT_INITIATOR    VARCHAR              NULL,
   NEWPORT_INDICATION_ID VARCHAR              NULL,
   NEWPORT_INDICATION   VARCHAR              NULL,
   NEWPORT_FORMULATION_TYPE_ID VARCHAR              NULL,
   NEWPORT_FORMULATION_TYPE VARCHAR              NULL,
   NEWPORT_FRAMEWORK_ID VARCHAR              NULL,
   NEWPORT_FRAMEWORK    VARCHAR              NULL,
   NEWPORT_FUNDING_ID   VARCHAR              NULL,
   NEWPORT_FUNDING      VARCHAR              NULL,
   NEWPORT_IS_GBO_ID    VARCHAR              NULL,
   NEWPORT_IS_GBO       VARCHAR              NULL,
   NEWPORT_AREA_ID      VARCHAR              NOT NULL,
   NEWPORT_AREA         VARCHAR              NULL,
   NEWPORT_NEW_PORT_NUMBER VARCHAR              NOT NULL,
   NEWPORT_ORIGIN_ID    VARCHAR              NULL,
   NEWPORT_ORIGIN       VARCHAR              NULL,
   NEWPORT_PRODUCT_HIERARCHY VARCHAR              NULL,
   NEWPORT_LAUNCH_YEAR  VARCHAR              NULL,
   NEWPORT_STATUS_ID    VARCHAR              NULL,
   NEWPORT_STATUS       VARCHAR              NULL,
   NEWPORT_PTRS         VARCHAR              NULL,
   NEWPORT_LAST_MODIFIED VARCHAR              NULL,
   NEWPORT_LAST_MODIFIED_USER_CWID VARCHAR              NULL,
   NEWPORT_LAST_MODIFIED_USER VARCHAR              NULL,
   NEWPORT_PRIO_CATEGORY VARCHAR              NULL,
   NEWPORT_PRIO_RANKING_B VARCHAR              NULL,
   NEWPORT_PRIO_COMMENT_B VARCHAR              NULL,
   NEWPORT_CURRENCY     VARCHAR              NULL,
   NEWPORT_GLOBAL_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_GLOBAL_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_IGM_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_IGM_PEAK_YEAR NUMERIC              NULL,
   NEWPORT_GLOBAL_FUTURE_PRO_COST NUMERIC              NULL,
   NEWPORT_GLOBAL_INC_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_NET_SALES_I NUMERIC              NULL,
   NEWPORT_GLOBAL_INC_IGM_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_YEAR_IGM_IN NUMERIC              NULL,
   NEWPORT_GLOBAL_SALES_VOLUME NUMERIC              NULL,
   NEWPORT_GLOBAL_AGGREGATED_VOLUM NUMERIC              NULL,
   NEWPORT_LOCAL_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_NET_SALES NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_NET_SALES_IN NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM_INC NUMERIC              NULL,
   NEWPORT_GLOBAL_EXP_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_GLOBAL_PERC_IGM_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_PRODUCTIVITY_IND NUMERIC              NULL,
   NEWPORT_LOCAL_EXP_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM_PER NUMERIC              NULL,
   NEWPORT_OBJECTIVE    VARCHAR              NULL,
   NEWPORT_SUCCESS_FACTORS VARCHAR              NULL,
   NEWPORT_PRODUCT_PROFILE VARCHAR              NULL,
   NEWPORT_JUSTIFICATION VARCHAR              NULL,
   PTRS_FOLLOW_UP       BOOL                 NOT NULL,
   SCIENCE_RECOMMENDATION       VARCHAR       NULL,
   TECH_RESPONSABILITY       VARCHAR       NULL,
   TECH_STATUS       VARCHAR       NULL,
   TECH_RECOMMENDATION       VARCHAR       NULL,
   SOL_OBJECTIVE       VARCHAR       NULL,
   SOL_RESULT       VARCHAR       NULL,
   SOL_RECOMMENDATION       VARCHAR       NULL,
   FS_PTRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   FS_PTRS_SCORE_MODIFIED_DATE VARCHAR     NULL,
   FS_PTRS_SCORE_UPDATED_BY VARCHAR   NULL,
   FS_PTRS_SCORE_UPDATED_DATE VARCHAR     NULL,
   FT_PTRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   FT_PTRS_SCORE_MODIFIED_DATE VARCHAR   NULL,
   RS_ENSA_PTRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   RS_ENSA_PTRS_SCORE_MODIFIED_DATE VARCHAR   NULL,
   RS_OPERATOR_PTRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   RS_OPERATOR_PTRS_SCORE_MODIFIED_DATE VARCHAR   NULL,
   RS_DIETARY_PTRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   RS_DIETARY_PTRS_SCORE_MODIFIED_DATE VARCHAR   NULL,
   RS_REG_AFFAIRS_SCORE_MODIFIED_BY VARCHAR   NULL,
   RS_REG_AFFAIRS_SCORE_MODIFIED_DATE VARCHAR   NULL,
   RS_PTRS_SCORE_RMK_MODIFIED_DATE VARCHAR              NULL,
   RS_PTRS_SCORE_RMK_MODIFIED_BY VARCHAR    NULL,
   IS_UPDATE VARCHAR NULL,
   NEWPORT_PROJECT_APPROVAL_DATE VARCHAR NULL,
   CATEGORY_CHANGED_DATE_NFPCTOFD VARCHAR NULL,
   CATEGORY_CHANGED_DATE_NASTOLCM VARCHAR NULL,
   APPROVAL_YEAR VARCHAR  NULL,
   approval_date VARCHAR NULL,
   approval_year_month varchar null,
   draft_year VARCHAR NULL,
   draft_year_month varchar null,
   is_segment_present varchar null,
   TECH_RECOMMENDATION_MODIFIED_DATE VARCHAR   NULL,
   TECH_RECOMMENDATION_MODIFIED_BY VARCHAR   NULL,
   SOL_RECOMMENDATION_MODIFIED_DATE VARCHAR   NULL,
   SOL_RECOMMENDATION_MODIFIED_BY VARCHAR   NULL,
   SCIENCE_RECOMMENDATION_MODIFIED_DATE VARCHAR   NULL,
   SCIENCE_RECOMMENDATION_MODIFIED_BY VARCHAR   NULL,
   CONSOLIDATED_REGION VARCHAR NULL,
   CONSTRAINT PK_PROJECT PRIMARY KEY (ID),
   CONSTRAINT AK_NEWPORT_ID_PROJECT UNIQUE (NEWPORT_PROJECT_ID)
);

/*==============================================================*/
/* Index: PROJECT_NEWPORT_ID                                    */
/*==============================================================*/
CREATE UNIQUE INDEX PROJECT_NEWPORT_ID ON PROJECT (
NEWPORT_PROJECT_ID
);

/*==============================================================*/
/* Table: PROJECT_COMMENT                                       */
/*==============================================================*/
CREATE TABLE PROJECT_COMMENT (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   PROJECT_ID           INT8                 NOT NULL,
   DTYPE                VARCHAR              NOT NULL
      CONSTRAINT CKC_DTYPE_PROJECT_ CHECK (DTYPE IN ('PRIO','OVERALL','PTRS') AND DTYPE = UPPER(DTYPE)),
   TIMESTMP             TIMESTAMP WITH TIME ZONE NOT NULL,
   USR                  VARCHAR              NOT NULL,
   TEXT                 VARCHAR              NULL,
   CONSTRAINT PK_PROJECT_COMMENT PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: PROJECT_QUESTION                                      */
/*==============================================================*/
CREATE TABLE PROJECT_QUESTION (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   PROJECT_ID           INT8                 NOT NULL,
   PROJECT_QUESTION_DEFINITION_ID INT8                 NOT NULL,
   ANSWER               BOOL                 NOT NULL,
   CONSTRAINT PK_PROJECT_QUESTION PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: PROJECT_QUESTION_DEFINITION                           */
/*==============================================================*/
CREATE TABLE PROJECT_QUESTION_DEFINITION (
   ID                   SERIAL NOT NULL,
   DTYPE                VARCHAR              NOT NULL
      CONSTRAINT CKC_DTYPE_PROJECT_ CHECK (DTYPE IN ('PRIO','OVERALL','PTRS') AND DTYPE = UPPER(DTYPE)),
   IS_ACTIVE            BOOL                 NOT NULL,
   QUESTION_TEXT        VARCHAR              NOT NULL,
   POS                  INT4                 NOT NULL,
   CONSTRAINT PK_PROJECT_QUESTION_DEFINITION PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: REGION                                                */
/*==============================================================*/
CREATE TABLE REGION (
   ID                   SERIAL NOT NULL,
   SOURCE_KEY           VARCHAR              NULL,
   NAME                 VARCHAR              NOT NULL,
   IS_PLACEHOLDER       BOOL                 NOT NULL,
   FLAG BOOL NULL,
   ROLE_SUFFIX          VARCHAR              NULL,
   CONSTRAINT PK_REGION PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_REGION UNIQUE (NAME)
);

/*==============================================================*/
/* Index: REGION_NAME                                           */
/*==============================================================*/
CREATE UNIQUE INDEX REGION_NAME ON REGION (
NAME
);

/*==============================================================*/
/* Table: SEGMENT                                               */
/*==============================================================*/
CREATE TABLE SEGMENT (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   PROJECT_ID           INT8                 NOT NULL,
   CROP_ID              INT8                 NOT NULL,
   REGION_ID            INT8                 NOT NULL,
   SUB_REGION_ID        INT8                 NOT NULL,
   COUNTRY_ID           INT8                 NOT NULL,
   COST_CENTER          VARCHAR              NOT NULL DEFAULT 'LOCAL'
      CONSTRAINT CKC_COST_CENTER_SEGMENT CHECK (COST_CENTER IN ('LOCAL','REGIONAL','GLOBAL') AND COST_CENTER = UPPER(COST_CENTER)),
   FS_PTRS_SCORE_RMK    VARCHAR              NULL,
   FS_PTRS_SCORE        PERCENT              NULL,
   TARGET               VARCHAR              NOT NULL,
   RS_REG_PTRS_SCORE_RMK VARCHAR             NULL,
   RS_REG_PTRS_SCORE    PERCENT              NULL,
   RS_REG_PRODUCT_PTRS_SCORE_RMK   VARCHAR              NULL,
   RS_REG_PRODUCT_PTRS_SCORE PERCENT         NULL,
   RS_REG_PRODUCT_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_REG_PRODUCT_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_REG_DIETARY_PTRS_SCORE_RMK   VARCHAR              NULL,
   RS_REG_DIETARY_PTRS_SCORE  PERCENT        NULL,
   RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_RMK VARCHAR NULL,
   RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE PERCENT NULL,
   RS_TOXICOLOGY_PTRS_SCORE_RMK VARCHAR NULL,
   RS_TOXICOLOGY_PTRS_SCORE PERCENT NULL,
   RS_ECOTOX_PTRS_SCORE_RMK VARCHAR NULL,
   RS_ECOTOX_PTRS_SCORE PERCENT NULL,
   RS_EFATE_PTRS_SCORE_RMK VARCHAR NULL,
   RS_EFATE_PTRS_SCORE PERCENT NULL,
   RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_RMK VARCHAR NULL,
   RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE PERCENT NULL,
   RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_RMK VARCHAR NULL,
   RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE PERCENT NULL,
   RS_FOREIGN_INFLUENCE_PTRS_SCORE_RMK VARCHAR NULL,
   RS_FOREIGN_INFLUENCE_PTRS_SCORE PERCENT NULL,
   RS_REGISTRATION_PTRS_SCORE_RMK VARCHAR NULL,
   RS_REGISTRATION_PTRS_SCORE PERCENT NULL,
   RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_ECOTOX_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_EFATE_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_EFATE_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_REG_DIETARY_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_REG_DIETARY_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
   RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
   PTRS_SEGMENT_OVERALL_SCORE PERCENT        NULL,
   QUICKSCAN_ASSESSMENT_ID TEXT              NULL,
   IS_QUICK_SCAN_NOT_APPLICABLE BOOL    NULL,
   QUICK_SCAN_NOT_APPLICABLE_REASON VARCHAR NULL,
   REGPRIME_Z_NUMBER    VARCHAR              NULL,
   REGPRIME_SEQUENCE_NUMBER INT4             NULL,
   PRIORITIZATION_TYPE  VARCHAR              NULL
      CONSTRAINT CKC_PRIORITIZATION_TY_SEGMENT CHECK (PRIORITIZATION_TYPE IS NULL OR (PRIORITIZATION_TYPE IN ('A','B','Cancelled'))),
   PRIORITIZATION_RMK   VARCHAR              NULL,
   PRIORITIZATION_GOVERNANCE VARCHAR              NULL
      CONSTRAINT CKC_PRIORITIZATION_GO_SEGMENT CHECK (PRIORITIZATION_GOVERNANCE IS NULL OR (PRIORITIZATION_GOVERNANCE IN ('REGIONAL','GLOBAL') AND PRIORITIZATION_GOVERNANCE = UPPER(PRIORITIZATION_GOVERNANCE))),
   STRATEGIC_FIT_RMK    VARCHAR              NULL,
   REGPRIME_CROP_CODE   VARCHAR              NULL,
   REGPRIME_PRODUCT_LINE_NUMBER VARCHAR              NULL,
   REGPRIME_COUNTRY_CODE VARCHAR              NULL,
   NEWPORT_DISEASES_PESTS_WEEDS_ID VARCHAR              NOT NULL,
   NEWPORT_PTRS         VARCHAR              NULL,
   NEWPORT_LAUNCH_YEAR_COUNTRY VARCHAR              NULL,
   NEWPORT_LAUNCH_YEAR_SEGMENT VARCHAR              NULL,
   NEWPORT_LAUNCH_YEAR_NET_SALES VARCHAR              NULL,
   NEWPORT_SUBMISSION_YEAR VARCHAR              NULL,
   NEWPORT_IS_LAUNCHED  VARCHAR              NULL,
   NEWPORT_WEIGHT_UNIT  VARCHAR              NULL,
   NEWPORT_CURRENCY     VARCHAR              NULL,
   NEWPORT_GLOBAL_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_GLOBAL_EXP_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_GLOBAL_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_NET_SALES_Y INT4                 NULL,
   NEWPORT_GLOBAL_PEAK_YEAR_IGM_PE NUMERIC              NULL,
   NEWPORT_GLOBAL_IGM_PERC_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_IGM_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_IGM_PEAK_YEAR NUMERIC              NULL,
   NEWPORT_GLOBAL_FUTURE_PRO_COST NUMERIC              NULL,
   NEWPORT_GLOBAL_PRODUCTIVITY_IND NUMERIC              NULL,
   NEWPORT_GLOBAL_INC_NET_SALES NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_NET_SALES_I NUMERIC              NULL,
   NEWPORT_GLOBAL_INC_IGM_YEAR_4 NUMERIC              NULL,
   NEWPORT_GLOBAL_PEAK_YEAR_IGM_IN NUMERIC              NULL,
   NEWPORT_GLOBAL_PAYBACK_YEAR INT4                 NULL,
   NEWPORT_GLOBAL_PAYBACK_TIME NUMERIC              NULL,
   NEWPORT_GLOBAL_SALES_VOLUME NUMERIC              NULL,
   NEWPORT_GLOBAL_AGGREGATED_VOLUM NUMERIC              NULL,
   NEWPORT_LOCAL_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_LOCAL_EXP_NPV_YEAR_10 NUMERIC              NULL,
   NEWPORT_LOCAL_PAYBACK_TIME NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_NET_SALES NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_NET_SALES_YE INT4                 NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM_PER NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_NET_SALES_IN NUMERIC              NULL,
   NEWPORT_LOCAL_PEAK_YEAR_IGM_INC NUMERIC              NULL,
   PTRS_FOLLOW_UP       BOOL                 NOT NULL,
   FS_PTRS_SCORE_UPDATED_DATE VARCHAR              NULL,
   FS_PTRS_SCORE_UPDATED_BY VARCHAR              NULL,
   RS_PTRS_SCORE_UPDATED_DATE VARCHAR              NULL,
   RS_PTRS_SCORE_UPDATED_BY VARCHAR              NULL,
   NEWPORT_CATEGORY     VARCHAR              NULL,
   NEWPORT_BUSINESS_UNIT VARCHAR              NULL,
   NEWPORT_STATUS       VARCHAR              NULL,
   LAUNCH_DATE          DATE                 NULL,
   SUBMISSION_DATE      DATE                 NULL,
   COUNTRY_NAME         VARCHAR              NULL,
   CROP_NAME            VARCHAR              NULL,
   NEWPORT_NAME            VARCHAR              NULL,
   NEWPORT_FREE_TEXT            VARCHAR              NULL,
   PRECISE_NEWPORT_ID           VARCHAR              NULL,
   SUB_REGION_NAME            VARCHAR              NULL,
   CROP_PLATFORM_NAME         VARCHAR              NULL,
   CROP_GROUP_NAME           VARCHAR              NULL,
   REGION_NAME               VARCHAR              NULL,
   CREATION_YEAR             VARCHAR              NULL,
   creation_date           VARCHAR NULL,
   creation_date_month VARCHAR NULL,
   COUNTRY_TYPE VARCHAR NULL,
    RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY VARCHAR NULL,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE VARCHAR NULL,
  NEWPORT_SEGMENT_CREATION_DATE VARCHAR NULL,
   CONSTRAINT PK_SEGMENT PRIMARY KEY (ID),
   CONSTRAINT AK_AK_SEGMENT UNIQUE (PROJECT_ID, CROP_ID, REGION_ID, SUB_REGION_ID, COUNTRY_ID, TARGET, COST_CENTER)
);

/*==============================================================*/
/* Table: SEGMENT_COMMENT                                       */
/*==============================================================*/
CREATE TABLE SEGMENT_COMMENT (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   SEGMENT_ID           INT8                 NOT NULL,
   DTYPE                VARCHAR              NOT NULL
      CONSTRAINT CKC_DTYPE_SEGMENT_ CHECK (DTYPE IN ('PRIO','OVERALL','PTRS') AND DTYPE = UPPER(DTYPE)),
   TIMESTMP             TIMESTAMP WITH TIME ZONE NOT NULL,
   USR                  VARCHAR              NOT NULL,
   TEXT                 VARCHAR              NULL,
   CONSTRAINT PK_SEGMENT_COMMENT PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: SEGMENT_COST                                          */
/*==============================================================*/
CREATE TABLE SEGMENT_COST (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   SEGMENT_ID           INT8                 NOT NULL,
   YEAR                 VARCHAR              NOT NULL,
   AGRONOMIC_DEVELOPMENT NUMERIC              NULL,
   ENVIRONMENTAL_SAFETY NUMERIC              NULL,
   FORMULATION_TECHNOLOGY NUMERIC              NULL,
   PRODUCT_SUPPLY       NUMERIC              NULL,
   LAUNCH_MARKETING     NUMERIC              NULL,
   REGULATORY_AFFAIRS   NUMERIC              NULL,
   REGISTRATION_FEES    NUMERIC              NULL,
   RESEARCH             NUMERIC              NULL,
   HUMAN_SAFETY         NUMERIC              NULL,
   OTHER_COSTS          NUMERIC              NULL,
   TOTAL_PROJECT_COSTS  NUMERIC              NULL,
   FIELD_DEVELOPMENT    NUMERIC              NULL,
   CUSTOMER_ADVISORY    NUMERIC              NULL,
   ROCS_ENVIRONMENTAL_RESEARCH NUMERIC              NULL,
   LAST_MODIFIED_ON     TIMESTAMP WITH TIME ZONE NOT NULL,
   CONSTRAINT PK_SEGMENT_COST PRIMARY KEY (ID),
   CONSTRAINT AK_AK_SEGMENT_ UNIQUE (SEGMENT_ID, YEAR)
);

/*==============================================================*/
/* Table: SEGMENT_QUESTION                                      */
/*==============================================================*/
CREATE TABLE SEGMENT_QUESTION (
   ID                   SERIAL NOT NULL,
   VERSION              INT8                 NOT NULL,
   SEGMENT_ID           INT8                 NOT NULL,
   SEGMENT_QUESTION_DEFINITION_ID INT8                 NOT NULL,
   ANSWER               BOOL                 NOT NULL,
   CONSTRAINT PK_SEGMENT_QUESTION PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: SEGMENT_QUESTION_DEFINITION                           */
/*==============================================================*/
CREATE TABLE SEGMENT_QUESTION_DEFINITION (
   ID                   SERIAL NOT NULL,
   DTYPE                VARCHAR              NOT NULL
      CONSTRAINT CKC_DTYPE_SEGMENT_ CHECK (DTYPE IN ('PRIO','OVERALL','PTRS') AND DTYPE = UPPER(DTYPE)),
   IS_ACTIVE            BOOL                 NOT NULL,
   QUESTION_TEXT        VARCHAR              NOT NULL,
   POS                  INT4                 NOT NULL,
   CONSTRAINT PK_SEGMENT_QUESTION_DEFINITION PRIMARY KEY (ID)
);

/*==============================================================*/
/* Table: SETTING                                               */
/*==============================================================*/
CREATE TABLE SETTING (
   ID                   SERIAL NOT NULL,
   MODULE               VARCHAR              NOT NULL,
   OWNER                VARCHAR              NULL,
   KEY                  VARCHAR              NOT NULL,
   TEXT_VALUE           VARCHAR              NULL,
   CONSTRAINT PK_SETTING PRIMARY KEY (ID),
   CONSTRAINT AK_AK_SETTING UNIQUE (MODULE, OWNER, KEY)
);

/*==============================================================*/
/* Table: SUB_REGION                                            */
/*==============================================================*/
CREATE TABLE SUB_REGION (
   ID                   SERIAL NOT NULL,
   SOURCE_KEY           VARCHAR              NULL,
   NAME                 VARCHAR              NOT NULL,
   IS_PLACEHOLDER       BOOL                 NOT NULL,
   FLAG BOOL NULL,
   CONSTRAINT PK_SUB_REGION PRIMARY KEY (ID),
   CONSTRAINT AK_NAME_SUB_REGI UNIQUE (NAME)
);

/*==============================================================*/
/* Index: SUB_REGION_NAME                                       */
/*==============================================================*/
CREATE UNIQUE INDEX SUB_REGION_NAME ON SUB_REGION (
NAME
);


ALTER TABLE ACTIVE_INGREDIANT_2_PRODUCT
   ADD CONSTRAINT FK_ACTIVE_I_AI2AIP_ACTIVE_I FOREIGN KEY (ACTIVE_INGREDIANT_ID)
      REFERENCES ACTIVE_INGREDIANT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE ACTIVE_INGREDIANT_2_PRODUCT
   ADD CONSTRAINT FK_ACTIVE_I_PRD2AIP_PRODUCT FOREIGN KEY (PRODUCT_ID)
      REFERENCES PRODUCT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE ALLOWED_VALUE
   ADD CONSTRAINT FK_ALLOWED__FCO2ALV_FACET_CO FOREIGN KEY (FACET_CONFIG_ID)
      REFERENCES FACET_CONFIG (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE CROP
   ADD CONSTRAINT FK_CROP_CRG2CR_CROP_GRO FOREIGN KEY (CROP_GROUP_ID)
      REFERENCES CROP_GROUP (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE CROP_GROUP
   ADD CONSTRAINT FK_CROP_GRO_CRP2CRG_CROP_PLA FOREIGN KEY (CROP_PLATFORM_ID)
      REFERENCES CROP_PLATFORM (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PROJECT
   ADD CONSTRAINT FK_PROJECT_PRD2PRJ_PRODUCT FOREIGN KEY (PRODUCT_ID)
      REFERENCES PRODUCT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PROJECT_COMMENT
   ADD CONSTRAINT FK_PROJECT__PRO2PRC_PROJECT FOREIGN KEY (PROJECT_ID)
      REFERENCES PROJECT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PROJECT_QUESTION
   ADD CONSTRAINT FK_PROJECT__PQD2PRQ_PROJECT_ FOREIGN KEY (PROJECT_QUESTION_DEFINITION_ID)
      REFERENCES PROJECT_QUESTION_DEFINITION (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PROJECT_QUESTION
   ADD CONSTRAINT FK_PROJECT__PRO2PRQ_PROJECT FOREIGN KEY (PROJECT_ID)
      REFERENCES PROJECT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT
   ADD CONSTRAINT FK_SEGMENT_COU2SEG_COUNTRY FOREIGN KEY (COUNTRY_ID)
      REFERENCES COUNTRY (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT
   ADD CONSTRAINT FK_SEGMENT_CR2SEG_CROP FOREIGN KEY (CROP_ID)
      REFERENCES CROP (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT
   ADD CONSTRAINT FK_SEGMENT_PRJ2SEG_PROJECT FOREIGN KEY (PROJECT_ID)
      REFERENCES PROJECT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT
   ADD CONSTRAINT FK_SEGMENT_REG2SEG_REGION FOREIGN KEY (REGION_ID)
      REFERENCES REGION (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT
   ADD CONSTRAINT FK_SEGMENT_SUR2SEG_SUB_REGI FOREIGN KEY (SUB_REGION_ID)
      REFERENCES SUB_REGION (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT_COMMENT
   ADD CONSTRAINT FK_SEGMENT__SEG2SEC_SEGMENT FOREIGN KEY (SEGMENT_ID)
      REFERENCES SEGMENT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT_COST
   ADD CONSTRAINT FK_SEGMENT__SEG2SCO_SEGMENT FOREIGN KEY (SEGMENT_ID)
      REFERENCES SEGMENT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT_QUESTION
   ADD CONSTRAINT FK_SEGMENT__SEG2SEQ_SEGMENT FOREIGN KEY (SEGMENT_ID)
      REFERENCES SEGMENT (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE SEGMENT_QUESTION
   ADD CONSTRAINT FK_SEGMENT__SQD2SEQ_SEGMENT_ FOREIGN KEY (SEGMENT_QUESTION_DEFINITION_ID)
      REFERENCES SEGMENT_QUESTION_DEFINITION (ID)
      ON DELETE RESTRICT ON UPDATE RESTRICT;

