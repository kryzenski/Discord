package com.bayer.pmodi.masterlist.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.test.annotation.DirtiesContext;

import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.DomainUtil;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SubRegion;
import com.bayer.pmodi.masterlist.model.enums.CostCenterEnum;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.bayer.pmodi.masterlist.search.NumberOperatorEnum;
import com.bayer.pmodi.masterlist.search.SearchCriterion;

@DataJpaTest(showSql = false)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class SegmentSearchTest {

	private static final double SCORE = 0.890123;

	private static final int TOTAL_PROJECTS = 10;
	private static final int TOTAL_SEGMENTS = 100;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CropPlatformRepository cropPlatformRepository;

	@Autowired
	private CropGroupRepository cropGroupRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@BeforeEach
	private void init() {
		TestUtil.createCountryData(regionRepository, subRegionRepository, countryRepository, 1, 1, 2);
		TestUtil.createCropData(cropPlatformRepository, cropGroupRepository, cropRepository, 1, 1, 1);

		Iterator<Product> productIterator = TestUtil.createProductData(productRepository, 2).iterator();
		Product p1 = productIterator.next();
		Product p2 = productIterator.next();

		Country country = countryRepository.getOne(1l);
		SubRegion subRegion = subRegionRepository.getOne(1l);
		Region region = regionRepository.getOne(1l);
		Crop crop = cropRepository.getOne(1l);

		List<Project> projects = new ArrayList<Project>(TOTAL_PROJECTS);
		List<Segment> segments = new ArrayList<Segment>(TOTAL_SEGMENTS);
		for (int i = 0; i < TOTAL_PROJECTS; i++) {
			Project p = new Project();
			p.setNewportProjectId(String.valueOf(20000 + i));
			p.setNewportAreaId("A");
			p.setNewportNewPortNumber("0000" + i);
			p.setPreciseNewportId(DomainUtil.createPreciseNewportId(p.getNewportAreaId(), p.getNewportNewPortNumber()));
			p.setNewportName("Project " + i);
			if (i % 2 == 0) {
				p.setProduct(p1);
				p.setNewportInitiator("Hans");
			} else {
				p.setProduct(p2);
				p.setNewportInitiator("Hubert");
			}
			p.setNewportGlobalNpvYear10(Double.valueOf(((i + 500) / 4) + ".23"));
			p.setNewportLaunchYear(String.valueOf(Integer.valueOf(2020 + i)));
			p.setFtPtrsScore(SCORE);
			p.setTechResponsability("FT Monheim");
			p.setTechStatus("FT-work not started");
			p.setTechRecommendation("Continue POC");
			p.setTechRecommendationModifiedBy("Test user");
			p.setTechRecommendationModifiedDate("13/05/2022");

			p.setSolObjective("test solution objective");
			p.setSolResult("test solution result");
			p.setSolRecommendation("Continue POC");
			p.setSolRecommendationModifiedBy("Test user");
			p.setSolRecommendationModifiedDate("13/05/2022");

			p.setScienceRecommendation("Continue POC");
			p.setScienceRecommendationModifiedBy("Test user");
			p.setScienceRecommendationModifiedDate("13/05/2022");

			p.setFsPtrsScoreModifiedBy("Test user");
			p.setFsPtrsScoreModifiedDate("13/05/2022");
			p.setFtPtrsScoreModifiedBy("test user");
			p.setFtPtrsScoreModifiedDate("13/05/2022");
			p.setRsEnsaPtrsScoreModifiedBy("test user");
			p.setRsEnsaPtrsScoreModifiedDate("13/05/2022");
			p.setRsOperatorPtrsScoreModifiedBy("test user");
			p.setRsOperatorPtrsScoreModifiedDate("13/03/2022");
			p.setRsDietaryPtrsScoreModifiedBy("test user");
			p.setRsDietaryPtrsScoreModifiedDate("13/05/2022");
			p.setRsRegAffairsScoreModifiedBy("test user");
			p.setRsRegAffairsScoreModifiedDate("13/05/2022");
			p.setRsPtrsScoreRmkModifiedBy("test user");
			p.setRsPtrsScoreRmkModifiedDate("07/06/2022");

			int maxSegments = i % 2 == 0 ? 12 : 8;
			for (int j = 0; j < maxSegments; j++) {
				Segment s = new Segment();
				s.setProject(p);
				s.setCountry(country);
				s.setSubRegion(subRegion);
				s.setRegion(region);
				s.setCrop(crop);
				s.setTarget("Target X" + j);
				s.setNewportDiseasesPestsWeedsId("X" + j);

				s.setRsRegProductPtrsScore(SCORE);
				s.setRsRegProductPtrsScoreRmk("rsRegProductScoreRmk");
				s.setRsRegDietaryPtrsScore(SCORE);
				s.setRsRegDietaryPtrsScoreRmk("rsRegDietaryScoreRmk");
				s.setRsOccupationalResidentialExposurePtrsScore(SCORE);
				s.setRsOccupationalResidentialExposurePtrsScoreRmk("rsOccupationalResidentialExposurePtrsScoreRmk");
				s.setRsToxicologyPtrsScore(SCORE);
				s.setRsToxicologyPtrsScoreRmk("rsToxicologyPtrsScoreRmk");
				s.setRsEcotoxPtrsScore(SCORE);
				s.setRsEcotoxPtrsScoreRmk("rsEcotoxPtrsScoreRmk");
				s.setRsEfatePtrsScore(SCORE);
				s.setRsEfatePtrsScoreRmk("rsEfatePtrsScoreRmk");
				s.setRsLocalRestrictionOthersPtrsScore(SCORE);
				s.setRsLocalRestrictionOthersPtrsScoreRmk("rsLocalRestrictionOthersPtrsScoreRmk");
				s.setRsLocalRestrictionPolicyPtrsScore(SCORE);
				s.setRsLocalRestrictionPolicyPtrsScoreRmk("rsLocalRestrictionPolicyPtrsScoreRmk");
				s.setRsRegistrationPtrsScore(SCORE);
				s.setRsRegistrationPtrsScoreRmk("rsRegistrationPtrsScoreRmk");
				s.setRsForeignInfluencePtrsScore(SCORE);
				s.setRsForeignInfluencePtrsScoreRmk("rsForeignInfluencePtrsScoreRmk");

				s.setCostCenter(CostCenterEnum.GLOBAL);

				if (i == 2 && j == 4) {
					s.setFsPtrsScoreRmk("fsPtrsScoreRmk");
					s.setFsPtrsScore(SCORE);
					s.setPrioritizationRmk("prioritizationRmk");
					s.setPrioritizationGovernance(LocationTypeEnum.REGIONAL);
					s.setPrioritizationType(PrioritizationTypeEnum.B);
					s.setPtrsFollowUp(true);
					// s.setPtrsSegmentOverallScore(12345.6789); // calculated
					s.setQuickscanAssessmentId("12345");
					s.setRegprimeCountryCode("regprimeCountryCode");
					s.setRegprimeCropCode("regprimeCropCode");
					s.setRegprimeProductLineNumber("regprimeProductLineNumber");
					s.setRegprimeSequenceNumber(1);
					s.setRegprimeZNumber("regprimeZNumber");
					s.setRsRegPtrsScoreRmk("rsRegPtrsScoreRmk");
					//s.setRsRegPtrsScore(SCORE); //will be calculated

					s.setStrategicFitRmk("strategicFitRmk");

					s.setNewportPtrs("ptr");
					s.setNewportLaunchYearCountry("2020");
					s.setNewportLaunchYearSegment("2020");
					s.setNewportLaunchYearNetSales("2020");
					s.setNewportSubmissionYear("2020");
					s.setNewportIsLaunched("n");
					s.setNewportWeightUnit("nwu");
					s.setNewportCurrency("cur");
					s.setNewportGlobalNpvYear10(12345.6789);
					s.setNewportGlobalExpectedNpvYear10(12345.6789);
					s.setNewportGlobalNetSales(12345.6789);
					s.setNewportGlobalPeakNetSales(12345.6789);
					s.setNewportGlobalPeakNetSalesYear(2020);
					s.setNewportGlobalPeakYearIgmPercNetSales(12345.6789);
					s.setNewportGlobalIgmPercYear4(12345.6789);
					s.setNewportGlobalIgmYear4(12345.6789);
					s.setNewportGlobalIgmPeakYear(12345.6789);
					s.setNewportGlobalFutureProjectCost(12345.6789);
					s.setNewportGlobalProductivityIndex(12345.6789);
					s.setNewportGlobalIncrementalNetSales(12345.6789);
					s.setNewportGlobalPeakNetSalesIncremental(12345.6789);
					s.setNewportGlobalIncrementalIgmYear4(12345.6789);
					s.setNewportGlobalPeakYearIgmIncremental(12345.6789);
					s.setNewportGlobalPaybackYear(2020);
					s.setNewportGlobalPaybackTime(1.234);
					s.setNewportGlobalSalesVolume(12345.6789);
					s.setNewportGlobalAggregatedVolume(12345.6789);
					s.setNewportLocalNpvYear10(12345.6789);
					s.setNewportLocalExpectedNpvYear10(12345.6789);
					s.setNewportLocalPaybackTime(12345.6789);
					s.setNewportLocalPeakNetSales(12345.6789);
					s.setNewportLocalPeakNetSalesYear(2020);
					s.setNewportLocalPeakYearIgmPercNetSales(12345.6789);
					s.setNewportLocalPeakYearIgm(12345.6789);
					s.setNewportLocalPeakNetSalesIncremental(12345.6789);
					s.setNewportLocalPeakYearIgmIncremental(12345.6789);
					s.setFsPtrsScoreUpdatedDate("01/05/2022");
					s.setFsPtrsScoreUpdatedBy("Test user");
					s.setRsPtrsScoreUpdatedDate("01/05/2022");
					s.setRsPtrsScoreUpdatedBy("Test user");

				}
				segments.add(s);
			}

			projects.add(p);
		}
		projectRepository.saveAll(projects);

		segmentRepository.saveAll(segments);
	}

	@Test
	void testSearchWithoutCriteriaAndWithoutPageRequest() {
		Page<Segment> results = segmentRepository.search(null, null);
		assertThat(results).isNotNull().hasSize(TOTAL_SEGMENTS);
	}

	@Test
	void testSearchTextWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("target", "Target X10");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(5);
	}

	@Test
	void testSearchTextWithEqualsAndIgnoreCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("target", "target x1", true);

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
	}

	@Test
	void testSearchTextWithContains() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextContains("target", "get X1");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(20);
	}

	@Test
	void testSearchTextWithIn() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("target", "Target X10", "Target X11", "Dummy",
				"Target X19");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
	}

	@Test
	void testSearchTextWithEqualsAndTwoMatchingCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("target", "Target X4");
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "prioritizationRmk"));

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
	}

	@Test
	void testSearchEnumWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("prioritizationGovernance",
				LocationTypeEnum.REGIONAL.name(), false);

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
	}

	@Test
	void testSearchDoubleWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.EQUALS, 12345.6789);

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
	}

	@Test
	void testSearchIntWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchNumber("newportGlobalPaybackYear",
				NumberOperatorEnum.EQUALS, 2020);

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
	}

	@Test
	void testSearchTextWithEqualsOnParentProject() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("project.preciseNewportId", "A-0");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(12);
	}

	@Test
	void testSearchBooleanWithStringTrueCamelCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("ptrsFollowUp", "TrUe");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
	}

	@Test
	void testSearchBooleanWithIllegalTerm() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("ptrsFollowUp", "Wahr", "False");
			segmentRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage()).contains("Unsupported boolean text value");
	}

	@Test
	void testSearchAllNonUniqueProperties() {
		List<SearchCriterion> criteria = createNonUniqueSearchCriteria();

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(0);
	}

	private List<SearchCriterion> createNonUniqueSearchCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("fsPtrsScoreRmk", "fsPtrsScoreRmk");
		criteria.addAll(SearchTestUtil.searchDoubles("fsPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "prioritizationRmk"));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationGovernance", LocationTypeEnum.REGIONAL.name()));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationType", PrioritizationTypeEnum.B.name()));
		// Attention: the following property is calculated and rounded
		criteria.addAll(SearchTestUtil.searchDoubles("ptrsSegmentOverallScore", NumberOperatorEnum.EQUALS, 0.70526133));
		criteria.addAll(SearchTestUtil.searchTextEqual("quickscanAssessmentId", "12345"));
		criteria.addAll(SearchTestUtil.searchTextEqual("regprimeCountryCode", "regprimeCountryCode"));
		criteria.addAll(SearchTestUtil.searchTextEqual("regprimeCropCode", "regprimeCropCode"));
		criteria.addAll(SearchTestUtil.searchTextEqual("regprimeProductLineNumber", "regprimeProductLineNumber"));
		criteria.addAll(SearchTestUtil.searchTextEqual("regprimeZNumber", "regprimeZNumber"));
		criteria.addAll(SearchTestUtil.searchNumber("regprimeSequenceNumber", NumberOperatorEnum.EQUALS, 1));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsRegPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchDoubles("rsRegProductPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegProductPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsRegDietaryPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegDietaryPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsOccupationalResidentialExposurePtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsOccupationalResidentialExposurePtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsToxicologyPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsToxicologyPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsEcotoxPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsEcotoxPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsEfatePtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsEfatePtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsLocalRestrictionPolicyPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsLocalRestrictionPolicyPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsLocalRestrictionOthersPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsLocalRestrictionOthersPtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsForeignInfluencePtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsForeignInfluencePtrsScoreRmk", "rsRegPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsRegistrationPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
	    criteria.addAll(SearchTestUtil.searchTextEqual("rsRegistrationPtrsScoreRmk", "rsRegPtrsScoreRmk"));

		criteria.addAll(SearchTestUtil.searchTextEqual("strategicFitRmk", "strategicFitRmk"));
		criteria.addAll(SearchTestUtil.searchTextEqual("costCenter", CostCenterEnum.GLOBAL.name()));

		criteria.addAll(SearchTestUtil.searchTextEqual("newportDiseasesPestsWeedsId", "X4"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportPtrs", "ptr"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLaunchYearCountry", "2020"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLaunchYearSegment", "2020"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLaunchYearNetSales", "2020"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportSubmissionYear", "2020"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportIsLaunched", "n"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportWeightUnit", "nwu"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportCurrency", "cur"));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalNpvYear10", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalExpectedNpvYear10", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalNetSales", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalPeakNetSales", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchNumber("newportGlobalPeakNetSalesYear", NumberOperatorEnum.EQUALS, 2020));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakYearIgmPercNetSales", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalIgmPercYear4", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalIgmYear4", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalIgmPeakYear", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalFutureProjectCost", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalProductivityIndex", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalIncrementalNetSales", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakNetSalesIncremental", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalIncrementalIgmYear4", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakYearIgmIncremental", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchNumber("newportGlobalPaybackYear", NumberOperatorEnum.EQUALS, 2020));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPaybackTime", NumberOperatorEnum.EQUALS, 1.234));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalSalesVolume", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalAggregatedVolume", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalNpvYear10", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportLocalExpectedNpvYear10", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPaybackTime", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportLocalPeakNetSales", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchNumber("newportLocalPeakNetSalesYear", NumberOperatorEnum.EQUALS, 2020));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgmPercNetSales", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgm", NumberOperatorEnum.EQUALS, 12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakNetSalesIncremental", NumberOperatorEnum.EQUALS,
				12345.6789));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgmIncremental", NumberOperatorEnum.EQUALS,
				12345.6789));

		criteria.addAll(SearchTestUtil.searchTextEqual("ptrsFollowUp", "TRUE"));

		criteria.addAll(SearchTestUtil.searchTextEqual("fsPtrsScoreUpdatedDate", "01/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("fsPtrsScoreUpdatedBy", "Test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsPtrsScoreUpdatedDate", "01/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsPtrsScoreUpdatedBy", "Test user"));


		return criteria;
	}

	@Test
	void testSearchTextWithEqualsOnChildCountry() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("country.name",
				"Country 1 of Sub-Region 1 of Region 1");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_SEGMENTS);
	}

	@Test
	void testSearchTextWithEqualsOnChildOfChildOfChildCrop() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("crop.cropGroup.cropPlatform.name",
				"CropPlatform 1");

		Page<Segment> results = segmentRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_SEGMENTS);
	}

	// ------------------------------------------------------------
}
