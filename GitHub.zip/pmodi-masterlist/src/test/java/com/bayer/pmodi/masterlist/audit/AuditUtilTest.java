package com.bayer.pmodi.masterlist.audit;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.Segment;

class AuditUtilTest {

	private static final boolean SYSOUT_FIELDS = false;

	@Test
	void testGetAuditedFieldsForProject() {
		List<String> results = AuditUtil.getAuditedFieldsWithModifiedFlag(Project.class);
		assertThat(results).isNotNull().isNotEmpty().contains("fsPtrsScoreRmk", "fsPtrsScore");
		if (SYSOUT_FIELDS) {
			System.out.println("Audited Project Fields: \n" + StringUtils.join(results, ","));
		}
	}

	@Test
	void testGetAuditedFieldsForSegment() {
		List<String> results = AuditUtil.getAuditedFieldsWithModifiedFlag(Segment.class);
		assertThat(results).isNotNull().isNotEmpty().contains("fsPtrsScoreRmk", "fsPtrsScore");
		if (SYSOUT_FIELDS) {
			System.out.println("Audited Segment Fields: \n" + StringUtils.join(results, ","));
		}
	}

}
