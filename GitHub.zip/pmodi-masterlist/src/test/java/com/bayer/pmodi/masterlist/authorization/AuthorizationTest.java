package com.bayer.pmodi.masterlist.authorization;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.entry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

import com.bayer.pmodi.masterlist.config.security.UserDetailsHelper;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.rest.model.ProjectDto;

class AuthorizationTest {

	private boolean printGroups = false;

	@Test
	void testSegmentAuthenticatedFieldDefinition_GlobalAdmin() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalAdminFields()).contains("regprimeSequenceNumber", "regprimeCropCode");

		if (printGroups) {
			System.out.println("Segment fields per group:");
			for (String group : Groups.ALL_GROUPS) {
				if (((SegmentAuthenticatedFieldDefinition) def).isRelevantGroup(group)) {
					System.out.println("    " + group + ": " + StringUtils.join(def.getGroupFields(group), ", "));
				}
			}
		}
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_GlobalDevelopment() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalDevelopmentFields()).contains("regprimeSequenceNumber", "regprimeCropCode",
				"regprimeCountryCode", "regprimeProductLineNumber");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_GlobalMarketing() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalMarketingFields()).contains("strategicFitRmk", "regprimeSequenceNumber",
				"regprimeCropCode");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_RegionalAdmin() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getRegionalAdminFields()).contains("fsPtrsScore","regprimeSequenceNumber");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_RegionalDevelopment() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getRegionalDevelopmentFields()).contains("fsPtrsScore","regprimeSequenceNumber");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_RegionalMarketing() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getRegionalMarketingFields()).contains("prioritizationRmk")
				.doesNotContain("regprimeSequenceNumber", "regprimeCropCode");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_EditableFields() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getEditableFields()).contains("fsPtrsScore", "strategicFitRmk", "prioritizationGovernance",
				"prioritizationType", "prioritizationRmk", "regprimeSequenceNumber", "regprimeCropCode",
				"regprimeCountryCode", "regprimeProductLineNumber");
	}

	@Test
	void testSegmentAuthenticatedFieldDefinition_SpecialFields() {
		AuthenticatedFieldDefinition def = SegmentAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getSpecialFields())
				.contains(entry("prioritizationType", SpecialTreatment.PRIORITIZATION_TYPE_BY_GOVERNANCE));
	}

	@Test
	void testProjectAuthenticatedFieldDefinition_GlobalAdmin() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalAdminFields()).contains("fsPtrsScore", "lumosLocalProjectId", "rsGovernance",
				"labelForSafeUse");

		if (printGroups) {
			System.out.println("Project fields per group:");
			for (String group : Groups.ALL_GROUPS) {
				if (((ProjectAuthenticatedFieldDefinition) def).isRelevantGroup(group)) {
					System.out.println("    " + group + ": " + StringUtils.join(def.getGroupFields(group), ", "));
				}
			}
		}
	}

	@Test
	void testProjectAuthenticatedFieldDefinition_GlobalDevelopment() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalDevelopmentFields()).contains("fsPtrsScore", "labelForSafeUse");
	}

	@Test
	void testProjectAuthenticatedFieldDefinition_GlobalMarketing() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getGlobalMarketingFields()).contains("strategicFitRmk");
	}

//	@Test
//	void testProjectAuthenticatedFieldDefinition_RegionalAdmin() {
//		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
//		assertThat(def.getRegionalAdminFields()).contains("fsPtrsScore");
//	}

	@Test
	void testProjectAuthenticatedFieldDefinition_RegionalMarketing() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getRegionalMarketingFields()).contains("prioritizationRmk");
	}

	@Test
	void testProjectAuthenticatedFieldDefinition_EditableFields() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getEditableFields()).contains("ftPtrsScore", "strategicFitRmk",
				"prioritizationGovernance", "prioritizationType", "prioritizationRmk", "lumosGlobalProjectId",
				"rsGovernance", "labelForSafeUse");
	}

	@Test
	void testProjectAuthenticatedFieldDefinition_SpecialFields() {
		AuthenticatedFieldDefinition def = ProjectAuthenticatedFieldDefinition.getInstance();
		assertThat(def.getSpecialFields())
				.contains(entry("prioritizationType", SpecialTreatment.PRIORITIZATION_TYPE_BY_GOVERNANCE));
	}

	@Test
	void testCheckFields_NoRoles() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER", null);

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().isEmpty();
	}

	@Test
	void testCheckFields_SuperAdmin() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_SUPER_ADMIN));

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(
				ProjectAuthenticatedFieldDefinition.getInstance().getEditableFields());
	}

	@Test
	void testCheckFields_GlobalAdmin() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_ADMIN));

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(
				ProjectAuthenticatedFieldDefinition.getInstance().getGlobalAdminFields());
	}

	@Test
	void testCheckFields_GlobalDevelopment() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_DEVELOPMENT));

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(
				ProjectAuthenticatedFieldDefinition.getInstance().getGlobalDevelopmentFields());
	}

	@Test
	void testCheckFields_GlobalDevelopment_Locked() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_DEVELOPMENT));
		List<String> lockedGroups = Arrays.asList(Groups.GROUP_PROJECT_PTRS);
		AuthenticatedFieldDefinition definition = ProjectAuthenticatedFieldDefinition.getInstance();

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(), definition,
				null, f -> true, lockedGroups);

		List<String> expected = definition.getGlobalDevelopmentFields().stream()
				.filter(f -> !definition.getGroupFields(Groups.GROUP_PROJECT_PTRS).contains(f))
				.collect(Collectors.toList());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	@Test
	void testCheckFields_GlobalDevelopment_OthersLocked() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_DEVELOPMENT));
		List<String> lockedGroups = Arrays.asList(Groups.GROUP_PROJECT_PRIO, Groups.GROUP_PROJECT_GUIDANCE_IP);
		AuthenticatedFieldDefinition definition = ProjectAuthenticatedFieldDefinition.getInstance();

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(), definition,
				null, f -> true, lockedGroups);

		List<String> expected = definition.getGlobalDevelopmentFields().stream()
				.filter(f -> !definition.getGroupFields(Groups.GROUP_PROJECT_PRIO).contains(f)
						&& !definition.getGroupFields(Groups.GROUP_PROJECT_GUIDANCE_IP).contains(f))
				.collect(Collectors.toList());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	@Test
	void testCheckFields_GlobalDevelopment_OtherEntityLocked() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_DEVELOPMENT));
		List<String> lockedGroups = Arrays.asList(Groups.GROUP_SEGMENT_PTRS);
		AuthenticatedFieldDefinition definition = ProjectAuthenticatedFieldDefinition.getInstance();

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(), definition,
				null, f -> true, lockedGroups);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(definition.getGlobalDevelopmentFields());
	}

	@Test
	void testCheckFields_GlobalMarketing_WithMatchingSpecialTreatment() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_MARKETING));
		ProjectDto project = new ProjectDto();
		project.setPrioritizationGovernance(LocationTypeEnum.GLOBAL);

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, project,
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		List<String> expected = new ArrayList<String>(
				ProjectAuthenticatedFieldDefinition.getInstance().getGlobalMarketingFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getSpecialFields().keySet());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	@Test
	void testCheckFields_GlobalMarketing_WithNotMatchingSpecialTreatment() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_GLOBAL_MARKETING));
		ProjectDto project = new ProjectDto();
		project.setPrioritizationGovernance(LocationTypeEnum.REGIONAL);

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, project,
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(
				ProjectAuthenticatedFieldDefinition.getInstance().getGlobalMarketingFields());
	}

	@Test
	void testCheckFields_RegionalAdmin_WithNoRegion() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_ADMIN + "EMEA"));

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), null, f -> true);

		assertThat(results).isNotNull().isEmpty();
	}

	@Test
	void testCheckFields_RegionalAdmin_WithNotMatchingRegion() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_ADMIN + "EMEA"));
		List<String> roleSuffixes = java.util.Arrays.asList("LATAM", "NA", "APAC");

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), roleSuffixes, f -> true);

		assertThat(results).isNotNull().isEmpty();
	}

	@Test
	void testCheckFields_RegionalAdmin_WithMatchingRegion() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_ADMIN + "EMEA"));
		List<String> roleSuffixes = java.util.Arrays.asList("EMEA", "NA");

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), roleSuffixes, f -> true);

		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(
				ProjectAuthenticatedFieldDefinition.getInstance().getRegionalAdminFields());
	}

	@Test
	void testCheckFields_AllRegionalRoles_WithMatchingRegion() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_ADMIN + "LATAM",
						Roles.ROLE_PREFIX_REGIONAL_MARKETING + "EMEA",
						Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT + "EMEA"));
		List<String> roleSuffixes = java.util.Arrays.asList("EMEA", "NA", "LATAM");

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), roleSuffixes, f -> true);

		Set<String> expected = new HashSet<>(
				ProjectAuthenticatedFieldDefinition.getInstance().getRegionalAdminFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getRegionalMarketingFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getRegionalDevelopmentFields());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	@Test
	void testCheckFields_AllRegionalRolesButWithoutAdmin_WithMatchingRegion() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_MARKETING + "LATAM",
						Roles.ROLE_PREFIX_REGIONAL_MARKETING + "EMEA",
						Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT + "EMEA"));
		List<String> roleSuffixes = java.util.Arrays.asList("EMEA", "NA", "LATAM");

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, new ProjectDto(),
				ProjectAuthenticatedFieldDefinition.getInstance(), roleSuffixes, f -> true);

		Set<String> expected = new HashSet<>(
				ProjectAuthenticatedFieldDefinition.getInstance().getRegionalMarketingFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getRegionalDevelopmentFields());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	@Test
	void testCheckFields_AllRegionalRolesButWithoutAdmin_WithMatchingRegionAndMatchngSpecialTreatment() {
		UserDetailsHelper userDetailsHelper = getTestUserDetailsHelper("TESTER",
				java.util.Arrays.asList(Roles.ROLE_PREFIX_REGIONAL_MARKETING + "NA",
						Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT + "NA",
						Roles.ROLE_PREFIX_REGIONAL_DEVELOPMENT + "EMEA"));
		List<String> roleSuffixes = java.util.Arrays.asList("EMEA", "NA", "LATAM");
		ProjectDto project = new ProjectDto();
		project.setPrioritizationGovernance(LocationTypeEnum.REGIONAL);

		List<String> results = AuthorizationUtil.checkFields(userDetailsHelper, false, project,
				ProjectAuthenticatedFieldDefinition.getInstance(), roleSuffixes, f -> true);

		Set<String> expected = new HashSet<>(
				ProjectAuthenticatedFieldDefinition.getInstance().getRegionalMarketingFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getRegionalDevelopmentFields());
		expected.addAll(ProjectAuthenticatedFieldDefinition.getInstance().getSpecialFields().keySet());
		assertThat(results).isNotNull().containsExactlyInAnyOrderElementsOf(expected);
	}

	/**
	 * @param user  User; mandatory (but not checked)
	 * @param roles Roles; optional
	 * @return UserDetailsHelper with the given user and roles which accepts null as
	 *         ServletRequest
	 */
	private UserDetailsHelper getTestUserDetailsHelper(String user, List<String> roles) {
		UserDetailsHelper userDetailsHelper = new UserDetailsHelper() {

			@Override
			public List<String> getCurrentUserRoles() {
				return roles == null ? Collections.emptyList() : roles;
			}

			@Override
			public String getCurrentUserId() {
				return user;
			}

			@Override
			public Object getCurrentUserClaim(String claimKey) {
				return user;
			}
		};
		return userDetailsHelper;
	}

}
