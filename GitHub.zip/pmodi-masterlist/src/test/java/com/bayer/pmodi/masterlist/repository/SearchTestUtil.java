package com.bayer.pmodi.masterlist.repository;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.bayer.pmodi.masterlist.model.enums.CodeEnum;
import com.bayer.pmodi.masterlist.search.NumberOperatorEnum;
import com.bayer.pmodi.masterlist.search.SearchCriterion;
import com.bayer.pmodi.masterlist.search.TextOperatorEnum;

public class SearchTestUtil {

	public static List<SearchCriterion> searchCodeEnumEqual(String fieldName, CodeEnum<?> enumValue,
			boolean ignoreCase) {
		List<String> operatorOptions = optionsWith(ignoreCase);
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(TextOperatorEnum.EQUALS.code());
		critera.setOperatorOptions(operatorOptions);
		critera.setStringValues(Arrays.asList(enumValue.toString()));
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchCodeEnumIn(String fieldName, CodeEnum<?>... enumValue) {
		List<String> values = Arrays.asList(enumValue).stream().map(v -> v.toString()).collect(Collectors.toList());
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(TextOperatorEnum.IN.code());
		critera.setStringValues(values);
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchTextEqual(String fieldName, String textValue) {
		return searchTextEqual(fieldName, textValue, false);
	}

	public static List<SearchCriterion> searchTextEqual(String fieldName, String textValue, boolean ignoreCase) {
		return searchText(fieldName, TextOperatorEnum.EQUALS, textValue, ignoreCase);
	}

	public static List<SearchCriterion> searchTextContains(String fieldName, String textValue) {
		return searchTextContains(fieldName, textValue, false);
	}

	public static List<SearchCriterion> searchTextContains(String fieldName, String textValue, boolean ignoreCase) {
		return searchText(fieldName, TextOperatorEnum.CONTAINS, textValue, ignoreCase);
	}

	public static List<SearchCriterion> searchTextIn(String fieldName, String... textValue) {
		return searchTextIn(fieldName, false, textValue);
	}

	public static List<SearchCriterion> searchTextIn(String fieldName, boolean ignoreCase, String... textValue) {
		List<String> values = Arrays.asList(textValue);
		List<String> operatorOptions = optionsWith(ignoreCase);
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(TextOperatorEnum.IN.code());
		critera.setOperatorOptions(operatorOptions);
		critera.setStringValues(values);
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchText(String fieldName, TextOperatorEnum operator, String textValue,
			boolean ignoreCase) {
		List<String> operatorOptions = optionsWith(ignoreCase);
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(operator.code());
		critera.setOperatorOptions(operatorOptions);
		critera.setStringValues(Arrays.asList(textValue));
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchTextIsNull(String fieldName) {
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(TextOperatorEnum.IS_NULL.code());
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchNumber(String fieldName, NumberOperatorEnum operator,
			Integer numberValue) {
		return searchNumber(fieldName, operator, Long.valueOf(numberValue));
	}

	public static List<SearchCriterion> searchNumber(String fieldName, NumberOperatorEnum operator, Long numberValue) {
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(operator.code());
		critera.setIntValues(Arrays.asList(numberValue));
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchDoubles(String fieldName, NumberOperatorEnum operator,
			Double... doubleValue) {
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(operator.code());
		if (doubleValue != null) {
			critera.setDoubleValues(Arrays.asList(doubleValue));
		}
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchDate(String fieldName, NumberOperatorEnum operator, LocalDate dateValue) {
		SearchCriterion critera = new SearchCriterion();
		critera.setFieldName(fieldName);
		critera.setOperator(operator.code());
		if (dateValue != null) {
			String dateStr = dateValue.format(DateTimeFormatter.ISO_LOCAL_DATE);
			critera.setDateValues(Arrays.asList(dateStr));
		}
		return searchBy(critera);
	}

	public static List<SearchCriterion> searchBy(SearchCriterion criterion) {
		List<SearchCriterion> criteria = new ArrayList<>();
		criteria.add(criterion);
		return criteria;
	}

	public static List<String> optionsWith(boolean ignoreCase) {
		List<String> operatorOptions = null;
		if (ignoreCase) {
			operatorOptions = new ArrayList<String>();
			operatorOptions.add("ignoreCase");
		}
		return operatorOptions;
	}

}
