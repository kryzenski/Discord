package com.bayer.pmodi.masterlist.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.DirtiesContext;

import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.SubRegion;

@DataJpaTest(showSql = false)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class CountryRepositoryTest {

	private static final String REGION_NAME = "EMEA2";
	private static final String SUB_REGION_NAME = "EMEA2sub";

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private RegionRepository regionRepository;

	@BeforeEach
	private void init() {
		Region r1 = new Region();
		r1.setSourceKey("R1");
		r1.setName(REGION_NAME);
		regionRepository.save(r1);

		SubRegion sr1 = new SubRegion();
		sr1.setSourceKey("SR1");
		sr1.setName(SUB_REGION_NAME);
		subRegionRepository.save(sr1);

		Region r2 = new Region();
		r2.setSourceKey("R2");
		r2.setName("Dummy");
		r2.setPlaceholder(true);
		regionRepository.save(r2);

		SubRegion sr2 = new SubRegion();
		sr2.setSourceKey("R2");
		sr2.setName("Dummy");
		sr2.setPlaceholder(true);
		subRegionRepository.save(sr2);

		List<Country> countries1 = IntStream.range(0, 10).mapToObj(i -> mockCountry(i + 1, false))
				.collect(Collectors.toList());
		countryRepository.saveAll(countries1);

		List<Country> countries2 = IntStream.range(10, 20).mapToObj(i -> mockCountry(i + 1, false))
				.collect(Collectors.toList());
		countryRepository.saveAll(countries2);

		List<Country> placeholderCountries = IntStream.range(20, 25).mapToObj(i -> mockCountry(i + 1, true))
				.collect(Collectors.toList());
		countryRepository.saveAll(placeholderCountries);
	}

	@Test
	void testGetOne() {
		Country result = countryRepository.getOne(1L);
		assertThat(result).isNotNull();
		assertThat(result.getName()).isNotNull().isEqualTo("Country 1");
		assertThat(result.isPlaceholder()).isFalse();
	}

	@Test
	void testFindAll() {
		Iterable<Country> results = countryRepository.findAll();
		assertThat(results).isNotNull().hasSize(25);
	}

	@Test
	void testFindByName() {
		Country result = countryRepository.findByName("Country 3");
		assertThat(result).isNotNull();
	}

	@Test
	void testFindByName_NoResult() {
		Country result = countryRepository.findByName("XYZ");
		assertThat(result).isNull();
	}

	@Test
	void testFindByIsPlaceholder() {
		Iterable<Country> results = countryRepository.findByIsPlaceholder(true, null);
		assertThat(results).isNotNull().hasSize(5);
	}

	public static Country mockCountry(int i, boolean isPlaceholder) {
		Country c = new Country();
		c.setName("Country " + i);
		c.setSourceKey("C" + i);
		c.setPlaceholder(isPlaceholder);
		return c;
	}

}
