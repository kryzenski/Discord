package com.bayer.pmodi.masterlist.repository;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;

import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.CropGroup;
import com.bayer.pmodi.masterlist.model.CropPlatform;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.SubRegion;

public final class TestUtil {

	private TestUtil() {
		// No instance allowed
	}

	public static Iterable<Product> createProductData(ProductRepository productRepository, int numberOfProducts) {
		List<Product> products = IntStream.range(0, numberOfProducts).mapToObj(i -> {
			Product p = new Product();
			p.setSpecNumber("108" + StringUtils.leftPad(String.valueOf(i + 1), 7, "0"));
			p.setProductLineText("Product " + (i + 1));
			p.setBrandName("Brand Name " + (i + 1));
			return p;
		}).collect(Collectors.toList());
		return productRepository.saveAll(products);
	}

	public static void createCountryData(RegionRepository regionRepository, SubRegionRepository subRegionRepository,
			CountryRepository countryRepository, int numberOfRegions, int numberOfSubRegionsPerRegion,
			int numberOfCountriesPerSubRegion) {
		List<Region> regions = IntStream.range(0, numberOfRegions).mapToObj(i -> {
			Region r = new Region();
			r.setSourceKey("R" + (i + 1));
			r.setName("Region " + (i + 1));
			return r;
		}).collect(Collectors.toList());
		regionRepository.saveAll(regions);

		for (Region region : regions) {
			List<SubRegion> subRegions = IntStream.range(0, numberOfSubRegionsPerRegion).mapToObj(i -> {
				SubRegion sr = new SubRegion();
				sr.setSourceKey("SR" + region.getId() + "-" + (i + 1));
				sr.setName("Sub-Region " + (i + 1) + " of " + region.getName());
				return sr;
			}).collect(Collectors.toList());
			subRegionRepository.saveAll(subRegions);
			for (SubRegion subRegion : subRegions) {
				List<Country> countries = IntStream.range(0, numberOfCountriesPerSubRegion).mapToObj(i -> {
					Country c = new Country();
					c.setSourceKey("C" + subRegion.getId() + "-" + (i + 1));
					c.setName("Country " + (i + 1) + " of " + subRegion.getName());
					return c;
				}).collect(Collectors.toList());
				countryRepository.saveAll(countries);
			}
		}
	}

	public static void createCropData(CropPlatformRepository cropPlatformRepository,
			CropGroupRepository cropGroupRepository, CropRepository cropRepository, int numberOfCropPlatforms,
			int numberOfCropGroupsPerCropPlatform, int numberOfCropsPerCropGroup) {
		List<CropPlatform> cropPlatforms = IntStream.range(0, numberOfCropPlatforms).mapToObj(i -> {
			CropPlatform cp = new CropPlatform();
			cp.setName("CropPlatform " + (i + 1));
			cp.setSourceKey("CP" + (i + 1));
			return cp;
		}).collect(Collectors.toList());
		cropPlatformRepository.saveAll(cropPlatforms);

		for (CropPlatform cropPlatform : cropPlatforms) {
			List<CropGroup> cropGroups = IntStream.range(0, numberOfCropGroupsPerCropPlatform).mapToObj(i -> {
				CropGroup cg = new CropGroup();
				cg.setName("CropGroup " + (i + 1) + " of " + cropPlatform.getName());
				cg.setSourceKey("CG" + (i + 1));
				cg.setCropPlatform(cropPlatform);
				return cg;
			}).collect(Collectors.toList());
			cropGroupRepository.saveAll(cropGroups);
			for (CropGroup cropGroup : cropGroups) {
				List<Crop> crops = IntStream.range(0, numberOfCropsPerCropGroup).mapToObj(i -> {
					Crop c = new Crop();
					c.setName("Crop " + (i + 1) + " of " + cropGroup.getName());
					c.setSourceKey("C" + (i + 1));
					c.setCropGroup(cropGroup);
					return c;
				}).collect(Collectors.toList());
				cropRepository.saveAll(crops);
			}
		}
	}

	public static Iterable<String> createRegprimeCountryData(int numberOfEntities) {
		return IntStream.range(0, numberOfEntities).mapToObj(i -> {
			return "RCOU" + (i + 1);
		}).collect(Collectors.toList());
	}

	public static Iterable<String> createRegprimeCropData(int numberOfEntities) {
		return IntStream.range(0, numberOfEntities).mapToObj(i -> {
			return "RCRO" + (i + 1);
		}).collect(Collectors.toList());
	}

	public static Iterable<String> createRegprimePltData(int numberOfEntities) {
		return IntStream.range(0, numberOfEntities).mapToObj(i -> {
			return "RPLT" + (i + 1);
		}).collect(Collectors.toList());
	}

}
