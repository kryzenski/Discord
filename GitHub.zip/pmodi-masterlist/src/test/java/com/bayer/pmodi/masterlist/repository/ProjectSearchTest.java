package com.bayer.pmodi.masterlist.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.test.annotation.DirtiesContext;

import com.bayer.pmodi.masterlist.model.Country;
import com.bayer.pmodi.masterlist.model.Crop;
import com.bayer.pmodi.masterlist.model.DomainUtil;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Project;
import com.bayer.pmodi.masterlist.model.Region;
import com.bayer.pmodi.masterlist.model.Segment;
import com.bayer.pmodi.masterlist.model.SubRegion;
import com.bayer.pmodi.masterlist.model.enums.LocationTypeEnum;
import com.bayer.pmodi.masterlist.model.enums.PrioritizationTypeEnum;
import com.bayer.pmodi.masterlist.search.NumberOperatorEnum;
import com.bayer.pmodi.masterlist.search.SearchCriterion;

@DataJpaTest(showSql = false)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ProjectSearchTest {

	private static final double SCORE = 0.890123;

	private static final int TOTAL_PROJECTS = 100;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private SubRegionRepository subRegionRepository;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CropPlatformRepository cropPlatformRepository;

	@Autowired
	private CropGroupRepository cropGroupRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private SegmentRepository segmentRepository;

	@BeforeEach
	private void init() {
		TestUtil.createCountryData(regionRepository, subRegionRepository, countryRepository, 1, 1, 2);
		TestUtil.createCropData(cropPlatformRepository, cropGroupRepository, cropRepository, 1, 1, 1);
		TestUtil.createProductData(productRepository, 2);

		Country country = countryRepository.getOne(1l);
		Country alternateCountry = countryRepository.getOne(2l);
		SubRegion subRegion = subRegionRepository.getOne(1l);
		Region region = regionRepository.getOne(1l);
		Crop crop = cropRepository.getOne(1l);
		Product p1 = productRepository.getOne(1l);
		Product p2 = productRepository.getOne(2l);

		List<Project> projects = new ArrayList<Project>(TOTAL_PROJECTS);
		List<Segment> segments = new ArrayList<Segment>(4);
		for (int i = 0; i < TOTAL_PROJECTS; i++) {
			Project p = new Project();
			p.setNewportProjectId(String.valueOf(20000 + i));
			p.setNewportAreaId("A");
			p.setNewportNewPortNumber("0000" + i);
			p.setPreciseNewportId(DomainUtil.createPreciseNewportId(p.getNewportAreaId(), p.getNewportNewPortNumber()));
			p.setNewportName("Project " + i);
			p.setProduct(i % 2 == 0 ? p1 : p2);
			if (i < 10) {
				p.setNewportFreeText("project free name");
			} else if (i < 20) {
				p.setNewportFreeText("Project Free Name");
			} else {
				p.setNewportFreeText("Project Free Name " + i);
			}
			if (i < 5) {
				p.setPrioritizationRmk("prio comment");
			} else if (i < 15) {
				p.setPrioritizationRmk("Prio Comment");
			} else {
				p.setPrioritizationRmk("Prio Comment " + i);
			}
			if (i < 30) {
				p.setNewportStatus("Launched");
			} else if (i < 40) {
				p.setNewportStatus("Draft");
			} else {
				p.setNewportStatus("In Progress");
			}
			p.setNewportGlobalNpvYear10(Double.valueOf(((i + 500) / 10) + ".23"));
			p.setNewportGlobalPeakNetSales(Double.valueOf(Math.round(((i + 560) / 4)) + ".23"));
			p.setNewportLaunchYear(String.valueOf(Integer.valueOf(((i + 20200) / 10))));
			if (i == 0 || i == 2) {
				p.setDevelopmentFunctions("developmentFunctions");
				p.setSustainabilityAssessment("sustainabilityAssessment");
				p.setFsPtrsScoreRmk("fsPtrsScoreRmk");
				p.setFsPtrsScore(SCORE);
				p.setFtPtrsScoreRmk("ftPtrsScoreRmk");
				p.setFtPtrsScore(SCORE);
				p.setGlobalPortfolioGuidance("globalPortfolioGuidance");
				p.setGlobalRegGuidance("globalRegGuidance");
				p.setSpecificProjectFramework("specificProjectFramework");
				p.setIntelectualPropertyAssessment("intelectualPropertyAssessment");
				p.setLabelForSafeUse("labelForSafeUse");
				p.setThirdPartyAiRegCheck("thirdPartyAiRegCheck");
				p.setLumosGlobalProjectId("lumosGlobalProjectId");
				p.setLumosLocalProjectId("lumosLocalProjectId");
				p.setNewportArea("newportArea");
				p.setNewportBusinessGroup("newportBusinessGroup");
				p.setNewportBusinessGroupId("ng");
				p.setNewportBusinessObjectiveNumber("newportBus");
				p.setNewportBusinessSegment("newportBusinessSegme");
				p.setNewportBusinessSegmentId("nbs");
				p.setNewportBusinessUnit("newportBusinessUnit");
				p.setNewportBusinessUnitId("nu");
				p.setNewportCategory("Test1");
				p.setNewportCategoryId("pc");
				p.setNewportConcentrationUnit("newportConcentrationUnit");
				p.setNewportConcentrationUnitId("n");
				p.setNewportCurrency("cur");
				p.setNewportFormulationType("newportFormulationType");
				p.setNewportFormulationTypeId("nft");
				p.setNewportFramework("newportFramework");
				p.setNewportFrameworkId("nf");
				p.setNewportFunding("newportFunding");
				p.setNewportFundingId("f");
				p.setNewportIndication("newportIndication");
				p.setNewportIndicationId("ni");
				p.setNewportInitiator("newportInitiator");
				p.setNewportInitiatorId("newportInitiatorId");
				p.setNewportIsGbo("newportIsGbo");
				p.setNewportIsGboId("g");
				p.setNewportJustification("newportJustification");
				p.setNewportLastModified("20201231");
				p.setNewportLastModifiedUser("newportLastModifiedUser");
				p.setNewportLastModifiedUserCwid("newportLastModifiedUserCw");
				p.setNewportLaunchYear("2020");
				p.setNewportLeadAi("LAI");
				p.setNewportObjective("newportObjective");
				p.setNewportOrigin("newportOri");
				p.setNewportOriginId("o");
				p.setNewportSpg("newportSpg");
				p.setNewportPlt("newportPlt");
				p.setNewportPrioritizationCategory("B");
				p.setNewportPrioritizationCommentB("newportPrioritizationCommentB");
				p.setNewportPrioritizationRankingB("prb");
				p.setNewportProductHierarchy("newportProductHier");
				p.setNewportProductProfile("newportProductProfile");
				p.setNewportProjectCreated("20201231");
				p.setNewportPtrs("ptr");
				p.setNewportSuccessFactors("newportSuccessFactors");
				// p.setOverallPtrsScore(1234.5678); // calculated
				p.setPrioritizationGovernance(LocationTypeEnum.REGIONAL);
				p.setPrioritizationType(PrioritizationTypeEnum.A);
				p.setPtrsFollowUp(true);
				p.setRsDietaryPtrsScore(SCORE);
				p.setRsDietaryPtrsScoreRmk("rsDietaryPtrsScoreRmk");
				p.setRsEnsaPtrsScore(SCORE);
				p.setRsEnsaPtrsScoreRmk("rsEnsaPtrsScoreRmk");
				p.setRsGovernance("rsGovernance");
				p.setRsPtrsScoreRmk("rsPtrsScoreRmk");
				p.setRsOperatorPtrsScore(SCORE);
				p.setRsOperatorPtrsScoreRmk("rsOperatorPtrsScoreRmk");
				// p.setRsPtrsScore(89.0123); // calculated
				p.setRsRegAffairsScore(SCORE);
				p.setRsRegAffairsScoreRmk("rsRegAffairsScoreRmk");
				p.setStrategicFitRmk("strategicFitRmk");

				p.setNewportGlobalAggregatedVolume(1234.5678);
				p.setNewportGlobalExpectedNpvYear10(1234.5678);
				p.setNewportGlobalFutureProjectCost(1234.5678);
				p.setNewportGlobalIgmPeakYear(1234.5678);
				p.setNewportGlobalIgmYear4(1234.5678);
				p.setNewportGlobalIncrementalIgmYear4(1234.5678);
				p.setNewportGlobalIncrementalNetSales(1234.5678);
				p.setNewportGlobalNetSales(1234.5678);
				p.setNewportGlobalPeakNetSalesIncremental(1234.5678);
				p.setNewportGlobalPeakYearIgmIncremental(1234.5678);
				p.setNewportGlobalPercIgmYear4(1234.5678);
				p.setNewportGlobalProductivityIndex(1234.5678);
				p.setNewportGlobalSalesVolume(1234.5678);
				p.setNewportLocalExpectedNpvYear10(1234.5678);
				p.setNewportLocalNpvYear10(1234.5678);
				p.setNewportLocalPeakNetSales(1234.5678);
				p.setNewportLocalPeakNetSalesIncremental(1234.5678);
				p.setNewportLocalPeakYearIgm(1234.5678);
				p.setNewportLocalPeakYearIgmIncremental(1234.5678);
				p.setNewportLocalPeakYearIgmPercNetSales(1234.5678);
				p.setFsPtrsScoreModifiedBy("Test user");
				p.setFsPtrsScoreModifiedDate("13/05/2022");
				p.setFsPtrsScoreUpdatedBy("Test user");
				p.setFsPtrsScoreUpdatedDate("13/05/2022");
				p.setFtPtrsScoreModifiedBy("test user1");
				p.setFtPtrsScoreModifiedDate("14/05/2022");
				p.setRsEnsaPtrsScoreModifiedBy("test user2");
				p.setRsEnsaPtrsScoreModifiedDate("12/05/2022");
				p.setRsOperatorPtrsScoreModifiedBy("test user3");
				p.setRsOperatorPtrsScoreModifiedDate("15/03/2022");
				p.setRsDietaryPtrsScoreModifiedBy("test user4");
				p.setRsDietaryPtrsScoreModifiedDate("10/05/2022");
				p.setRsRegAffairsScoreModifiedBy("test user5");
				p.setRsRegAffairsScoreModifiedDate("16/05/2022");
				p.setRsPtrsScoreRmkModifiedBy("test user");
				p.setRsPtrsScoreRmkModifiedDate("07/06/2022");
				p.setIsSegmentPresent("Absent");

				for (int j = 0; j < 2; j++) {
					Segment s = new Segment();
					s.setProject(p);
					s.setCountry(country);
					s.setSubRegion(subRegion);
					s.setRegion(region);
					s.setCrop(crop);
					s.setTarget("Target X" + j);
					s.setNewportDiseasesPestsWeedsId("X" + j);
					s.setRsRegProductPtrsScore(SCORE);
					s.setRsRegProductPtrsScoreRmk("rsRegProductScoreRmk");
					s.setRsRegDietaryPtrsScore(SCORE);
					s.setRsRegDietaryPtrsScoreRmk("rsRegDietaryScoreRmk");
					s.setRsOccupationalResidentialExposurePtrsScore(SCORE);
					s.setRsOccupationalResidentialExposurePtrsScoreRmk("rsOccupationalResidentialExposurePtrsScoreRmk");
					s.setRsToxicologyPtrsScore(SCORE);
					s.setRsToxicologyPtrsScoreRmk("rsToxicologyPtrsScoreRmk");
					s.setRsEcotoxPtrsScore(SCORE);
					s.setRsEcotoxPtrsScoreRmk("rsEcotoxPtrsScoreRmk");
					s.setRsEfatePtrsScore(SCORE);
					s.setRsEfatePtrsScoreRmk("rsEfatePtrsScoreRmk");
					s.setRsLocalRestrictionOthersPtrsScore(SCORE);
					s.setRsLocalRestrictionOthersPtrsScoreRmk("rsLocalRestrictionOthersPtrsScoreRmk");
					s.setRsLocalRestrictionPolicyPtrsScore(SCORE);
					s.setRsLocalRestrictionPolicyPtrsScoreRmk("rsLocalRestrictionPolicyPtrsScoreRmk");
					s.setRsRegistrationPtrsScore(SCORE);
					s.setRsRegistrationPtrsScoreRmk("rsRegistrationPtrsScoreRmk");
					s.setRsForeignInfluencePtrsScore(SCORE);
					s.setRsForeignInfluencePtrsScoreRmk("rsForeignInfluencePtrsScoreRmk");

					segments.add(s);
					// p.addSegment(s);
				}

			} else if (i == 7) {
				p.setPrioritizationGovernance(LocationTypeEnum.GLOBAL);
				p.setNewportInitiator("projectManager");
				Segment s = new Segment();
				s.setProject(p);
				s.setCountry(alternateCountry);
				s.setSubRegion(subRegion);
				s.setRegion(region);
				s.setCrop(crop);
				s.setTarget("Target XYZ 77");
				s.setRsRegProductPtrsScore(SCORE);
				s.setRsRegProductPtrsScoreRmk("rsRegProductScoreRmk");
				s.setRsRegDietaryPtrsScore(SCORE);
				s.setRsRegDietaryPtrsScoreRmk("rsRegDietaryScoreRmk");
				s.setRsOccupationalResidentialExposurePtrsScore(SCORE);
				s.setRsOccupationalResidentialExposurePtrsScoreRmk("rsOccupationalResidentialExposurePtrsScoreRmk");
				s.setRsToxicologyPtrsScore(SCORE);
				s.setRsToxicologyPtrsScoreRmk("rsToxicologyPtrsScoreRmk");
				s.setRsEcotoxPtrsScore(SCORE);
				s.setRsEcotoxPtrsScoreRmk("rsEcotoxPtrsScoreRmk");
				s.setRsEfatePtrsScore(SCORE);
				s.setRsEfatePtrsScoreRmk("rsEfatePtrsScoreRmk");
				s.setRsLocalRestrictionOthersPtrsScore(SCORE);
				s.setRsLocalRestrictionOthersPtrsScoreRmk("rsLocalRestrictionOthersPtrsScoreRmk");
				s.setRsLocalRestrictionPolicyPtrsScore(SCORE);
				s.setRsLocalRestrictionPolicyPtrsScoreRmk("rsLocalRestrictionPolicyPtrsScoreRmk");
				s.setRsRegistrationPtrsScore(SCORE);
				s.setRsRegistrationPtrsScoreRmk("rsRegistrationPtrsScoreRmk");
				s.setRsForeignInfluencePtrsScore(SCORE);
				s.setRsForeignInfluencePtrsScoreRmk("rsForeignInfluencePtrsScoreRmk");
				s.setNewportDiseasesPestsWeedsId("XYZ 77");
				segments.add(s);
			} else if (i < 10) {
				p.setPrioritizationGovernance(LocationTypeEnum.GLOBAL);
				p.setNewportInitiator("projectManager");
			}
			projects.add(p);
		}
		projectRepository.saveAll(projects);

		segmentRepository.saveAll(segments);
	}

	@Test
	void testSearchWithoutCriteriaAndWithoutPageRequest() {
		Page<Project> results = projectRepository.search(null, null);
		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS);
	}

	@Test
	void testSearchWithNullValueThrowsException() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportStatus", null, false);
			projectRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage()).contains("value may not be null");
	}

	@Test
	void testSearchTextWithIsNull() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIsNull("newportInitiator");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS - 10);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS - 10);
	}

	@Test
	void testSearchTextWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "Project Free Name");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

	@Test
	void testSearchTextWithEqualsAndIgnoreCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "Project Free Name", true);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(20);
		assertThat(results.getTotalElements()).isEqualTo(20);
	}

	@Test
	void testSearchTextWithContains() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextContains("newportFreeText", "Project Free Name");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(90);
		assertThat(results.getTotalElements()).isEqualTo(90);
	}

	@Test
	void testSearchTextWithContainsAndIgnoreCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextContains("newportFreeText", "Project Free Name",
				true);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS);
	}

	@Test
	void testSearchTextWithIn() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("newportFreeText", "Project free nAme 23",
				"Project Free Name 26", "Project Free Name 27", "project free name");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(12);
		assertThat(results.getTotalElements()).isEqualTo(12);
	}

	@Test
	void testSearchTextWithInAndIgnoreCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("newportFreeText", true, "ProJEct Free NamE 23",
				"project free NAMe 46", "Project Free Name 67", "project free name ", "free name");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(3);
		assertThat(results.getTotalElements()).isEqualTo(3);
	}

	@Test
	void testSearchTextWithEqualsAndTwoMatchingCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "Project Free Name");
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "Prio Comment"));

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(5);
		assertThat(results.getTotalElements()).isEqualTo(5);
	}

	@Test
	void testSearchTextWithEqualsAndTwoExcludingCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "Project Free Name");
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "prio comment"));

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(0);
		assertThat(results.getTotalElements()).isEqualTo(0);
	}

	@Test
	void testSearchTextWithEqualsAndTwoExcludingCriteriaButWithIgnoreCaseThenMatching() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "project free name");
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "prio comment", true));

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

	@Test
	void testSearchTextWithEqualsWhereUnknownPropertyThrowsException() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("dummyProperty", "x", false);
			projectRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage().toLowerCase()).contains("unable to locate attribute");
	}

	@Test
	void testSearchTextWithEqualsWhereWrongDataTypeThrowsException() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportGlobalProductivityIndex", "1.0",
					false);
			projectRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage().toLowerCase()).contains("search value missing!");
	}

	@Test
	void testSearchEnumWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportStatus", "In Progress", false);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(60);
		assertThat(results.getTotalElements()).isEqualTo(60);
	}

	@Test
	void testSearchEnumWithEqualsIgnoreCaseOptionIgnored() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportStatus", "Draft", true);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

//	@Test
//	void testSearchEnumWithEqualsWhereWrongDataTypeThrowsException() {
//		Exception thrown = assertThrows(Exception.class, () -> {
//			List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportStatus", "drraft", false);
//			projectRepository.search(criteria, null);
//		}, "Expected data type exception not thrown");
//		assertThat(thrown.getMessage()).contains(" does not exist in domain");
//	}

	@Test
	void testSearchEnumWithIn() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("newportStatus", "Draft", "Launched", "Cancelled");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(40);
		assertThat(results.getTotalElements()).isEqualTo(40);
	}

	@Test
	void testSearchEnumWithIsNull() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIsNull("newportCurrency");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS - 2);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS - 2);
	}

	@Test
	void testSearchDoubleWithEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.EQUALS, 57.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

	@Test
	void testSearchDoubleWithEqualsAndTwoCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.EQUALS, 51.23);
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakNetSales", NumberOperatorEnum.EQUALS, 142.23));

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

	@Test
	void testSearchDoubleWithNotEquals() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalPeakNetSales",
				NumberOperatorEnum.NOT_EQUALS, 142.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS - 4);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS - 4);
	}

	@Test
	void testSearchDoubleWithLessOrEqual() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.LESS_OR_EQUAL, 51.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(20);
		assertThat(results.getTotalElements()).isEqualTo(20);
	}

	@Test
	void testSearchDoubleWithLess() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10", NumberOperatorEnum.LESS,
				51.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

	@Test
	void testSearchDoubleWithGreaterOrEqual() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.GREATER_OR_EQUAL, 51.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(90);
		assertThat(results.getTotalElements()).isEqualTo(90);
	}

	@Test
	void testSearchDoubleWithGreater() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.GREATER, 51.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(80);
		assertThat(results.getTotalElements()).isEqualTo(80);
	}

	@Test
	void testSearchDoubleWithBetween() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
				NumberOperatorEnum.BETWEEN, 51.23, 53.23);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(30);
		assertThat(results.getTotalElements()).isEqualTo(30);
	}

	@Test
	void testSearchDoubleWithBetweenWhereWrongValueSizeThrowsException() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10",
					NumberOperatorEnum.BETWEEN, 51.23);
			projectRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage().toLowerCase()).contains("between operator needs two values");
	}

	@Test
	void testSearchDoubleWithIn() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("newportGlobalNpvYear10", NumberOperatorEnum.IN,
				51.23, 53.23, 55.23, 56.23, 56.24, 56.22, 52.29999999);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(40);
		assertThat(results.getTotalElements()).isEqualTo(40);
	}

	@Test
	void testSearchDoubleWithIsNull() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("fsPtrsScore", NumberOperatorEnum.IS_NULL,
				(Double[]) null);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS - 2);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS - 2);
	}

	@Test
	void testSearchDoubleWithIsNullAndIgnoredValues() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("fsPtrsScore", NumberOperatorEnum.IS_NULL, 1.23,
				5.67);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS - 2);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS - 2);
	}

	@Test
	void testSearchDoubleWithIsNotNull() {
		List<SearchCriterion> criteria = SearchTestUtil.searchDoubles("fsPtrsScore", NumberOperatorEnum.IS_NOT_NULL,
				(Double[]) null);

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

//	@Test
//	void testSearchIntWithEquals() {
//		List<SearchCriterion> criteria = SearchTestUtil.searchNumber("newportLaunchYear", NumberOperatorEnum.EQUALS,
//				2020);
//
//		Page<Project> results = projectRepository.search(criteria, null);
//
//		assertThat(results).isNotNull().hasSize(10);
//		assertThat(results.getTotalElements()).isEqualTo(10);
//	}

//	@Test
//	void testSearchIntWithNotEquals() {
//		List<SearchCriterion> criteria = SearchTestUtil.searchNumber("newportLaunchYear", NumberOperatorEnum.NOT_EQUALS,
//				2022);
//
//		Page<Project> results = projectRepository.search(criteria, null);
//
//		assertThat(results).isNotNull().hasSize(90);
//		assertThat(results.getTotalElements()).isEqualTo(90);
//	}

	@Test
	void testSearchSimpleEnumWithEqual() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("prioritizationGovernance",
				LocationTypeEnum.GLOBAL.name());

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(8);
		assertThat(results.getTotalElements()).isEqualTo(8);
	}

	@Test
	void testSearchSimpleEnumWithIn() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("prioritizationGovernance",
				LocationTypeEnum.REGIONAL.name(), LocationTypeEnum.GLOBAL.name());

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(10);
		assertThat(results.getTotalElements()).isEqualTo(10);
	}

	@Test
	void testSearchTextWithEqualsOnParentProduct() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("product.productLineText", "Product 1");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(50);
		assertThat(results.getTotalElements()).isEqualTo(50);
	}

	@Test
	void testSearchBooleanWithStringTrue() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("ptrsFollowUp", "true");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

	@Test
	void testSearchBooleanWithStringTrueCamelCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("ptrsFollowUp", "TrUe");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

	@Test
	void testSearchBooleanWithStringYesCamelCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("ptrsFollowUp", "YeS");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

	@Test
	void testSearchBooleanWithInWithCamelCase() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("ptrsFollowUp", "tRuE", "nO");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(TOTAL_PROJECTS);
		assertThat(results.getTotalElements()).isEqualTo(TOTAL_PROJECTS);
	}

	@Test
	void testSearchBooleanWithInWithIllegalFalseTerm() {
		Exception thrown = assertThrows(Exception.class, () -> {
			List<SearchCriterion> criteria = SearchTestUtil.searchTextIn("ptrsFollowUp", "tRuE", "nein");
			projectRepository.search(criteria, null);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage()).contains("Unsupported boolean text value");
	}

	@Test
	void testSearchAllNonUniqueProperties() {
		List<SearchCriterion> criteria = createNonUniqueSearchCriteria();

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(results.getSize());
		assertThat(results.getTotalElements()).isEqualTo(0);
	}

	@Test
	void testSearchAllProperties() {
		List<SearchCriterion> criteria = createNonUniqueSearchCriteria();
		criteria.addAll(SearchTestUtil.searchTextEqual("newportName", "Project 2"));
		criteria.addAll(SearchTestUtil.searchTextEqual("preciseNewportId", "A-2"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportAreaId", "A"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportNewPortNumber", "00002"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportProjectId", "20002"));

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(results.getSize());
		assertThat(results.getTotalElements()).isEqualTo(0);
	}

	private List<SearchCriterion> createNonUniqueSearchCriteria() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("newportFreeText", "project free name");

		criteria.addAll(SearchTestUtil.searchTextEqual("product.productLineText", "Product 1"));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationRmk", "prio comment"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportStatus", "Launched", false));
		criteria.addAll(SearchTestUtil.searchTextEqual("developmentFunctions", "developmentFunctions"));
		criteria.addAll(SearchTestUtil.searchTextEqual("sustainabilityAssessment", "sustainabilityAssessment"));

		criteria.addAll(SearchTestUtil.searchTextEqual("fsPtrsScoreRmk", "fsPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("fsPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("ftPtrsScoreRmk", "ftPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("ftPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("globalPortfolioGuidance", "globalPortfolioGuidance"));
		criteria.addAll(SearchTestUtil.searchTextEqual("globalRegGuidance", "globalRegGuidance"));
		criteria.addAll(SearchTestUtil.searchTextEqual("specificProjectFramework", "specificProjectFramework"));
		criteria.addAll(
				SearchTestUtil.searchTextEqual("intelectualPropertyAssessment", "intelectualPropertyAssessment"));
		criteria.addAll(SearchTestUtil.searchTextEqual("labelForSafeUse", "labelForSafeUse"));
		criteria.addAll(SearchTestUtil.searchTextEqual("thirdPartyAiRegCheck", "thirdPartyAiRegCheck"));
		criteria.addAll(SearchTestUtil.searchTextEqual("lumosGlobalProjectId", "lumosGlobalProjectId"));
		criteria.addAll(SearchTestUtil.searchTextEqual("lumosLocalProjectId", "lumosLocalProjectId"));
		// Attention: the following property is calculated and rounded
		criteria.addAll(SearchTestUtil.searchDoubles("overallPtrsScore", NumberOperatorEnum.EQUALS, 0.70526133));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationGovernance", LocationTypeEnum.REGIONAL.name()));
		criteria.addAll(SearchTestUtil.searchTextEqual("prioritizationType", PrioritizationTypeEnum.A.name()));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportCategory", "Test1", false));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportInitiator", "newportInitiator"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsDietaryPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsDietaryPtrsScoreRmk", "rsDietaryPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsEnsaPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsEnsaPtrsScoreRmk", "rsEnsaPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsGovernance", "rsGovernance"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsPtrsScoreRmk", "rsPtrsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchDoubles("rsOperatorPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsOperatorPtrsScoreRmk", "rsOperatorPtrsScoreRmk"));
		// Attention: the following property is calculated
		criteria.addAll(SearchTestUtil.searchDoubles("rsPtrsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchDoubles("rsRegAffairsScore", NumberOperatorEnum.EQUALS, SCORE));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegAffairsScoreRmk", "rsRegAffairsScoreRmk"));
		criteria.addAll(SearchTestUtil.searchTextEqual("strategicFitRmk", "strategicFitRmk"));

		criteria.addAll(SearchTestUtil.searchTextEqual("newportArea", "newportArea"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessGroup", "newportBusinessGroup"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessGroupId", "ng"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessObjectiveNumber", "newportBus"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessSegment", "newportBusinessSegme"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessSegmentId", "nbs"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessUnit", "newportBusinessUnit"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportBusinessUnitId", "nu"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportCategoryId", "pc"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportConcentrationUnit", "newportConcentrationUnit"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportConcentrationUnitId", "n"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportCurrency", "cur"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFormulationType", "newportFormulationType"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFormulationTypeId", "nft"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFramework", "newportFramework"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFrameworkId", "nf"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFunding", "newportFunding"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportFundingId", "f"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportIndication", "newportIndication"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportIndicationId", "ni"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportInitiatorId", "newportInitiatorId"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportIsGbo", "newportIsGbo"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportIsGboId", "g"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLastModifiedUserCwid", "newportLastModifiedUserCw"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLastModifiedUser", "newportLastModifiedUser"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLastModified", "20201231"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLaunchYear", "2020"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportLeadAi", "LAI"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportOrigin", "newportOri"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportOriginId", "o"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportSpg", "newportSpg"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportPlt", "newportPlt"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportPrioritizationCategory", "B"));
		criteria.addAll(
				SearchTestUtil.searchTextEqual("newportPrioritizationCommentB", "newportPrioritizationCommentB"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportPrioritizationRankingB", "prb"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportProductHierarchy", "newportProductHier"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportProjectCreated", "20201231"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportPtrs", "ptr"));

		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalNpvYear10", NumberOperatorEnum.EQUALS, 50.23));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakNetSales", NumberOperatorEnum.EQUALS, 140.23));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalAggregatedVolume", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalExpectedNpvYear10", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalFutureProjectCost", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalIgmPeakYear", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalIgmYear4", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalIncrementalIgmYear4", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalIncrementalNetSales", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalNetSales", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakNetSalesIncremental", NumberOperatorEnum.EQUALS,
				1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalPeakYearIgmIncremental", NumberOperatorEnum.EQUALS,
				1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalPercIgmYear4", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportGlobalProductivityIndex", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportGlobalSalesVolume", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(
				SearchTestUtil.searchDoubles("newportLocalExpectedNpvYear10", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalNpvYear10", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakNetSales", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakNetSalesIncremental", NumberOperatorEnum.EQUALS,
				1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgm", NumberOperatorEnum.EQUALS, 1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgmIncremental", NumberOperatorEnum.EQUALS,
				1234.5678));
		criteria.addAll(SearchTestUtil.searchDoubles("newportLocalPeakYearIgmPercNetSales", NumberOperatorEnum.EQUALS,
				1234.5678));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportObjective", "newportObjective"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportSuccessFactors", "newportSuccessFactors"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportProductProfile", "newportProductProfile"));
		criteria.addAll(SearchTestUtil.searchTextEqual("newportJustification", "newportJustification"));

		criteria.addAll(SearchTestUtil.searchTextEqual("ptrsFollowUp", "true"));


	/*	criteria.addAll(SearchTestUtil.searchTextEqual("fsPtrsScoreModifiedBy", "Test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("fsPtrsScoreModifiedDate", "13/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("ftPtrsScoreModifiedBy", "test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("ftPtrsScoreModifiedDate", "14/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsEnsaPtrsScoreModifiedBy", "test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsEnsaPtrsScoreModifiedDate", "12/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsOperatorPtrsScoreModifiedBy", "test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsOperatorPtrsScoreModifiedDate", "15/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsDietaryPtrsScoreModifiedBy", "test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsDietaryPtrsScoreModifiedDate", "10/05/2022"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegAffairsScoreModifiedBy", "test user"));
		criteria.addAll(SearchTestUtil.searchTextEqual("rsRegAffairsScoreModifiedDate", "16/05/2022"));*/


		return criteria;
	}

	@Test
	void testSearchTextWithEqualsOnChildSegment() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("segments.target", "Target X1");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(2);
		assertThat(results.getTotalElements()).isEqualTo(2);
	}

	@Test
	void testSearchTextWithEqualsOnChildOfChildSegment() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("segments.crop.sourceKey", "C1");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(3);
		assertThat(results.getTotalElements()).isEqualTo(3);
	}

	@Test
	void testSearchTextWithEqualsOnChildOfChildOfChildOfChildSegment() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("segments.crop.cropGroup.cropPlatform.name",
				"CropPlatform 1");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(3);
		assertThat(results.getTotalElements()).isEqualTo(3);
	}

	@Test
	void testSearchTextWithEqualsOnCountryName() {
		List<SearchCriterion> criteria = SearchTestUtil.searchTextEqual("segments.country.name",
				"Country 2 of Sub-Region 1 of Region 1");

		Page<Project> results = projectRepository.search(criteria, null);

		assertThat(results).isNotNull().hasSize(1);
		assertThat(results.getTotalElements()).isEqualTo(1);
	}
}
