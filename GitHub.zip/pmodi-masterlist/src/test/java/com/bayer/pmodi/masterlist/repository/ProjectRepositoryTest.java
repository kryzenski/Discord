package com.bayer.pmodi.masterlist.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.DirtiesContext;

import com.bayer.pmodi.masterlist.model.DomainUtil;
import com.bayer.pmodi.masterlist.model.Product;
import com.bayer.pmodi.masterlist.model.Project;

@DataJpaTest(showSql = false)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ProjectRepositoryTest {

	private static final int TOTAL_PROJECTS = 11;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@BeforeEach
	private void init() {
		TestUtil.createProductData(productRepository, 2);
		Product p1 = productRepository.getOne(1l);
		Product p2 = productRepository.getOne(2l);

		List<Project> projects = new ArrayList<Project>(TOTAL_PROJECTS);
		for (int i = 0; i < TOTAL_PROJECTS; i++) {
			Project p = new Project();
			p.setNewportProjectId(String.valueOf(20000 + i));
			p.setNewportAreaId("A");
			p.setNewportNewPortNumber("0000" + i);
			p.setPreciseNewportId(DomainUtil.createPreciseNewportId(p.getNewportAreaId(), p.getNewportNewPortNumber()));
			p.setNewportName("Project " + (i + 1));
			p.setProduct(i % 2 == 0 ? p1 : p2);
			p.setPreciseNewportId("A" + "-" + i);
			p.setNewportInitiator("ProjectManager " + (i % 2 == 0 ? "ABC" : "AAA"));
			projects.add(p);
		}
		projectRepository.saveAll(projects);
	}

	@Test
	void testGetOne() {
		Project result = projectRepository.getOne(1L);
		assertThat(result).isNotNull();
		assertThat(result.getProduct()).isNotNull();
		assertThat(result.getProduct().getProductLineText()).isEqualTo("Product 1");
		assertThat(result.getNewportInitiator()).isNotNull().isEqualTo("ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputNull() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", null, null, false);
		assertThat(results).isNotNull().hasSize(2).containsExactly("ProjectManager AAA", "ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputEmpty() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "", null, false);
		assertThat(results).isNotNull().hasSize(2).containsExactly("ProjectManager AAA", "ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerMissingProperty() {
		Exception thrown = assertThrows(Exception.class, () -> {
			projectRepository.findDistinctValuesStartingWith(null, null, null, false);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage()).containsIgnoringCase("missing column name");
	}

	@Test
	void testFindDistinctValuesProjectManagerIllegalProperty() {
		final String columnName = "proManger";
		Exception thrown = assertThrows(Exception.class, () -> {
			projectRepository.findDistinctValuesStartingWith(columnName, null, null, false);
		}, "Expected data type exception not thrown");
		assertThat(thrown.getMessage()).containsIgnoringCase("unable to locate attribute");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputGeneral() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectManager A",
				null, false);
		assertThat(results).isNotNull().hasSize(2).containsExactly("ProjectManager AAA", "ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputRestricting() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectManager AB",
				null, false);
		assertThat(results).isNotNull().hasSize(1).containsExactly("ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputTooRestricting() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectManager X",
				null, false);
		assertThat(results).isNotNull().isEmpty();
	}

	@Test
	void testFindDistinctValuesProjectManagerInputCaseSensitive() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectManager AB",
				null, true);
		assertThat(results).isNotNull().hasSize(1).containsExactly("ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputCaseSensitivePossibleMatchExcluded() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectMANager Ab",
				null, true);
		assertThat(results).isNotNull().isEmpty();
	}

	@Test
	void testFindDistinctValuesProjectManagerInputCaseInSensitive() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "projectmAnaGer aB",
				null, false);
		assertThat(results).isNotNull().hasSize(1).containsExactly("ProjectManager ABC");
	}

	@Test
	void testFindDistinctValuesProjectManagerInputWithLimit() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("newportInitiator", "ProjectManager A",
				1, false);
		assertThat(results).isNotNull().hasSize(1).containsExactly("ProjectManager AAA");
	}

	@Test
	void testFindDistinctValuesForParentProductInputGeneral() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("product.brandName", "Brand", null,
				false);
		assertThat(results).isNotNull().hasSize(2).containsExactly("Brand Name 1", "Brand Name 2");
	}

	@Test
	void testFindDistinctValuesForParentProductInputRestricting() {
		List<String> results = projectRepository.findDistinctValuesStartingWith("product.productLineText", "Product 1",
				null, false);
		assertThat(results).isNotNull().hasSize(1).containsExactly("Product 1");
	}

}
