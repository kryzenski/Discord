const merge = require('webpack-merge');
const common = require('./webpack-client.js');
const webpack = require('webpack');

module.exports = merge(common, {
  mode: 'development',
  devtool: 'source-map',

  plugins: [
    new webpack.EnvironmentPlugin({
      NODE_ENV: 'DEV',
      DEBUG: true,
    }),
  ],

  module: {
    rules: [
      {
        test: /\.(j|t)sx?$/,
        enforce: 'pre',
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'ifdef-loader',
            options: {
              build: 'DEV',
              'ifdef-verbose': true,
            },
          },
        ],
      },
    ],
  },
});
