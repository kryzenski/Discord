const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

// path declaration
const APP_DIR = path.resolve(__dirname, 'src/client/main');
// const SHARED_DIR = path.resolve(__dirname, 'src/shared');
const BUILD_DIR_CLIENT = path.resolve(__dirname, 'dist/build-client');
const BUILD_DIR_SERVER = path.resolve(__dirname, 'dist/build-server');

const htmlTemplate = new HtmlWebpackPlugin({
  template: APP_DIR + '/index.html',
  filename: BUILD_DIR_SERVER + '/index.html',
});

// used for ts typecheck
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
  entry: {
    app: [APP_DIR + '/client.tsx'],
  },
  output: {
    path: BUILD_DIR_CLIENT,
    filename: 'main_index.js',
    publicPath: '/build-client/',
  },
  resolve: {
    alias: {
      '~': path.resolve(__dirname, 'src'),
      '@main': path.resolve(__dirname, 'src/client/main'),
      '@shared': path.resolve(__dirname, 'src/shared'),
    },
    extensions: ['.js', '.jsx', '.json', '.ts', '.tsx'],
  },
  module: {
    rules: [
      {
        test: /\.(j|t)sx?$/,
        enforce: 'post',
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              presets: [
                '@babel/preset-react', // jsx support
                ['@babel/preset-env', { useBuiltIns: 'usage', corejs: 2 }],
              ],
              plugins: [['@babel/plugin-proposal-class-properties', { loose: true }]],
              cacheDirectory: true, // accelerate compile time
            },
          },
          {
            loader: 'ts-loader',
          },
        ],
      },
      {
        test: /\.(png|woff|woff2|eot|ttf|svg)$/,
        loader: 'url-loader?limit=100000',
      },
      {
        test: /\.(j|t)sx?$/,
        enforce: 'pre',
        exclude: /node_modules/,
        include: /src/,
        loader: 'eslint-loader',
        options: {
          emitWarning: true, // when true, can print warning message on console
          emitError: true, // when treu, can print error message on console
          fix: false, // fix code automatically, discard.
        },
      },
      {
        test: /\.css$/,
        use: [{ loader: 'style-loader' }, { loader: 'css-loader' }],
      },
      {
        test: /\.(less|css)$/,
        use: [
          { loader: 'style-loader' },
          {
            loader: '@teamsupercell/typings-for-css-modules-loader',
          },
          {
            loader: 'css-loader',
            options: {
              modules: { localIdentName: '[name]-[local]-[hash:base64:5]' },
              sourceMap: true,
            },
          },
          {
            loader: 'less-loader',
            options: { javascriptEnabled: true, sourceMap: true },
          },
        ],
      },
    ],
  },
  plugins: [
    htmlTemplate,
    new ForkTsCheckerWebpackPlugin({ eslint: true }),
    new CleanWebpackPlugin({
      verbose: true,
      cleanOnceBeforeBuildPatterns: [BUILD_DIR_CLIENT],
    }),
  ],
};
