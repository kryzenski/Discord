#!/bin/bash

# this script will replace placeholders with environmental variables on the client side script 
CLIENT_DIR='dist/build-client'

sed "s|@PRECISE_ML_AZURE_AUTHORITY@|$PRECISE_ML_AZURE_AUTHORITY|g" "$CLIENT_DIR/main_index.js" > "$CLIENT_DIR/tmp1.js"
sed "s|@PRECISE_ML_CLIENT_ID@|$PRECISE_ML_CLIENT_ID|g" "$CLIENT_DIR/tmp1.js" > "$CLIENT_DIR/done.js"
# this is done in src/server/helper/configHelper.ts
#sed "s|@BACKEND_PROTOCOL@|$BACKEND_PROTOCOL|g" "$CLIENT_DIR/tmp2.js" > "$CLIENT_DIR/tmp3.js"
#sed "s|@BACKEND_URL@|$BACKEND_URL|g" "$CLIENT_DIR/tmp3.js" > "$CLIENT_DIR/done.js"
rm "$CLIENT_DIR/tmp1.js"
mv "$CLIENT_DIR/done.js" "$CLIENT_DIR/main_index.js"
