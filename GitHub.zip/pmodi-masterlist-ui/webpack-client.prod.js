const merge = require('webpack-merge');
const common = require('./webpack-client.js');
const uglify = require('uglifyjs-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const webpack = require('webpack');

module.exports = merge(common, {
  mode: 'production',
  module: {
    rules: [
      {
        test: /\.(j|t)sx?$/,
        enforce: 'pre',
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'ifdef-loader',
            options: {
              build: 'production',
              'ifdef-verbose': true,
            },
          },
        ],
      },
    ],
  },
  plugins: [
    new webpack.EnvironmentPlugin({
      NODE_ENV: 'PROD',
      DEBUG: false,
    }),
    new TerserPlugin({
      parallel: true,
      terserOptions: {
        ecma: 6,
        format: {
          comments: /@license/i,
        },
      },
    }),
  ],
});
