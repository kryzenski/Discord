const path = require('path');

const CopyWebpackPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const nodeExternals = require('webpack-node-externals');
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');

// For symplicity, we only have one webpack-server config file.
const isProduction = typeof NODE_ENV !== 'undefined' && NODE_ENV === 'production';
const mode = isProduction ? 'production' : 'development';
const devtool = isProduction ? false : 'inline-source-map';

const SRC_DIR = path.resolve(__dirname, 'src');
const APP_DIR = path.resolve(__dirname, 'src/server');
const BUILD_DIR_SERVER = path.resolve(__dirname, 'dist/build-server');

const SERVER_CONFIG_FILE = 'server_configuration.json';
const CLIENT_CONFIG_FILE = 'client_configuration.json';

module.exports = {
  mode,
  devtool,
  target: 'node',
  node: {
    __dirname: false,
    __filename: false,
  },
  entry: {
    app: [APP_DIR + '/index.ts'],
  },
  output: {
    path: BUILD_DIR_SERVER,
    filename: 'index.js',
  },
  resolve: {
    alias: {
      '~': SRC_DIR,
      '@main': APP_DIR,
    },
    extensions: ['.js', '.jsx', '.json', '.ts', '.tsx'],
  },
  externals: [nodeExternals()],
  module: {
    rules: [
      {
        test: /\.(j|t)sx?$/,
        enforce: 'post',
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              presets: [
                '@babel/preset-react', // jsx support
                ['@babel/preset-env', { useBuiltIns: 'usage', corejs: 2 }],
              ],
              plugins: [['@babel/plugin-proposal-class-properties', { loose: true }]],
              cacheDirectory: true, // accelerate compile time
            },
          },
          {
            loader: 'ts-loader',
          },
        ],
      },
    ],
  },
  plugins: [
    new ForkTsCheckerWebpackPlugin({ eslint: true }),
    new CleanWebpackPlugin({
      verbose: true,
      cleanOnceBeforeBuildPatterns: ['!*.html'],
    }),
    new CopyWebpackPlugin(
      [
        {
          from: `${APP_DIR}/${SERVER_CONFIG_FILE}`,
          to: `${SERVER_CONFIG_FILE}`,
        },
        {
          from: `${APP_DIR}/${CLIENT_CONFIG_FILE}`,
          to: `${CLIENT_CONFIG_FILE}`,
        },
      ],
      {
        copyUnmodified: true,
        logLevel: 'info',
      },
    ),
  ],
};
