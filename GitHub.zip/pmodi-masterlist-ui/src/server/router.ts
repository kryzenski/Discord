import Express from 'express';
import { mainReqestHandler } from './server';

export const configRouter = () => {
  const router = Express.Router();

  router.all('/', mainReqestHandler());

  router.all('/api', (req, resp) => {
    resp.send('<h1>hello world</h1>');
  });
  router.all('*', mainReqestHandler());
  return router;
};
