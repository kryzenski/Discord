import { Express as ExpressType, Request, Response } from 'express';
import { readMainDefault, getEntryHtml } from './helper/configHelper';
import { AddressInfo } from 'net';
import * as http from 'http';
import { logger } from './helper/logging';

export function mainReqestHandler() {
  return async function handleRequest(req: Request, resp: Response) {
    const htmlString = await getEntryHtml();
    resp.send(htmlString);
  };
}

export async function startServer(app: ExpressType) {
  const configuration = await readMainDefault();
  let port = configuration.port;
  process.argv.forEach((val, index, array) => {
    if (array[index].startsWith('--port=')) {
      port = array[index].replace('--port=', '');
    }
  });

  const server: http.Server = app.listen(port, () => {
    const addr = server.address() as AddressInfo;
    const actualPort = addr.port;

    logger.info(`Server started and listening on port ${actualPort}`);
  });
}
