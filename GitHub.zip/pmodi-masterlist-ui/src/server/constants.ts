export const SERVER_CONFIGURATION = 'server_configuration.json';
export const CLIENT_CONFIGURATION = 'client_configuration.json';
