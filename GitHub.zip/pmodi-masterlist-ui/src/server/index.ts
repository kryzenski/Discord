import Express from 'express';
import path from 'path';
import { startServer } from './server';
import { configRouter } from './router';

const clientPath = path.resolve(__dirname, '../build-client');

function createAndStartApp() {
  const app = Express();

  const router = configRouter();

  app.use('/build-client', Express.static(clientPath));
  app.use('/', router);

  startServer(app);
}

createAndStartApp();
