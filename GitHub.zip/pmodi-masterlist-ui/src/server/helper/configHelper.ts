import _ from 'lodash';
import fs from 'fs';
import path from 'path';
import yaml from 'js-yaml';
import https from 'https';
import axios from 'axios';

import { logger } from './logging';
import { SERVER_CONFIGURATION, CLIENT_CONFIGURATION } from '../constants';

interface ConfigType {
  port: string;
  configServerUrl: string;
  mainHtmlTemplate: string;
  titlePlaceholder: string;
  initialStatePlaceholder: string;
  appTitle: string;
  token: string;
  configurations: unknown;
}

let option = {};
export let configuraiton: ConfigType;

/// #if build === "DEV"
const skipHttpsValidation = () => {
  const agent = new https.Agent({
    rejectUnauthorized: false,
  });
  option = {
    httpsAgent: agent,
  };
};

skipHttpsValidation();
/// #endif

export function getToken(
  url: string,
  logger: {
    info: { (arg0: string): void; (arg0: string): void };
    error: (arg0: string, arg1: unknown) => void;
  },
) {
  return new Promise((resolve, reject) => {
    try {
      axios
        .get(url, option)
        .then(response => {
          const data = yaml.safeLoad(response.data);
          const token = _.get(data, ['space-datamanagement-informationobjectindex', 'techJWT']);
          resolve(token);
        })
        .catch(error => {
          logger.error(
            'Error on reading application configuration from config server: ' + url,
            error,
          );
        });
    } catch (error) {
      reject(error);
    }
  });
}

const readFile = (configPath: string) => {
  let data = '';
  try {
    data = fs.readFileSync(configPath, 'utf8');
    logger.info(`successfully read configuration from ${configPath}`);
  } catch (err) {
    logger.error(`Could not read configuration from ${configPath}`);
  }
  return data;
};
export const readMainDefault = async (): Promise<ConfigType> => {
  const serverConfigPath = path.resolve(__dirname, `./${SERVER_CONFIGURATION}`);
  const clientConfigPath = path.resolve(__dirname, `./${CLIENT_CONFIGURATION}`);

  // TODO: should use Promise.all
  const serverData = readFile(serverConfigPath);
  const clientData = readFile(clientConfigPath);

  const serverConfig = JSON.parse(serverData);

  const config = { ...serverConfig, ...JSON.parse(clientData) };
  config.endpoints.defaultProtocol =
    process.env.REST_ENDPOINT_PROTOCOL || config.endpoints.defaultProtocol;
  config.endpoints.defaultHost = process.env.REST_ENDPOINT_HOST || config.endpoints.defaultHost;
  config.endpoints.defaultPort = process.env.REST_ENDPOINT_PORT || config.endpoints.defaultPort;
  configuraiton = config;
  return config;
};

export const getEntryHtml = async (): Promise<string> => {
  const { mainHtmlTemplate, appTitle, titlePlaceholder, initialStatePlaceholder } = configuraiton;
  const templatePath = path.resolve(__dirname, `./${mainHtmlTemplate}`);
  let htmlString = '';
  try {
    htmlString = fs.readFileSync(templatePath, 'utf8');
    const stateInject = `
    <script>
      window.__INITIAL_STATE__ = ${JSON.stringify(configuraiton).replace(/</g, '\\u003c')};
    </script>
  `;
    const titleInject = `<title>${appTitle}</title>`;
    htmlString = htmlString.replace(titlePlaceholder, titleInject);
    htmlString = htmlString.replace(initialStatePlaceholder, stateInject);
    logger.info(`successfully read htmlTemplate ${templatePath}`);
  } catch (err) {
    logger.error(`could not read html template file path ${templatePath}`);
  }
  return htmlString;
};
