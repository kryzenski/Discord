import fs from 'fs';
import path from 'path';

const winston = require('winston');

export const getLoggerWinston = (logLevel, logFile) => {
  const logFormat = winston.format.printf(
    info => `${info.timestamp} ${info.level}: ${info.message}`,
  );
  // winston 3.0.0rc cannot yet configure different formats
  // for different transports. => Therefore we just create
  // an individual logger for console and file.
  // GN 12.11.2018: updated to winston 3.1.0 => re-evaluate, if meanwhile different formats can be configured
  const consoleLogger = winston.createLogger({
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.prettyPrint(),
      winston.format.colorize(),
      logFormat,
    ),
    level: logLevel,
    transports: [new winston.transports.Console({ handleExceptions: true })],
    exitOnError: false, // Else, nothing would be logged to the logfile in case of an unhandled exception
  });
  let fileLogger = null;
  if (logFile) {
    fileLogger = winston.createLogger({
      format: winston.format.combine(winston.format.timestamp(), winston.format.prettyPrint()),
      level: logLevel,
      transports: [
        new winston.transports.File({
          filename: logFile,
          handleExceptions: true,
          //maxsize: 1000000, // currently with 3.0.0rc, neither maxsize, nor zippedArchive are working => wait for next version to setup rolling logs
          //zippedArchive,
        }),
      ],
      exitOnError: false, // Else, nothing would be logged to the logfile in case of an unhandled exception
    });
  }
  const logger = {
    info: item => {
      consoleLogger.info(item);
      if (fileLogger !== null) {
        fileLogger.info(item);
      }
    },
    warn: item => {
      consoleLogger.warn(item);
      if (fileLogger !== null) {
        fileLogger.warn(item);
      }
    },
    error: item => {
      consoleLogger.error(item);
      if (fileLogger !== null) {
        fileLogger.error(item);
      }
    },
  };
  return logger;
};

/**
 * Get logger.
 *
 * @param {string} logLevel - Log level (info, warn, error); mandatory
 * @param {string} logFile  - File path of the log file; mandatory
 * @param {string} loggerType - Logger type (currently only 'winston') to use
 * @returns {object} Logger
 */
export const getLogger = (logLevel, logFile, loggerType) => {
  if (loggerType === 'winston') {
    return getLoggerWinston(logLevel, logFile);
  } else {
    throw new Error("Logger '" + loggerType + "' is not supported!");
  }
};

export function setupLogging(logLevel) {
  const logPath = path.resolve(__dirname, 'log');
  try {
    fs.mkdirSync(logPath); // eslint-disable-line no-sync
  } catch (error) {
    if (error.code !== 'EEXIST') {
      throw error;
    }
  }
  // const logFile = path.resolve(logPath, 'server.log');
  const logger = getLogger(logLevel, false, 'winston');
  console.info('Logging set-up completed - writing log files to ', logPath);
  return logger;
}

export const logger = setupLogging('info');
