import React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';

type ComboBoxProps = {
  options: Array<{ value: string; title: string }>;
  getOptionLabel?: (option) => string;
  value: { value: string; title: string };
  onChange: (value) => any;
};

export const ComboBox = (props: ComboBoxProps): JSX.Element => {
  const { options, getOptionLabel, value, onChange } = props;
  return (
    <Autocomplete
      id="combo-box-demo"
      options={options}
      value={value}
      getOptionLabel={getOptionLabel}
      style={{ width: 300 }}
      size="small"
      renderInput={params => <TextField {...params} variant="outlined" />}
      onChange={(event, value) => onChange(value)}
    />
  );
};
