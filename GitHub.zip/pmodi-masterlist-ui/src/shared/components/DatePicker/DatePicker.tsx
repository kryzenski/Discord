import 'date-fns';
import React from 'react';
import DateFnsUtils from '@date-io/date-fns';
import { makeStyles } from '@material-ui/core/styles';
import { MuiPickersUtilsProvider, KeyboardDatePicker } from '@material-ui/pickers';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import { Message } from '@shared/utils/message';

const useStyles = makeStyles({
  datePickerView: {
    position: 'fixed',
    width: '100%',
    zIndex: 999,
    backgroundColor: '#CCCCFF',
    height: '48px',
  },
  showText: {
    margin: '0.8%',
    float: 'left',
  },
  submit: {
    marginTop: '0.4%',
    marginLeft: '2%',
    backgroundColor: 'white',
  },
  datePicker: {
    margin: '0.5%',
  },
});

type DatePickerProps = {
  value: string;
  onClick: any;
  title: string;
};

export default function DatePicker(props: DatePickerProps) {
  const classes = useStyles();
  const { value, onClick, title } = props;
  const [selectedDate, setSelectedDate] = React.useState(new Date(value));
  const handleDateChange = date => {
    setSelectedDate(date);
  };
  const getDataByNewDate = () => {
    onClick(selectedDate);
  };
  return (
    <div className={classes.datePickerView}>
      <Typography className={classes.showText}>{title}</Typography>
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
        <KeyboardDatePicker
          disableToolbar
          variant="inline"
          format="yyyy-MM-dd"
          className={classes.datePicker}
          value={selectedDate}
          onChange={handleDateChange}
        />
      </MuiPickersUtilsProvider>
      <Button className={classes.submit} variant="outlined" onClick={getDataByNewDate}>
        {Message.button.submit}
      </Button>
    </div>
  );
}
