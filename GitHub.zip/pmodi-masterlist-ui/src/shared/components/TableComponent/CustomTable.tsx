import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import clsx from 'clsx';
import _ from 'lodash';

const useStyles = makeStyles({
  tableRow: {
    '&:nth-of-type(odd)': { backgroundColor: '#EEE' },
  },
  tableContainer: {
    width: '92%',
    marginTop: '1%',
    marginBottom: '1%',
    border: '1px solid rgba(224, 224, 224, 1)',
    marginLeft: '3%',
  },
  tableCell: {
    fontSize: '0.875rem',
    paddingBottom: '10px',
    paddingTop: '5px',
  },
});

const CustomerHeader = headers => {
  const classes = useStyles();
  return _.map(headers, header => <TableCell className={classes.tableCell}>{header}</TableCell>);
};

const CustomerTable = (values, customerTableCellClass) => {
  const classes = useStyles();
  return _.map(values, value => (
    <TableCell className={clsx(classes.tableCell, customerTableCellClass)}>{value}</TableCell>
  ));
};

export default function CustomTable({
  rows,
  headers,
  customerTableCellClass,
}: {
  rows: Array<{ name: string; values: any }>;
  headers?: Array<string>;
  customerTableCellClass?: string;
}) {
  const classes = useStyles();
  return (
    <TableContainer component={Paper} classes={{ root: classes.tableContainer }}>
      <Table>
        {isNotEmptyValue(headers) && (
          <TableHead>
            <TableRow>
              <TableCell
                style={{ fontSize: 15, fontWeight: 400, paddingBottom: '10px', paddingTop: '5px' }}
              ></TableCell>
              {CustomerHeader(headers)}
            </TableRow>
          </TableHead>
        )}
        <TableBody>
          {rows.map(row => (
            <TableRow key={row.name} className={classes.tableRow}>
              <TableCell
                component="th"
                scope="row"
                style={{ fontSize: 15, fontWeight: 400, paddingBottom: '10px', paddingTop: '5px' }}
              >
                {row.name}
              </TableCell>
              {CustomerTable(row.values, customerTableCellClass)}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
