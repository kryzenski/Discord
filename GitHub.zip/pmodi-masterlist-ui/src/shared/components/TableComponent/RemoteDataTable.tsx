import React from 'react';
import MaterialTable, { MTableToolbar } from 'material-table';
import { headerStyle } from '@main/constants/constants';
import _ from 'lodash';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { makeStyles } from '@material-ui/core/styles';
import { toDecimal } from '@shared/utils/numberUtils';
const useStyles = makeStyles({
  toolbar: {
    minHeight: '50px',
  },
});

type RemoteDataTableProps = {
  itemRenderOptions: {
    columns: Array<{ title: string; field: string; formatter?: string }>;
    onTableRowClick?: Function;
    setLocalStorage?: Function;
    handleColumnDrag?: Function;
    customActions?: Array<any>;
    rowStyle?: object;
    maxBodyHeight?: string;
    isFilterActive?: boolean;
    detailPanel?: any;
    loadData: Function;
    pageSize: number;
    tableElement?: any;
    pageSizeOptions?: Array<number>;
    updateData?: Function;
    toIntegerFields?: Array<{ title: string; field: string; formatter?: string }>;
    toFetchUpdatedByAndDate?: Function;
    type?: string;
  };
};

const emptyData = {
  data: [],
  page: 0,
  size: 0,
  totalCount: 0,
};
export const RemoteDataTable = React.memo(
  ({ itemRenderOptions }: RemoteDataTableProps): JSX.Element => {
    const classes = useStyles();
    const {
      columns,
      onTableRowClick = _.noop,
      customActions = [],
      rowStyle,
      maxBodyHeight,
      isFilterActive,
      detailPanel = null,
      loadData,
      pageSize,
      tableElement,
      pageSizeOptions,
      setLocalStorage = _.noop,
      handleColumnDrag = _.noop,
      updateData = _.noop,
      toIntegerFields,
      toFetchUpdatedByAndDate,
      type,
    } = itemRenderOptions;

    const [selectedRow, setSelectedRow] = React.useState(null);
    const onRowClick = (_event, rowData) => {
      !isFilterActive && setSelectedRow(rowData);
      !isFilterActive && onTableRowClick(rowData);
    };

    const onColumnDragged = (sourceIndex, destinationIndex) => {
      handleColumnDrag(sourceIndex, destinationIndex);
    };
    return (
      <MaterialTable
        columns={columns}
        title=""
        tableRef={tableElement}
        options={{
          pageSizeOptions,
          pageSize,
          search: false,
          headerStyle,
          maxBodyHeight,
          emptyRowsWhenPaging: false,
          rowStyle: rowData => ({
            ...rowStyle,
            backgroundColor:
              !isFilterActive && selectedRow && selectedRow.tableData.id === rowData.tableData.id
                ? '#EEE'
                : '#FFF',
          }),
        }}
        detailPanel={detailPanel}
        onRowClick={onRowClick}
        onColumnDragged={onColumnDragged}
        actions={customActions}
        data={async query => {
          setLocalStorage(query);
          return isNotEmptyValue(loadData)
            ? await loadData({
                page: query.page,
                size: query.pageSize,
                sortBy: _.get(query, 'orderBy.field'),
                sortDir: query.orderDirection,
              })
            : emptyData;
        }}
        components={{
          Toolbar: props => <MTableToolbar {...props} classes={{ root: classes.toolbar }} />,
        }}
        editable={{
          onRowUpdate: async (newData, oldata) => {
            const entity = { ...newData };
            _.map(toIntegerFields, col => {
              entity[col.field] =
                entity[col.field] > 1 ? toDecimal(entity[col.field]) : entity[col.field];
            });
            toFetchUpdatedByAndDate(entity, oldata, type);
            try {
              await updateData({
                entity,
                id: newData.id,
              });
            } catch (err) {
              console.log(err);
            }
          },
        }}
      />
    );
  },
);
RemoteDataTable.displayName = 'RemoteDataTable';
