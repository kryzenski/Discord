import React from 'react';
import MaterialTable from 'material-table';
import { headerStyle } from '@main/constants/constants';
import _ from 'lodash';

type TableComponentProps = {
  itemRenderOptions: {
    columns: Array<{ title: string; field: string; width: string }>;
    data: Array<object>;
    search?: boolean;
    title?: string;
    grouping?: boolean;
    paging?: boolean;
    sorting?: boolean;
    selection?: boolean;
    onTableRowClick?: Function;
    customActions?: Array<any>;
    rowStyle?: object;
    maxBodyHeight?: string;
    isLoading?: boolean;
    isFilterActive?: boolean;
    toolbar?: boolean;
    detailPanel?: any;
    tableElement?: any;
    handleSelection?: (rows: any) => void;
  };
};

export const TableComponent = React.memo(
  ({ itemRenderOptions }: TableComponentProps): JSX.Element => {
    const {
      search = false,
      title = '',
      grouping = false,
      paging = false,
      sorting = false,
      selection = false,
      columns,
      onTableRowClick = _.noop,
      customActions = [],
      rowStyle,
      maxBodyHeight,
      data,
      isLoading = false,
      isFilterActive,
      toolbar = true,
      detailPanel = null,
      tableElement,
      handleSelection = _.noop,
    } = itemRenderOptions;

    const [selectedRow, setSelectedRow] = React.useState(null);
    const onRowClick = (_event, rowData) => {
      !isFilterActive && setSelectedRow(rowData);
      !isFilterActive && onTableRowClick(rowData);
    };

    return (
      <MaterialTable
        tableRef={tableElement}
        columns={columns}
        data={data}
        isLoading={isLoading}
        title={title}
        options={{
          search,
          toolbar,
          grouping,
          selection,
          paging,
          sorting,
          headerStyle,
          maxBodyHeight,
          rowStyle: rowData => ({
            ...rowStyle,
            backgroundColor:
              !isFilterActive && selectedRow && selectedRow.tableData.id === rowData.tableData.id
                ? '#EEE'
                : '#FFF',
          }),
        }}
        detailPanel={detailPanel}
        onRowClick={onRowClick}
        actions={customActions}
        onSelectionChange={rows => handleSelection(rows)}
      />
    );
  },
);
TableComponent.displayName = 'TableComponent';
