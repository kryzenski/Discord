import clsx from 'clsx';
import React from 'react';
import Button from '@material-ui/core/Button';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { Message } from '@shared/utils/message';

type SaveButtonProps = {
  onClick?: (event: object) => void;
  isDisabled?: boolean;
  cssClass?: string;
};

const useStyles = makeStyles(() =>
  createStyles({
    button: {
      marginLeft: '91.5%',
      marginTop: '1%',
    },
  }),
);

export const SaveButton = (props: SaveButtonProps): JSX.Element => {
  const classes = useStyles();
  const { onClick, isDisabled, cssClass } = props;

  return (
    <Button
      variant="outlined"
      disabled={isDisabled}
      className={clsx(classes.button, cssClass)}
      onClick={onClick}
    >
      {Message.button.save}
    </Button>
  );
};
