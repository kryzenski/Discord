import clsx from 'clsx';
import React from 'react';
import Button from '@material-ui/core/Button';
import { makeStyles, createStyles } from '@material-ui/core/styles';

type ButtonProps = {
  handleClick?: (event: object) => void;
  isDisabled: boolean;
  customClass?: string;
  text: string;
};

const useStyles = makeStyles(() =>
  createStyles({
    disabled: {
      color: '#FFFFFF !important',
      backgroundColor: '#90B0EA !important',
    },
    available: { color: '#FFFFFF', backgroundColor: '#6495ED' },
  }),
);

export const BasicButton = (props: ButtonProps): JSX.Element => {
  const classes = useStyles();
  const { text, isDisabled, customClass, handleClick } = props;

  return (
    <Button
      variant="contained"
      disabled={isDisabled}
      className={clsx(isDisabled ? classes.disabled : classes.available, customClass)}
      onClick={handleClick}
    >
      {text}
    </Button>
  );
};
