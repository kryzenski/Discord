import React from 'react';
import TextField from '@material-ui/core/TextField';
import { TextValidator } from 'react-material-ui-form-validator';
import { Message } from '@shared/utils/message';

type NumberTextFieldProps = {
  error?: boolean;
  value?: string | number;
  defaultValue?: string | number;
  name?: string;
  handleChange?: (event: object) => void;
  customerClass?: string;
  isDisabled?: boolean;
  helperText?: string;
  isFormValidator?: boolean;
  validatorListener?: (validatorListener: boolean) => void;
  key?: string;
  required?: boolean;
};

const handleKeyPress = event => {
  const invalidChars = ['-', '+', 'e', '.', 'E'];
  if (invalidChars.indexOf(event.key) !== -1) {
    event.preventDefault();
  }
};

export const NumberTextField = (props: NumberTextFieldProps): JSX.Element => {
  const {
    error,
    helperText,
    value,
    isDisabled = false,
    name,
    handleChange,
    customerClass,
    isFormValidator = false,
    validatorListener,
    defaultValue,
    key,
    required,
  } = props;

  return isFormValidator ? (
    <TextValidator
      className={customerClass}
      value={value}
      defaultValue={defaultValue}
      onChange={event => handleChange(event)}
      size="small"
      variant="outlined"
      validators={['isNumber', 'matchRegexp:^([1-9]|[1-9]\\d|100)$']}
      errorMessages={[Message.validation.invalidNumber, Message.validation.invalidNumber]}
      name={name}
      type="number"
      validatorListener={validatorListener}
      disabled={isDisabled}
      onKeyPress={event => handleKeyPress(event)}
      key={key}
      required={required}
    />
  ) : (
    <TextField
      key={key}
      className={customerClass}
      error={error}
      helperText={helperText}
      onChange={event => handleChange(event)}
      value={value}
      name={name}
      variant="outlined"
      size="small"
      type="number"
      disabled={isDisabled}
      onKeyPress={event => handleKeyPress(event)}
      inputProps={{
        min: 0,
        max: 100,
      }}
      required={required}
    />
  );
};
