import React from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { linkStyle } from '~/client/main/components/ListOfLinks/ListOfLinksStyle';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';

type TextAreaProps = {
  label?: string;
  value: string;
  name: string;
  handleChange?: (event: object) => void;
  customerClass?: string;
  isDisabled: boolean;
  rows?: string;
  textFiledClass?: string;
  auditLog?: JSX.Element;
  lableWithLog?: boolean;
  textWithLog?: boolean;
};
const useStyles = makeStyles(() =>
  createStyles({
    label: {
      marginTop: '1%',
      fontSize: '16px',
      color: 'black',
      marginLeft: '3%',
      display: 'inline-block',
    },
    textArea: {
      width: '90%',
      marginTop: '10px',
      marginLeft: '5%',
    },
    textAreaWithAuditLog: {
      width: '90%',
      marginTop: '-5px',
      marginLeft: '5%',
    },
  }),
);

export const TextArea = (props: TextAreaProps): JSX.Element => {
  const classes = useStyles();
  const style = linkStyle();
  const {
    label,
    value,
    handleChange,
    name,
    customerClass,
    isDisabled,
    rows = 4,
    textFiledClass = '',
    auditLog,
    lableWithLog = true,
    textWithLog = false,
  } = props;
  return (
    <div className={customerClass}>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {label && <InputLabel className={classes.label}>{label}</InputLabel>}
          {lableWithLog && auditLog}
          {name === 'thirdPartyAiRegCheck' && (
            <div>
              <Link
                href="https://app.powerbi.com/groups/me/reports/d3d05838-dd64-4cbc-9a94-cfb4f1ea63cd/ReportSection1778955096318a5b0107?experience=power-bi"
                target="_blank"
                rel="noopener"
                underline="always"
              >
                <Typography className={style.linkColor}>3rdParty Evaluation Tool</Typography>
              </Link>
            </div>
          )}
        </div>
      </div>
      <TextField
        className={clsx(
          isNotEmptyValue(auditLog) && lableWithLog
            ? classes.textAreaWithAuditLog
            : classes.textArea,
          textFiledClass,
        )}
        variant="outlined"
        value={value}
        rows={rows}
        multiline
        size="small"
        name={name}
        onChange={event => {
          handleChange(event);
        }}
        disabled={isDisabled}
      />
      {textWithLog && auditLog}
    </div>
  );
};
