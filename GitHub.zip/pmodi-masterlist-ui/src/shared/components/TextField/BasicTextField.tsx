import React from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { makeStyles, createStyles } from '@material-ui/core/styles';

type TextFieldProps = {
  label?: string;
  value: any;
  name?: string;
  rows?: string;
  handleChange?: (event: object) => void;
  customerClass?: string;
  isDisabled: boolean;
  hasUnit?: boolean;
  unitText?: string;
  textFiledClass?: string;
  helperText?: string;
  error?: boolean;
  auditLog?: JSX.Element;
  lableWithLog?: boolean;
  key?: string;
};
const useStyles = makeStyles(() =>
  createStyles({
    label: {
      marginTop: '1%',
      fontSize: '15px',
      color: 'rgba(0, 0, 0, 0.87)',
    },
    unit: {
      marginLeft: '15%',
      marginTop: '-1.6%',
    },
  }),
);

export const BasicTextField = (props: TextFieldProps): JSX.Element => {
  const classes = useStyles();
  const {
    label = '',
    value,
    handleChange,
    name = '',
    rows = '',
    customerClass,
    isDisabled = false,
    hasUnit = false,
    unitText = ' ',
    textFiledClass,
    helperText = '',
    error = false,
    auditLog,
    lableWithLog,
    key = 'BasicTextField',
  } = props;

  return (
    <div className={customerClass}>
      {label && <InputLabel className={classes.label}>{label}</InputLabel>}
      {lableWithLog && auditLog}
      <TextField
        className={textFiledClass}
        variant="outlined"
        value={value}
        size="small"
        name={name}
        rows={rows}
        multiline
        onChange={event => {
          handleChange(event);
        }}
        disabled={isDisabled}
        helperText={helperText}
        error={error}
        key={name + key}
      />
      {hasUnit && <div className={classes.unit}>{unitText}</div>}
    </div>
  );
};
