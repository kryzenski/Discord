import React from 'react';
import Switch from '@material-ui/core/Switch';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import classnames from 'classnames';
import _ from 'lodash';

type switchGroupProps = {
  switchGroups: any;
  title: string;
  handleSwitchChange: any;
  customerClass?: string;
  customerTitleClass?: string;
};
const useStyles = makeStyles(() =>
  createStyles({
    root: {
      marginTop: '3%',
    },
    label: {
      marginTop: '5%',
      marginLeft: '5%',
      fontSize: '20px',
      color: 'black',
    },
    switchGroupLabel: {
      marginLeft: '0 !important',
      marginTop: '3%',
    },
    formGroup: {
      marginLeft: '8%',
      marginTop: '3%',
      width: '100%',
    },
  }),
);

export const SwitchGroup = (props: switchGroupProps): JSX.Element => {
  const classes = useStyles();
  const { switchGroups, title, handleSwitchChange, customerClass, customerTitleClass } = props;

  const switchGroup = [];
  _.forEach(switchGroups, (item, key) => {
    switchGroup.push(
      <FormControlLabel
        value={item.value}
        key={item.label}
        control={
          <Switch checked={item.value} onChange={handleSwitchChange} name={key} color="primary" />
        }
        label={item.label}
        classes={{
          root: classes.switchGroupLabel,
        }}
      />,
    );
  });
  return (
    <FormControl component="fieldset" className={classnames(classes.root, customerClass)}>
      <FormLabel component="legend" className={classnames(classes.label, customerTitleClass)}>
        {title}
      </FormLabel>
      <FormGroup
        classes={{
          root: classes.formGroup,
        }}
      >
        {switchGroup}
      </FormGroup>
    </FormControl>
  );
};
