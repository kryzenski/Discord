import _ from 'lodash';
import clsx from 'clsx';
import React from 'react';
import Link from '@material-ui/core/Link';
import FormLabel from '@material-ui/core/FormLabel';
import FormGroup from '@material-ui/core/FormGroup';
import FormControl from '@material-ui/core/FormControl';
import { makeStyles } from '@material-ui/styles';
import DateUtils from '@shared/utils/dateUtils';

type FieldSetProps = {
  items: Array<{ value: string; label: string; type: string; url: string; field: string }>;
  fieldSetText?: string;
  custmerClass?: any;
  type?: string;
  newCatogry?: string;
};

const useStyles = makeStyles(() => ({
  root: {
    width: '100%',
  },
  propertyLabel: {
    fontSize: '15px !important',
    paddingTop: '2%',
    wordBreak: 'break-all',
    fontWeight: 'bold',
  },

  legend: {
    fontSize: '16px',
    color: 'black',
    marginLeft: '10px',
  },
  identifiers: {
    marginLeft: '1%',
    marginRight: '1%',
    marginTop: '1%',
    borderRadius: '4px',
    border: 'solid 2PX',
    borderColor: '#737373',
    width: '12%',
    float: 'left',
  },
  identifiersRow: {
    listStyleType: 'none',
    marginTop: '10px',
    marginLeft: '-5%',
  },
  formGroup: {
    display: 'block',
    marginTop: '0',
    marginBottom: '0',
  },
  listStyle: {
    marginTop: '0',
  },
  liStyle: {
    marginTop: '0',
  },
}));

export const FieldSet = (props: FieldSetProps): JSX.Element => {
  const classes = useStyles();
  const { fieldSetText, items, custmerClass, type, newCatogry } = props;
  const li = _.map(items, item => {
    if (
      item.field !== 'newportProjectCreated' &&
      item.field !== 'approvalDate' &&
      item.field !== 'creationDate' &&
      item.field !== 'categoryChangedDateNASToLCM' &&
      item.field !== 'categoryChangedDateNFPCToFD'
    ) {
      return (
        <li className={classes.identifiersRow} key={'li ' + item.label}>
          <span className={classes.propertyLabel} key={'label ' + item.label}>
            {`${item.label}: `}
          </span>
          {item.type === 'text' ? (
            <span key={'value ' + item.value}>{item.value}</span>
          ) : (
            <Link
              onClick={() => {
                window.open(item.url);
              }}
            >
              {item.value}
            </Link>
          )}
        </li>
      );
    } else if (
      type === 'projects' &&
      (item.field === 'newportProjectCreated' || item.field === 'approvalDate')
    ) {
      return (
        <li className={classes.identifiersRow} key={'li ' + item.label}>
          <span className={classes.propertyLabel} key={'label ' + item.label}>
            {`${item.label}: `}
          </span>
          {item.value === '00000000' || item.value === null ? (
            ''
          ) : (
            <span key={'value ' + item.value}>
              {DateUtils.getStringFromDatePattern(
                DateUtils.getDateFormatForMonth(),
                item.value,
                false,
              )}
            </span>
          )}
        </li>
      );
    } else if (item.field === 'approvalDate') {
      return (
        <li className={classes.identifiersRow} key={'li ' + item.label}>
          <span className={classes.propertyLabel} key={'label ' + item.label}>
            {`${item.label}: `}
          </span>
          {item.value === '00000000' || item.value === null ? (
            ''
          ) : (
            <span key={'value ' + item.value}>
              {DateUtils.getStringFromDatePattern(
                DateUtils.getDateFormatForMonth(),
                item.value,
                false,
              )}
            </span>
          )}
        </li>
      );
    } else if (type === 'segments' && item.field === 'creationDate') {
      return (
        <li className={clsx(classes.identifiersRow, classes.liStyle)} key={'li ' + item.label}>
          <span className={classes.propertyLabel} key={'label ' + item.label}>
            {`${item.label}: `}
          </span>
          {item.value === '00000000' || item.value === null ? (
            ''
          ) : (
            <span key={'value ' + item.value}>
              {DateUtils.getStringFromDatePattern(
                DateUtils.getDateFormatForMonth(),
                item.value,
                false,
              )}
            </span>
          )}
        </li>
      );
    } else if (
      item.field === 'categoryChangedDateNASToLCM' ||
      item.field === 'categoryChangedDateNFPCToFD'
    ) {
      return (
        <li className={classes.identifiersRow} key={'li ' + item.label}>
          {item.field === 'categoryChangedDateNASToLCM' ? (
            item.value === '00000000' || item.value === null || item.value === '' ? (
              ''
            ) : (
              <span className={classes.propertyLabel} key={'label ' + item.label}>
                {`${item.label} ${newCatogry} : `}
              </span>
            )
          ) : item.value === '00000000' || item.value === null || item.value === '' ? (
            ''
          ) : (
            <span className={classes.propertyLabel} key={'label ' + item.label}>
              {`${item.label}: `}
            </span>
          )}

          {item.value === '00000000' || item.value === null ? (
            ''
          ) : (
            <span key={'value ' + item.value}>
              {DateUtils.getStringFromDatePattern(
                DateUtils.getDateFormatForMonth(),
                item.value,
                false,
              )}
            </span>
          )}
        </li>
      );
    }
  });

  return (
    <FormControl component="fieldset" className={clsx(classes.identifiers, custmerClass)}>
      <FormLabel className={classes.legend} component="legend">
        {fieldSetText}
      </FormLabel>
      <FormGroup className={classes.formGroup} key="FormGroup">
        <ul className={classes.listStyle}>{li}</ul>
      </FormGroup>
    </FormControl>
  );
};
