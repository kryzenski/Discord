import React from 'react';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';

type SimpleDialogProps = {
  ItemRender?: any;
  itemRenderOptions?: object;
  title: string;
  onClose?: (event: object, reason: string) => void;
  open: boolean;
  cancelText?: string;
  okText?: string;
  hasButton?: boolean;
  handleCancel?: (event: object) => void;
  handleOK?: (event: object) => void;
  customerClass?: string;
  disableOKButton?: boolean;
};

export const SimpleDialog = (props: SimpleDialogProps): JSX.Element => {
  const {
    title,
    ItemRender,
    itemRenderOptions,
    onClose,
    open,
    cancelText,
    okText,
    hasButton = false,
    handleCancel,
    handleOK,
    customerClass,
    disableOKButton,
  } = props;

  return (
    <Dialog onClose={onClose} open={open} maxWidth="lg" classes={{ paper: customerClass }}>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent dividers>
        <ItemRender itemRenderOptions={itemRenderOptions} />
      </DialogContent>
      {hasButton && (
        <DialogActions>
          <Button autoFocus onClick={handleCancel} color="primary">
            {cancelText}
          </Button>
          <Button autoFocus onClick={handleOK} color="primary" disabled={disableOKButton}>
            {okText}
          </Button>
        </DialogActions>
      )}
    </Dialog>
  );
};
