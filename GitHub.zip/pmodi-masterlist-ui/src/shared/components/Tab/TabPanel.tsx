import React from 'react';
import PropTypes from 'prop-types';

export default function TabPanel(props) {
  const { itemRender, value, tabKey, index, ...other } = props;
  return (
    <div role="tabpanel" {...other} key={tabKey + index}>
      {value === index && itemRender}
    </div>
  );
}

TabPanel.propTypes = {
  itemRender: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
  tabKey: PropTypes.any.isRequired,
};
