import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useSelector } from 'react-redux';
import { typeState } from '@main/stateManagement/store';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import { sortByKey } from '@shared/utils/functionUtils';
import { FIELD_ORDER } from '@main/constants/fieldsInfo';
import _ from 'lodash';
import {
  getMatsterViewOptionsFromLocalStorage,
  setMatsterViewOptionsToLocalStorage,
} from '~/client/main/security/localStore';
import SearchColumns from '@main/modules/masterList/SearchColumns';

const useStyles = makeStyles(theme => ({
  root: {
    margin: 'auto',
  },
  paper: {
    width: 300,
    height: 230,
    overflow: 'auto',
    border: '2px solid rgba(0,0,0,0.12)',
  },
  button: {
    margin: theme.spacing(0.5, 0),
  },
  title: {
    fontSize: 17,
    paddingBottom: '10px',
  },
  listItem: {
    paddingTop: '0px',
    paddingBottom: '0px',
  },
}));

type TransferListProps = {
  itemRenderOptions: {
    selectedColumn: Array<{ [propName: string]: unknown }>;
    unSelectedColumn?: Array<{ [propName: string]: unknown }>;
    leftTitle?: string;
    rightTitle?: string;
    setSelectedColumns: Function;
    setUnSelectedColumns: Function;
    type: string;
  };
};

const FilterItem = (columns, checked) => {
  return columns.filter(value => checked.indexOf(value) === -1);
};

const filterCheckedFields = (columns, checked) => {
  const checkedFieldNames = checked.map(col => col.field);
  return columns.filter(column => !checkedFieldNames.includes(column.field));
};

const intersection = (projectChecked, columns) => {
  return projectChecked.filter(value => columns.indexOf(value) !== -1);
};

export const TransferList = ({ itemRenderOptions }: TransferListProps): JSX.Element => {
  const {
    selectedColumn,
    unSelectedColumn,
    leftTitle,
    rightTitle,
    setSelectedColumns,
    setUnSelectedColumns,
    type,
  } = itemRenderOptions;
  const classes = useStyles();
  const tableOptions = getMatsterViewOptionsFromLocalStorage(type);
  const columnsInStorage = _.get(tableOptions, 'selectedColumns');

  const [filteredUnselectedColumns, setFilteredUnselectedColumns] = useState(unSelectedColumn);
  const [filteredSelectedColumns, setFilteredSelectedColumns] = useState(selectedColumn);
  const [unSelectedSearchText, setUnSelectedSearchText] = useState('');
  const [selectedSearchText, setSelectedSearchText] = useState('');

  const { selectedColumns } = useSelector((state: typeState) => {
    return {
      selectedColumns: columnsInStorage || state.MasterList[type].selectedColumns,
    };
  });
  const [checked, setChecked] = React.useState([]);
  const leftChecked = intersection(checked, unSelectedColumn);
  const rightChecked = intersection(checked, selectedColumn);
  const handleToggle = item => () => {
    const currentIndex = checked.indexOf(item);
    const newChecked = [...checked];
    if (currentIndex === -1) {
      newChecked.push(item);
    } else {
      newChecked.splice(currentIndex, 1);
    }
    setChecked(newChecked);
  };

  const handleAllRight = () => {
    const updatedSelectedColumns = sortByKey(
      selectedColumns.concat(filteredUnselectedColumns),
      FIELD_ORDER,
    );
    setSelectedColumns(updatedSelectedColumns);
    setMatsterViewOptionsToLocalStorage({ selectedColumns: updatedSelectedColumns }, type);
    setUnSelectedColumns(unSelectedColumn.filter(n => !filteredUnselectedColumns.includes(n)));
    setUnSelectedSearchText('');
    setSelectedSearchText('');
  };

  const handleCheckedRight = () => {
    setSelectedColumns(sortByKey(selectedColumns.concat(leftChecked), FIELD_ORDER));
    setMatsterViewOptionsToLocalStorage(
      { selectedColumns: sortByKey(selectedColumns.concat(leftChecked), FIELD_ORDER) },
      type,
    );
    setUnSelectedColumns(filterCheckedFields(unSelectedColumn, leftChecked));
    setChecked(FilterItem(checked, leftChecked));
    setUnSelectedSearchText('');
    setSelectedSearchText('');
  };

  const handleCheckedLeft = () => {
    setUnSelectedColumns(unSelectedColumn.concat(rightChecked));
    setMatsterViewOptionsToLocalStorage(
      {
        selectedColumns: sortByKey(filterCheckedFields(selectedColumns, rightChecked), FIELD_ORDER),
      },
      type,
    );
    const filteredSelectedColumns = sortByKey(
      filterCheckedFields(selectedColumns, rightChecked),
      FIELD_ORDER,
    );
    setSelectedColumns(filteredSelectedColumns);
    setChecked(FilterItem(checked, rightChecked));
    setUnSelectedSearchText('');
    setSelectedSearchText('');
  };

  const handleAllLeft = () => {
    const updatedUnSelectedColumns = sortByKey(
      unSelectedColumn.concat(filteredSelectedColumns),
      FIELD_ORDER,
    );
    setUnSelectedColumns(updatedUnSelectedColumns);
    setMatsterViewOptionsToLocalStorage({ unSelectColumn: updatedUnSelectedColumns }, type);
    setSelectedColumns(selectedColumn.filter(n => !filteredSelectedColumns.includes(n)));
    setUnSelectedSearchText('');
    setSelectedSearchText('');
  };

  const filterByValue = (array, search) => {
    const updatedSearch = search.toLowerCase();
    return array.filter(item => item.title.toLowerCase().includes(updatedSearch));
  };

  const handleSearchUnSelectedColumn = searchText => {
    const filteredList = filterByValue(unSelectedColumn, searchText);
    setFilteredUnselectedColumns(filteredList);
    setUnSelectedSearchText(searchText);
  };

  const handleSearchSelectedColumn = searchText => {
    const filteredList = filterByValue(selectedColumn, searchText);
    setFilteredSelectedColumns(filteredList);
    setSelectedSearchText(searchText);
  };
  useEffect(() => {
    setFilteredUnselectedColumns(unSelectedColumn);
  }, [unSelectedColumn]);

  useEffect(() => {
    setFilteredSelectedColumns(selectedColumn);
  }, [selectedColumn]);

  const customList = items => (
    <Paper className={classes.paper}>
      <List dense component="div" role="list">
        {items.map(item => {
          const labelId = `transfer-list-item-${item.title}-label`;
          return (
            <ListItem
              key={item.field}
              role="listitem"
              button
              onClick={handleToggle(item)}
              className={classes.listItem}
            >
              <ListItemIcon>
                <Checkbox
                  checked={_.indexOf(checked, item) !== -1}
                  tabIndex={-1}
                  inputProps={{ 'aria-labelledby': labelId }}
                />
              </ListItemIcon>
              <ListItemText id={labelId} primary={item.title} />
            </ListItem>
          );
        })}
        <ListItem />
      </List>
    </Paper>
  );

  return (
    <Grid container spacing={2} justify="center" alignItems="center" className={classes.root}>
      <Grid item>
        <Typography className={classes.title}>{leftTitle}</Typography>
        <SearchColumns
          handleSearch={handleSearchUnSelectedColumn}
          searchText={unSelectedSearchText}
        />
        {customList(filteredUnselectedColumns)}
      </Grid>
      <Grid item>
        <Grid container direction="column" alignItems="center">
          <Button
            variant="outlined"
            size="small"
            className={classes.button}
            onClick={handleAllRight}
            disabled={!unSelectedColumn.length || !filteredUnselectedColumns.length}
            aria-label="move all right"
          >
            ≫
          </Button>
          <Button
            variant="outlined"
            size="small"
            className={classes.button}
            onClick={handleCheckedRight}
            disabled={!leftChecked.length}
            aria-label="move selected right"
          >
            &gt;
          </Button>
          <Button
            variant="outlined"
            size="small"
            className={classes.button}
            onClick={handleCheckedLeft}
            disabled={!rightChecked.length}
            aria-label="move selected left"
          >
            &lt;
          </Button>
          <Button
            variant="outlined"
            size="small"
            className={classes.button}
            onClick={handleAllLeft}
            disabled={!selectedColumn.length || !filteredSelectedColumns.length}
            aria-label="move all left"
          >
            ≪
          </Button>
        </Grid>
      </Grid>
      <Grid item>
        <Typography className={classes.title}>{rightTitle}</Typography>
        <SearchColumns handleSearch={handleSearchSelectedColumn} searchText={selectedSearchText} />
        {customList(filteredSelectedColumns)}
      </Grid>
    </Grid>
  );
};
