import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/styles';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import clsx from 'clsx';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import { Message } from '@shared/utils/message';
import { isEmptyValue } from '@shared/utils/functionUtils';
const useStyles = makeStyles(() => ({
  accordion: {
    float: 'left',
    display: 'block',
    width: '100%',
  },
  title: {
    marginBottom: '1%',
    fontSize: '1.25rem',
    fontWeight: 500,
    marginLeft: '3%',
    marginTop: '1%',
  },
  showText: {
    marginLeft: '45%',
  },
  emptyText: {
    marginTop: '3%',
    marginLeft: '-14%',
    fontSize: '16px',
    color: 'grey',
  },
}));

const Accordion = withStyles({
  root: {
    border: '1px solid rgba(0, 0, 0, .125)',
    boxShadow: 'none',
    '&:not(:last-child)': {
      borderBottom: 0,
    },
    '&:before': {
      display: 'none',
    },
    width: '90%',
    marginLeft: '5%',
  },
  expanded: {
    marginLeft: '5% !important',
  },
})(MuiAccordion);

const AccordionSummary = withStyles({
  root: {
    backgroundColor: 'rgba(0, 0, 0, .03)',
    borderBottom: '1px solid rgba(0, 0, 0, .125)',
    minHeight: 16,
  },
  content: {
    '&$expanded': {
      margin: '12px 0',
    },
  },
  expanded: { minHeight: '16px !important' },
})(MuiAccordionSummary);

const AccordionDetails = withStyles(theme => ({
  root: {
    padding: theme.spacing(2),
  },
}))(MuiAccordionDetails);

type CustomizedAccordionsProps = {
  ItemRender?: Function;
  itemRenderOptions?: any;
  showText: string;
  emptyText?: string;
};

export default function CustomizedAccordions(props: CustomizedAccordionsProps) {
  const styles = useStyles();
  const { ItemRender = null, showText, itemRenderOptions, emptyText = '' } = props;
  return (
    <div className={clsx(styles.accordion)}>
      <h6 className={styles.title}>{Message.gap.gap}</h6>
      <Accordion square>
        <AccordionSummary expandIcon={isEmptyValue(emptyText) && <ArrowDropDownIcon />}>
          <Typography className={styles.showText}>{showText}</Typography>
          <br />
          {emptyText && <Typography className={styles.emptyText}>{emptyText}</Typography>}
        </AccordionSummary>
        {isEmptyValue(emptyText) && (
          <AccordionDetails>
            <ItemRender itemRenderOptions={itemRenderOptions} />
          </AccordionDetails>
        )}
      </Accordion>
    </div>
  );
}
