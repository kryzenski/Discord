import React, { Fragment, useState, useEffect } from 'react';
import clsx from 'clsx';
import IconButton from '@material-ui/core/IconButton';
import Button from '@material-ui/core/Button';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import _ from 'lodash';

const applyToSpecificSegments = 'Apply to specific Segments';

const useStyles = makeStyles(() =>
  createStyles({
    panelSummary: {
      height: '48px',
      backgroundColor: '#6495ed',
      color: '#f5f5f5',
      minHeight: '48px! important',
    },
    tableWith: {
      maxWidth: '100vw',
      width: '100%',
    },
    expandButton: {
      marginLeft: '5%',
      backgroundColor: 'White',
    },
  }),
);

type ExpansionPanelViewProps = {
  test?: any;
  ItemRender?: Function;
  itemRenderOptions?: object;
  text: string;
  onChange?: (expanded: boolean) => void;
  expandAllClick?: () => void;
  shownExpandIcon?: boolean;
  defaultExpanded?: boolean;
  cssClass?: string;
  showExpandAll?: boolean;
  expandOverride?: boolean;
  viewType?: string;
  showApplyButton?: boolean;
  isApplyButtonDisabled?: boolean;
  applyPtrsScrore?: () => void;
  openScoresDialog?: (pannelType: string) => void;
  isDisableSegmentCopy?: boolean;
  type?: string;
};

export const ExpansionPanelView = (props: ExpansionPanelViewProps): JSX.Element => {
  const {
    test = false,
    ItemRender,
    onChange = _.noop,
    expandAllClick = _.noop,
    itemRenderOptions,
    shownExpandIcon = true,
    defaultExpanded = false,
    cssClass,
    showExpandAll = false,
    showApplyButton = false,
    expandOverride = true,
    text,
    viewType = 'index',
    openScoresDialog = _.noop,
    isDisableSegmentCopy = false,
    type,
  } = props;
  const classes = useStyles();
  const editableFields = _.get(itemRenderOptions, 'editableFields');
  const checkForEditabilty =
    _.includes(editableFields, 'fsPtrsScore') || _.includes(editableFields, 'rsPtrsScore');

  const [expanded, setExpanded] = useState(defaultExpanded);
  const expansionChanged = (_event: object, isExpanded: boolean) => {
    setExpanded(isExpanded);
    onChange(isExpanded);
  };

  const renderExpandAllText = () => {
    return expandOverride ? 'Collapse All' : 'Expand All';
  };

  viewType === 'index' &&
    useEffect(() => {
      setExpanded(expandOverride);
    }, [expandOverride]);

  return (
    <Fragment>
      <MuiAccordion
        className={clsx(cssClass)}
        square
        onChange={expansionChanged}
        defaultExpanded={defaultExpanded}
        TransitionProps={{ unmountOnExit: true }}
        expanded={expanded}
      >
        <MuiAccordionSummary
          className={clsx(classes.panelSummary)}
          expandIcon={<IconButton>{shownExpandIcon && <ExpandMoreIcon />}</IconButton>}
        >
          <Typography style={{ flex: 1 }}>{text}</Typography>
          {showExpandAll && (
            <Button
              className={clsx(classes.expandButton)}
              size="small"
              variant="contained"
              onFocus={event => event.stopPropagation()}
              onClick={event => {
                expandAllClick();
                event.stopPropagation();
              }}
            >
              <Typography>{renderExpandAllText()}</Typography>
            </Button>
          )}
          {showApplyButton && (
            <Fragment>
              <Button
                size="small"
                variant="contained"
                className={clsx(classes.expandButton)}
                onFocus={event => event.stopPropagation()}
                disabled={!(isDisableSegmentCopy && checkForEditabilty)}
                onClick={event => {
                  openScoresDialog(type);
                  event.stopPropagation();
                }}
              >
                <Typography>{applyToSpecificSegments} </Typography>
              </Button>
            </Fragment>
          )}
        </MuiAccordionSummary>
        <MuiAccordionDetails>
          {isNotEmptyValue(ItemRender) && expanded && (
            <div className={classes.tableWith}>
              <ItemRender itemRenderOptions={itemRenderOptions} test={test} />
            </div>
          )}
        </MuiAccordionDetails>
      </MuiAccordion>
    </Fragment>
  );
};
