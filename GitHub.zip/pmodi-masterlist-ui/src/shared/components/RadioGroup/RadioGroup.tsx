import React from 'react';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import classnames from 'classnames';
import _ from 'lodash';

type radioGroupProps = {
  radioGroups: Array<{ label: string; value: string }>;
  label: string;
  value: string;
  name: string;
  handleRadioChange: any;
  customerClass?: string;
  isDisabled: boolean;
};
const useStyles = makeStyles(() =>
  createStyles({
    root: {
      marginTop: '1%',
    },
    label: {
      marginTop: '1%',
      fontSize: '16px',
      color: 'black',
    },
    radioGroup: {
      marginLeft: '16%',
      width: '100%',
    },
  }),
);

export const RadioGroups = (props: radioGroupProps): JSX.Element => {
  const classes = useStyles();
  const { radioGroups, label, value, handleRadioChange, name, customerClass, isDisabled } = props;

  const radioGroup = _.map(radioGroups, radioGroup => (
    <div className={classes.radioGroup}>
      <RadioGroup
        name={name}
        value={value}
        onChange={event => handleRadioChange(event)}
        key={'radioGroup' + radioGroup.label}
      >
        <FormControlLabel
          value={radioGroup.value}
          control={<Radio color="default" size="small" />}
          label={radioGroup.label}
          disabled={isDisabled}
        />
      </RadioGroup>
    </div>
  ));

  return (
    <FormControl component="fieldset" className={classnames(classes.root, customerClass)}>
      <FormLabel component="legend" className={classes.label}>
        {label}
      </FormLabel>
      {radioGroup}
    </FormControl>
  );
};
