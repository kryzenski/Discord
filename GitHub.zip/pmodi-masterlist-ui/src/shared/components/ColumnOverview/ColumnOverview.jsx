import PropTypes from 'prop-types';
import React from 'react';
import { Button, Popup } from 'semantic-ui-react';
import styles from './columnOverview.less';

const navStyles = require('@main/styles/detailsPane.less');

const MIN_WIDTH = 0;
const MAX_WIDTH = 100;
const DEFAULT_WIDTH = 50;

const ColumnOverview = ({
  customClassName,
  leftContent,
  rightContent,
  leftColumnWidth,
  editTooltip,
  onClickEdit,
  editingAllowed,
  id,
}) => {
  let editContent = null;
  if (editingAllowed) {
    editContent = (
      <Button
        icon="edit"
        className={navStyles.button + ' ' + styles.showOnHover}
        id={id}
        onClick={onClickEdit}
      />
    );
    if (editTooltip) {
      editContent = (
        <Popup trigger={editContent} content={editTooltip} position="left center" size="mini" />
      );
    }
  }

  const leftWidth =
    leftColumnWidth < MIN_WIDTH || leftColumnWidth > MAX_WIDTH
      ? DEFAULT_WIDTH
      : leftColumnWidth - 6.25; // eslint-disable-line no-magic-numbers
  const rightWidth = 87.5 - leftWidth; // eslint-disable-line no-magic-numbers
  let outerStyle = styles.outerContainer;
  if (customClassName) {
    outerStyle += ' ' + customClassName;
  }
  return (
    <div className={outerStyle}>
      <div className={styles.leftContainer} style={{ width: leftWidth + '%' }}>
        {leftContent}
      </div>
      <div className={styles.centerContainer} style={{ width: '6.25%' }}>
        {editContent}
      </div>
      <div className={styles.rightContainer} style={{ width: rightWidth + '%' }}>
        {rightContent}
      </div>
    </div>
  );
};

ColumnOverview.propTypes = {
  /** Custom CSS class for additional styling; optional */
  customClassName: PropTypes.string,
  /** Content of the left side; mandatory */
  leftContent: PropTypes.node.isRequired,
  /** Content of the right side; mandatory */
  rightContent: PropTypes.node.isRequired,
  /** Width of the left column (from 0% to 100%); optional (but then the default of 50 is used) */
  leftColumnWidth: PropTypes.number,
  /** Tooltip text for the edit icon; optional (but then no tooltip is displayed)*/
  editTooltip: PropTypes.string,
  /** Function which is called when the edit icon is clicked; mandatory*/
  onClickEdit: PropTypes.func.isRequired,
  /* flag if the user has the permission to the edit the content */
  editingAllowed: PropTypes.bool,
  id: PropTypes.string,
};

ColumnOverview.defaultProps = {
  customClassName: null,
  leftColumnWidth: DEFAULT_WIDTH,
  editTooltip: null,
  editingAllowed: false,
  id: null,
};

export default ColumnOverview;
