declare namespace ListItemRendererLessModule {
  export interface IListItemRendererLess {
    actionsContainer: string;
    'bg-semantic-black': string;
    'bg-sematic-green': string;
    'bg-standard': string;
    'bg-standard-above-zindex': string;
    'bg-status-error': string;
    'bg-status-good': string;
    'bg-status-warning': string;
    contentContainer: string;
    contentRow: string;
    'fg-standard': string;
    item: string;
    'menu-item-bg': string;
    'semantic-black': string;
    'sematic-green': string;
    'status-error': string;
    'status-good': string;
    'status-warning': string;
    titleRow: string;
  }
}

declare const ListItemRendererLessModule: ListItemRendererLessModule.IListItemRendererLess & {
  /** WARNING: Only available when `css-loader` is used without `style-loader` or `mini-css-extract-plugin` */
  locals: ListItemRendererLessModule.IListItemRendererLess;
};

export = ListItemRendererLessModule;
