import moment from 'moment';
import de from 'date-fns/esm/locale/de';
import { format } from 'date-fns/esm';
import en from 'date-fns/esm/locale/en-US';

const DATE_FORMAT = 'YYYY-MM-DD HH:mm:ss';

class DateUtils {
  constructor() {
    this.toMoment = this.toMoment.bind(this);
    this.checkJsDate = this.checkJsDate.bind(this);
    this.dateEquals = this.dateEquals.bind(this);
    this.getStringFromDatePattern = this.getStringFromDatePattern.bind(this);
  }

  getLocale(locale: string) {
    //default to en if locale does not match any
    let usedLocale = en;
    if (locale === 'de') {
      usedLocale = de;
    } else {
      usedLocale = en;
    }
    return usedLocale;
  }
  getDateFormatShort() {
    return 'YYYY/MMM/DD';
  }
  getDateFormatForMonth() {
    return 'YYYY-MMM-DD';
  }
  getDateFormatForAssessment() {
    return 'YYYY/MM/DD';
  }
  getDateFormat() {
    return DATE_FORMAT;
  }

  getDateString(date: Date, pattern: string) {
    return format(date, pattern);
  }

  getStringFromDatePattern(
    pattern: string,
    possibleDate: string,
    useUTC: boolean,
    locale?: string,
  ) {
    if (pattern) {
      if (possibleDate) {
        let m = useUTC ? moment.utc(possibleDate) : moment(possibleDate);
        if (locale) {
          m = m.locale(locale);
        }
        const stringValue = useUTC === true ? m.utc().format(pattern) : m.format(pattern);
        return stringValue;
      }
      return '';
    } else {
      throw new Error('Pattern missing!');
    }
  }

  /**
   * Get a moment for a given Date.
   *
   * @param {Date} dateValue - Date to transform to Moment (in UTC); optional (but then null is returned)
   * @param {boolean} useUTC - Flag if moment should be converted to UTC; optional
   * @returns {Moment} Moment or null (only if the given date value was not a Date)
   */
  toMoment(dateValue: Date, useUTC: boolean): unknown {
    if (dateValue && dateValue instanceof Date) {
      const m = moment(dateValue);
      return useUTC ? m.utc() : m;
    }
    return null;
  }

  /**
   * Check if the given date is a Javascript date. Throws an error if not! Undefined or null passes the test.
   *
   * @param {Date} dateValue - Date to check; optional
   * @param {string} identifier - Text used in the error message; optional
   * @returns {void}
   */
  checkJsDate(dateValue: Date, identifier: string): void {
    if (dateValue && !(dateValue instanceof Date)) {
      throw new Error(identifier ? identifier + ' is not a Date!' : 'Given value is not a Date!');
    }
  }

  /**
   * Check if two dates are equal. Also if both dates are not defined or null true is returned.
   *
   * @param {Date} date1 - Date to check; optional
   * @param {Date} date2 - Date to check; optional
   * @returns {boolean} True if the dates are equal
   */
  dateEquals(date1: Date, date2: Date): boolean {
    this.checkJsDate(date1, 'Date1');
    this.checkJsDate(date2, 'Date2');
    if (date1) {
      if (date2) {
        return date1.getTime() === date2.getTime();
      } else {
        return false;
      }
    } else {
      return date2 === null || typeof date2 === 'undefined';
    }
  }
}

const dateUtils = new DateUtils();
export default dateUtils;
