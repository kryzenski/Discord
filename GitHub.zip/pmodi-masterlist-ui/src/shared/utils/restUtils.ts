import qs from 'qs';
import _ from 'lodash';
import axios from 'axios';

import { getToken } from '@shared/utils/securityUtils';
import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { JWT_TOKEN_KEY } from '@shared/utils/security';
import { isNotNil, isEmptyValue } from '@shared/utils/functionUtils';

export const POST_HEADER_CONTENT = {
  'Content-Type': 'application/ld+json',
  Accept: 'application/json',
};

export const GET_HEADER_CONTENT = {
  Accept: 'application/ld+json',
};

export const POST_CONFIG = (headerOptions: object, options: object) => ({
  headers: {
    ...POST_HEADER_CONTENT,
    ...headerOptions,
    Authorization: 'Bearer ' + getToken(JWT_TOKEN_KEY),
  },
  ...options,
});

// Use the same for put and post
export const PUT_CONFIG = (headerOptions, options) => ({
  headers: {
    ...GET_HEADER_CONTENT,
    ...POST_HEADER_CONTENT,
    // api: updateInformationPackage, back end will check this property: motivateBy added through extra options
    ...headerOptions,
    Authorization: 'Bearer ' + getToken(JWT_TOKEN_KEY),
  },
  ...options,
});

export const GET_CONFIG = (headerOptions: object, options: object) => ({
  mode: 'cors',
  headers: {
    ...GET_HEADER_CONTENT,
    ...headerOptions,
    Authorization: 'Bearer ' + getToken(JWT_TOKEN_KEY),
  },
  ...options,
});

export function createGetConfig(params, headerOptions, options) {
  let headers = GET_HEADER_CONTENT;
  if (headerOptions) {
    headers = {
      ...GET_HEADER_CONTENT,
      ...headerOptions,
    };
  }
  headers['Authorization'] = 'Bearer ' + getToken(JWT_TOKEN_KEY);
  return {
    params,
    mode: 'cors',
    headers: headers,
    ...options,
    paramsSerializer: params1 => qs.stringify(params1, { indices: false }),
  };
}

/**
 * create a new url that combine with the sort related param
 * @private this method should be private, but export for jest test,
 * this will fix in other ticket with:https://github.com/speedskater/babel-plugin-rewire
 * @param {String}url - original url
 * @param {String|Array.<String>}sortBy - query param of order field array
 * @param {String|Array.<String>}sortDir - query param of order direction array
 * @return {String} has sort param url
 */

export function getUrlByConfig(url: string, sortBy: unknown, sortDir: unknown): string {
  if (isEmptyValue(sortBy) || isEmptyValue(sortDir)) {
    return url;
  }
  let newUrl = url;
  // const regexCheckUrlHaveParam = /\?[^=]+=.+/g;
  // above is old pattern applying alternate pattern - /[?]([^&=]+)/g,
  const regexCheckUrlHaveParam = /[?]([^&=]+)/g;
  newUrl += regexCheckUrlHaveParam.test(url) ? '&' : '?';

  if (_.isArray(sortBy) && _.isArray(sortDir)) {
    newUrl += sortBy.map(it => `sortBy=${it}`).join('&');
    newUrl = sortDir.reduce((pre, cur) => `${pre}&sortDir=${cur}`, newUrl);
  } else if (_.isString(sortBy) && _.isString(sortDir)) {
    newUrl += `sortBy=${sortBy}&sortDir=${sortDir}`;
  } else {
    throw new Error(
      `sortBy and sortDir must be Array type or String type at same time, but sortBy type is [${typeof sortBy}] and sortDir type is [${typeof sortDir}]`,
    );
  }
  return newUrl;
}

export function getUrlByParam(url: string, param: object) {
  if (isEmptyValue(param)) {
    return url;
  }
  let newUrl = url;
  // const regexCheckUrlHaveParam = /\?[^=]+=.+/g;
  // above is old pattern applying alternate pattern - /[?]([^&=]+)/g,
  const regexCheckUrlHaveParam = /[?]([^&=]+)/g;
  newUrl += regexCheckUrlHaveParam.test(url) ? '&' : '?';

  _.forEach(param, (value: object, key: string) => {
    if (_.isArray(value)) {
      newUrl += value.map(it => `${key}=${it}`).join('&');
    } else if (_.isString(value)) {
      newUrl += `${key}=${value}`;
    } else {
      throw new Error(
        `param must be Array type or String type at same time, but param type is [${typeof param}]`,
      );
    }
  });

  return newUrl;
}

const getRequest = (
  url: string,
  params: null | { sortBy?: string; sortDir?: string },
  headerOptions: object,
  options: object,
) =>
  new Promise((resolve, reject) => {
    const query = params || { sortBy: '', sortDir: '' };
    const { sortBy, sortDir, ...excludeSortParams } = query;
    const newUrl = getUrlByConfig(url, sortBy, sortDir);
    const config = isNotNil(excludeSortParams)
      ? createGetConfig(excludeSortParams, headerOptions, options)
      : GET_CONFIG(headerOptions, options);
    axios.get(newUrl, config).then(resolve, reject);
  });

const patchRequest = (url: string, body: object, headerOptions: object, options: object) =>
  new Promise((resolve, reject) => {
    axios
      .patch(url, body, POST_CONFIG(headerOptions, options))
      .then(result => resolve(result))
      .catch(error => reject(error));
  });

const postRequest = (url: string, body: object, headerOptions: object, options: object) =>
  new Promise((resolve, reject) => {
    axios
      .post(url, body, POST_CONFIG(headerOptions, options))
      .then(result => resolve(result))
      .catch(error => reject(error));
  });

const putRequest = (url: string, body: object, headerOptions: object, options: object) =>
  new Promise((resolve, reject) => {
    axios
      .put(url, body, PUT_CONFIG(headerOptions, options))
      .then(result => resolve(result))
      .catch(error => reject(error));
  });

//TODO rename the configration so they represent better what they are instead of using them over and over as they are needed
const deleteRequest = (url: string, body: object, headerOptions: object, options: object) =>
  new Promise((resolve, reject) => {
    const newUrl = getUrlByParam(url, body);
    axios
      .delete(newUrl, POST_CONFIG(headerOptions, options))
      .then(result => resolve(result))
      .catch(error => reject(error));
  });

/**
 * Get parameters from an URL.
 *
 * @param {string=} paramString - URL parameters e.g. searchAfter=123&size=10
 * @return {object} Parameters as object (may be empty)
 */
export function getUrlParams(paramString: { split: Function }): object {
  const params = {};
  if (paramString) {
    paramString.split('&').forEach(part => {
      const item = part.split('=');
      params[item[0]] = decodeURIComponent(item[1]);
    });
  }
  return params;
}

/**
 * A generic function to perform a rest api call using axios
 * @param{string} url - The url of the API to be called
 * @param {string} method - The HTTP METHOD, e.g. POST, GET, PUT, DELETE.... Use the ENUM HTTPMethods
 * @param {object} [body] - the body to send to the server if POST/PUT
 * @param {object} [parameters] -  url parameters as a map so they can be added to the url
 * @param {object} [headerOptions] - if extra header options are needed or custom header options are needed
 * @param {object} [options] - further options to be used in the request
 * @return {promise} the promise.
 */
export const restRequest = (
  url: string,
  method: string,
  body: object = {},
  parameters: object = {},
  headerOptions: object = {},
  options: object = {},
): Promise<unknown> => {
  switch (method) {
    case HTTPMethod.get:
      return getRequest(url, parameters, headerOptions, options);
    case HTTPMethod.post:
      return postRequest(url, body, headerOptions, options);
    case HTTPMethod.put:
      return putRequest(url, body, headerOptions, options);
    case HTTPMethod.delete:
      return deleteRequest(url, body, headerOptions, options);
    case HTTPMethod.patch:
      return patchRequest(url, body, headerOptions, options);
    default:
      //Should never be the case
      return Promise.reject(new Error('Not supported HTTP method'));
  }
};

/**
 * Generic way to build the URLs for api calls so a change needs to be performed in one single place
 * @param {object} hostInformation the information needed to reach a host such as , Protocol, the address of the host and the port(optional)
 * @param {array} paths the paths to append after /api this will also include any identifier if needed
 * @param {string} defaultProtocol, if there is no protocol, we will use default protocol
 * @param {string} defaultHost, if host is null, we will use default host
 * @returns {string} url to be used in the request
 */
export const buildUrlWithDefaultProtocolAndDefaultHost = (
  paths: Array<string>,
  defaultProtocol: string,
  defaultHost: string,
  defaultPort: string,
) => {
  const port = defaultPort ? `:${defaultPort}` : '';
  const url = `${defaultProtocol}://${defaultHost}${port}/${paths ? paths.join('/') : '/'}`;
  return url.endsWith('/') ? url : `${url}/`;
};
