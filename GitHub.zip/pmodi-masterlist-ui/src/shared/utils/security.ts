// TODO: should move to the configuration
export const TOKEN =
  'eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vbW9jay92Mi4wIiwiaWF0IjoxNTg2ODkxNjc4LCJuYmYiOjE1ODY4OTE2NzgsImV4cCI6ODI4Njg5NTU3OCwiYWlvIjoiQVRRQXkvOFBBQUFBT3VOT2gyMGExQWZTN0RSYXpHODdEM202cFJLdjR2M2xnOGZkeXluTFZTSlNXajgvVURQUW54M0pJMnc5UjJ2ciIsImF1ZCI6Im1vY2siLCJuYW1lIjoiSm9obiBEb2UiLCJub25jZSI6Im1vY2siLCJvaWQiOiJtb2NrX21vY2siLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJKb2huLkRlb0BiYXllci5jb20iLCJzdWIiOiJNb2NrIiwidGlkIjoibW9jayIsInV0aSI6Im1vY2siLCJ2ZXIiOiIyLjAifQ.XvOPHrPE_UAE5-gxkSVLZS_f7B73KF-s1ThdEiEo53A';
export const REFRESH_TOKEN = '';

export const SIGNED_IN = 'SIGNED_IN';
export const SIGNED_OUT = 'SIGNED_OUT';
export const JWT_TOKEN_KEY = 'token';
export const REFRESH_TOKEN_KEY = 'refresh';
export const SESSION_COOKIE_KEY = 'pmo-session_' + window.location.hostname;
