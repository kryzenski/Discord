import {
  TOKEN,
  SIGNED_IN,
  REFRESH_TOKEN,
  JWT_TOKEN_KEY,
  REFRESH_TOKEN_KEY,
  SESSION_COOKIE_KEY,
} from '@shared/utils/security';

const setJwtToken = (jwtToken: string) => {
  localStorage.setItem(JWT_TOKEN_KEY, JSON.stringify(jwtToken));
};

const setRefreshToken = (refreshToken: string) => {
  localStorage.setItem(REFRESH_TOKEN_KEY, JSON.stringify(refreshToken));
};

const setLoginStatus = (loginStatus: string) => {
  document.cookie = SESSION_COOKIE_KEY + '=' + loginStatus + '; path=/';
};

const isSignedIn = () => {
  const cookieString = document.cookie;
  if (!cookieString || cookieString === '') {
    return false;
  }
  const splitName = SESSION_COOKIE_KEY + '=';
  let splitIndex = cookieString.indexOf(splitName);
  if (splitIndex < 0) {
    return false;
  }
  splitIndex += splitName.length;
  if (splitIndex >= cookieString.length) {
    return false;
  }
  let valueString = cookieString.substring(splitIndex);
  splitIndex = valueString.indexOf(';');
  if (splitIndex > 0) {
    valueString = valueString.substring(0, splitIndex);
  }
  valueString = valueString.trim();
  return valueString === SIGNED_IN;
};

export const getToken = (key: string) => {
  if (!isSignedIn()) {
    return null;
  }

  const encodedToken = localStorage.getItem(key);
  return encodedToken ? JSON.parse(encodedToken) : null;
};

export const getJwtToken = () => getToken(JWT_TOKEN_KEY);

export const getRefreshToken = () => getToken(REFRESH_TOKEN_KEY);

const handleLogin = () => {
  setTimeout(() => {
    setJwtToken(TOKEN);
    setRefreshToken(REFRESH_TOKEN);

    setLoginStatus(SIGNED_IN);
  }, 0);
};

export const initSecurity = () => {
  handleLogin();
};
