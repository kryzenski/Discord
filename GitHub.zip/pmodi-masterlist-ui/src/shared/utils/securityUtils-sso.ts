import * as Msal from 'msal';
import { JWT_TOKEN_KEY } from '@shared/utils/security';

const setJwtToken = jwtToken => {
  sessionStorage.setItem(JWT_TOKEN_KEY, JSON.stringify(jwtToken));
};
const removeJwtToken = () => {
  sessionStorage.clear(); // clear all to prevent sessionStorage data accumulating
};

const isExpired = (encodedToken: any) => {
  const token = JSON.parse(encodedToken);
  return new Date().getTime() / 1000 + 300 > parseInt(token.expiration); // force refresh 5 mintues before expiration
};

const isSignedIn = () => {
  const encodedToken = sessionStorage.getItem(JWT_TOKEN_KEY);
  if (encodedToken) {
    return true;
  }
  return false;
};

const initMsalInstance = () => {
  let redirectUri = `${window.location.protocol}\\\\${window.location.hostname}`;
  if (window.location.port) {
    redirectUri += `:${window.location.port}`;
  }

  const msalConfig: any = {
    auth: {
      clientId: '@PRECISE_ML_CLIENT_ID@',
      authority: '@PRECISE_ML_AZURE_AUTHORITY@',
      redirectUri: redirectUri,
    },
    cache: {
      cacheLocation: 'sessionStorage',
      storeAuthStateInCookie: false,
    },
  };
  return new Msal.UserAgentApplication(msalConfig);
};

const requestObj = {
  scopes: ['User.Read'],
};

const handleLogin = () => {
  const msalInstance = initMsalInstance();
  msalInstance.handleRedirectCallback((error, response) => {
    // if error is not null, something went wrong
    // if not, response is a successful login response
    if (error) {
      console.log(error);
    } else {
      setJwtToken(response.idToken);
      // redirect back to page before login
      window.location.href = response.accountState;
    }
  });

  if (isSignedIn()) {
    return;
  }
  setTimeout(() => {
    msalInstance.loginRedirect({ ...requestObj, state: window.location.href });
  }, 0);
};

export const getToken = key => {
  if (!isSignedIn()) {
    return null;
  }
  const encodedToken = sessionStorage.getItem(key);
  if (isExpired(encodedToken)) {
    console.error('accessToken expired');
    removeJwtToken();
    handleLogin();
  }
  const token = JSON.parse(encodedToken);
  return token.rawIdToken;
};

export const initSecurity = () => {
  handleLogin();
};
