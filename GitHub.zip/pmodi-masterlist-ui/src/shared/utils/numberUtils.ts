import _ from 'lodash';

const thousandsSeparatorMap = new Map();
thousandsSeparatorMap.set('en', ',');
thousandsSeparatorMap.set('de', '.');

const decimalSeparatorMap = new Map();
decimalSeparatorMap.set('en', '.');
decimalSeparatorMap.set('de', ',');

export const toInteger = (decimal: number, precision = 0, multiple = 100): number => {
  return _.round(_.multiply(decimal, multiple), precision);
};

export const isValidateNumberValue = value => {
  if (value) {
    const reg = new RegExp('^([1-9]|[1-9]\\d|100)$');
    if (value < 1 || value > 100 || !reg.test(value)) {
      return false;
    } else {
      return true;
    }
  }
  return true;
};

export const toDecimal = value => {
  return _.divide(value, 100) || null;
};

export const getStringFromNumberWithThousandsSeparator = (number, lang = 'en-US') => {
  if (_.isNumber(number)) {
    if (number > 1) {
      return new Intl.NumberFormat(lang, { maximumFractionDigits: 0 }).format(number);
    } else {
      return _.round(number, 2);
    }
  }
  return '';
};
