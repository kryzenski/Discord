import _ from 'lodash';

/**
 * check if param is empty, empty means: null, undefined, empty Array|Set|Map or {}
 * @param {any} arg - need be checked param
 * @return {boolean} true if arg is null, undefined, empty Array|Set|Map or {}
 */
export const isEmptyValue = (arg: unknown): boolean => {
  if (_.isNil(arg) || arg === '') {
    return true;
  } else if (_.isArrayLike(arg) && arg.length === 0) {
    return true;
  } else if (_.isSet(arg) && arg.size === 0) {
    return true;
  } else if (_.isMap(arg) && arg.size === 0) {
    return true;
  } else if (_.isEqual(arg, {})) {
    return true;
  } else if (typeof arg === 'undefined') {
    return true;
  } else if (_.isString(arg) && _.replace(arg, /\s/g, '').length === 0) {
    return true;
  } else {
    return false;
  }
};

export const isNotNil = _.negate(_.isNil);
export const isNotEmptyValue = _.negate(isEmptyValue);

export const getCurrentItem = (data, id) => {
  return _.find(data, item => {
    return _.toString(item.id) === _.toString(id);
  });
};

export const sortByKey = (array, key) => _.sortBy(array, [key]);
export const SortArray = (x, y) => {
  return x.title.localeCompare(y.title);
};
export const convertArrayToMap = (array, key) => _.keyBy(array, key);
export const DIGIT_PATTERN = /^\d+$/;
export const DATE_PATTERN = /^((?:19|20)\d\d)\-((0?[1-9])|(1[0-2]))\-((0?[1-9])|([1-2][0-9])|30|31)$/;
