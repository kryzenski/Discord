import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';

export default function ErrorDialog(props: {
  isOpen: boolean;
  errorObj: { message: string; defaultErrorMessage: string };
}) {
  const { isOpen, errorObj } = props;
  const [open, setOpen] = React.useState(isOpen);
  const handleClose = () => {
    setOpen(false);
    window.location.reload();
  };
  return (
    <Dialog id="ErrorDialog" disableBackdropClick disableEscapeKeyDown maxWidth="md" open={open}>
      <DialogTitle id="error-dialog-title">Error</DialogTitle>
      <DialogContent>
        <DialogContentText id="error-dialog-description">
          {errorObj.message || errorObj.defaultErrorMessage}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="primary">
          Reload
        </Button>
      </DialogActions>
    </Dialog>
  );
}
