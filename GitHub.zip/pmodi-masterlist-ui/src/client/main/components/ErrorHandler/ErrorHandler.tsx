import _ from 'lodash';
import React, { Fragment } from 'react';

import { useAxiosInterceptors } from '@main/interceptors/axiosInterceptor';
import ErrorDialog from './ErrorDialog';

export const ErrorHandler = ({ children }) => {
  const { errorObj } = useAxiosInterceptors();
  switch (_.get(errorObj, 'status')) {
    case 409:
      return (
        <Fragment>
          {children}
          <ErrorDialog isOpen={true} errorObj={errorObj} />
        </Fragment>
      );
    default:
      return children;
  }
};
