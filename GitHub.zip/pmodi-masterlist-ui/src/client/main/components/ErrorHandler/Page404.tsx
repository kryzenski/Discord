import * as React from 'react';

export const Page404 = () => {
  return <p>404, not found</p>;
};
