import _ from 'lodash';
import clsx from 'clsx';
import React, { Fragment } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import { Message } from '@shared/utils/message';
import { toInteger } from '@shared/utils/numberUtils';
import { useScoreContainerStyles } from '@main/components/ScoreContainer/UseScoreContainerStyle';
import InfoIcon from '@material-ui/icons/Info';
import IconButton from '@material-ui/core/IconButton';
import {
  OVERALL_PTRS_SCORE_FIELD,
  ProjectPtrsFields,
  FS_RATIONALE_COMPARATIVE_MESSAGE,
  RS_RATIONALE_COMPARATIVE_MESSAGE,
} from '@main/constants/projectOptions';
import {
  SegmentPtrsFields,
  PTRS_SEGMENT_OVERALL_SCORE_FIELD,
} from '@main/constants/segmentOptions';

export const useScoreContainer = (props): Array<any> => {
  const classes = useScoreContainerStyles();
  const { data, hasButton, buttonText, custmerTextContainer, onClick, type } = props;
  const checkForWarning =
    type === 'projects' &&
    (data['newportCategory'] === 'Label Expansion' ||
      data['newportCategory'] === 'Country Extension')
      ? true
      : false;

  const checkForFsPtrs =
    checkForWarning && _.includes(data['fsPtrsScoreRmk'], FS_RATIONALE_COMPARATIVE_MESSAGE)
      ? true
      : false;
  const checkForRsPtrs =
    checkForWarning &&
    data['rsRegAffairsScore'] === null &&
    data['rsDietaryPtrsScore'] === null &&
    data['rsEnsaPtrsScore'] === null &&
    data['rsOperatorPtrsScore'] === null &&
    _.includes(data['rsPtrsScoreRmk'], RS_RATIONALE_COMPARATIVE_MESSAGE)
      ? true
      : false;
  const createTextField = (field, hasHelperText = true, textFieldClass = classes.textField) => {
    const value = toInteger(_.get(data, field)) || '';
    return _.includes([PTRS_SEGMENT_OVERALL_SCORE_FIELD, OVERALL_PTRS_SCORE_FIELD], field) ? (
      <Fragment key={'overAllPtrsScoreFragment'}>
        <div key={'overAllPtrsScoreDiv'}>
          <span key={'overAllPtrsScoreSpan'}>{Message.score.equal}</span>
        </div>
        <TextField
          key={'overAllPtrsScoreTextField'}
          disabled
          size="small"
          margin="normal"
          variant="outlined"
          value={value}
          className={textFieldClass}
          helperText={hasHelperText ? Message.score[field] : ''}
        />
      </Fragment>
    ) : (
      <TextField
        key={Message.score[field]}
        disabled
        size="small"
        margin="normal"
        variant="outlined"
        value={value}
        className={textFieldClass}
        helperText={hasHelperText ? Message.score[field] : ''}
      />
    );
  };
  const fields = type === 'segments' ? SegmentPtrsFields : ProjectPtrsFields;
  const textFields = _.map(fields, field => createTextField(field));
  const scoreTextFiled = (
    <Fragment>
      <div className={clsx(classes.textContainer, custmerTextContainer)}>
        {textFields}
        {hasButton && (
          <Button className={classes.button} variant="outlined" onClick={onClick}>
            {buttonText}
          </Button>
        )}
      </div>
      <div>
        {(checkForFsPtrs || checkForRsPtrs) && (
          <div className={classes.warningContainer}>
            <div>
              <IconButton edge="start" color="secondary" className={classes.infoButton}>
                <InfoIcon />
              </IconButton>
            </div>
            <div>
              {checkForFsPtrs ? (
                <span>
                  {' '}
                  {FS_RATIONALE_COMPARATIVE_MESSAGE}
                  <br />
                </span>
              ) : (
                ''
              )}

              <span>{checkForRsPtrs ? RS_RATIONALE_COMPARATIVE_MESSAGE : ''}</span>
            </div>
          </div>
        )}
      </div>
    </Fragment>
  );
  return [classes.scoreContainer, classes.scoreLable, scoreTextFiled];
};
