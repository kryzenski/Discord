import clsx from 'clsx';
import React from 'react';
import { Message } from '@shared/utils/message';
import { useScoreContainer } from './useScoreContainer';
import { ScoreContainerProps } from '@main/constants/types';

export const ScoreContainer = (props: ScoreContainerProps): JSX.Element => {
  const [containerClass, labelClass, scoreTextFiled] = useScoreContainer(props);
  return (
    <div className={clsx(containerClass, props.custmerClass)}>
      <h6 className={labelClass}>{Message.score.score}</h6>
      {scoreTextFiled}
    </div>
  );
};
