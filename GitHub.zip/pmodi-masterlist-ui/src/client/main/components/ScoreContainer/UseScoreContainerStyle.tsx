import { makeStyles } from '@material-ui/core/styles';

export const useScoreContainerStyles = makeStyles(() => ({
  scoreLable: {
    marginBottom: '1%',
    fontSize: '1.25rem',
    fontWeight: 500,
    marginLeft: '3%',
  },
  textField: {
    width: 150,
    marginLeft: '0.5% !important',
  },
  scoreContainer: {
    float: 'left',
    display: 'block',
    width: '100%',
  },
  textContainer: {
    display: 'flex',
    alignItems: 'baseline',
    marginTop: '-20px',
    marginLeft: '4.5%',
  },
  button: {
    marginLeft: '1% !important',
  },
  warningContainer: {
    alignItems: 'baseline',
    marginLeft: '5.5%',
    display: 'flex',
  },
  infoButton: {
    width: '20px',
  },
}));
