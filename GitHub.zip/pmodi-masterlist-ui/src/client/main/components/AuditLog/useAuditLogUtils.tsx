import _ from 'lodash';
import { DialogProps } from '@material-ui/core/Dialog';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import React, { useState, useEffect, useReducer } from 'react';

import DateUtils from '@shared/utils/dateUtils';
import { isEmptyValue } from '@shared/utils/functionUtils';
import { getRevisions } from '@main/serviceData/auditLog/revisions';
import { renderFunc, getAllFieldsInfo, getAuditLogFields } from '@main/constants/fieldsInfo';
import {
  GRID_LARGE,
  EMPTY_CELL_COLOR,
  EMPTY_PLACEHOLDER,
  FT_RECOMMENDATION_DELETED,
  FT_RECOMMENDATION_DELETED_DEFAULT,
  DELETED_CELL_COLOR,
  ACTION_CLOSE_POPUP,
  ACTION_ASYNC_GET_REVISIONS,
  FIELD_NAME_MODIFIED_BY,
  FIELD_NAME_MODIFIED_AT,
  FIELD_LABEL_CHANGED_BY,
  FIELD_LABEL_CHANGED_ON,
  FS_RECCOMMENDATION_TITLE,
  FS_RECOMMENDATION_FEILD,
  FS_OBJECTIVE_TITLE,
  FS_OBJECTIVE_FEILD,
  FS_RESULT_TITLE,
  FS_RESULT_FEILD,
  RS_RECOMMENDATION_FIELD,
  RS_RECOMMENDATION_TITLE,
  FT_RECOMMENDATION_FIELD,
  FT_RECOMMENDATION_TITLE,
  FT_RESPONSIBLITY_FIELD,
  FT_RESPONSIBLITY_TITLE,
  FT_STATUS_FIELD,
  FT_STATUS_TITLE,
} from '@main/constants/constants';
import {
  FS_RATIONALE_COMPARATIVE_MESSAGE,
  RS_RATIONALE_COMPARATIVE_MESSAGE,
} from '../../constants/projectOptions';

export const auditLogStyles = makeStyles(() =>
  createStyles({
    logInfoIcon: {},
    label: { marginTop: '2px', marginLeft: '3px' },
  }),
);

const comparativeOfRationale = (fields, flag, paths) => {
  const type = paths[0];
  let val = false;
  if (fields.hasOwnProperty('fsPtrsScoreRmk')) {
    val = fields['fsPtrsScoreRmk']?.includes(FS_RATIONALE_COMPARATIVE_MESSAGE);
  } else if (fields.hasOwnProperty('rsPtrsScoreRmk')) {
    val = fields['rsPtrsScoreRmk']?.includes(RS_RATIONALE_COMPARATIVE_MESSAGE);
  }
  if (
    !val &&
    type === 'projects' &&
    (fields.hasOwnProperty('fsPtrsScoreRmk') || fields.hasOwnProperty('rsPtrsScoreRmk'))
  ) {
    return false;
  }
  return val || flag;
};

const cellStyleFunc = cellValue => {
  if (isEmptyValue(cellValue)) {
    return { backgroundColor: EMPTY_CELL_COLOR };
  }
};

const renderDeleteCell = field => rowData => {
  const value = rowData[field];
  if (value === EMPTY_PLACEHOLDER) {
    return <span style={{ color: DELETED_CELL_COLOR }}>{value}</span>;
  }
  if (rowData['flag'] && field === 'modifiedBy') {
    return <span>\data-projects.sql</span>;
  }
  return value;
};
const fsFeilSolutionColumn: any[] = [
  { title: FS_RECCOMMENDATION_TITLE, field: FS_RECOMMENDATION_FEILD },
  { title: FS_OBJECTIVE_TITLE, field: FS_OBJECTIVE_FEILD },
  { title: FS_RESULT_TITLE, field: FS_RESULT_FEILD },
  { title: RS_RECOMMENDATION_TITLE, field: RS_RECOMMENDATION_FIELD },
  { title: FT_RECOMMENDATION_TITLE, field: FT_RECOMMENDATION_FIELD },
  { title: FT_STATUS_TITLE, field: FT_STATUS_FIELD },
  { title: FT_RESPONSIBLITY_TITLE, field: FT_RESPONSIBLITY_FIELD },
];

const createColumns = (fieldNames, allFieldsInfo) => {
  let columns: any[] = _.map(fieldNames, fieldName => {
    const fieldInfo = allFieldsInfo[fieldName];
    return {
      title: fieldInfo && fieldInfo.title,
      field: fieldName,
      render: renderDeleteCell(fieldName),
      cellStyle: cellStyleFunc,
    };
  });

  if (
    fieldNames[0] === FS_OBJECTIVE_FEILD ||
    fieldNames[0] === FS_RECOMMENDATION_FEILD ||
    fieldNames[0] === FS_RESULT_FEILD ||
    fieldNames[0] === RS_RECOMMENDATION_FIELD ||
    fieldNames[0] === FT_RECOMMENDATION_FIELD ||
    fieldNames[0] === FT_STATUS_FIELD ||
    fieldNames[0] === FT_RESPONSIBLITY_FIELD
  ) {
    _.forEach(fsFeilSolutionColumn, item => {
      if (fieldNames[0] === item.field) {
        columns = [
          {
            title: item.title,
            field: item.field,
            render: renderDeleteCell(item.field),
            cellStyle: cellStyleFunc,
          },
        ];
      }
    });
  }

  return _.concat(columns, [
    {
      title: FIELD_LABEL_CHANGED_BY,
      field: FIELD_NAME_MODIFIED_BY,
      width: 200,
      render: renderDeleteCell(FIELD_NAME_MODIFIED_BY),
    },
    { title: FIELD_LABEL_CHANGED_ON, field: FIELD_NAME_MODIFIED_AT, width: 200 },
  ]);
};

const reducer = (state, action) => {
  let flag = false;
  switch (action.type) {
    case ACTION_ASYNC_GET_REVISIONS:
      const { response, allFieldsInfo, paths } = action.payload;

      const data = _.map(response, item => {
        const fields = {};
        _.forEach(item.changes, it => {
          const { fieldName, revisionValue } = it;
          const fieldInfo = allFieldsInfo[fieldName] || '';
          const getValue = renderFunc(fieldInfo);
          fields[fieldName] = isEmptyValue(revisionValue)
            ? fieldName == 'techRecommendation' ||
              fieldName == 'scienceRecommendation' ||
              fieldName == 'solRecommendation'
              ? FT_RECOMMENDATION_DELETED
              : EMPTY_PLACEHOLDER
            : getValue(it.revisionValue);
          // fields[fieldName] = isEmptyValue(revisionValue) ? FT_RECOMMENDATION_DELETED : getValue(it.revisionValue);
        });
        flag = comparativeOfRationale(fields, flag, paths);
        return {
          modifiedBy:
            fields['techRecommendation'] == FT_RECOMMENDATION_DELETED
              ? FT_RECOMMENDATION_DELETED_DEFAULT
              : fields['solRecommendation'] == FT_RECOMMENDATION_DELETED
              ? FT_RECOMMENDATION_DELETED_DEFAULT
              : fields['scienceRecommendation'] == FT_RECOMMENDATION_DELETED
              ? FT_RECOMMENDATION_DELETED_DEFAULT
              : item.modifiedBy,
          modifiedAt: DateUtils.getStringFromDatePattern(
            DateUtils.getDateFormat(),
            item.modifiedAt,
            false,
          ),
          flag,
          ...fields,
        };
      });
      return { ...state, data, isLoading: false };
    case ACTION_CLOSE_POPUP:
      return { ...state, data: [], isLoading: true };
    default: {
      return state;
    }
  }
};

export const useAuditLog = (props): Array<any> => {
  const { paths, id, fieldName, customClass } = props;

  const allFieldsInfo = getAllFieldsInfo(paths);
  const fieldNames = getAuditLogFields(fieldName, paths);

  const classes = auditLogStyles();
  const [isOpen, setIsOpen] = useState(false);
  const [maxWidth] = useState<DialogProps['maxWidth']>(GRID_LARGE);

  const [state, dispatch] = useReducer(reducer, { data: [], isLoading: true });

  useEffect(() => {
    if (isOpen) {
      const fetchData = async () => {
        const response = await getRevisions(paths, id, fieldNames);
        dispatch({
          type: ACTION_ASYNC_GET_REVISIONS,
          payload: { response, fieldNames, allFieldsInfo, paths },
        });
      };
      fetchData();
    }
  }, [_.toString([id, paths, isOpen, fieldNames])]);

  const handleClickOpen = () => {
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    dispatch({ type: ACTION_CLOSE_POPUP });
  };
  const options = {
    columns: createColumns(fieldNames, allFieldsInfo),
    data: state.data,
    isLoading: state.isLoading,
    toolbar: false,
  };

  return [isOpen, maxWidth, classes, options, customClass, handleClose, handleClickOpen];
};
