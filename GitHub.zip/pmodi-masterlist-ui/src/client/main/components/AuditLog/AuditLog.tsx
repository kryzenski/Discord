import _ from 'lodash';
import clsx from 'clsx';
import React from 'react';
import Dialog from '@material-ui/core/Dialog';
import Tooltip from '@material-ui/core/Tooltip';
import InfoIcon from '@material-ui/icons/Info';
import IconButton from '@material-ui/core/IconButton';
import DialogContent from '@material-ui/core/DialogContent';

import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import { AuditLogProps } from '@main/constants/types';
import { AUDIT_LOG_INFO_ICON_TOOLTIP } from '@main/constants/constants';
import { useAuditLog } from './useAuditLogUtils';

export const AuditLog = (props: AuditLogProps): JSX.Element => {
  const [
    isOpen,
    maxWidth,
    classes,
    options,
    customClass,
    handleClose,
    handleClickOpen,
  ] = useAuditLog(props);

  return (
    <React.Fragment>
      <Tooltip placement="top-end" title={AUDIT_LOG_INFO_ICON_TOOLTIP}>
        <IconButton
          edge="start"
          color="primary"
          className={clsx(classes.logInfoIcon, customClass)}
          onClick={_.debounce(handleClickOpen, 300)}
        >
          <InfoIcon />
        </IconButton>
      </Tooltip>
      <Dialog fullWidth open={isOpen} maxWidth={maxWidth} onClose={handleClose}>
        <DialogContent>
          <TableComponent itemRenderOptions={options} />
        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
};
