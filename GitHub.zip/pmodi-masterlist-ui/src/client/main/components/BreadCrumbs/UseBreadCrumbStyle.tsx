import { makeStyles } from '@material-ui/core/styles';
export const useBreadCrumbsStyles = makeStyles(() => ({
  link: {
    textDecoration: 'none',
    color: 'rgb(0, 0, 238)',
  },
}));
