import React from 'react';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import { useBreadCrumbs } from './UseBreadCrumbs';
import { BreadCrumbsProps } from '@main/constants/types';

export const BreadCrumbs = (props: BreadCrumbsProps): JSX.Element => {
  const [links] = useBreadCrumbs(props);
  return (
    <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} aria-label="breadcrumb">
      {links}
    </Breadcrumbs>
  );
};
