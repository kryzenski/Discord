import React from 'react';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import { useBreadCrumbsStyles } from '~/client/main/components/BreadCrumbs/UseBreadCrumbStyle';

export const useBreadCrumbs = (props): Array<any> => {
  const styles = useBreadCrumbsStyles();
  const links = [];

  props.items.forEach(item => {
    const link = item.path ? (
      <Link to={item.path} className={styles.link} key={item.path}>
        {item.text}
      </Link>
    ) : (
      <Typography color="textPrimary" key={item.path}>
        {item.text}
      </Typography>
    );
    links.push(link);
  });
  return [links];
};
