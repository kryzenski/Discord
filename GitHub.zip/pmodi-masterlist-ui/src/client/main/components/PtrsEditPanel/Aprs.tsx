import _ from 'lodash';
import React, { useEffect, useReducer } from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';

import { Message } from '@shared/utils/message';
import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import { getAprs } from '@main/serviceData/project/projects';
import {
  APRS_ACTIVE_INGREDIANT,
  APRS_SCORE_VALUE,
  APRS_REGION,
  APRS_SCORE_COMMENT,
  APRS_ACTION_ASYNC_GET_APRS,
} from '@main/constants/constants';

const aprsColumns = [APRS_ACTIVE_INGREDIANT, APRS_SCORE_VALUE, APRS_REGION, APRS_SCORE_COMMENT];

const aprsStyles = makeStyles(() =>
  createStyles({
    projectTableClass: {
      marginBottom: '2%',
      marginTop: '1%',
      width: '99%',
    },

    segmentTableClass: {
      width: '90%',
      marginTop: '1%',
      marginLeft: '5%',
      marginBottom: '2%',
    },
  }),
);

const createColumns = () =>
  _.map(aprsColumns, fieldName => ({
    title: Message.ptrs.aprs[fieldName],
    field: fieldName,
    width: 'auto',
  }));

const useEffectAsync = (effect: Function, inputs: Array<string>) => {
  useEffect(() => {
    effect();
  }, inputs);
};

const reducer = (state, action) => {
  switch (action.type) {
    case APRS_ACTION_ASYNC_GET_APRS:
      return { ...state, data: action.payload.results, isLoading: false };
    default: {
      return state;
    }
  }
};

export const useAprsUtils = (id, isSegment): Array<any> => {
  const [state, dispatch] = useReducer(reducer, { data: [], isLoading: true });
  useEffectAsync(async () => {
    const results = await getAprs(id, isSegment);
    dispatch({
      type: APRS_ACTION_ASYNC_GET_APRS,
      payload: { results },
    });
  }, [_.toString([id, isSegment])]);

  return [state.data, state.isLoading];
};

export const Aprs = (props: { data; isLoading; isSegment }): JSX.Element => {
  const { data, isLoading, isSegment } = props;
  const { segmentTableClass, projectTableClass } = aprsStyles();
  const options = {
    data,
    toolbar: false,
    isLoading: isLoading,
    maxBodyHeight: '300px',
    columns: createColumns(),
  };

  return (
    <div className={isSegment ? segmentTableClass : projectTableClass}>
      <TableComponent itemRenderOptions={options} />
    </div>
  );
};
