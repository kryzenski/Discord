import _ from 'lodash';
import React, { Fragment } from 'react';
// import { SaveButton } from '@shared/components/Buttons/SaveButton';
//import InputLabel from '@material-ui/core/InputLabel';
import { Select, MenuItem, FormControl, Grid } from '@material-ui/core';
import { Message } from '@shared/utils/message';
import { TextArea } from '@shared/components/TextField/TextArea';
import { NumberTextField } from '@shared/components/TextField/NumberTextField';
import { AuditLog } from '@main/components/AuditLog/AuditLog';
import { usePtrsEditPanel } from './UsePtrsEditPanel';
import { PtrsEditPanelProps } from '@main/constants/types';
import clsx from 'clsx';
import { ValidatorForm } from 'react-material-ui-form-validator';
import Button from '@material-ui/core/Button';

type FormRowPropsType = {
  SegmentSubScore?: Array<object>;
  editableFields?: Array<string>;
  handleChange: (event: object) => void;
  field?: any;
  classes?: any;
  riskKey?: string;
  rationaleKey?: string;
  rsSegmentSubScore?: any;
  validatorListener?: (isValid: boolean) => void;
  hasAuditLog?: boolean;
  path?: Array<string>;
  item?: any;
};

type FormLastRowPropsType = {
  isValidate?: boolean;
  shownScoreValue?: any;
  scoreKey?: string;
  hasAuditLog?: boolean;
  path?: Array<string>;
  scoreLabel?: string;
  rationaleLabel?: string;
  shownRationaleValue?: string;
  rationaleKey?: string;
  item?: any;
  classes?: any;
  handleChange?: (event: object) => void;
  toCheckEditablityOfPtrsScore?: boolean;
  editableFields?: Array<string>;
  test?: string;
  checkingForWarningDisplayMessage?: any;
};

const getGridItem = (
  item,
  SegmentSubScore,
  handleChange,
  editableFields,
  classes,
  rsSegmentSubScore,
  validatorListener,
  isValidate,
  shownScoreValue,
  scoreKey,
  hasAuditLog,
  path,
  scoreLabel,
  rationaleLabel,
  shownRationaleValue,
  rationaleKey,
  test,
  toCheckEditablityOfPtrsScore,
  checkingForWarningDisplayMessage,
) => {
  return (
    <Fragment>
      <Grid container xs={10} spacing={0} className={classes.gridSpacing}>
        {test === 'rsSubScore' && SegmentSubScore
          ? _.map(SegmentSubScore, field => (
              <FormRow
                riskKey={field.risk}
                rationaleKey={field.rationale}
                handleChange={handleChange}
                classes={classes}
                rsSegmentSubScore={rsSegmentSubScore}
                editableFields={editableFields}
                validatorListener={validatorListener}
                hasAuditLog={hasAuditLog}
                path={path}
                item={item}
              />
            ))
          : null}
      </Grid>
      <FormLastRow
        isValidate={isValidate}
        item={item}
        shownScoreValue={shownScoreValue}
        scoreKey={scoreKey}
        hasAuditLog={hasAuditLog}
        path={path}
        scoreLabel={scoreLabel}
        rationaleLabel={rationaleLabel}
        shownRationaleValue={shownRationaleValue}
        rationaleKey={rationaleKey}
        classes={classes}
        handleChange={handleChange}
        toCheckEditablityOfPtrsScore={toCheckEditablityOfPtrsScore}
        editableFields={editableFields}
        checkingForWarningDisplayMessage={checkingForWarningDisplayMessage}
      />
    </Fragment>
  );
};

const FormRow = ({
  riskKey,
  rationaleKey,
  handleChange,
  classes,
  rsSegmentSubScore,
  editableFields,
  validatorListener,
  hasAuditLog,
  path,
  item,
}: FormRowPropsType) => {
  const riskValue = _.get(rsSegmentSubScore, riskKey) || '';
  const rationaleValue = _.get(rsSegmentSubScore, rationaleKey);
  return (
    <Fragment>
      <Grid item xs={2}>
        <div key={rationaleKey + 'propertyLable'} className={classes.propertyLabel}>
          {Message.segmentSubScore[riskKey]}
        </div>
      </Grid>
      <Grid item xs={8}>
        <TextArea
          value={rationaleValue}
          name={rationaleKey}
          handleChange={handleChange}
          rows="3"
          isDisabled={!_.includes(editableFields, rationaleKey)}
          textFiledClass={classes.textAreaRationaleField}
        />
      </Grid>
      <Grid item xs={2}>
        <NumberTextField
          validatorListener={validatorListener}
          isFormValidator={true}
          handleChange={handleChange}
          value={riskValue}
          name={riskKey}
          isDisabled={!_.includes(editableFields, riskKey)}
          customerClass={classes.textRiskField}
          key={riskKey + 'NumberTextField'}
        />
        {hasAuditLog && (
          <AuditLog
            paths={path}
            id={item.id}
            customClass={classes.segmentSubScoreAuditLog}
            fieldName={riskKey}
          />
        )}
      </Grid>
    </Fragment>
  );
};

const FormLastRow = ({
  isValidate,
  shownScoreValue,
  scoreKey,
  hasAuditLog,
  path,
  scoreLabel,
  rationaleLabel,
  shownRationaleValue,
  rationaleKey,
  item,
  classes,
  handleChange,
  editableFields,
  toCheckEditablityOfPtrsScore,
  checkingForWarningDisplayMessage,
}: FormLastRowPropsType) => {
  const warningMessageforFS =
    'If FS PTRS score is deleted and no new value is entered, the weighted segment FS score becomes project FS score by default.';
  return (
    <Fragment>
      <Grid item xs={12} style={{ display: 'flex' }}>
        <div className={classes.label}>{scoreLabel}</div>
        {hasAuditLog && (
          <AuditLog paths={path} id={item.id} customClass={classes.auditLog} fieldName={scoreKey} />
        )}
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={3}>
          <NumberTextField
            error={!isValidate}
            helperText={isValidate ? '' : Message.validation.invalidNumber}
            handleChange={handleChange}
            value={shownScoreValue}
            isDisabled={!_.includes(editableFields, scoreKey) || toCheckEditablityOfPtrsScore}
            name={scoreKey}
            customerClass={classes.textField}
          />
        </Grid>
        <Grid item xs={9}>
          {checkingForWarningDisplayMessage ? (
            <div className={classes.warningMessage}>{warningMessageforFS}</div>
          ) : (
            ''
          )}
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <div className={classes.label}>{rationaleLabel}</div>
      </Grid>

      <TextArea
        value={shownRationaleValue}
        name={rationaleKey}
        handleChange={handleChange}
        isDisabled={!_.includes(editableFields, rationaleKey)}
        textFiledClass={classes.textAreaField}
      />
    </Fragment>
  );
};

export const PtrsEditPanel = (props: PtrsEditPanelProps): JSX.Element => {
  const {
    test,
    item,
    scoreKey,
    rationaleKey,
    recommendationKey,
    objectiveKey,
    resultKey,
    responsiblityKey,
    ftrecommendationKey,
    statusKey,
    isEmptyView = false,
    scoreLabel,
    rationaleLabel,
    emptyText,
    editableFields,
    hasAuditLog = false,
    path,
  } = props.itemRenderOptions;
  const [
    classes,
    isValidate,
    isSaveAble,
    shownScoreValue,
    shownRationaleValue,
    shownSolObjective,
    shownSolResult,
    shownSolRecommendation,
    shownTechResponsability,
    shownTechStatus,
    shownTechRecommendation,
    onClick,
    handleChange,
    rsSegmentSubScore,
    validatorListener,
    SegmentSubScores,
    toCheckEditablityOfPtrsScore,
    checkingForWarningDisplayMessage,
  ] = usePtrsEditPanel(props);
  const displayStyle = {
    marginLeft: '5%',
    width: '90%',
  };

  const visiblity =
    item['newportCategory'] !== 'Country Extension' &&
    item['newportCategory'] !== 'Label Expansion' &&
    item['newportCategory'] !== 'Formulation Development' &&
    item['newportCategory'] !== 'New Active Substance Developments'
      ? true
      : false;

  const ftVisiblity =
    item['newportCategory'] !== 'Country Extension' && item['newportCategory'] !== 'Label Expansion'
      ? true
      : false;

  const recommendationVisibiltiy =
    item['newportCategory'] !== 'Country Extension' && item['newportCategory'] !== 'Label Expansion'
      ? true
      : false;

  const formulationDevelopmentForFT =
    item['newportCategory'] === 'Formulation Development' ||
    item['newportCategory'] === 'New Active Substance Developments' ||
    item['newportCategory'] === 'Third Party';

  const fsOptionsRecommendation = [
    'Continue Project',
    'Discontinue Project',
    'Place on hold',
    'Other (see FS Rationale)',
  ];
  if (
    item['newportCategory'] === 'Formulation Development' ||
    item['newportCategory'] === 'New Active Substance Developments'
  ) {
    fsOptionsRecommendation.unshift('FS work finalized');
  }
  return isEmptyView ? (
    <div className={classes.emptyView}>{emptyText} </div>
  ) : (
    <Fragment>
      <FormControl style={{ width: '100%' }}>
        <ValidatorForm onSubmit={onClick}>
          {test === 'technology' ? (
            <div>
              <div style={{ display: 'flex' }}>
                <div className={classes.label} id="demo-simple-select-label">
                  FT Responsibility
                </div>
                {hasAuditLog && (
                  <AuditLog
                    paths={path}
                    id={item.id}
                    customClass={classes.auditLog}
                    fieldName={responsiblityKey}
                  />
                )}
              </div>
              <FormControl style={displayStyle}>
                <Select
                  className={classes.customDropDownList}
                  labelId="demo-simple-select-label"
                  id="techResponsability"
                  name="techResponsability"
                  value={shownTechResponsability}
                  label="Age"
                  onChange={handleChange}
                >
                  <MenuItem value={'FT Monheim'}>FT Monheim </MenuItem>
                  <MenuItem value={'FT St. Louis'}>FT St. Louis </MenuItem>
                  <MenuItem value={'FT Japan'}>FT Japan </MenuItem>
                </Select>
              </FormControl>

              {visiblity && (
                <div>
                  <div style={{ display: 'flex' }}>
                    <div className={classes.label} id="demo-simple-select-label">
                      FT Status NF-PoC (Only NF-PoC Project)
                    </div>
                    {hasAuditLog && (
                      <AuditLog
                        paths={path}
                        id={item.id}
                        customClass={classes.auditLog}
                        fieldName={statusKey}
                      />
                    )}
                  </div>

                  <FormControl style={displayStyle}>
                    <Select
                      className={classes.customDropDownList}
                      labelId="demo-simple-select-label"
                      id="techStatus"
                      name="techStatus"
                      value={shownTechStatus}
                      label="Age"
                      onChange={handleChange}
                    >
                      <MenuItem value={'FT - work not started'}>FT - work not started </MenuItem>
                      <MenuItem value={'FT - work ongoing, no sample sent to AD yet'}>
                        FT - work ongoing, no sample sent to AD yet
                      </MenuItem>
                      <MenuItem value={'FT - work ongoing, sample sent to AD'}>
                        FT - work ongoing, sample sent to AD
                      </MenuItem>
                      <MenuItem value={'Other (see FT Rationale)'}>
                        Other (see FT Rationale)
                      </MenuItem>
                    </Select>
                  </FormControl>
                </div>
              )}

              {ftVisiblity &&
                (formulationDevelopmentForFT ? (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <div className={classes.label} id="demo-simple-select-label">
                        FT Recommendation
                      </div>
                      {hasAuditLog && (
                        <AuditLog
                          paths={path}
                          id={item.id}
                          customClass={classes.auditLog}
                          fieldName={ftrecommendationKey}
                        />
                      )}
                    </div>
                    <FormControl style={displayStyle}>
                      <Select
                        className={classes.customDropDownList}
                        labelId="demo-simple-select-label"
                        id="techRecommendation"
                        name="techRecommendation"
                        value={shownTechRecommendation}
                        label="Age"
                        onChange={handleChange}
                      >
                        <MenuItem value={'FT work finalized'}>FT work finalized</MenuItem>
                        <MenuItem value={'Continue Project'}>Continue Project</MenuItem>
                        <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                        <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                        <MenuItem value={'Other (see FT Rationale)'}>
                          Other (see FT Rationale)
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                ) : (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <div className={classes.label} id="demo-simple-select-label">
                        FT Recommendation
                      </div>
                      {hasAuditLog && (
                        <AuditLog
                          paths={path}
                          id={item.id}
                          customClass={classes.auditLog}
                          fieldName={ftrecommendationKey}
                        />
                      )}
                    </div>
                    <FormControl style={displayStyle}>
                      <Select
                        className={classes.customDropDownList}
                        labelId="demo-simple-select-label"
                        id="techRecommendation"
                        name="techRecommendation"
                        value={shownTechRecommendation}
                        label="Age"
                        onChange={handleChange}
                      >
                        <MenuItem value={'Continue POC'}>Continue POC</MenuItem>
                        <MenuItem value={'Promote to Formulation Development'}>
                          Promote to Formulation Development
                        </MenuItem>
                        <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                        <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                        <MenuItem value={'Other (see FT Rationale)'}>
                          Other (see FT Rationale)
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                ))}
            </div>
          ) : null}
          {test === 'solution' ? (
            <div>
              {visiblity && (
                <div>
                  <div style={{ display: 'flex' }}>
                    <div className={classes.label}>FS Objective (Only NF-PoC Project)</div>
                    {hasAuditLog && (
                      <AuditLog
                        paths={path}
                        id={item.id}
                        customClass={classes.auditLog}
                        fieldName={objectiveKey}
                      />
                    )}
                  </div>
                  <TextArea
                    value={shownSolObjective}
                    name="solObjective"
                    handleChange={handleChange}
                    rows="3"
                    isDisabled={!_.includes(editableFields, 'solObjective')}
                    textFiledClass={classes.textAreaField}
                  />
                </div>
              )}
              {visiblity && (
                <div>
                  <div style={{ display: 'flex' }}>
                    <div className={classes.label}>FS Result (Only NF-PoC Project)</div>
                    {hasAuditLog && (
                      <AuditLog
                        paths={path}
                        id={item.id}
                        customClass={classes.auditLog}
                        fieldName={resultKey}
                      />
                    )}
                  </div>
                  <TextArea
                    value={shownSolResult}
                    name="solResult"
                    handleChange={handleChange}
                    rows="3"
                    isDisabled={!_.includes(editableFields, 'solResult')}
                    textFiledClass={classes.textAreaField}
                  />
                </div>
              )}

              {recommendationVisibiltiy &&
                (formulationDevelopmentForFT ? (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <div className={classes.label}>FS Recommendation</div>
                      {hasAuditLog && (
                        <AuditLog
                          paths={path}
                          id={item.id}
                          customClass={classes.auditLog}
                          fieldName={recommendationKey}
                        />
                      )}
                    </div>

                    <FormControl style={displayStyle}>
                      <Select
                        className={classes.customDropDownList}
                        name={'solRecommendation'}
                        labelId="demo-simple-select-label"
                        id="solRecommendation"
                        value={shownSolRecommendation}
                        label="Age"
                        onChange={handleChange}
                      >
                        {fsOptionsRecommendation?.map(value => (
                          <MenuItem key={value} value={value}>
                            {value}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </div>
                ) : (
                  <div>
                    <div style={{ display: 'flex' }}>
                      <div className={classes.label}>FS Recommendation</div>
                      {hasAuditLog && (
                        <AuditLog
                          paths={path}
                          id={item.id}
                          customClass={classes.auditLog}
                          fieldName={recommendationKey}
                        />
                      )}
                    </div>

                    <FormControl style={displayStyle}>
                      <Select
                        className={classes.customDropDownList}
                        name={'solRecommendation'}
                        labelId="demo-simple-select-label"
                        id="solRecommendation"
                        value={shownSolRecommendation}
                        label="Age"
                        onChange={handleChange}
                      >
                        <MenuItem value={'Continue POC'}>Continue POC</MenuItem>
                        <MenuItem value={'Promote to Formulation Development'}>
                          Promote to Formulation Development
                        </MenuItem>
                        <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                        <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                        <MenuItem value={'Other (see FS Rationale)'}>
                          Other (see FS Rationale)
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                ))}
            </div>
          ) : null}

          <Fragment>
            {test === 'rsSubScore' && SegmentSubScores ? (
              <div className={classes.rsSubScorePannel}>
                <Grid item xs={10} style={{ textAlign: 'center' }}>
                  <div className={clsx(classes.propertyLabel, classes.rationaleLabel)}>
                    {Message.ptrs.rationale}
                  </div>
                </Grid>
                <Grid item xs={2} style={{ textAlign: 'center' }}>
                  <div className={clsx(classes.propertyLabel, classes.riskLabel)}>
                    {Message.ptrs.risk}
                  </div>
                </Grid>
              </div>
            ) : null}
            {getGridItem(
              item,
              SegmentSubScores,
              handleChange,
              editableFields,
              classes,
              rsSegmentSubScore,
              validatorListener,
              isValidate,
              shownScoreValue,
              scoreKey,
              hasAuditLog,
              path,
              scoreLabel,
              rationaleLabel,
              shownRationaleValue,
              rationaleKey,
              test,
              toCheckEditablityOfPtrsScore,
              checkingForWarningDisplayMessage,
            )}
          </Fragment>
          <Grid container item xs={11} spacing={1}>
            <Button
              type="submit"
              className={classes.button}
              variant="outlined"
              disabled={!isSaveAble}
            >
              {Message.button.save}
            </Button>
          </Grid>
        </ValidatorForm>
      </FormControl>
    </Fragment>
  );
};
