import _ from 'lodash';
import moment from 'moment';
import React from 'react';
import { useSelector } from 'react-redux';
import { typeState } from '@main/stateManagement/store';
import { toInteger, isValidateNumberValue, toDecimal } from '@shared/utils/numberUtils';
import { usePtrsEditPanelStyles } from '@main/components/PtrsEditPanel/UsePtrsEditPanelStyle';
import {
  FS_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_UPDATED_BY_FIELD,
  FS_PTRS_SCORE_UPDATED_DATE_FIELD,
  RS_REGULATORY_PTRS_SCORE_FIELD,
  RS_PTRS_SCORE_UPDATED_BY_FIELD,
  RS_PTRS_SCORE_UPDATED_DATE_FIELD,
  FT_PTRS_SCORE_FIELD,
  FT_PTRS_SCORE_MODIFIED_BY_FIELD,
  FT_PTRS_SCORE_MODIFIED_DATE_FIELD,
  FS_PTRS_SCORE_REMARK_FIELD,
  RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
  FT_PTRS_SCORE_REMARK_FIELD,
  SegmentSubScoresForNA,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY,
  RS_EFATE_PTRS_SCORE,
  RS_EFATE_REMARK_FIELD,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE,
  RS_EFATE_PTRS_SCORE_MODIFIED_BY,
  RS_EFATE_PTRS_SCORE_MODIFIED_DATE,
  RS_ECOTOX_PTRS_SCORE,
  RS_ECOTOX_REMARK_FIELD,
  RS_ECOTOX_PTRS_SCORE_MODIFIED_BY,
  RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE,
  RS_DIETARY_PTRS_SCORE,
  RS_DIETARY_REMARK_FIELD,
  RS_DIETARY_PTRS_SCORE_MODIFIED_BY,
  RS_DIETARY_PTRS_SCORE_MODIFIED_DATE,
  RS_TOXICOLOGY_PTRS_SCORE,
  RS_TOXICOLOGY_REMARK_FIELD,
  RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY,
  RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE,
  RS_REGISTRATION_PTRS_SCORE,
  RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY,
  RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE,
  // SegmentSubScoresForAPAC,
  RS_PRODUCT_PTRS_SCORE,
  RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD,
  RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE,
  RS_PRODUCT_REMARK_FEILD,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY,
  RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE,
  RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE,
  RS_FOREIGN_INFLUENZE_REMARK_FIELD,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE,
} from '@main/constants/segmentOptions';
import { FS_RECOMMENDATION_FEILD, FT_RECOMMENDATION_FIELD } from '../../constants/constants';
import {
  FS_RECOMMENDATION_MODIFIED_BY_FIELD,
  FS_RECOMMENDATION_MODIFIED_DATE_FIELD,
  FT_RECOMMENDATION_MODIFIED_BY_FIELD,
  FT_RECOMMENDATION_MODIFIED_DATE_FIELD,
} from '../../constants/projectOptions';

interface NewEntityType {
  version: number;
  [FS_PTRS_SCORE_FIELD]?: number;
  [FS_PTRS_SCORE_UPDATED_BY_FIELD]?: string;
  [FS_PTRS_SCORE_UPDATED_DATE_FIELD]?: string;
  byUser?: string;
}

export const usePtrsEditPanel = (props): Array<any> => {
  const classes = usePtrsEditPanelStyles();
  const {
    test,
    item,
    scoreKey,
    rationaleKey,
    handleClick,
    handleValueChangedForApplyButton = _.noop,
  } = props.itemRenderOptions;
  const scoreValue = item[scoreKey];
  const roleSuffix = _.get(item, 'region.roleSuffix');
  const SegmentSubScores = roleSuffix == 'NA' && SegmentSubScoresForNA;
  //for APAC subscores
  // if (roleSuffix == 'NA' || roleSuffix == 'APAC') {
  //   SegmentSubScores = roleSuffix == 'NA' ? SegmentSubScoresForNA : SegmentSubScoresForAPAC;
  // }
  const entity = {
    ...item,
  };

  const subScorePtrsScores = {};

  _.forEach(SegmentSubScores, scores => {
    subScorePtrsScores[scores.risk] = toInteger(_.get(item, scores.risk));
    subScorePtrsScores[scores.rationale] = _.get(item, scores.rationale);
  });

  entity[scoreKey] = toInteger(scoreValue) || '';
  const { version, id } = item;
  const [editEntity, setEntity] = React.useState<NewEntityType>({ version });
  const [shownEntity, setShownEntity] = React.useState(entity);
  const [rsSegmentSubScore, setRsSegmentSubScore] = React.useState(
    test === 'rsSubScore' && subScorePtrsScores,
  );
  const [isValidate, setValidate] = React.useState(true);
  const [isValidSubScore, setValidSubScore] = React.useState(true);
  const [checkingForWarningDisplayMessage, setWarningDisplayMessage] = React.useState(false);
  const userRolesStr = useSelector((state: typeState) => state.User.userName);
  const date = new Date();
  const lastDateModified = moment(date).format('YYYY-MM-DD');

  const validatorListener = isValid => {
    setValidSubScore(isValid);
  };

  const handleChange = event => {
    const { value, name, type } = event.target;
    type === 'number' && test !== 'rsSubScore' && setValidate(isValidateNumberValue(value));
    name === RS_REGULATORY_PTRS_SCORE_FIELD && setValidate(isValidateNumberValue(value));
    const newShownEntity = { ...shownEntity };
    newShownEntity[name] = value;
    setShownEntity(newShownEntity);
    if (test === 'rsSubScore' && SegmentSubScores) {
      const newRsSegmentSubScore = { ...rsSegmentSubScore };
      newRsSegmentSubScore[name] = value;
      setRsSegmentSubScore(newRsSegmentSubScore);
    }
    const newEntity: NewEntityType = { ...editEntity };
    newEntity[name] = type === 'number' ? toDecimal(value) : value;
    if (
      name === FS_PTRS_SCORE_FIELD ||
      name === FS_PTRS_SCORE_REMARK_FIELD ||
      name === FS_RECOMMENDATION_FEILD
    ) {
      newEntity[FS_PTRS_SCORE_UPDATED_BY_FIELD] = userRolesStr;
      newEntity[FS_PTRS_SCORE_UPDATED_DATE_FIELD] = lastDateModified;
      newEntity[FS_RECOMMENDATION_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[FS_RECOMMENDATION_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (
      name === RS_REGULATORY_PTRS_SCORE_FIELD ||
      name === RS_REGULATORY_PTRS_SCORE_REMARK_FIELD
    ) {
      newEntity[RS_PTRS_SCORE_UPDATED_BY_FIELD] = userRolesStr;
      newEntity[RS_PTRS_SCORE_UPDATED_DATE_FIELD] = lastDateModified;
    } else if (
      name === FT_PTRS_SCORE_FIELD ||
      name === FT_PTRS_SCORE_REMARK_FIELD ||
      name === FT_RECOMMENDATION_FIELD
    ) {
      newEntity[FT_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[FT_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
      newEntity[FT_RECOMMENDATION_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[FT_RECOMMENDATION_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (
      name === RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE ||
      name === RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD
    ) {
      newEntity[RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (name === RS_EFATE_PTRS_SCORE || name === RS_EFATE_REMARK_FIELD) {
      newEntity[RS_EFATE_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_EFATE_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (name === RS_ECOTOX_PTRS_SCORE || name === RS_ECOTOX_REMARK_FIELD) {
      newEntity[RS_ECOTOX_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (name === RS_DIETARY_PTRS_SCORE || name === RS_DIETARY_REMARK_FIELD) {
      newEntity[RS_DIETARY_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_DIETARY_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (name === RS_TOXICOLOGY_PTRS_SCORE || name === RS_TOXICOLOGY_REMARK_FIELD) {
      newEntity[RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (
      name === RS_REGISTRATION_PTRS_SCORE ||
      name === RS_REGULATORY_PTRS_SCORE_REMARK_FIELD
    ) {
      newEntity[RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (name === RS_PRODUCT_PTRS_SCORE || name === RS_PRODUCT_REMARK_FEILD) {
      newEntity[RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (
      name === RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE ||
      name === RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD
    ) {
      newEntity[RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (
      name === RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE ||
      name === RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD
    ) {
      newEntity[RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    } else if (
      name === RS_FOREIGN_INFLUENCE_PTRS_SCORE ||
      name === RS_FOREIGN_INFLUENZE_REMARK_FIELD
    ) {
      newEntity[RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY] = userRolesStr;
      newEntity[RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE] = lastDateModified;
    }
    newEntity.byUser =
      test === 'solution' &&
      name === 'fsPtrsScore' &&
      (item['newportCategory'] === 'Label Expansion' ||
        item['newportCategory'] === 'Country Extension')
        ? 'true'
        : '';

    setEntity(newEntity);
    handleValueChangedForApplyButton(newEntity[name]);

    const isNullCheckForFS = item[name] === 0 && newEntity[name] === null;
    const warningCheck =
      !(item['weightedFsScore'] == 0) &&
      test === 'solution' &&
      name === 'fsPtrsScore' &&
      item['fsPtrsScore'] !== newEntity[name] &&
      !isNullCheckForFS &&
      (item['newportCategory'] === 'Label Expansion' ||
        item['newportCategory'] === 'Country Extension') &&
      (newEntity[name] === '' || newEntity[name] === null)
        ? true
        : false;

    setWarningDisplayMessage(warningCheck);
  };

  const onClick = event => {
    handleClick({ entity: editEntity, id });
    event.preventDefault();
  };
  const shownSolObjective = shownEntity['solObjective'] || '';
  const shownSolResult = shownEntity['solResult'] || '';
  const shownSolRecommendation = shownEntity['solRecommendation'] || '';
  const shownTechResponsability = shownEntity['techResponsability'] || '';
  const shownTechStatus = shownEntity['techStatus'] || '';
  const shownTechRecommendation = shownEntity['techRecommendation'] || '';
  const shownScoreValue = shownEntity[scoreKey] || '';
  const shownRationaleValue = shownEntity[rationaleKey] || '';

  const isSaveAble =
    test === 'rsSubScore'
      ? isValidSubScore && !_.isEqual({ ...item, ...editEntity }, item)
      : isValidate && !_.isEqual({ ...item, ...editEntity }, item);

  const toCheckEditablityOfPtrsScore = test === 'rsSubScore' && roleSuffix === 'NA' ? true : false;
  return [
    classes,
    isValidate,
    isSaveAble,
    shownScoreValue,
    shownRationaleValue,
    shownSolObjective,
    shownSolResult,
    shownSolRecommendation,
    shownTechResponsability,
    shownTechStatus,
    shownTechRecommendation,
    onClick,
    handleChange,
    rsSegmentSubScore,
    validatorListener,
    SegmentSubScores,
    toCheckEditablityOfPtrsScore,
    checkingForWarningDisplayMessage,
    ,
  ];
};
