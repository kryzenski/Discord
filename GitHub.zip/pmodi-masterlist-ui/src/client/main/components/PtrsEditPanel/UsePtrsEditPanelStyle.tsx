import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';

export const usePtrsEditPanelStyles = makeStyles((theme: Theme) =>
  createStyles({
    emptyView: {
      marginTop: '6%',
      padding: 'inherit',
      marginLeft: '40%',
      height: 100,
      fontSize: '18px',
    },
    label: {
      marginLeft: '3%',
      marginTop: '1%',
      fontSize: '16px',
      color: 'black',
    },
    textField: {
      marginLeft: '20%',
      marginTop: '-10px',
      width: '30%',
    },
    auditLog: {
      marginTop: '2px',
    },
    segmentSubScoreAuditLog: {
      marginTop: '2px',
      marginLeft: '76%',
    },
    textAreaField: {
      marginLeft: '5%',
    },
    textAreaRationaleField: {
      width: '100%',
      marginTop: '0%',
      marginLeft: '15%',
      padding: 0,
    },
    customDropDownList: {
      paddingLeft: '15px',
      fontSize: '16px',
      color: 'black',
    },
    textRationaleField: {
      width: '100%',
      marginTop: '0%',
      marginLeft: '15%',
    },
    propertyLabel: {
      fontSize: '18px !important',
      paddingTop: '2%',
    },
    textRiskField: {
      width: '100%',
      marginLeft: '85%',
    },
    gridSpacing: {
      marginLeft: '3%',
      marginTop: '1%',
    },
    rsSubScorePannel: {
      display: 'flex',
    },
    rationaleLabel: {
      marginLeft: '25%',
      display: 'inline',
    },
    riskLabel: {
      display: 'inline',
    },
    button: {
      marginLeft: '100%',
      marginTop: theme.spacing(2),
    },
    warningMessage: {
      color: '#ff1a1a',
      fontSize: '16px',
      marginLeft: '-15%',
    },
  }),
);
