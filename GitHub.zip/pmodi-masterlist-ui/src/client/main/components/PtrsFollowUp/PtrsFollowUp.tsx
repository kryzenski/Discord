import React, { useState } from 'react';
import { Message } from '@shared/utils/message';
import { Checkbox, FormControlLabel } from '@material-ui/core';
import { usePtrsFollowUpStyle } from './UsePtrsFollowUpStyle';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '../../stateManagement/store';

export const PtrsFollowUpType = {
  PROJECT: 'project',
  SEGMENT: 'segment',
};

const isPtrsFollowUpChecked = entity => {
  return entity && entity.ptrsFollowUp && String(entity.ptrsFollowUp).toLowerCase() === 'true';
};

export const PtrsFollowUp = (props: any): JSX.Element => {
  const { entity, type } = props;
  const classes = usePtrsFollowUpStyle();
  const dispatch = useDispatch<typeDispatch>();
  const [isChecked, setIsChecked] = useState(isPtrsFollowUpChecked(entity));

  const handlePtrsFollowUpCheckChange = () => {
    if (type === PtrsFollowUpType.PROJECT) {
      dispatch.MasterList.updateProject({
        entity: { ...entity, ptrsFollowUp: !isChecked },
        id: entity.id,
      });
    } else if (type === PtrsFollowUpType.SEGMENT) {
      dispatch.MasterList.updateSegment({
        entity: { ...entity, ptrsFollowUp: !isChecked },
        id: entity.id,
      });
    }
    setIsChecked(!isChecked);
  };

  return (
    <div className={classes.ptrsFollowUpContainer}>
      <FormControlLabel
        control={
          <Checkbox
            name={Message.ptrs.ptrsFollowUp.label}
            checked={isChecked}
            onChange={() => handlePtrsFollowUpCheckChange()}
            color="primary"
          />
        }
        label={Message.ptrs.ptrsFollowUp.label}
      />
    </div>
  );
};
