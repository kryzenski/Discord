import { makeStyles } from '@material-ui/core/styles';

export const usePtrsFollowUpStyle = makeStyles(() => ({
  ptrsFollowUpContainer: {
    float: 'left',
    display: 'block',
    width: '100%',
    paddingLeft: '3%',
  },
}));
