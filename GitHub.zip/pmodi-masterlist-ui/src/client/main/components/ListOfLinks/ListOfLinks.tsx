import React from 'react';
import { linkStyle } from './ListOfLinksStyle';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';

export const ListOfLinks = (): JSX.Element => {
  const styles = linkStyle();

  return (
    <div className={styles.textField}>
      <Accordion className={styles.shadow}>
        <AccordionSummary
          expandIcon={<ArrowDropDownIcon />}
          aria-controls="panel2-content"
          id="panel2-header"
          className={styles.gapContainerSummary}
        >
          <Typography className={styles.linkTitleField}>Quick Links</Typography>
        </AccordionSummary>
        <AccordionDetails className={styles.gapContainer}>
          <Link
            href="https://bayergroup.sharepoint.com/sites/022356/Shared%20Documents/PRECISE"
            target="_blank"
            rel="noopener"
            underline="always"
          >
            <Typography className={styles.linkColor}>PRECISE User Manual</Typography>
          </Link>
        </AccordionDetails>
        <AccordionDetails className={styles.gapContainer}>
          <Link
            href="https://bayergroup.sharepoint.com/sites/022356/sitepages/HomePage.aspx"
            target="_blank"
            rel="noopener"
            underline="always"
          >
            <Typography className={styles.linkColor}>PortRes Portal</Typography>
          </Link>
        </AccordionDetails>
        <AccordionDetails className={styles.gapContainer}>
          <Link
            href="https://spotfire-app.monsanto.com/spotfire/login.html?targetUrl=%2Fspotfire%2Fwp%2FstartPage%23%2FlibraryBrowser%3Fid%3Df092f3db-37fc-4cc9-b381-4d79688a18dd#/"
            target="_blank"
            rel="noopener"
            underline="always"
          >
            <Typography className={styles.linkColor}>PortRes Dashboard</Typography>
          </Link>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};
