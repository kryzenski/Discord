import { makeStyles } from '@material-ui/core/styles';

export const linkStyle = makeStyles(() => ({
  textField: {
    marginTop: 'auto',
    marginLeft: '120px',
    width: '86%',
    justifyContent: 'end',
    display: 'flex',
  },

  shadow: {
    boxShadow: 'none',
  },
  unitTextField: {
    minWidth: '120px',
    height: '63px',
  },
  linkColor: {
    color: '#3f51b5',
    fontWeight: 500,
    fontSize: '14px',
  },
  ArrowDropDownIconSize: {
    height: '1.25rem',
    width: '1.25rem',
  },
  linkField: {
    color: '#3f51b5',
    fontWeight: 500,
  },

  linkTitleField: {
    color: '#3f51b5',
    fontWeight: 500,
    paddingLeft: '0px',
    fontSize: '1.25rem',
  },

  unit: {
    marginTop: '11px',
    color: '#3f51b5',
    background: '#fafafa',
    fontWeight: 500,
  },
  gapContainer: {
    background: '#fafafa',
    height: '31px',
    paddingBottom: '0px',
    // paddingTop: '0px',
    // minHeight: '41px',
  },
  gapContainerSummary: {
    background: '#fafafa',
    height: '31px',
    paddingBottom: '0px',
    // minHeight: '0px'
  },
  unitMargin: {
    marginLeft: '3% !important',
    width: '30%',
  },
}));
