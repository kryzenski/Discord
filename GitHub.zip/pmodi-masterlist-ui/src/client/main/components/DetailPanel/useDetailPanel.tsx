import React from 'react';
import { useDetailPanelStyles } from '@main/components/DetailPanel/UseDetailPanelStyles';

export const useDetailPanel = (props): Array<any> => {
  const classes = useDetailPanelStyles();
  const rows = [];
  if (props.items) {
    props.items.forEach((item, i) => {
      rows.push(
        <div className={classes.details} key={'row_' + i}>
          <div>
            <div className={classes.propertyLabel}>{item.label}</div>
          </div>

          <div>
            <div className={classes.propertyValue}>{item.value}</div>
          </div>
        </div>,
      );
    });
  }

  return [classes.detailsSet, rows];
};
