import { makeStyles } from '@material-ui/core/styles';

export const useDetailPanelStyles = makeStyles(() => ({
  details: {
    padding: '5px !important',
    marginBottom: '0px',
    display: 'inline-flex',
    width: '100%',
  },

  propertyLabel: {
    fontSize: '15px !important',
    fontWeight: 'bold',
    marginLeft: '5px',
    wordBreak: 'break-all',
  },

  propertyValue: {
    fontSize: '15px !important',
    fontWeight: 'normal',
    marginLeft: '5px',
  },

  detailsSet: {
    overflow: 'auto',
    padding: '0 10px 0 0',
    display: 'block',
    width: '50%',
    marginLeft: '30%',
    marginTop: '1%',
  },
}));
