import clsx from 'clsx';
import React from 'react';
import { useDetailPanel } from './useDetailPanel';
import { DetailPanelProps } from '@main/constants/types';

export const DetailPanel = (props: DetailPanelProps): JSX.Element => {
  const [detailsSetClass, rows] = useDetailPanel(props);
  return <div className={clsx(detailsSetClass, props.cssClass)}>{rows}</div>;
};
