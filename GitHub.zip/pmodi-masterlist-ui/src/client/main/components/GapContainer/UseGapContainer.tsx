import React from 'react';
import { useGapContainerStyle } from './UseGapContainerStyle';
import { BasicTextField } from '@shared/components/TextField/BasicTextField';
import _ from 'lodash';
import { GapItems } from '@main/constants/constants';
import { Message } from '@shared/utils/message';

const useItems = quickscanAssessments => {
  return _.map(GapItems, item => ({
    leftLabel: Message.gap[item.left],
    leftValue: quickscanAssessments[item.left],
    rightLabel: Message.gap[item.right],
    rightValue: quickscanAssessments[item.right],
    unit: quickscanAssessments[item.unit],
  }));
};

export const useGapContainer = (props): Array<any> => {
  const styles = useGapContainerStyle();
  const { itemRenderOptions, cssClass } = props;
  const items = useItems(itemRenderOptions);

  const DetailItem = _.map(items, item => (
    <div className={styles.details} key={item.leftLabel + 'divDetails'}>
      <div className={styles.propertyLabel} key={item.leftLabel + 'propertyLabel'}>
        {item.leftLabel}
      </div>
      <div className={styles.propertyValue} key={item.leftLabel + 'propertyValue'}>
        <BasicTextField
          value={item.leftValue}
          textFiledClass={styles.textField}
          key={item.leftLabel}
          isDisabled={true}
        />
      </div>
      <div
        className={styles.propertyLabel}
        style={{ marginLeft: '3%' }}
        key={item.rightLabel + 'propertyLabel'}
      >
        {item.rightLabel}
      </div>
      {item.unit && (
        <div className={styles.unit} key={item.unit + 'propertyLabel'}>
          <BasicTextField
            key={'unit'}
            value={item.unit}
            textFiledClass={styles.unitTextField}
            isDisabled={true}
          />
        </div>
      )}
      <div
        className={item.unit ? styles.unitMargin : styles.propertyValue}
        key={item.rightLabel + 'propertyValue'}
      >
        <BasicTextField
          key={item.rightLabel}
          value={item.rightValue}
          textFiledClass={styles.textField}
          isDisabled={true}
        />
      </div>
    </div>
  ));
  return [DetailItem, styles, cssClass];
};
