import { makeStyles } from '@material-ui/core/styles';

export const useGapContainerStyle = makeStyles(() => ({
  textField: {
    width: '100%',
  },
  textFieldLeft: {
    width: '97%',
    marginLeft: '-2%',
  },
  unitTextField: {
    width: '100%',
  },
  details: {
    padding: '5px !important',
    marginBottom: '0px',
    display: 'inline-flex',
    width: '100%',
  },

  propertyLabel: {
    fontSize: '15px !important',
    width: '10%',
    marginTop: '1%',
  },
  propertyLabelRegPrime: {
    fontSize: '15px !important',
    width: '20%',
    marginTop: '1%',
  },

  propertyValue: {
    width: '30%',
    marginLeft: '10% !important',
  },
  propertyValueRegPrime: {
    width: '30%',
  },
  unit: {
    width: '7%',
  },
  gapContainer: {
    width: '100%',
  },
  unitMargin: {
    marginLeft: '3% !important',
    width: '30%',
  },
}));
