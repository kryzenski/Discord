import React from 'react';
import clsx from 'clsx';
import { useGapContainer } from './UseGapContainer';
import { GapContainerProps } from '@main/constants/types';

export const GapContainer = (props: GapContainerProps): JSX.Element => {
  const [DetailItem, styles, cssClass] = useGapContainer(props);
  return <div className={clsx(styles.gapContainer, cssClass)}>{DetailItem}</div>;
};
