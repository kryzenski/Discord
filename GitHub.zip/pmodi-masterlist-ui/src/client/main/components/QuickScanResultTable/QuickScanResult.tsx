import React, { Fragment, useState } from 'react';
import { Message } from '@shared/utils/message';
import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import { useQuickScanResult } from './UseQuickScanResultTableOption';
import { QuickScanResultProps } from '@main/constants/types';
import { useQuickScanResultStyles } from './UseQucikScanResultStyle';
import Link from '@material-ui/core/Link';
import OpenInBrowserIcon from '@material-ui/icons/OpenInBrowser';
import { DIGIT_PATTERN } from '@shared/utils/functionUtils';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  FormControlLabel,
  Checkbox,
  FormControl,
  Select,
  MenuItem,
} from '@material-ui/core';
import { isNil } from 'lodash';
import { assessmentLink } from '@main/constants/constants';
import { SaveButton } from '~/shared/components/Buttons/SaveButton';

export const QuickScanResult = (props: QuickScanResultProps): JSX.Element => {
  const [open, setOpen] = useState(false);
  const [quickScanId, setQuickScanId] = useState('');
  const [
    titleClass,
    tableClass,
    tableOptions,
    hasTitle,
    onLinkAssessement,
    segmentData,
    onSaveReason,
    deleteQuickScanId,
    onDeleteQuickScanId,
    isDeleteClicked,
  ] = useQuickScanResult(props);
  const { quickScanNotApplicableReason, isQuickScanNotApplicable } = segmentData || '';
  const [isSaveEnable, setSaveEnable] = useState(true);
  const hasData = Array.isArray(tableOptions.data) && tableOptions.data.length > 0;
  const classes = useQuickScanResultStyles();
  const [notApplicableReason, setReason] = useState(
    isQuickScanNotApplicable ? quickScanNotApplicableReason : '',
  );
  const [isChecked, setIsChecked] = useState(isQuickScanNotApplicable && !hasData ? true : false);
  if (isNil(onLinkAssessement)) {
    return (
      <Fragment>
        {hasTitle && <h6 className={titleClass}>{Message.ptrs.quickScanResult} </h6>}
        <div className={tableClass}>
          <TableComponent itemRenderOptions={tableOptions} />
        </div>
      </Fragment>
    );
  }

  const msg = hasData ? '' : Message.ptrs.emptyQuickScan;
  const closeDialog = () => {
    setOpen(false);
  };
  const handleIdChange = event => {
    const input = event.target.value;
    if (input === '') {
      setQuickScanId(input);
    } else {
      const isNumber = DIGIT_PATTERN.test(input);
      if (isNumber) {
        setQuickScanId(input.length > 16 ? input.substring(0, 16) : input);
      }
    }
  };
  const onSave = () => {
    const reason = {
      notApplicable: isChecked,
      validReason: notApplicableReason,
    };
    onSaveReason(reason);
  };
  const reasonHandle = event => {
    const { value } = event.target;
    if (value !== quickScanNotApplicableReason) {
      setReason(value);
      setSaveEnable(false);
    }
  };
  const handleCheckbox = () => {
    setIsChecked(!isChecked);
  };

  return (
    <Fragment>
      <div className={classes.notApplicable}>
        {hasTitle && <h6 className={titleClass}>{Message.ptrs.quickScanResult} </h6>}
        <FormControlLabel
          className={classes.notApplicableCheckbox}
          label={Message.ptrs.notApplicable}
          control={
            <Checkbox
              checked={isChecked}
              name={Message.ptrs.notApplicable}
              onChange={handleCheckbox}
              color={'primary'}
            />
          }
        />
        {isChecked && (
          <FormControl className={classes.displayStyle}>
            <Select name="notApplicableReason" value={notApplicableReason} onChange={reasonHandle}>
              <MenuItem value={'Country out of scope'}>Country out of scope</MenuItem>
              <MenuItem value={'Use not yet in QuickScan (e.g. Greenhouse, Drone)'}>
                Use not yet in QuickScan (e.g. Greenhouse, Drone)
              </MenuItem>
              <MenuItem value={'No endpoints available yet (new or newly inlicenced a.i.)'}>
                No endpoints available yet (new or newly inlicenced a.i.)
              </MenuItem>
              <MenuItem value={'New Formulation'}>New Formulation</MenuItem>
              <MenuItem value={'Biologics, Safener, Fertilizer (out of scope of QuickScan)'}>
                Biologics, Safener, Fertilizer (out of scope of QuickScan)
              </MenuItem>
              <MenuItem
                value={
                  'Crop not covered in QuickScan (should first check if a surrogate crop could be used)'
                }
              >
                Crop not covered in QuickScan (should first check if a surrogate crop could be used)
              </MenuItem>
              <MenuItem value={'Other reasons'}>Other reasons</MenuItem>
            </Select>
          </FormControl>
        )}
      </div>

      {!isChecked && (
        <div className={classes.quickScanTop}>
          <div className={classes.quickScanTopLeft}>{msg}</div>
          <Button
            className={classes.quickScanTopRight}
            variant="outlined"
            onClick={() => {
              setOpen(true);
              setQuickScanId('');
            }}
          >
            {Message.ptrs.linkQuickScan}
          </Button>
        </div>
      )}
      {hasData && !isChecked && (
        <div className={tableClass}>
          <TableComponent itemRenderOptions={tableOptions} />
        </div>
      )}
      <Dialog fullWidth onClose={closeDialog} aria-labelledby="simple-dialog-title" open={open}>
        <DialogTitle id="simple-dialog-title">
          <span style={{ display: 'flex' }}>
            {Message.ptrs.linkDialog.title}
            <span style={{ flexGrow: 1 }}> </span>
            <Typography variant="subtitle1">
              <Link href={assessmentLink} target="_blank" rel="noopener noreferrer">
                {Message.ptrs.linkDialog.assessmentLinkLabel}
                <OpenInBrowserIcon className={classes.linkIcon} />
              </Link>
            </Typography>
          </span>
        </DialogTitle>
        <DialogContent dividers>
          <TextField
            id="qid"
            fullWidth
            label={Message.ptrs.linkDialog.label}
            variant="outlined"
            value={quickScanId}
            onChange={handleIdChange}
          />
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" onClick={closeDialog} color="primary">
            {Message.ptrs.linkDialog.cancel}
          </Button>
          <Button
            variant="outlined"
            onClick={() => {
              onLinkAssessement(quickScanId === '' ? null : Number(quickScanId));
              closeDialog();
            }}
            color="primary"
            autoFocus
          >
            {Message.ptrs.linkDialog.submit}
          </Button>
        </DialogActions>
      </Dialog>
      {(isDeleteClicked || isChecked) && (
        <SaveButton
          isDisabled={isChecked ? isSaveEnable : false}
          onClick={() => {
            isDeleteClicked ? onDeleteQuickScanId(deleteQuickScanId) : '';
            isChecked ? onSave() : '';
          }}
        />
      )}
    </Fragment>
  );
};
