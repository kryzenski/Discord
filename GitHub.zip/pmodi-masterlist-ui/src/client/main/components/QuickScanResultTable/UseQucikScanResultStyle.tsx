import { makeStyles, createStyles } from '@material-ui/core/styles';

export const useQuickScanResultStyles = makeStyles(() =>
  createStyles({
    circle: {
      borderRadius: '50%',
      height: '30px',
      width: '30px',
      display: 'inline-block',
    },
    quickSanTitle: {
      marginBottom: '1%',
      fontSize: '1.25rem',
      fontWeight: 500,
      marginLeft: '3%',
      marginTop: '1%',
    },
    linkStyle: {
      paddingLeft: 0,
    },
    quickScanTop: {
      display: 'block',
      height: '40px',
      marginLeft: '5%',
    },
    quickScanTopLeft: {
      float: 'left',
      marginTop: '10px',
    },
    notApplicable: {
      display: 'inline-flex',
      width: '100%',
    },
    notApplicableCheckbox: {
      marginLeft: '10%',
    },
    quickScanTopRight: {
      marginLeft: '35%',
      marginTop: '-1%',
    },
    subTableTitle: {
      fontSize: '16px',
      marginLeft: '-3%',
      marginTop: '1%',
    },
    detailPanel: {
      marginLeft: '4%',
      marginTop: '1%',
      borderRadius: '4px',
      borderColor: '#737373',
      width: '94%',
    },
    subTable: {
      marginTop: '-1%',
      marginBottom: '3%',
    },
    quickTable: {
      marginLeft: '5%',
      width: '90%',
      marginBottom: '1%',
    },
    linkIcon: {
      marginLeft: '5px',
      verticalAlign: 'middle',
    },
    displayStyle: {
      marginLeft: '20%',
      width: '40%',
      marginTop: '1%',
    },
    mitigateIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'green',
    },
    stopIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'red',
    },
    goAheadIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'green',
    },
    notMitigateIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'gray',
    },
    noGoAheadIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'gray',
    },
    notStopIconStyle: {
      height: '1.3em',
      width: '1.3em',
      color: 'gray',
    },
    customTooltip: {
      margin: '0px',
      fontSize: '13px',
    },
    confirmMassage: {
      margin: '0px',
      fontSize: '13px',
    },
  }),
);
