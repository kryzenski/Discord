import { useQuickScanResultStyles } from '@main/components/QuickScanResultTable/UseQucikScanResultStyle';
import IconButton from '@material-ui/core/IconButton';
import LinkIcon from '@material-ui/icons/Link';
import DeleteIcon from '@material-ui/icons/Delete';
import OpenInBrowserIcon from '@material-ui/icons/OpenInBrowser';
import { cellStyleForQuickScan } from '@main/constants/constants';
import React, { Fragment } from 'react';
import DateUtils from '@shared/utils/dateUtils';
import ReportProblemOutlinedIcon from '@material-ui/icons/ReportProblemOutlined';
import CheckCircleOutlineSharpIcon from '@material-ui/icons/CheckCircleOutlineSharp';
import NotInterestedSharpIcon from '@material-ui/icons/NotInterestedSharp';
import Tooltip from '@material-ui/core/Tooltip';

export const getquickScanTableColumn = (hasActions, onDeleteLinkAssessment) => {
  const classes = useQuickScanResultStyles();

  const checkMitigate: any = checkMitigate => {
    let icon: any = null;
    let isMitigationConfirmed: any = null;
    if (checkMitigate !== null) {
      if (
        checkMitigate &&
        checkMitigate['expertDecision'] &&
        checkMitigate?.expertDecision === 'MITIGATE'
      ) {
        isMitigationConfirmed = checkMitigate?.reviewStatus === 'IN_PROGRESS' ? true : false;
        icon = (
          <div>
            <Tooltip
              title={
                isMitigationConfirmed ? (
                  <p className={classes.customTooltip}>MITIGATE To be confirmed by GRM</p>
                ) : (
                  <p className={classes.customTooltip}>{checkMitigate?.expertDecision} Confirmed</p>
                )
              }
              placement="top-start"
            >
              <ReportProblemOutlinedIcon
                className={
                  isMitigationConfirmed ? classes.notMitigateIconStyle : classes.mitigateIconStyle
                }
              />
            </Tooltip>
          </div>
        );
      } else if (
        checkMitigate &&
        checkMitigate['expertDecision'] &&
        checkMitigate?.expertDecision === 'STOP'
      ) {
        isMitigationConfirmed = checkMitigate?.reviewStatus === 'IN_PROGRESS' ? true : false;
        icon = (
          <Tooltip
            title={
              isMitigationConfirmed ? (
                <p className={classes.customTooltip}>
                  {checkMitigate?.expertDecision} To be confirmed by GRM
                </p>
              ) : (
                <p className={classes.customTooltip}>{checkMitigate?.expertDecision} Confirmed</p>
              )
            }
            placement="top-start"
          >
            <NotInterestedSharpIcon
              className={isMitigationConfirmed ? classes.notStopIconStyle : classes.stopIconStyle}
            />
          </Tooltip>
        );
      } else if (
        checkMitigate &&
        checkMitigate['expertDecision'] &&
        checkMitigate?.expertDecision.toLowerCase().includes('go')
      ) {
        isMitigationConfirmed = checkMitigate?.reviewStatus === 'IN_PROGRESS' ? true : false;
        icon = (
          <Tooltip
            title={
              isMitigationConfirmed ? (
                <p className={classes.customTooltip}>GO AHEAD To be confirmed by GRM</p>
              ) : (
                <p className={classes.customTooltip}>GO AHEAD Confirmed</p>
              )
            }
            placement="top-start"
          >
            <CheckCircleOutlineSharpIcon
              className={
                isMitigationConfirmed ? classes.noGoAheadIconStyle : classes.goAheadIconStyle
              }
            />
          </Tooltip>
        );
      } else {
        icon = null;
      }
    }
    return icon;
  };

  const columns = [
    {
      title: 'Link',
      field: 'url',
      width: '3%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => (
        <IconButton
          onClick={() => window.open(rowData.url)}
          color="inherit"
          className={classes.linkStyle}
        >
          {rowData.url && (
            <Fragment>
              <LinkIcon />
              <OpenInBrowserIcon />
            </Fragment>
          )}
        </IconButton>
      ),
    },
    {
      title: 'Creation Date',
      field: 'createdAt',
      width: '8%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData =>
        DateUtils.getStringFromDatePattern(
          DateUtils.getDateFormatForAssessment(),
          rowData.createdAt,
          false,
        ),
    },
    {
      title: 'Product',
      field: 'productLineText',
      width: hasActions === 'gapSegmentInfo' ? '40%' : '37%',
    },
    {
      title: 'Crop',
      field: 'cropText',
      width: hasActions === 'gapSegmentInfo' ? '20%' : '15%',
    },
    {
      title: 'Country',
      field: 'countryName',
      width: hasActions === 'gapSegmentInfo' ? '20%' : '15%',
    },
    {
      title: 'Fish',
      field: 'fishRiskColor',
      width: '5%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => {
        // <div className={classes.circle} style={{ backgroundColor: rowData.fishRiskColor }}></div>
        const isMitigationPresent = checkMitigate(
          rowData['mitigationDetail'] !== undefined
            ? {
                ...rowData?.mitigationDetail[0]?.generalReviewDetails?.mitigationDetails
                  ?.mitigations['fish'],
                reviewStatus: rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewStatus,
              }
            : '',
        );
        return (
          <div>
            {isMitigationPresent !== null ? (
              isMitigationPresent
            ) : (
              <div
                className={classes.circle}
                style={{ backgroundColor: rowData.fishRiskColor }}
              ></div>
            )}
          </div>
        );
      },
    },
    {
      title: 'Birds',
      field: 'birdsMammalsRiskColor',
      width: '5%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => {
        const isMitigationPresent = checkMitigate(
          rowData['mitigationDetail'] !== undefined
            ? {
                ...rowData?.mitigationDetail[0]?.generalReviewDetails?.mitigationDetails
                  ?.mitigations['birdsAndMammals'],
                reviewStatus: rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewStatus,
              }
            : '',
        );
        return (
          <div>
            {isMitigationPresent !== null ? (
              isMitigationPresent
            ) : (
              <div
                className={classes.circle}
                style={{ backgroundColor: rowData.birdsMammalsRiskColor }}
              ></div>
            )}
          </div>
        );
      },
    },
    {
      title: 'Bees',
      field: 'beesRiskColor',
      width: '5%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => {
        const isMitigationPresent = checkMitigate(
          rowData['mitigationDetail'] !== undefined
            ? {
                ...rowData?.mitigationDetail[0]?.generalReviewDetails?.mitigationDetails
                  ?.mitigations['bees'],
                reviewStatus: rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewStatus,
              }
            : '',
        );
        return (
          // <div className={classes.circle} style={{ backgroundColor: rowData.beesRiskColor }}></div>
          <div>
            {isMitigationPresent !== null ? (
              isMitigationPresent
            ) : (
              <div
                className={classes.circle}
                style={{ backgroundColor: rowData.beesRiskColor }}
              ></div>
            )}
          </div>
        );
      },
    },
    {
      title: 'Operator',
      field: 'operatorRiskColor',
      width: '5%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => {
        const isMitigationPresent = checkMitigate(
          rowData['mitigationDetail'] !== undefined
            ? {
                ...rowData?.mitigationDetail[0]?.generalReviewDetails?.mitigationDetails
                  ?.mitigations['operator'],
                reviewStatus: rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewStatus,
              }
            : '',
        );
        return (
          // <div className={classes.circle} style={{ backgroundColor: rowData.operatorRiskColor }}></div>
          <div>
            {isMitigationPresent !== null ? (
              isMitigationPresent
            ) : (
              <div
                className={classes.circle}
                style={{ backgroundColor: rowData.operatorRiskColor }}
              ></div>
            )}
          </div>
        );
      },
    },
    {
      title: 'Dietary',
      field: 'dietaryRiskColor',
      width: '5%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => {
        // <div className={classes.circle} style={{ backgroundColor: rowData.dietaryRiskColor }}></div>
        const isMitigationPresent = checkMitigate(
          rowData['mitigationDetail'] !== undefined
            ? {
                ...rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewDetails?.reviews[
                  'dietary'
                ],
                reviewStatus: rowData?.mitigationDetail[0]?.generalReviewDetails?.reviewStatus,
              }
            : '',
        );
        return (
          <div>
            {isMitigationPresent !== null ? (
              isMitigationPresent
            ) : (
              <div
                className={classes.circle}
                style={{ backgroundColor: rowData.dietaryRiskColor }}
              ></div>
            )}
          </div>
        );
      },
    },
  ];
  const segmentColumn = [
    {
      title: 'QuickScan ID',
      field: 'id',
      width: hasActions === 'gapSegmentInfo' ? '20%' : '16%',
    },
    {
      title: 'Actions',
      field: 'delete',
      width: '3%',
      hidden: hasActions === 'gapSegmentInfo' ? true : false,
      render: rowData => (
        <IconButton onClick={() => onDeleteLinkAssessment(rowData.id)} color="inherit">
          <DeleteIcon />
        </IconButton>
      ),
    },
  ];

  if (hasActions === 'segment') {
    columns.unshift(...segmentColumn);
  }
  if (hasActions === 'gapSegmentInfo') {
    columns.unshift(...segmentColumn);
  }
  const projectColumn: any = [
    {
      title: 'QuickScan ID',
      field: 'id',
      width: '16%',
    },
    {
      title: 'Applicable',
      field: 'isQuickScanNotApplicable',
      width: '12%',
      render: rowData => <div>{rowData.isQuickScanNotApplicable ? 'No' : 'Yes'}</div>,
    },
    {
      title: 'Reason',
      field: 'quickScanNotApplicableReason',
      width: '20%',
    },
  ];
  if (hasActions === 'assessment' || hasActions === 'segmentPtrs') {
    columns.unshift(...projectColumn);
  }
  return columns.map(column => ({
    ...column,
    cellStyleForQuickScan,
  }));
};
