import React from 'react';
import { Message } from '@shared/utils/message';

export const EmptyView = ({ cssClass }: { cssClass?: string }) => {
  return <div className={cssClass}>{Message.ptrs.emptyQuickScan}</div>;
};
