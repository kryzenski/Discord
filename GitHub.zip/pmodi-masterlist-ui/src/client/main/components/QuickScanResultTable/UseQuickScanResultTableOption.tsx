import _ from 'lodash';
import { useQuickScanResultStyles } from '@main/components/QuickScanResultTable/UseQucikScanResultStyle';
import { getquickScanTableColumn } from '@main/components/QuickScanResultTable/UseColumns';
import clsx from 'clsx';
import { useState } from 'react';

export const useQuickScanResult = (props): Array<any> => {
  const classes = useQuickScanResultStyles();
  const {
    quickScanData,
    detailPanel,
    hasTitle = true,
    cssClass,
    quickScanAssessmentId,
    onLinkAssessement,
    segmentData,
    type,
    onSaveReason,
    onDeleteQuickScanId,
  } = props;
  const [quickScanAssessment, setQuickScanData] = useState(quickScanData);
  const [listOfIds, setListOfIds] = useState(quickScanAssessmentId);
  const [isDeleteClicked, setisDeleteClicked] = useState(false);
  const onDeleteLinkAssessment = deleteId => {
    setisDeleteClicked(true);
    const quickScanRow: any = _.filter(quickScanAssessment, item => item.id !== deleteId);
    setQuickScanData(quickScanRow);
    const id = _.toString(deleteId);
    const arr = _.split(listOfIds, ',');
    const tempId = _.filter(arr, item => item !== id);
    const idNotDeleted = _.join(tempId, ',');
    setListOfIds(idNotDeleted);
  };
  const tableOptions = {
    columns: getquickScanTableColumn(type, onDeleteLinkAssessment),
    data: quickScanAssessment,
    toolbar: false,
    detailPanel,
  };

  return [
    classes.quickSanTitle,
    clsx(classes.quickTable, cssClass),
    tableOptions,
    hasTitle,
    onLinkAssessement,
    segmentData,
    onSaveReason,
    listOfIds,
    onDeleteQuickScanId,
    isDeleteClicked,
  ];
};
