import React from 'react';
import { quickScanMitigationStyle } from './QuickScanMitigationStyle';
import Box from '@material-ui/core/Box';
import _ from 'lodash';
import { Typography } from '@material-ui/core';
import Tooltip from '@material-ui/core/Tooltip';
import { TableComponent } from '~/shared/components/TableComponent/TableComponent';
import { cellStyleMitigation } from '@main/constants/constants';

export const QuickScanMitigation = (props: any): JSX.Element => {
  const style = quickScanMitigationStyle();
  const { itemRenderOptions } = props;
  // const mitigationContent = require('./case1.json');
  let mitigations = itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails?.mitigations
    ? itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails?.mitigations
    : {};
  const reviewDetails = itemRenderOptions[0]?.generalReviewDetails?.reviewDetails;
  mitigations = { ...mitigations, ...reviewDetails?.reviews };
  // console.log('mitigations', mitigations);
  const typesOfMitigationList = itemRenderOptions[0]?.typesOfMitigation;
  const typeAndOption = [];
  const typeOfMitigations = () => {
    if (mitigations) {
      Object?.keys(mitigations).map(function(key) {
        if (key !== null) {
          const keyOptions = itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails
            ?.mitigations[key]?.options
            ? itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails?.mitigations[key]
                ?.options
            : '';
          if (key === 'birdsAndMammals') {
            key = 'birds and mammals';
          }
          let concatTypes: any = '';
          let concatValues = '';
          _.map(keyOptions, optionId => {
            _.map(typesOfMitigationList, typeOfMitigationValue => {
              if (typeOfMitigationValue['id'] === optionId) {
                const mitigationOptionValues = {
                  type: `${typeOfMitigationValue['type']}`,
                  value: typeOfMitigationValue['value'],
                  key: `${key}`,
                };
                typeAndOption.push(mitigationOptionValues);
                concatValues += `${typeOfMitigationValue['value']}, `;
                concatTypes = `${typeOfMitigationValue['type']}`;
              } else {
              }
            });
          });

          return (
            <div>
              <Tooltip
                title={
                  concatTypes != '' ? <p className={style.customTooltip}>{concatTypes}</p> : ''
                }
                placement="top-start"
              >
                <Typography className={style.typeOfMitigationPpeText}>
                  {concatTypes !== '' ? concatTypes : <span>&nbsp;</span>}
                </Typography>
              </Tooltip>

              <Box my={4} p={2} className={style.typeOfMitigationText}>
                <Tooltip
                  title={<p className={style.customTooltip}>{concatValues}</p>}
                  placement="top-start"
                >
                  <Typography className={style.typeOfMitigationConcatValues}>
                    {concatValues}
                  </Typography>
                </Tooltip>
              </Box>
            </div>
          );
        }
      });
    }

    const multipleValues = [
      {
        request: 'fish',
        uniqueValues: typeAndOption.filter(obj => {
          return obj.key === 'fish';
        }),
      },
      {
        request: 'bees',
        uniqueValues: typeAndOption.filter(obj => {
          return obj.key === 'bees';
        }),
      },
      {
        request: 'birds and mammals',
        uniqueValues: typeAndOption.filter(obj => {
          return obj.key === 'birds and mammals';
        }),
      },
      {
        request: 'operator',
        uniqueValues: typeAndOption.filter(obj => {
          return obj.key === 'operator';
        }),
      },
      {
        request: 'dietary',
        uniqueValues: typeAndOption.filter(obj => {
          return obj.key === 'dietary';
        }),
      },
    ];

    const finalArray = [];
    _.map(multipleValues, options => {
      const key = options.request;
      _.map(options.uniqueValues, uniqueOptions => {
        const concatValues = {
          key: key,
          type: '',
          value: '',
        };
        if (uniqueOptions.type) {
          if (finalArray.length === 0) {
            concatValues.type = uniqueOptions.type;
            concatValues.value = uniqueOptions.value;
            finalArray.push(concatValues);
          } else if (finalArray.length > 0) {
            let isPresent = false;
            _.map(finalArray, finalValue => {
              if (finalValue.type === uniqueOptions.type && finalValue.key === key) {
                finalValue.value += `, ${uniqueOptions.value}`;
                isPresent = true;
              } else {
              }
            });
            if (!isPresent) {
              finalArray.push({ key: key, type: uniqueOptions.type, value: uniqueOptions.value });
            }
          } else {
          }
        }
      });
    });

    const finalTypeOfValues = [
      {
        request: mitigations['fish'] ? 'FISH' : '',
        uniqueValues: finalArray.filter(obj => {
          return obj.key === 'fish';
        }),
      },
      {
        request: mitigations['bees'] ? 'BEES' : '',
        uniqueValues: finalArray.filter(obj => {
          return obj.key === 'bees';
        }),
      },
      {
        request: mitigations['birdsAndMammals'] ? 'BIRDS AND MAMMALS' : '',
        uniqueValues: finalArray.filter(obj => {
          return obj.key === 'birds and mammals';
        }),
      },
      {
        request: mitigations['operator'] ? 'OPERATOR' : '',
        uniqueValues: finalArray.filter(obj => {
          return obj.key === 'operator';
        }),
      },
      {
        request: mitigations['dietary'] ? 'DIETARY' : '',
        uniqueValues: finalArray.filter(obj => {
          return obj.key === 'dietary';
        }),
      },
    ];

    const getSubTableColumn = () => {
      const columns = [
        {
          title: 'Protection goal',
          field: 'request',
          width: '12%',
          cellStyle: {
            paddingBottom: '0px',
            paddingRight: '0px',
            paddingTop: '13px',
          },
        },
        {
          title: 'Type of mitigation',
          field: 'request',
          width: '42%',
          cellStyle: {
            padding: '8px 0px 0px 7px',
          },
          headerStyle: {
            paddingLeft: '7px',
          },
          render: rowData => {
            const finalTypeOfValues = rowData;
            const key = finalTypeOfValues?.request?.toLowerCase();
            return (
              <div className={style.mitigationTypes}>
                <div key={key}>
                  {finalTypeOfValues?.request !== '' ? (
                    <div
                      key={finalTypeOfValues.request}
                      className={`${style.mitigationRow} ${style.lastDiv}`}
                    >
                      <div className={style.mitigationColTwo}>
                        {finalTypeOfValues.uniqueValues.map(function(data, i) {
                          const isLastIndex = i === finalTypeOfValues.uniqueValues?.length - 1;
                          return (
                            <div
                              key={data.type}
                              className={isLastIndex ? style.lastText : style.allText}
                            >
                              <Tooltip
                                title={<p className={style.customTooltip}>{data.type}</p>}
                                placement="top-start"
                              >
                                <Typography className={style.typeOfMitigationPpeText}>
                                  {data.type}
                                </Typography>
                              </Tooltip>

                              <Box my={4} p={2} className={style.typeOfMitigationText}>
                                <Tooltip
                                  title={<p className={style.customTooltip}>{data.value}</p>}
                                  placement="top-start"
                                >
                                  <Typography className={style.typeOfMitigationConcatValues}>
                                    {data.value}
                                  </Typography>
                                </Tooltip>
                              </Box>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <p className={style.empty}></p>
                  )}
                </div>
              </div>
            );
          },
        },
        {
          title: 'Comment',
          field: 'request',
          width: '23%',
          cellStyle: {
            padding: '8px 0px 0px 7px',
          },
          headerStyle: {
            paddingLeft: '7px',
          },
          render: rowData => {
            const finalTypeOfValues = rowData;
            return (
              <div className={style.mitigationTypes}>
                <div key={finalTypeOfValues.request}>
                  {finalTypeOfValues?.request !== '' ? (
                    <div key={finalTypeOfValues.request} className={style.mitigationRow}>
                      <div className={style.mitigationColThree}>
                        <Box my={4} display="flex" p={2} className={style.textField}>
                          <Tooltip
                            title={
                              <p className={style.customTooltip}>
                                {
                                  mitigations[finalTypeOfValues.request.toLowerCase()]
                                    ?.expertComment
                                }
                              </p>
                            }
                            disableHoverListener={
                              !mitigations[finalTypeOfValues.request.toLowerCase()]?.expertComment
                            }
                            placement="top-start"
                          >
                            <p className={style.mitigationPara}>
                              {
                                mitigations[
                                  finalTypeOfValues.request.toLowerCase().includes('birds')
                                    ? 'birdsAndMammals'
                                    : finalTypeOfValues.request.toLowerCase()
                                ]?.expertComment
                              }
                            </p>
                          </Tooltip>
                        </Box>
                      </div>
                    </div>
                  ) : (
                    <p className={style.empty}></p>
                  )}
                </div>
              </div>
            );
          },
        },
        // {
        //   title: 'General Comment Ensa',
        //   field: 'request',
        //   width: '20%',
        //   cellStyle: {
        //     borderBottom: '#ffff',
        //     padding: '8px 0px 0px 7px',
        //   },
        //   headerStyle: {
        //     paddingLeft: '7px',
        //   },
        //   render: rowData => {
        //     const finalTypeOfValues = rowData;
        //     return (
        //       <div className={style.mitigationTypes}>
        //         <div key={finalTypeOfValues.request}>
        //           {finalTypeOfValues?.request !== '' ? (
        //             <div key={finalTypeOfValues.request} className={style.mitigationRow}>
        //               <div className={style.mitigationColThree}>
        //                 <Box my={4} display="flex" p={2} className={style.textField}>
        //                   <Tooltip
        //                     title={
        //                       <p className={style.customTooltip}>
        //                         {finalTypeOfValues?.comments?.ensa}
        //                       </p>
        //                     }
        //                     disableHoverListener={
        //                       !mitigations[finalTypeOfValues.request.toLowerCase()]?.expertComment
        //                     }
        //                     placement="top-start"
        //                   >
        //                     <p className={style.mitigationPara}>
        //                       {finalTypeOfValues?.comments?.ensa}
        //                     </p>
        //                   </Tooltip>
        //                 </Box>
        //               </div>
        //             </div>
        //           ) : (
        //             <p className={style.empty}></p>
        //           )}
        //         </div>
        //       </div>
        //     );
        //   },
        // },
        // {
        //   title: 'General Comment ORE',
        //   field: 'request',
        //   width: '20%',
        //   cellStyle: {
        //     borderBottom: '#ffff',
        //     padding: '8px 0px 0px 7px',
        //   },
        //   rowspan: '2',
        //   headerStyle: {
        //     paddingLeft: '7px',
        //   },
        //   render: rowData => {
        //     const finalTypeOfValues = rowData;
        //     return (
        //       <div className={style.mitigationTypes}>
        //         <div key={finalTypeOfValues.request}>
        //           {finalTypeOfValues?.request !== '' ? (
        //             <div key={finalTypeOfValues.request} className={style.mitigationRow}>
        //               <div className={style.mitigationColThree}>
        //                 <Box my={4} display="flex" p={2} className={style.textField}>
        //                   <Tooltip
        //                     title={
        //                       <p className={style.customTooltip}>
        //                         {finalTypeOfValues?.comments?.orxe}
        //                       </p>
        //                     }
        //                     disableHoverListener={
        //                       !mitigations[finalTypeOfValues.request.toLowerCase()]?.expertComment
        //                     }
        //                     placement="top-start"
        //                   >
        //                     <p className={style.mitigationPara}>
        //                       {finalTypeOfValues?.comments?.orxe}
        //                     </p>
        //                   </Tooltip>
        //                 </Box>
        //               </div>
        //             </div>
        //           ) : (
        //             <p className={style.empty}></p>
        //           )}
        //         </div>
        //       </div>
        //     );
        //   },
        // },
        {
          title: 'General Comment',
          field: 'request',
          width: '23%',
          cellStyle: rowData => {
            const finalTypeOfValues = rowData;
            if (
              (finalTypeOfValues && finalTypeOfValues === 'OPERATOR') ||
              (finalTypeOfValues && finalTypeOfValues === 'DIETARY')
            ) {
              return {
                borderTop: '1px solid rgba(224, 224, 224, 1)',
                padding: '0px',
              };
            } else {
              return {
                borderBottom: '#ffff',
                padding: '0px',
              };
            }
          },
          headerStyle: {
            paddingLeft: '7px',
          },
          render: rowData => {
            const finalTypeOfValues = rowData;
            return (
              <div className={style.mitigationTypes}>
                <div key={finalTypeOfValues.request}>
                  {finalTypeOfValues?.request !== '' ? (
                    <div key={finalTypeOfValues.request} className={style.mitigationRow}>
                      <div className={style.mitigationColThree}>
                        <Box my={4} display="flex" p={2} className={style.textField}>
                          <Tooltip
                            title={
                              <p className={style.customTooltip}>
                                {finalTypeOfValues?.comments?.ensa}
                                {finalTypeOfValues?.comments?.orxe}
                                {finalTypeOfValues?.comments?.dsa}
                              </p>
                            }
                            disableHoverListener={
                              !mitigations[finalTypeOfValues.request.toLowerCase()]?.expertComment
                            }
                            placement="top-start"
                          >
                            <p className={style.mitigationPara}>
                              {finalTypeOfValues?.comments?.ensa}
                              {finalTypeOfValues?.comments?.orxe}
                              {finalTypeOfValues?.comments?.dsa}
                            </p>
                          </Tooltip>
                        </Box>
                      </div>
                    </div>
                  ) : (
                    <p className={style.empty}></p>
                  )}
                </div>
              </div>
            );
          },
        },
      ];
      return columns.map(column => ({
        ...column,
        cellStyleMitigation,
      }));
    };

    const generalComments = finalTypeOfValues => {
      const mitigationArray = finalTypeOfValues.filter(item => item.request !== '');
      mitigationArray.map((item, i) => {
        if (
          i === 0 &&
          (item?.request === 'FISH' ||
            item?.request === 'BEES' ||
            item?.request === 'BIRDS AND MAMMALS')
        ) {
          return (item.comments = {
            ensa: itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails?.generalCommentEnsa,
          });
        } else if (item?.request === 'OPERATOR') {
          return (item.comments = {
            orxe: itemRenderOptions[0]?.generalReviewDetails?.mitigationDetails?.generalCommentOpex,
          });
        } else if (item?.request === 'DIETARY') {
          return (item.comments = {
            dsa: itemRenderOptions[0]?.generalReviewDetails?.reviewDetails?.generalCommentDsa,
          });
        }
      });
      // console.log('mitigationArray', mitigationArray);
      return mitigationArray;
    };

    return (
      <div>
        <TableComponent
          itemRenderOptions={{
            columns: getSubTableColumn(),
            data: generalComments(finalTypeOfValues),
            toolbar: false,
            rowStyle: { verticalAlign: 'top' },
          }}
        />
      </div>
    );
  };

  return (
    <div>
      <Typography className={style.title}>Mitigation Review</Typography>
      <div>
        <div className={style.row}>
          <div className={style.paragraph}>
            <div className={style.typeOfMitigationColumn}>
              <Box my={4} display="flex" p={2}>
                {typeOfMitigations}
              </Box>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
