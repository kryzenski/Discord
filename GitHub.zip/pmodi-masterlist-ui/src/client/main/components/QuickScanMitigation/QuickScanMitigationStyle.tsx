import { makeStyles } from '@material-ui/core/styles';

export const quickScanMitigationStyle = makeStyles(() => ({
  textField: {
    // border: '1px solid #f2f2f2',
    height: 'auto',
    width: 'auto',
    padding: '3px',
    marginTop: '0px',
    marginBottom: '5px',
    minHeight: '50px',
    borderRadius: '5px',
    display: 'block',
    wordWrap: 'break-word',
  },

  customTooltip: {
    margin: '0px',
    fontSize: '13px',
  },

  row: {
    content: '',
    display: 'table',
    clear: 'both',
    width: '94.5%',
    // border: '1px solid grey',
    height: 'auto',
    marginLeft: '3.5%',
  },

  newRow: {
    borderBottom: 'white',
  },

  allText: {
    display: 'flex',
    borderBottom: '1px solid #f2f2f2',
  },

  lastText: {
    display: 'flex',
  },

  column: {
    width: '100%',
    paddingLeft: '10px',
    display: 'inline-flex',
  },

  commentColumn: {
    float: 'left',
    width: '50%',
    paddingLeft: '10px',
  },

  protectionGoalColumn: {
    width: '11%',
    float: 'left',
    paddingLeft: '10px',
  },

  typeOfMitigationColumn: {
    width: '100%',
    float: 'left',
    paddingLeft: '10px',
    marginBottom: '13px',
  },

  mitigationColThree: {
    //width: '77%',
  },

  heading: {
    marginBottom: '4px',
    marginTop: '5px',
    fontSize: '15px',
    fontWeight: 500,
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  },

  comments: {
    marginBottom: '4px',
    marginTop: '5px',
    fontSize: '15px',
    fontWeight: 500,
    width: '12%',
  },

  paragraph: {
    marginBottom: '6px',
  },

  lastDiv: {
    background: 'red',
  },

  generalTextField: {
    border: '1px solid #f2f2f2',
    minHeight: '50px',
    padding: '3px',
    marginBottom: '6px',
    marginTop: '0px',
    width: '100%',
    marginLeft: '3px',
    borderRadius: '5px',
    height: '50px',
    overflowY: 'scroll',
  },

  mitigationTypes: {
    // border: '1px solid grey',
    display: 'inline-block',
    width: '100%',
    // padding: '5px',
    paddingLeft: '0px',
    height: 'auto',
    //minHeight: '187px',
    // marginRight: '4px',
  },

  title: {
    fontSize: '16px',
    marginTop: '1%',
    marginLeft: '1.2%',
    boxSizing: 'inherit',
    fontWeight: 'bold',
    letterSpacing: '0.01071em',
    marginBottom: '20px',
  },

  mitigationPara: {
    margin: '0px',
    //textOverflow: 'ellipsis',
    //overflow: 'hidden',
    //whiteSpace: 'nowrap',
    color: 'inherit',
    height: 'auto',
    maxHeight: '190px',
    overflowY: 'scroll',
    boxSizing: 'border-box',
    fontSize: '0.875rem',
    fontFamily: 'inherit',
    fontWeight: 'inherit',
  },

  typeOfMitigationText: {
    display: 'block',
    height: 'auto',
    //minHeight: '33px',
    width: '68%',
    //border: '1px solid #f2f2f2',
    marginBottom: '8px',
    marginTop: '0px',
    padding: '3px',
    float: 'right',
    paddingLeft: '5px',
    borderRadius: '5px',
    marginLeft: '14px',
  },

  mitigationType: {
    marginLeft: '5px',
  },

  dropDownSelect: {
    width: '100%',
    padding: '2px',
    borderRadius: '0px',
    height: '25px',
  },

  protectionGoalText: {
    //marginBottom: '12px',
    margin: '0px',
    // textOverflow: 'ellipsis',
    // overflow: 'hidden',
    // whiteSpace: 'nowrap',
    color: 'inherit',
    boxSizing: 'border-box',
    fontSize: '0.875rem',
    fontFamily: 'inherit',
    fontWeight: 'inherit',
    paddingBottom: '10px',
    paddingTop: '10px',
  },

  typeOfMitigationPpeText: {
    width: '30%',
    float: 'left',
    //textOverflow: 'ellipsis',
    //overflow: 'hidden',
    whiteSpace: 'initial',
    wordWrap: 'break-word',
    //marginBottom: '11px',
    color: 'inherit',
    fontSize: '0.875rem',
    padding: '3px',
    paddingTop: '4px',
    // font-size: inherit;
    // box-sizing: border-box;
    // font-family: inherit;
    // font-weight: inherit;
  },

  typeOfMitigationConcatValues: {
    margin: '0px',
    // textOverflow: 'ellipsis',
    // overflow: 'hidden',
    // whiteSpace: 'nowrap',
    fontSize: '0.875rem',
    // box: border-box;
    // overflow-y: scroll;
    // height: 40px;
    boxSizing: 'border-box',
    overflowY: 'scroll',
    height: '34px',
  },

  mitigationRow: {
    content: '',
    //display: 'flex',
    clear: 'both',
    width: '100%',
  },

  td: {
    verticalAlign: 'top',
  },

  mitigationColOne: {
    float: 'left',
    width: '20%',
    padding: '10px',
    height: 'auto',
    paddingLeft: '0px',
    paddingTop: '5px',
  },

  mitigationColTwo: {
    float: 'left',
    width: '100%',
    padding: '10px',
    height: 'auto',
    paddingLeft: '0px',
    paddingTop: '0px',
    paddingBottom: '0px',
  },

  mitigationHeadingColOne: {
    float: 'left',
    width: '20%',
    height: 'auto',
    paddingLeft: '0px',
    marginBottom: '4px',
    marginTop: '5px',
    fontSize: '15px',
    fontWeight: 500,
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  },

  mitigationHeadingColTwo: {
    float: 'left',
    width: '80%',
    height: 'auto',
    paddingLeft: '0px',
    marginBottom: '4px',
    marginTop: '5px',
    fontSize: '15px',
    fontWeight: 500,
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  },

  mitigationHeadingColThree: {
    float: 'left',
    width: '77%',
    height: 'auto',
    paddingLeft: '0px',
    marginBottom: '4px',
    marginTop: '5px',
    fontSize: '15px',
    fontWeight: 500,
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  },

  empty: {
    margin: '0px',
  },
}));
