import _ from 'lodash';
import axios from 'axios';
import { useState } from 'react';

const getStatusMessage = (status: string | number) => {
  if (!status || status === 'null' || status === '') {
    return 'unknown';
  }
  const statusCode = String(status);
  switch (statusCode) {
    case '301': {
      return '301 Moved Permanently';
    }
    case '400': {
      return '400 Bad Request';
    }
    case '401': {
      return '401 Unauthorized';
    }
    case '403': {
      return '403 Forbidden';
    }
    case '404': {
      return '404 Not Found';
    }
    case '405': {
      return '405 Method Not Allowed';
    }
    case '408': {
      return '408 Request Timeout';
    }
    case '414': {
      return '414 Request-URI Too Long';
    }
    case '500': {
      return '500 Internal Server Error';
    }
    case '501': {
      return '501 Not Implemented';
    }
    case '502': {
      return '502 Bad Gateway';
    }
    case '503': {
      return '503 Service Unavailable';
    }
    case '504': {
      return '504 Gateway Timeout';
    }
    default: {
      return statusCode;
    }
  }
};

const useHandleError = err => {
  const data = _.get(err, 'response.data');
  const statusCode = _.get(data, 'status');
  return { ...data, defaultErrorMessage: getStatusMessage(statusCode) };
};

export const useAxiosInterceptors = () => {
  const [errorObj, setErrorObj] = useState(null);
  axios.interceptors.response.use(
    response => response,
    err => setErrorObj(useHandleError(err)),
  );
  return { errorObj };
};
