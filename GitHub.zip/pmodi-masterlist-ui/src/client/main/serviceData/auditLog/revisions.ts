import _ from 'lodash';

import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { restRequest } from '@shared/utils/restUtils';
import { buildUrl } from '../apiUtils';
import {
  RESPONSE_DATA,
  AUDIT_LOG_URL_HISTORY,
  AUDIT_LOG_URL_REVISIONS,
  AUDIT_LOG_URL_MODIFIED_FIELD,
  AUDIT_LOG_PRRAMETERS_FIELDNAME,
} from '@main/constants/constants';

export const getRevisions = async (paths: Array<string>, id: string, fieldNames: Array<string>) => {
  const url = buildUrl(
    _.concat(
      AUDIT_LOG_URL_HISTORY,
      paths,
      id,
      AUDIT_LOG_URL_MODIFIED_FIELD,
      AUDIT_LOG_URL_REVISIONS,
    ),
  );
  const params = { [AUDIT_LOG_PRRAMETERS_FIELDNAME]: fieldNames };

  const response = await restRequest(url, HTTPMethod.get, null, params);
  return _.get(response, RESPONSE_DATA);
};
