import _ from 'lodash';
import FileSaver from 'file-saver';
import { AxiosResponse } from 'axios';
import { getMatsterViewOptionsFromLocalStorage } from '@main/security/localStore';
import { restRequest } from '@shared/utils/restUtils';
import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { isEmptyValue } from '@shared/utils/functionUtils';
import { buildUrl } from '../apiUtils';
import { defaultPageable } from '@main/constants/constants';
import { PRIORITIZATION_TYPE_FIELD } from '@main/constants/projectOptions';
// import { resourceLimits } from 'worker_threads';
function getFileNameFromResponse(response) {
  // Get the current date in the format YYYY-MM-DD
  const currentDate = new Date().toISOString().slice(0, 10);
  // Get the current time in the format HH:MM:SS
  let currentTime = new Date().toLocaleTimeString([], { hour12: false });
  // Replace spaces and colons in time with hyphens
  currentTime = currentTime.replace(/[:\s]/g, '-');
  // Construct the new filename
  let filename = `PRECISE Export_${currentDate}_${currentTime}.xlsx`;
  if (response) {
    const disposition = response.headers['content-disposition'];
    if (disposition && disposition.indexOf('attachment') !== -1) {
      // filename      # match filename, followed by
      // [^;=\n]*      # anything but a ;, a = or a newline
      // =
      // (             # first capturing group
      //     (['"])    # either single or double quote, put it in capturing group 2
      //     .*?       # anything up until the first...
      //     \2        # matching quote (single if we found single, double if we find double)
      // |             # OR
      //     [^;\n]*   # anything but a ; or a newline
      // )
      const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
      const matches = filenameRegex.exec(disposition);
      if (matches !== null && matches[1]) {
        filename = matches[1].replace(/['"]/g, '');
      }
    }
  }
  return filename;
}

export const downloadExport = (searchParams, failureCallback, stopLoading, isMounted) => {
  const url = buildUrl(['project', 'segments', 'export']);
  const options = { responseType: 'arraybuffer' };
  //const { stopLoading } = useContext(LoadingContext);
  document.title = 'Downloading...';
  console.log('isMounted.current', isMounted.current);
  restRequest(url, HTTPMethod.post, searchParams, null, null, options)
    .then(r => {
      const response = r as AxiosResponse;
      const filename = getFileNameFromResponse(response);
      const contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      const blobContent = [response.data];
      const blob = new Blob(blobContent, { type: contentType });

      if (blob.size !== 0) {
        FileSaver.saveAs(blob, filename);
      }
      stopLoading();
      console.log('Loading.stop1');
      document.title = 'PRECISE Bayer CropScience';
    })
    .catch(ex => {
      if (failureCallback && _.isFunction(failureCallback)) {
        failureCallback(ex);
      }
      document.title = 'PRECISE Bayer CropScience';
    })
    .finally(() => {
      if (isMounted.current) {
        //  setIsLoading(false);
        stopLoading();
        console.log('Loading.stop');
        document.title = 'PRECISE Bayer CropScience';
      }
    });
  console.log('isMounted.current', isMounted.current);
};

const getParametersFormLocalStorage = (type, parameters) => {
  const options = getMatsterViewOptionsFromLocalStorage(type);
  if (_.get(options, 'page')) {
    parameters.pageable.page = _.get(options, 'page');
  }
  if (_.get(options, 'pageSize')) {
    parameters.pageable.size = _.get(options, 'pageSize');
  }
  if (_.get(options, 'sortBy')) {
    parameters.pageable.sortBy = _.get(options, 'sortBy');
  }
  if (_.get(options, 'sortDir')) {
    parameters.pageable.sortDir = _.get(options, 'sortDir');
  }
  return parameters;
};

export const searchProjects = async searchParams => {
  let parameters = {
    ...searchParams,
  };
  parameters = getParametersFormLocalStorage('projects', parameters);
  const url = buildUrl(['project', 'projects', 'search']);
  const response = await restRequest(url, HTTPMethod.post, parameters);
  const results = _.get(response, 'data');
  let data = results.content;
  data = _.map(data, it => {
    if (isEmptyValue(it[PRIORITIZATION_TYPE_FIELD])) {
      it[PRIORITIZATION_TYPE_FIELD] = 'null';
    }
    return { ...it };
  });
  return {
    data,
    page: _.get(results, 'pageable.pageNumber'),
    size: _.get(results, 'pageable.pageSize'),
    totalCount: _.get(results, 'totalElements'),
  };
};

export const getProjectDataById = async id => {
  const url = buildUrl(['project', 'projects', id]);
  const response = await restRequest(url, HTTPMethod.get);
  const results = _.get(response, 'data');
  return results;
};

export const getProjectDataByDate = async (id, date) => {
  const selectedDate = new Date(date);
  const url = buildUrl(['history', 'projects', id, 'at-date']);
  const response = await restRequest(url, HTTPMethod.get, null, { date: selectedDate });
  const results = _.get(response, 'data');
  return results;
};

export const getSegmentDataById = async id => {
  const url = buildUrl(['project', 'segments', id]);
  const response = await restRequest(url, HTTPMethod.get);
  const results = _.get(response, 'data');
  return results;
};

export const updateProject = async (entity, id) => {
  const url = buildUrl(['project', 'projects', id]);
  if (entity[PRIORITIZATION_TYPE_FIELD] === 'null') {
    entity[PRIORITIZATION_TYPE_FIELD] = null;
  }
  const response = await restRequest(url, HTTPMethod.patch, entity);
  const results = _.get(response, 'data');
  return results;
};

export const updateSegment = async (entity, id) => {
  const url = buildUrl(['project', 'segments', id]);
  const prioratizationTypeField = _.get(entity, PRIORITIZATION_TYPE_FIELD);
  if (prioratizationTypeField === 'null') {
    entity[PRIORITIZATION_TYPE_FIELD] = null;
  }
  const response = await restRequest(url, HTTPMethod.patch, entity);
  const results = _.get(response, 'data');
  return results;
};

export const searchSegments = async (searchParams, id) => {
  let parameters = {
    pageable: { ...searchParams },
  };
  parameters = getParametersFormLocalStorage('segments', parameters);
  if (isEmptyValue(id)) {
    throw new Error('No projectId!');
  }
  const segmentsUrl = buildUrl(['project', 'projects', id, 'segments']);
  const segmentResponse = await restRequest(segmentsUrl, HTTPMethod.get, null, parameters.pageable);
  const responseData = _.get(segmentResponse, 'data');

  const { content, pageable, totalElements } = responseData;
  const segments = _.map(content, segment => {
    const { crop, country } = segment;
    return {
      ...segment,
      cropId: _.get(crop, 'id'),
      cropDisplayName: _.get(crop, 'displayName'),
      countryId: _.get(country, 'id'),
      countryDisplayName: _.get(country, 'displayName'),
    };
  });
  return {
    data: segments,
    page: _.get(pageable, 'pageNumber'),
    totalCount: totalElements,
  };
};

export const getAllowableEditFields = async (id, type) => {
  const url =
    type === 'projects'
      ? buildUrl(['project', 'projects', id, 'editable-fields'])
      : buildUrl(['project', 'segments', id, 'editable-fields']);
  const response = await restRequest(url, HTTPMethod.get);
  const results = _.get(response, 'data');
  return results;
};

export const searchAllSegments = async searchParams => {
  let parameters = {
    ...searchParams,
  };
  parameters = getParametersFormLocalStorage('segments', parameters);
  const url = buildUrl(['project', 'segments', 'search']);
  const response = await restRequest(url, HTTPMethod.post, parameters);
  const results = _.get(response, 'data');
  const segments = _.map(results.content, segment => {
    const { crop, country } = segment;
    return {
      ...segment,
      cropId: _.get(crop, 'id'),
      cropDisplayName: _.get(crop, 'displayName'),
      countryId: _.get(country, 'id'),
      countryDisplayName: _.get(country, 'displayName'),
    };
  });
  return {
    data: segments,
    page: _.get(results, 'pageable.pageNumber'),
    totalCount: _.get(results, 'totalElements'),
  };
};

export const getQuickscanMitigation = async (id, type) => {
  const url = buildUrl(['project', type, id, 'mitigation-module']);
  const response = await restRequest(url, HTTPMethod.get);
  const result = _.get(response, 'data');
  return result;
};

export const getQuickscanAssessments = async (id, type) => {
  const url = buildUrl(['project', type, id, 'quickscan-assessments']);
  const response = await restRequest(url, HTTPMethod.get);
  const results = _.get(response, 'data');
  return results;
};

export const searchSegmentsOfProjectsBySelectedDate = async (id, date) => {
  const selectedDate = new Date(date);
  const url = buildUrl(['history', 'projects', id, 'segments', 'at-date']);
  const response = await restRequest(url, HTTPMethod.get, null, { date: selectedDate });
  const results = _.get(response, 'data');
  const segments = _.map(results, segment => {
    const { crop, country } = segment;
    return {
      ...segment,
      cropId: _.get(crop, 'id'),
      cropDisplayName: _.get(crop, 'displayName'),
      countryId: _.get(country, 'id'),
      countryDisplayName: _.get(country, 'displayName'),
    };
  });
  return segments;
};

export const getPreciseCostListOfSegment = async (id, searchParams) => {
  const url = buildUrl(['project', 'segments', id, 'costs']);
  const response = await restRequest(url, HTTPMethod.get, null, searchParams);
  const results = _.get(response, 'data');
  return results.content;
};

export const updatePreciseCostListOfSegment = async (id, entity) => {
  const url = buildUrl(['project', 'segments', 'costs', id]);
  const response = await restRequest(url, HTTPMethod.patch, entity);
  const results = _.get(response, 'data');
  return results;
};

export const downloadPreciseCostListExport = async (id, failureCallback) => {
  const url = buildUrl(['project', 'segments', id, 'costs', 'export']);
  const options = { responseType: 'arraybuffer' };
  restRequest(url, HTTPMethod.get, null, null, null, options)
    .then(r => {
      const response = r as AxiosResponse;
      const filename = getFileNameFromResponse(response);
      const contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      const blobContent = [response.data];
      const blob = new Blob(blobContent, { type: contentType });

      if (blob.size !== 0) {
        FileSaver.saveAs(blob, filename);
      }
    })
    .catch(ex => {
      if (failureCallback && _.isFunction(failureCallback)) {
        failureCallback(ex);
      }
    });
};

export const getMilestonesOfSegment = async (id, searchParams) => {
  const url = buildUrl(['project', 'segments', id, 'regprime-milestones']);
  const response = await restRequest(url, HTTPMethod.get, null, searchParams);
  return _.get(response, 'data');
};

export const getMileStoneOfProject = async id => {
  const url = buildUrl(['project', 'projects', id, 'regprime-milestones']);
  const response = await restRequest(url, HTTPMethod.get, null, null);
  return _.get(response, 'data');
};

export const getAprs = async (id, isSegment, searchParams = defaultPageable) => {
  const url = buildUrl(['project', isSegment ? 'segments' : 'projects', id, 'aprs']);
  const response = await restRequest(url, HTTPMethod.get, null, searchParams);
  return _.get(response, 'data');
};

export const getSegmentsByProjectId = async projectId => {
  const segmentsUrl = buildUrl(['project', 'projects', projectId, 'segments']);
  const response = await restRequest(segmentsUrl, HTTPMethod.get, null, defaultPageable);
  return _.get(response, 'data.content');
};
