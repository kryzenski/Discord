import { buildUrlWithDefaultProtocolAndDefaultHost } from '@shared/utils/restUtils';

let getState = null;
export const setGetState = getStateFunc => {
  getState = getStateFunc;
};

export const buildUrl = (paths: Array<string>) => {
  const { defaultProtocol, defaultHost, defaultPort } = getState().configuration.endpoints;
  return buildUrlWithDefaultProtocolAndDefaultHost(
    paths,
    defaultProtocol,
    defaultHost,
    defaultPort,
  );
};
