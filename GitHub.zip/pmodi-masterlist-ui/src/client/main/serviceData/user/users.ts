import _ from 'lodash';

import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { restRequest } from '@shared/utils/restUtils';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { buildUrl } from '@main/serviceData/apiUtils';

export const getCurrentUser = async () => {
  const query = {
    sortBy: null,
    sortDir: null,
  };
  const url = buildUrl(['ui', 'current-user']);
  const response = await restRequest(url, HTTPMethod.get, null, query);
  const userName = _.get(response, 'data.name');
  const userRoles = _.get(response, 'data.roles');
  let userRolesStr = 'Default User';
  if (isNotEmptyValue(userRoles)) {
    const tooManyRoles = userRoles.length > 3;
    userRolesStr = tooManyRoles ? userRoles.slice(0, 3).join(', ') : userRoles.join(', ');
    if (tooManyRoles) userRolesStr += '...';
  }
  return { userName, userRoles, userRolesStr };
};
