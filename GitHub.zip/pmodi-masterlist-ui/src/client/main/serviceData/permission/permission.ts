import _ from 'lodash';

import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { restRequest } from '@shared/utils/restUtils';
import { buildUrl } from '@main/serviceData/apiUtils';

export const getLockGroups = async () => {
  const url = buildUrl(['permission', 'locked-groups']);
  const response = await restRequest(url, HTTPMethod.get, null, null);
  const results = _.get(response, 'data');
  return results;
};
export const updateLockGroup = async groups => {
  const url = buildUrl(['permission', 'locked-groups', 'lock']);

  const response = await restRequest(url, HTTPMethod.patch, groups);
  const results = _.get(response, 'data');
  return results;
};

export const updateUnLockGroup = async groups => {
  const url = buildUrl(['permission', 'locked-groups', 'unlock']);

  const response = await restRequest(url, HTTPMethod.patch, groups);
  const results = _.get(response, 'data');
  return results;
};
