import _ from 'lodash';

import { HTTPMethod } from '@shared/utils/HTTPMethods';
import { restRequest } from '@shared/utils/restUtils';
import { buildUrl } from '../apiUtils';

// TODO: make REST calls robust and handle errors
export const getFacetConfigurations = async searchParams => {
  const { orderBy, orderDirection } = searchParams;
  const query = {
    sortBy: orderBy || 'id',
    sortDir: orderDirection || 'ASC',
  };

  const url = buildUrl(['ui', 'facet-configs']);
  const response = await restRequest(url, HTTPMethod.get, null, query, null, null);
  const filters = _.get(response, 'data.content');

  const filterConfigration = [];
  filters.forEach(filter => {
    filterConfigration.push({ ...filter });
  });
  return filterConfigration;
};

export const getValueOfAutoComplete = async searchParams => {
  const url = buildUrl(['ui', 'distinct-properties']);
  const response = await restRequest(url, HTTPMethod.get, null, searchParams);
  const results = _.get(response, 'data');
  return results.map(result => ({
    title: result,
    value: result,
  }));
};
