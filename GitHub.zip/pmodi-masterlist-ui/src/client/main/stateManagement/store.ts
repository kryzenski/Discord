import updatedPlugin from '@rematch/updated';
import LoadingPlugin from '@rematch/loading';
import { createLogger } from 'redux-logger';
import { init } from '@rematch/core';
import { setPropertyInfo } from '@main/constants/fieldsInfo';
import * as allModels from '@main/models';
import { RematchRootDispatch, RematchRootState } from './rematch';

const middlewares = [];

if (process.env.NODE_ENV === 'DEV') {
  middlewares.push(createLogger());
}

// Getting the server-side-preloaded state:
const preloadedState = window['__INITIAL_STATE__'];
delete window['__INITIAL_STATE__'];

setPropertyInfo(preloadedState);
delete preloadedState.propertyInfo;

const models = {
  ...allModels,
  configuration: { state: preloadedState },
};

// TODO: we need error handle and dispatch interceptor...
export const store = init({
  models,
  redux: {
    middlewares,
  },
  plugins: [LoadingPlugin(), updatedPlugin()],
});

export type typeStore = typeof store;
export type typeState = RematchRootState<typeof models> & {
  loading: {
    global: boolean;
    models: {
      [M in keyof typeof models]?: boolean;
    };
    effects: {
      [M in keyof typeof models]?: {
        [E in keyof (typeof models[M] extends { effects: any }
          ? ReturnType<typeof models[M]['effects']>
          : {})]?: boolean;
      };
    };
  };
};
export type typeDispatch = RematchRootDispatch<typeof models>;
