export const PROJECT_STATUS_FIELD = 'newportStatus';
export const PROJECT_ID = 'id';
export const VERSION = 'version';
export const OVERALL_PTRS_SCORE_FIELD = 'overallPtrsScore';
export const PROJECT_NAME_FIELD = 'newportName';
export const PRECISE_NEW_PORT_ID_FIELD = 'preciseNewportId';
export const PROJECT_CATEGORY_FILED = 'newportCategory';
export const PEAKNET_SALES_FIELD = 'newportLocalPeakNetSales';
export const PROJECT_MANAGER_FIELD = 'newportInitiator';
export const NPV_YEAR_FIELD = 'newportLocalNpvYear10';
export const INC_PEAKNET_SALES_FIELD = 'newportLocalPeakNetSalesIncremental';
export const NPV_YEAR__FIELD = 'newportLocalNpvYear10';
export const PRIORITIZATION_GOVERNNCE_FIELD = 'prioritizationGovernance';
// export const NEWPORT_PROJECT_CREATED = 'newportProjectCreated';
export const PROJECT_APPROVAL_YEAR = 'approvalDate';
export const CATEGORY_CHANGED_FROM_NEW_ACTIVE_SD = 'categoryChangedDateNASToLCM';
export const CATEGORY_CHANGED_FROM_NEW_FOR_POC_FD = 'categoryChangedDateNFPCToFD';
export const SEGMENT_CREATION_YEAR = 'creationDate';
export const PRIORITIZATION_TYPE_FIELD = 'prioritizationType';
export const PRIORITIZATION_REMARK_FIELD = 'prioritizationRmk';
export const PRODUCTIVITY_INDEX_FIELD = 'newportGlobalProductivityIndex';
export const NEW_PORT_GLOBAL_FUTURE_PROJECT_COST_FIELD = 'newportGlobalFutureProjectCost';
export const NEWPORT_GLOBAL_SALSES_VOLUME_FIELD = 'newportGlobalSalesVolume';
export const NEWPORT_GLOBAL_AGGREGATED_VOLUME_FIELD = 'newportGlobalAggregatedVolume';
export const NEWPORT_GLOBAL_IGM_YEAR_FIELD = 'newportGlobalIgmPeakYear';
export const NEWPORT_GLOBAL_INCREMENTAL_IGM_YEAR_FIELD = 'newportGlobalPeakYearIgmIncremental';
export const NEWPORT_GLOBAL_NPV_YEAR_FIELD = 'newportGlobalNpvYear10';
export const NEWPORT_GLOBAL_EXPECTED_NPV_YEAR_FIELD = 'newportGlobalExpectedNpvYear10';
export const NEWPORT_LOCASL_EXPECTED_NPV_YEAR_FIELD = 'newportLocalExpectedNpvYear10';
export const NEWPORT_GLOBAL_NET_SALES_FIELD = 'newportGlobalNetSales';
export const NEWPORT_GLOBAL_INCREMENTAL_NET_SALES_FIELD = 'newportGlobalIncrementalNetSales';
export const NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD = 'newportGlobalPeakNetSales';
export const NEWPORT_GLOBAL_PEAK_NET_SALES_INCREMENTAL = 'newportGlobalPeakNetSalesIncremental';
export const NEWPORT_PROJECT_ID = 'newportProjectId';

export const STRATEGIC_FIT_REMARK = 'strategicFitRmk';
export const FREE_NAMES_FIELD = 'newportFreeText';
export const NEW_PORT_OBJECTIVE_FIELD = 'newportObjective';
export const NEW_PORT_PRODUCT_PROFILE_FIELD = 'newportProductProfile';
export const NEW_PORT_SUCCESS_FACTORS_FIELD = 'newportSuccessFactors';
export const NEW_PORT_JUSTIFICATION_FIELD = 'newportJustification';
export const GLOBAL_PORTFOLIO_GUIDANCE_FIELD = 'globalPortfolioGuidance';
export const SUSSTAINABILITY_ASSESSMENT = 'sustainabilityAssessment';
export const GLOBAL_REGULATORY_GUIDANCE_FIELD = 'globalRegGuidance';
export const GLOBAL_REGULATORY_GUIDANCE_REGIONS_FIELD = 'globalRegGuidanceRegion';
export const LABEL_FOR_SAFE_USE_FIELD = 'labelForSafeUse';
export const LABEL_FOR_SAFE_USE_REGION_FIELD = 'labelForSafeUseRegion';
export const DEVELOPMENT_FUNCTIONS_FIELD = 'developmentFunctions';
export const IP_ASSESSMENT_FIELD = 'intelectualPropertyAssessment';
export const FT_PTRS_SCORE_FIELD = 'ftPtrsScore';
export const FT_RECOMMENDATION_MODIFIED_BY_FIELD = 'techRecommendationModifiedBy';
export const FT_RECOMMENDATION_MODIFIED_DATE_FIELD = 'techRecommendationModifiedDate';
export const FT_PTRS_SCORE_REMARK_FIELD = 'ftPtrsScoreRmk';
export const FT_PTRS_SCORE_MODIFIED_BY_FIELD = 'ftPtrsScoreModifiedBy';
export const FT_PTRS_SCORE_MODIFIED_DATE_FIELD = 'ftPtrsScoreModifiedDate';
export const FS_PTRS_SCORE_FIELD = 'fsPtrsScore';
export const FS_PTRS_SCORE_REMARK_FIELD = 'fsPtrsScoreRmk';
export const FS_PTRS_SCORE_MODIFIED_BY_FIELD = 'fsPtrsScoreModifiedBy';
export const FS_PTRS_SCORE_MODIFIED_DATE_FIELD = 'fsPtrsScoreModifiedDate';
export const FS_PTRS_SCORE_UPDATED_BY_FIELD = 'fsPtrsScoreUpdatedBy';
export const FS_PTRS_SCORE_UPDATED_DATE_FIELD = 'fsPtrsScoreUpdatedDate';
export const FS_RECOMMENDATION_ONLY_NF_POC_PROJECT_FEILD = 'solRecommendation';
export const FS_RECOMMENDATION_MODIFIED_BY_FIELD = 'solRecommendationModifiedBy';
export const FS_RECOMMENDATION_MODIFIED_DATE_FIELD = 'solRecommendationModifiedDate';
export const RS_ENSA_PTRS_SCORE_REMARK_FIELD = 'rsEnsaPtrsScoreRmk';
export const RS_ENSA_PTRS_SCORE_FIELD = 'rsEnsaPtrsScore';
export const RS_ENSA_PTRS_SCORE_MODIFIED_BY_FIELD = 'rsEnsaPtrsScoreModifiedBy';
export const RS_ENSA_PTRS_SCORE_MODIFIED_DATE_FIELD = 'rsEnsaPtrsScoreModifiedDate';
export const RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD = 'rsOperatorPtrsScoreRmk';
export const RS_OPERATOR_RISK_PTRS_SCORE_FIELD = 'rsOperatorPtrsScore';
export const RS_OPERATOR_PTRS_SCORE_MODIFIED_BY_FIELD = 'rsOperatorPtrsScoreModifiedBy';
export const RS_OPERATOR_PTRS_SCORE_MODIFIED_DATE_FIELD = 'rsOperatorPtrsScoreModifiedDate';
export const RS_DIETARY_SAFETY_PTRS_SCORE_FIELD = 'rsDietaryPtrsScore';
export const RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD = 'rsDietaryPtrsScoreRmk';
export const RS_DIETARY_PTRS_SCORE_MODIFIED_BY_FIELD = 'rsDietaryPtrsScoreModifiedBy';
export const RS_DIETARY_PTRS_SCORE_MODIFIED_DATE_FIELD = 'rsDietaryPtrsScoreModifiedDate';
export const RS_REGULATORY_AFFAIRS_SCORE_FIELD = 'rsRegAffairsScore';
export const RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD = 'rsRegAffairsScoreRmk';
export const RS_REG_AFFAIR_SCORE_MODIFIED_BY_FIELD = 'rsRegAffairsScoreModifiedBy';
export const RS_REG_AFFAIR_SCORE_MODIFIED_DATE_FIELD = 'rsRegAffairsScoreModifiedDate';
export const RS_PTRS_SCORE_REMARK_FIELD = 'rsPtrsScoreRmk';
export const RS_PTRS_SCORE_REMARK_MODIFIED_BY_FIELD = 'rsPtrsScoreRmkModifiedBy';
export const RS_PTRS_SCORE_REMARK_MODIFIED_DATE_FIELD = 'rsPtrsScoreRmkModifiedDate';
export const RS_GOVERNANCE_FIELD = 'rsGovernance';
export const RS_PTRS_SCORE_FIELD = 'rsPtrsScore';
export const RS_RECOMMENDATION_MODIFIED_BY_FIELD = 'scienceRecommendationModifiedBy';
export const RS_RECOMMENDATION_MODIFIED_DATE_FIELD = 'scienceRecommendationModifiedDate';
export const NEWPORT_PLT = 'newportPlt';
export const NEWPORT_SPG = 'newportSpg';
export const NEWPORT_BUSINESS_UNIT = 'newportBusinessUnit';
export const SPECIFIC_PROJECT_FRAMEWORK = 'specificProjectFramework';
export const THIRD_PARTY_AI_REGCHECK = 'thirdPartyAiRegCheck';
export const NEWPORT_GLOBAL_IGM_PEAK_YEAR_FIELD = 'newportGlobalIgmPeakYear';
export const NEWPORT_GLOBAL_PEAK_YEAR_IGM_INCREMENTAL = 'newportGlobalPeakYearIgmIncremental';
export const FS_RATIONALE_COMPARATIVE_MESSAGE =
  'The weighted Segment FS score becomes Project FS PTRS score by default, as Project FS PTRS was empty.';
export const RS_RATIONALE_COMPARATIVE_MESSAGE =
  'The weighted Segment RS score becomes Project RS PTRS score by default, as Project RS PTRS was empty.';
export const WARNING_MESSAGE_RS =
  'If all RS Sub-scores are deleted and no new value is entered, the weighted segment RS score becomes project RS score by default.';
export const FinancialKPIColumns = [
  NEWPORT_GLOBAL_NPV_YEAR_FIELD,
  NEWPORT_GLOBAL_EXPECTED_NPV_YEAR_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD,
  NEWPORT_GLOBAL_IGM_YEAR_FIELD,
  NEWPORT_GLOBAL_INCREMENTAL_IGM_YEAR_FIELD,
  NEW_PORT_GLOBAL_FUTURE_PROJECT_COST_FIELD,
  PRODUCTIVITY_INDEX_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_SALES_INCREMENTAL,
];

export const ProjectPtrsFields = [
  FT_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_FIELD,
  RS_PTRS_SCORE_FIELD,
  OVERALL_PTRS_SCORE_FIELD,
];

export const RiskAssessmentFields = [
  { risk: RS_ENSA_PTRS_SCORE_FIELD, rationale: RS_ENSA_PTRS_SCORE_REMARK_FIELD },
  { risk: RS_OPERATOR_RISK_PTRS_SCORE_FIELD, rationale: RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD },
  {
    risk: RS_DIETARY_SAFETY_PTRS_SCORE_FIELD,
    rationale: RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD,
  },
  {
    risk: RS_REGULATORY_AFFAIRS_SCORE_FIELD,
    rationale: RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD,
  },
  {
    risk: '',
    rationale: RS_PTRS_SCORE_REMARK_FIELD,
  },
];

export const projectDetailsProjectIdentifiers = [
  PROJECT_ID,
  PRECISE_NEW_PORT_ID_FIELD,
  PROJECT_NAME_FIELD,
  PROJECT_CATEGORY_FILED,
  NEWPORT_BUSINESS_UNIT,
];
export const projectDetailsProjectProperties = [
  PROJECT_STATUS_FIELD,
  FREE_NAMES_FIELD,
  NEWPORT_PLT,
  NEWPORT_SPG,
  PROJECT_APPROVAL_YEAR,
  CATEGORY_CHANGED_FROM_NEW_ACTIVE_SD,
  CATEGORY_CHANGED_FROM_NEW_FOR_POC_FD,
];
export const segmentDetailsSegmentProperties = [SEGMENT_CREATION_YEAR];
export const globalGuidanceFields = [
  GLOBAL_PORTFOLIO_GUIDANCE_FIELD,
  GLOBAL_REGULATORY_GUIDANCE_FIELD,
  LABEL_FOR_SAFE_USE_FIELD,
  DEVELOPMENT_FUNCTIONS_FIELD,
  SPECIFIC_PROJECT_FRAMEWORK,
  THIRD_PARTY_AI_REGCHECK,
  SUSSTAINABILITY_ASSESSMENT,
  IP_ASSESSMENT_FIELD,
];

export const withLinkPropertiesOfProject = [
  RS_ENSA_PTRS_SCORE_FIELD,
  RS_OPERATOR_RISK_PTRS_SCORE_FIELD,
  RS_DIETARY_SAFETY_PTRS_SCORE_FIELD,
  RS_REGULATORY_AFFAIRS_SCORE_FIELD,
  FT_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_FIELD,
  RS_PTRS_SCORE_FIELD,
  OVERALL_PTRS_SCORE_FIELD,
  PRECISE_NEW_PORT_ID_FIELD,
];

export const monthValue = [
  { value: 'JAN', title: 'JAN' },
  { value: 'FEB', title: 'FEB' },
  { value: 'MAR', title: 'MAR' },
  { value: 'APR', title: 'APR' },
  { value: 'MAY', title: 'MAY' },
  { value: 'JUN', title: 'JUN' },
  { value: 'JUL', title: 'JUL' },
  { value: 'AUG', title: 'AUG' },
  { value: 'SEP', title: 'SEP' },
  { value: 'OCT', title: 'OCT' },
  { value: 'NOV', title: 'NOV' },
  { value: 'DEC', title: 'DEC' },
];

export const projectUpdateOptions = [
  {
    ptrsField: FT_PTRS_SCORE_FIELD,
    rationaleField: FT_PTRS_SCORE_REMARK_FIELD,
    updatedBy: FT_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: FT_PTRS_SCORE_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: FS_PTRS_SCORE_FIELD,
    rationaleField: FS_PTRS_SCORE_REMARK_FIELD,
    updatedBy: FS_PTRS_SCORE_UPDATED_BY_FIELD,
    updatedDate: FS_PTRS_SCORE_UPDATED_DATE_FIELD,
  },
  {
    rationaleField: RS_PTRS_SCORE_REMARK_FIELD,
    updatedBy: RS_PTRS_SCORE_REMARK_MODIFIED_BY_FIELD,
    updatedDate: RS_PTRS_SCORE_REMARK_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: RS_ENSA_PTRS_SCORE_FIELD,
    rationaleField: RS_ENSA_PTRS_SCORE_REMARK_FIELD,
    updatedBy: RS_ENSA_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: RS_ENSA_PTRS_SCORE_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: RS_OPERATOR_RISK_PTRS_SCORE_FIELD,
    rationaleField: RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD,
    updatedBy: RS_OPERATOR_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: RS_OPERATOR_PTRS_SCORE_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: RS_DIETARY_SAFETY_PTRS_SCORE_FIELD,
    rationaleField: RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD,
    updatedBy: RS_DIETARY_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: RS_DIETARY_PTRS_SCORE_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: RS_REGULATORY_AFFAIRS_SCORE_FIELD,
    rationaleField: RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD,
    updatedBy: RS_REG_AFFAIR_SCORE_MODIFIED_BY_FIELD,
    updatedDate: RS_REG_AFFAIR_SCORE_MODIFIED_DATE_FIELD,
  },
];
