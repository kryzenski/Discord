import { Message } from '@shared/utils/message';

export const REGION = 'country.subRegion.region.name';
export const REGPRIME_REGULATORY_ACTION_STATUS = 'regulatoryActionStatus';
export const REGPRIME_REGISTRATION_STATUS = 'registrationStatus';
export const COUNTRY_FIELD = 'countryName';
export const CROP_FIELD = 'cropName';
export const CROP_PLATFORM_FIELD = 'crop.cropPlatformDisplayName';
export const TARGET_FIELD = 'target';
export const PTRS_SEGMENT_OVERALL_SCORE_FIELD = 'ptrsSegmentOverallScore';
export const FT_PTRS_SCORE_FIELD = 'ftPtrsScore';
export const FT_PTRS_SCORE_REMARK_FIELD = 'ftPtrsScoreRmk';
export const FT_PTRS_SCORE_MODIFIED_BY_FIELD = 'ftPtrsScoreModifiedBy';
export const FT_PTRS_SCORE_MODIFIED_DATE_FIELD = 'ftPtrsScoreModifiedDate';
export const FS_PTRS_SCORE_FIELD = 'fsPtrsScore';
export const FS_PTRS_SCORE_REMARK_FIELD = 'fsPtrsScoreRmk';
export const FS_PTRS_SCORE_UPDATED_BY_FIELD = 'fsPtrsScoreUpdatedBy';
export const FS_PTRS_SCORE_UPDATED_DATE_FIELD = 'fsPtrsScoreUpdatedDate';
export const RS_REGULATORY_PTRS_SCORE_FIELD = 'rsRegPtrsScore';
export const RS_REGULATORY_PTRS_SCORE_REMARK_FIELD = 'rsRegPtrsScoreRmk';
export const RS_PTRS_SCORE_UPDATED_BY_FIELD = 'rsPtrsScoreUpdatedBy';
export const RS_PTRS_SCORE_UPDATED_DATE_FIELD = 'rsPtrsScoreUpdatedDate';
export const PRIORITIZATION_GOVERNNCE_FIELD = 'prioritizationGovernance';
export const PRIORITIZATION_TYPE_FIELD = 'prioritizationType';
export const PRIORITIZATION_REMARK_FIELD = 'prioritizationRmk';
export const NEWPORT_GLOBAL_FUTURE_PROJECT_COST_FIELD = 'newportGlobalFutureProjectCost';
export const NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD = 'newportGlobalPeakNetSales';
export const NEWPORT_LAUNCH_YEAR_SEGMENT_FIELD = 'newportLaunchYearSegment';
export const NEWPORT_LAUNCH_YEAR_COUNTRY_FIELD = 'newportLaunchYearCountry';
export const NEWPORT_LAUNCH_YEAR_NET_SALES_FIELD = 'newportLaunchYearNetSales';
export const NEWPORT_SUBMISSION_YEAR_FIELD = 'newportSubmissionYear';
export const NEWPORT_GLOBAL_NPV_YEAR_FIELD = 'newportGlobalNpvYear10';
export const NEWPORT_GLOBAL_IGM_PEAK_YEAR_FIELD = 'newportGlobalIgmPeakYear';
export const NEWPORT_GLOBAL_PEAK_NET_SALES_INCREMENTAL_FIELD =
  'newportGlobalPeakNetSalesIncremental';
export const NEWPORT_GLOBAL_PRODUCTIVITY_INDEX_FIELD = 'newportGlobalProductivityIndex';
export const REGPRIME_ZNUMBER = 'regprimeZNumber';
export const REGPRIME_SEQUENCE_NUMBER = 'regprimeSequenceNumber';
export const REGPRIME_PRODUCT_LINE_NUMBER_FIELD = 'regprimeProductLineNumber';
export const REGPRIME_COUNTRY_CODE_FIELD = 'regprimeCountryCode';
export const REGPRIME_CROP_CODE_FIELD = 'regprimeCropCode';
export const PRECISE_NEWPORT_ID = 'project.preciseNewportId';
export const PROJECT_ID = 'project.id';
export const SEGMENT_ID = 'id';
export const SUBMISSION_DATE_FIELD = 'submissionDate';
export const LAUNCH_DATE_FIELD = 'launchDate';
export const RS_PRODUCT_REMARK_FEILD = 'rsRegProductPtrsScoreRmk';
export const RS_PRODUCT_PTRS_SCORE = 'rsRegProductPtrsScore';
export const RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD = 'rsRegProductPtrsScoreModifiedBy';
export const RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE = 'rsRegProductPtrsScoreModifiedDate';
export const RS_DIETARY_REMARK_FIELD = 'rsRegDietaryPtrsScoreRmk';
export const RS_DIETARY_PTRS_SCORE = 'rsRegDietaryPtrsScore';
export const RS_DIETARY_PTRS_SCORE_MODIFIED_BY = 'rsRegDietaryPtrsScoreModifiedBy';
export const RS_DIETARY_PTRS_SCORE_MODIFIED_DATE = 'rsRegDietaryPtrsScoreModifiedDate';
export const RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE =
  'rsOccupationalResidentialExposurePtrsScore';
export const RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD =
  'rsOccupationalResidentialExposurePtrsScoreRmk';
export const RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY =
  'rsOccupationalResidentialExposurePtrsScoreModifiedBy';
export const RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE =
  'rsOccupationalResidentialExposurePtrsScoreModifiedDate';
export const RS_TOXICOLOGY_PTRS_SCORE = 'rsToxicologyPtrsScore';
export const RS_TOXICOLOGY_REMARK_FIELD = 'rsToxicologyPtrsScoreRmk';
export const RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY = 'rsToxicologyPtrsScoreModifiedBy';
export const RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE = 'rsToxicologyPtrsScoreModifiedDate';
export const RS_ECOTOX_PTRS_SCORE = 'rsEcotoxPtrsScore';
export const RS_ECOTOX_REMARK_FIELD = 'rsEcotoxPtrsScoreRmk';
export const RS_ECOTOX_PTRS_SCORE_MODIFIED_BY = 'rsEcotoxPtrsScoreModifiedBy';
export const RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE = 'rsEcotoxPtrsScoreModifiedDate';
export const RS_EFATE_PTRS_SCORE = 'rsEfatePtrsScore';
export const RS_EFATE_REMARK_FIELD = 'rsEfatePtrsScoreRmk';
export const RS_EFATE_PTRS_SCORE_MODIFIED_BY = 'rsEfatePtrsScoreModifiedBy';
export const RS_EFATE_PTRS_SCORE_MODIFIED_DATE = 'rsEfatePtrsScoreModifiedDate';
export const RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE = 'rsLocalRestrictionPolicyPtrsScore';
export const RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD = 'rsLocalRestrictionPolicyPtrsScoreRmk';
export const RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY =
  'rsLocalRestrictionPolicyPtrsScoreModifiedBy';
export const RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE =
  'rsLocalRestrictionPolicyPtrsScoreModifiedDate';
export const RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE = 'rsLocalRestrictionOthersPtrsScore';
export const RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD = 'rsLocalRestrictionOthersPtrsScoreRmk';
export const RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY =
  'rsLocalRestrictionOthersPtrsScoreModifiedBy';
export const RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE =
  'rsLocalRestrictionOthersPtrsScoreModifiedDate';
export const RS_FOREIGN_INFLUENCE_PTRS_SCORE = 'rsForeignInfluencePtrsScore';
export const RS_FOREIGN_INFLUENZE_REMARK_FIELD = 'rsForeignInfluencePtrsScoreRmk';
export const RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY = 'rsForeignInfluencePtrsScoreModifiedBy';
export const RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE =
  'rsForeignInfluencePtrsScoreModifiedDate';
export const RS_REGISTRATION_PTRS_SCORE = 'rsRegistrationPtrsScore';
export const RS_REGISTRATION_REMARK_FIELD = 'rsRegistrationPtrsScoreRmk';
export const RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY = 'rsRegistrationPtrsScoreModifiedBy';
export const RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE = 'rsRegistrationPtrsScoreModifiedDate';
export const COUNTRY_NAME = 'countryName';
export const CROP_NAME = 'cropName';

// Segment table of Regulatory Science in Project Ptrs screen
export const segmentColumnsOfRS = [
  COUNTRY_FIELD,
  CROP_FIELD,
  TARGET_FIELD,
  RS_REGULATORY_PTRS_SCORE_FIELD,
  RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD,
  REGPRIME_REGISTRATION_STATUS,
];

export const segmentColumnsOfFS = [
  COUNTRY_FIELD,
  CROP_FIELD,
  TARGET_FIELD,
  FS_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_REMARK_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD,
  REGPRIME_REGISTRATION_STATUS,
];

// Segment table in Project details screen
export const segmentColumnsOfProjectDetails = [
  COUNTRY_NAME,
  CROP_NAME,
  TARGET_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD,
  PTRS_SEGMENT_OVERALL_SCORE_FIELD,
  NEWPORT_LAUNCH_YEAR_SEGMENT_FIELD,
  NEWPORT_GLOBAL_NPV_YEAR_FIELD,
  NEWPORT_GLOBAL_FUTURE_PROJECT_COST_FIELD,
  NEWPORT_GLOBAL_IGM_PEAK_YEAR_FIELD,
  NEWPORT_GLOBAL_PEAK_NET_SALES_INCREMENTAL_FIELD,
  NEWPORT_GLOBAL_PRODUCTIVITY_INDEX_FIELD,
  REGPRIME_REGISTRATION_STATUS,
];

export const SegmentPtrsFields = [
  FT_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_FIELD,
  RS_REGULATORY_PTRS_SCORE_FIELD,
  PTRS_SEGMENT_OVERALL_SCORE_FIELD,
];

export const SegmentNASubscores = [
  RS_DIETARY_PTRS_SCORE,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
  RS_TOXICOLOGY_PTRS_SCORE,
  RS_ECOTOX_PTRS_SCORE,
  RS_EFATE_PTRS_SCORE,
  RS_REGISTRATION_PTRS_SCORE,
];

export const RegPrimeAndNewPortFields = [
  { newPort: '', regPrime: REGPRIME_PRODUCT_LINE_NUMBER_FIELD, label: Message.segmentDetail.plt },
  {
    newPort: COUNTRY_FIELD,
    regPrime: REGPRIME_COUNTRY_CODE_FIELD,
    label: Message.segmentDetail.country,
  },
  {
    newPort: CROP_FIELD,
    regPrime: REGPRIME_CROP_CODE_FIELD,
    label: Message.segmentDetail.crop,
  },
  {
    newPort: TARGET_FIELD,
    label: Message.segmentDetail.target,
  },
];

export const SegmentCostListMap = {
  formulationTechnology: 'Formulation Technology',
  regulatoryAffairs: 'Regulatory Affairs',
  registrationFees: 'Registration Fees',
  productSupply: 'Launch Marketing',
  humanSafety: 'Human Safety',
  environmentalSafety: 'Environmental Safetly',
  fieldDevelopment: 'Field Deveiopment',
  customerAdvisory: 'Customer Advisory',
  otherCosts: 'Other Costs',
};

export const NewPortFieldsOfMilestones = [
  NEWPORT_LAUNCH_YEAR_SEGMENT_FIELD,
  NEWPORT_SUBMISSION_YEAR_FIELD,
];

export const RegprimeOfMilestones = [
  { name: 'milestoneRegprimeActualSubmission', label: 'Submission Expected' },
  { name: 'milestoneRegprimeSubmissionPlanned', label: 'Submission Planned' },
  { name: 'milestoneRegprimeRegistrationExpected', label: 'Registration Expected' },
  { name: 'milestoneRegprimeRegistrationGrated', label: 'Registration Granted' },
];
export const numbesOfMilestones = [REGPRIME_ZNUMBER, REGPRIME_SEQUENCE_NUMBER];
export const withLinkPropertiesOfSegment = [COUNTRY_NAME, CROP_NAME, TARGET_FIELD];

export const PreciseFieldsOfMilestones = [SUBMISSION_DATE_FIELD, LAUNCH_DATE_FIELD];

export const SegmentSubScoresForNA = [
  {
    risk: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
    rationale: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD,
  },
  { risk: RS_DIETARY_PTRS_SCORE, rationale: RS_DIETARY_REMARK_FIELD },
  { risk: RS_TOXICOLOGY_PTRS_SCORE, rationale: RS_TOXICOLOGY_REMARK_FIELD },
  { risk: RS_ECOTOX_PTRS_SCORE, rationale: RS_ECOTOX_REMARK_FIELD },
  { risk: RS_EFATE_PTRS_SCORE, rationale: RS_EFATE_REMARK_FIELD },
  { risk: RS_REGISTRATION_PTRS_SCORE, rationale: RS_REGISTRATION_REMARK_FIELD },
];

export const SegmentSubScoresForAPAC = [
  { risk: RS_PRODUCT_PTRS_SCORE, rationale: RS_PRODUCT_REMARK_FEILD },
  {
    risk: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
    rationale: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD,
  },
  { risk: RS_DIETARY_PTRS_SCORE, rationale: RS_DIETARY_REMARK_FIELD },
  { risk: RS_TOXICOLOGY_PTRS_SCORE, rationale: RS_TOXICOLOGY_REMARK_FIELD },
  { risk: RS_ECOTOX_PTRS_SCORE, rationale: RS_ECOTOX_REMARK_FIELD },
  { risk: RS_EFATE_PTRS_SCORE, rationale: RS_EFATE_REMARK_FIELD },
  {
    risk: RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE,
    rationale: RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD,
  },
  {
    risk: RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE,
    rationale: RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD,
  },
  { risk: RS_FOREIGN_INFLUENCE_PTRS_SCORE, rationale: RS_FOREIGN_INFLUENZE_REMARK_FIELD },
];

export const segmentUpdateOptions = [
  {
    ptrsField: FT_PTRS_SCORE_FIELD,
    rationaleField: FT_PTRS_SCORE_REMARK_FIELD,
    updatedBy: FT_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: FT_PTRS_SCORE_MODIFIED_DATE_FIELD,
  },
  {
    ptrsField: FS_PTRS_SCORE_FIELD,
    rationaleField: FS_PTRS_SCORE_REMARK_FIELD,
    updatedBy: FS_PTRS_SCORE_UPDATED_BY_FIELD,
    updatedDate: FS_PTRS_SCORE_UPDATED_DATE_FIELD,
  },
  {
    ptrsField: RS_REGULATORY_PTRS_SCORE_FIELD,
    rationaleField: RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
    updatedBy: RS_PTRS_SCORE_UPDATED_BY_FIELD,
    updatedDate: RS_PTRS_SCORE_UPDATED_DATE_FIELD,
  },
  {
    ptrsField: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
    rationaleField: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD,
    updatedBy: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_TOXICOLOGY_PTRS_SCORE,
    rationaleField: RS_TOXICOLOGY_REMARK_FIELD,
    updatedBy: RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_ECOTOX_PTRS_SCORE,
    rationaleField: RS_ECOTOX_REMARK_FIELD,
    updatedBy: RS_ECOTOX_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_EFATE_PTRS_SCORE,
    rationaleField: RS_EFATE_REMARK_FIELD,
    updatedBy: RS_EFATE_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_EFATE_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE,
    rationaleField: RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD,
    updatedBy: RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_FOREIGN_INFLUENCE_PTRS_SCORE,
    rationaleField: RS_FOREIGN_INFLUENZE_REMARK_FIELD,
    updatedBy: RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_REGISTRATION_PTRS_SCORE,
    rationaleField: RS_REGISTRATION_REMARK_FIELD,
    updatedBy: RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_PRODUCT_PTRS_SCORE,
    rationaleField: RS_PRODUCT_REMARK_FEILD,
    updatedBy: RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD,
    updatedDate: RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_DIETARY_PTRS_SCORE,
    rationaleField: RS_DIETARY_REMARK_FIELD,
    updatedBy: RS_DIETARY_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_DIETARY_PTRS_SCORE_MODIFIED_DATE,
  },
  {
    ptrsField: RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE,
    rationaleField: RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD,
    updatedBy: RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY,
    updatedDate: RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE,
  },
];
