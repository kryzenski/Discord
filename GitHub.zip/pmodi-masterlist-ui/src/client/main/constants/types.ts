export type BreadCrumbsProps = {
  items: Array<{ path: string; text: string }>;
};

export type QuickScanResultProps = {
  quickScanData: Array<any>;
  detailPanel: any;
  hasTitle?: boolean;
  cssClass?: string;
  quickScanAssessmentId?: number;
  onLinkAssessement?(newQuickScanAssessmentId?: number): void;
  emptyViewCss?: string;
  type?: string;
  segmentData?: any;
  onSaveReason?(reason): void;
  onDeleteQuickScanId?(id): void;
};

export type DetailPanelProps = {
  items: Array<{ label: string; value: string }>;
  cssClass?: string;
};

export type AuditLogProps = {
  id: string;
  paths: Array<string>;
  fieldName: string;
  getValue?: Function;
  customClass?: string;
};

export type ScoreContainerProps = {
  data: {
    [propName: string]: any;
    rsPtrsScore: number;
    fsPtrsScore: number;
    ftPtrsScore: number;
  };
  type: string;
  hasButton?: boolean;
  onClick?: () => void;
  buttonText?: string;
  custmerClass?: any;
  custmerTextContainer?: any;
};

export type PtrsEditPanelProps = {
  itemRenderOptions: {
    scoreKey: string;
    scoreLabel: string;
    emptyText?: string;
    recommendationKey?: string;
    objectiveKey?: string;
    resultKey?: string;
    responsiblityKey?: string;
    statusKey?: string;
    ftrecommendationKey?: string;
    test?: any;
    rationaleKey: string;
    rationaleLabel: string;
    isEmptyView?: boolean;
    hasAuditLog?: boolean;
    path?: Array<string>;
    editableFields?: Array<string>;
    item: { [propName: string]: any };
    handleClick: Function;
  };
};

export type GapContainerProps = {
  itemRenderOptions: any;
  cssClass?: string;
};
