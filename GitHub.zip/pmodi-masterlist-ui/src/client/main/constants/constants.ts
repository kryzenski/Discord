import { PRECISE_NEW_PORT_ID_FIELD } from '@main/constants/projectOptions';

export const FIELD_NAME_MODIFIED_BY = 'modifiedBy';
export const FIELD_NAME_MODIFIED_AT = 'modifiedAt';
export const FIELD_NAME_REVISION_ID = 'revisionId';
export const FIELD_NAME_REVISION_VALUE = 'revisionValue';

export const FIELD_LABEL_CHANGED_BY = 'Changed by';
export const FIELD_LABEL_CHANGED_ON = 'Changed on';

export const AUDIT_LOG_INFO_ICON_TOOLTIP = 'View Change History';

export const GRID_EXTRA_SMALL = 'xs';
export const GRID_SMALL = 'sm';
export const GRID_MEDIUM = 'md';
export const GRID_LARGE = 'lg';
export const GRID_EXTRA_LARGE = 'xl';

export const AUDIT_LOG_URL_HISTORY = 'history';
export const AUDIT_LOG_URL_PROJECTS = 'projects';
export const AUDIT_LOG_URL_SEGMENTS = 'segments';
export const AUDIT_LOG_URL_QUESTIONS = 'questions';
export const AUDIT_LOG_URL_COSTS = 'costs';
export const AUDIT_LOG_URL_MODIFIED_FIELD = 'modified-field';
export const AUDIT_LOG_URL_REVISIONS = 'grouped-revisions';
export const AUDIT_LOG_URL_ATDATE = 'at-date';
export const AUDIT_LOG_PRRAMETERS_FIELDNAME = 'fieldName';
export const AUDIT_LOG_PRRAMETERS_DATE = 'date';

export const RESPONSE_DATA = 'data';

export const EMPTY_CELL_COLOR = '#f0f0f0';
export const EMPTY_PLACEHOLDER = '<<Deleted>>';
export const FT_RECOMMENDATION_DELETED =
  'Project category changed from New Formulation PoC to Formulation Development';
export const FT_RECOMMENDATION_DELETED_DEFAULT = 'PortRes-data.sql';
export const DELETED_CELL_COLOR = '#777777';
export const ACTION_CLOSE_POPUP = 'closePopup';
export const ACTION_ASYNC_GET_REVISIONS = 'getRevisions';

export const APRS_ACTIVE_INGREDIANT = 'activeIngrediant';
export const APRS_SCORE_VALUE = 'scoreValue';
export const APRS_REGION = 'region';
export const APRS_SCORE_COMMENT = 'scoreComment';
export const APRS_ACTION_ASYNC_GET_APRS = 'getAprs';
export const FS_RECCOMMENDATION_TITLE = 'FS RECOMMENDATION';
export const FS_RESULT_TITLE = 'FS RESULT';
export const FS_OBJECTIVE_TITLE = 'FS OBJECTIVE';
export const FS_RECOMMENDATION_FEILD = 'solRecommendation';
export const FS_RESULT_FEILD = 'solResult';
export const FS_OBJECTIVE_FEILD = 'solObjective';
export const RS_RECOMMENDATION_TITLE = 'RS RECOMMENDATION';
export const RS_RECOMMENDATION_FIELD = 'scienceRecommendation';
export const FT_RESPONSIBLITY_FIELD = 'techResponsability';
export const FT_RESPONSIBLITY_TITLE = 'FT RESPONSIBLITY';
export const FT_STATUS_FIELD = 'techStatus';
export const FT_STATUS_TITLE = 'FT STATUS';
export const FT_RECOMMENDATION_FIELD = 'techRecommendation';
export const FT_RECOMMENDATION_TITLE = 'FT RECOMMENDATION';

export const defaultOptions = {
  rowStyle: {
    height: 35,
    maxHeight: 35,
  },
  search: true,
  title: '',
  grouping: true,
  paging: false,
  sorting: true,
};

export const headerStyle = {
  fontSize: 15,
  height: 15,
  maxHeight: 15,
  paddingBottom: '1px',
  paddingTop: '1px',
  verticalAlign: 'top',
};

export const cellStyle = {
  paddingBottom: '10px',
  paddingTop: '10px',
  verticalAlign: 'top',
};

export const cellStyleForQuickScan = {
  paddingBottom: '10px',
  paddingTop: '10px',
};

export const cellStyleMitigation = {
  paddingBottom: '0px',
};

export const ASSESSMENT_DETAIL_LIST = 'assessmentDetailList';
export const ACTIVE_SUBSTANCE_SECIFICATION_NUMBER = 'activeSubstanceSpecificationNumber';
export const ACTIVE_SUBSTANCE_NAME = 'activeSubstanceName';
export const APPLICATION_TYPE_TEXT = 'applicationTypeText';
export const APPLICATION_EQUIPMENT_TEXT = 'applicationEquipmentText';
export const LOCATION_TYPE_TEXT = 'locationTypeText';
export const TIMING_FROM = 'timingFrom';
export const TIMING_TO = 'timingTo';
export const PHI = 'phi';
export const MAX_PRODUCT_AMOUNT = 'maxProductAmount';
export const MAX_NUMBER_OF_APPLICATION = 'maxNumberOfApplications';
export const MAX_PRODUCT_UNIT = 'maxProductUnit';
export const MIN_INTERVAL = 'minInterval';
export const CROP_HEIGHT = 'cropHeight';

export const MileStoneItems = [
  { left: 'plannedSubmissionDate', right: 'tradeName' },
  { left: 'actualSubmissionDate', right: 'regulatoryActionType' },
  { left: 'expectedRegistrationDate', right: 'productLineText' },
  { left: 'grantedRegistrationDate', right: 'country' },
  { left: 'registrationStatus', right: 'cropName' },
  { left: 'regulatoryActionStatus' },
];

export const GapItems = [
  { left: APPLICATION_TYPE_TEXT, right: PHI, unit: '' },
  { left: APPLICATION_EQUIPMENT_TEXT, right: MAX_PRODUCT_AMOUNT, unit: MAX_PRODUCT_UNIT },
  { left: LOCATION_TYPE_TEXT, right: MAX_NUMBER_OF_APPLICATION, unit: '' },
  { left: TIMING_FROM, right: MIN_INTERVAL, unit: '' },
  { left: TIMING_TO, right: CROP_HEIGHT, unit: '' },
];

export const defaultPageable = {
  page: 0,
  size: 50,
  sortBy: 'id',
  sortDir: 'ASC',
};

export const linkNewPort = 'https://by-dcccp.bayer-ag.com:50001/newport/app/projectView?projectId=';

export const assessmentLink = 'https://quickscan.int.bayer.com/stored-assessments';

export const newPortNumberDefaultFilter = {
  facet: {
    dataType: 'string',
    endpointAddress: '/ui/distinct-properties?entityType=PROJECT&fieldName=preciseNewportId',
    entityType: 'PROJECT',
    facetName: 'Project: NewPort #',
    facetType: 'autocomplete',
    fieldName: PRECISE_NEW_PORT_ID_FIELD,
    groupName: 'NewPort',
    multiSelect: true,
    values: [],
  },
  filter: {
    entityType: 'PROJECT',
    fieldName: PRECISE_NEW_PORT_ID_FIELD,
    operator: 'in',
    stringValues: [],
  },
};

export const allowEditGroups = {
  PROJECT_PTRS: { label: 'Project PTRS', value: true },
  PROJECT_GUIDANCE_IP: { label: 'Project Global Guidance. 3rd Party AI and IP Check', value: true },
  PROJECT_PRIO: { label: 'Project Prioritization', value: true },
  SEGMENT_PTRS: { label: 'Segment PTRS', value: true },
};
