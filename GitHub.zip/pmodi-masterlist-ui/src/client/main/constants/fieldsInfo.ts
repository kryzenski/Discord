import _ from 'lodash';

import { toInteger } from '@shared/utils/numberUtils';
import { sortByKey, convertArrayToMap } from '@shared/utils/functionUtils';
import { getStringFromNumberWithThousandsSeparator } from '@shared/utils/numberUtils';
import { PRIORITIZATION_TYPE_FIELD } from '@main/constants/projectOptions';
export const TYPE_PROJECT = 'project';
export const TYPE_SEGMENT = 'segment';

export const FORMATTER_TO_PERCENT = 'toPercent';
export const FORMATTER_TO_NUMBER = 'toNumber';
const FORMATTER_WITH_THOUSAND_SEPARATOR = 'withThousandSeparator';
const FORMATTER_TO_BOOLEAN = 'toBoolean';

export const FIELD_LABEL = 'label';
export const FIELD_TITLE = 'title';
export const FIELD_INFO_KEY = 'field';
export const FIELD_DEFAULT_COLUMN = 'defaultColumn';
export const FIELD_HIDDEN_COLUMN = 'hiddenColumn';
export const FIELD_AUDITLOG_FIELDS = 'auditLogFields';
export const FIELD_ORDER = 'order';

export const renderFunc = fieldInfo => rowData => {
  const { field, formatter } = fieldInfo;
  const fieldValue = _.isPlainObject(rowData) ? _.get(rowData, field, '') : rowData;
  if (formatter === FORMATTER_TO_PERCENT) {
    return fieldValue === 'null' ? '' : toInteger(fieldValue);
  } else if (formatter === FORMATTER_WITH_THOUSAND_SEPARATOR) {
    return getStringFromNumberWithThousandsSeparator(fieldValue) || '';
  } else if (formatter === FORMATTER_TO_BOOLEAN) {
    return fieldValue ? 'Yes' : 'No';
  } else if (field === PRIORITIZATION_TYPE_FIELD) {
    return fieldValue === 'null' ? 'No Category ' : fieldValue;
  }
  return fieldValue;
};

const withRender = fieldInfo => ({ ...fieldInfo, render: renderFunc(fieldInfo) });

let propertyInfo = null;
let pageSize = null;
export const setPropertyInfo = preloadedState => {
  propertyInfo = preloadedState.propertyInfo;
  pageSize = preloadedState.endpoints.pageSize;
};

const getFieldsInfo = (type: string) => {
  const fieldsWithAllInfo = _.map(propertyInfo[type], fieldInfo => ({
    ...propertyInfo.defaultInfo,
    ...withRender(fieldInfo),
  }));
  return convertArrayToMap(fieldsWithAllInfo, FIELD_INFO_KEY);
};

const getFields = (type, isDefault) =>
  _.filter(propertyInfo[type], info =>
    isDefault
      ? info[FIELD_DEFAULT_COLUMN]
      : !info[FIELD_DEFAULT_COLUMN] && !info[FIELD_HIDDEN_COLUMN],
  );

const getFieldsWithAllInfo = (type, isDefault) =>
  _.map(getFields(type, isDefault), it => ({ ...propertyInfo.defaultInfo, ...withRender(it) }));

const getSortedFields = (type, isDefault = true) =>
  sortByKey(getFieldsWithAllInfo(type, isDefault), FIELD_ORDER);

export const getSortedFieldsOfProject = isDefault => getSortedFields(TYPE_PROJECT, isDefault);
export const getSortedFieldsOfSegment = isDefault => getSortedFields(TYPE_SEGMENT, isDefault);

export const getFieldsInfoOfProject = (): object => getFieldsInfo(TYPE_PROJECT);
export const getFieldsInfoOfSegment = (): object => getFieldsInfo(TYPE_SEGMENT);

export const getPageSize = () => {
  return pageSize;
};

export const getAllFieldsInfo = paths =>
  _.includes(paths, 'projects') ? getFieldsInfoOfProject() : getFieldsInfoOfSegment();

export const getFieldInfo = (fieldName, paths) => _.get(getAllFieldsInfo(paths), fieldName);

export const getLabel = (fieldName, paths) =>
  _.get(getFieldInfo(fieldName, paths), FIELD_LABEL, '');

export const getLabelOfProjectField = fieldName =>
  _.get(_.get(getFieldsInfoOfProject(), fieldName), FIELD_LABEL, '');

export const getLabelOfSegmentField = fieldName =>
  _.get(_.get(getFieldsInfoOfSegment(), fieldName), FIELD_LABEL, '');

export const getAuditLogFields = (fieldName, paths) =>
  _.get(getFieldInfo(fieldName, paths), FIELD_AUDITLOG_FIELDS) || [fieldName];
