import _ from 'lodash';
export const MASTER_LIST_OPTIONS = 'masterListViewOptions';
const SEARCH_FILTER = 'searchFilter';

export const setMatsterViewOptionsToLocalStorage = (options, type) => {
  const masterListViewOptions = JSON.parse(localStorage.getItem(MASTER_LIST_OPTIONS));
  const tableOptions = _.get(masterListViewOptions, type);
  const newTableOptions = {
    ...tableOptions,
    ...options,
  };
  const newMasterListViewOptions = {
    ...masterListViewOptions,
  };
  newMasterListViewOptions[type] = newTableOptions;
  localStorage.setItem(MASTER_LIST_OPTIONS, JSON.stringify(newMasterListViewOptions));
};

export const getMatsterViewOptionsFromLocalStorage = type => {
  const masterListViewOptions = JSON.parse(localStorage.getItem(MASTER_LIST_OPTIONS));
  const tableOptions = _.get(masterListViewOptions, type);
  return tableOptions;
};

export const getSearchFiltersFromLocalStorage = () => {
  const result = localStorage.getItem(SEARCH_FILTER);
  return result ? JSON.parse(result) : null;
};

export const setSearchFiltersFromLocalStorage = filters => {
  localStorage.setItem(SEARCH_FILTER, JSON.stringify(filters));
};
