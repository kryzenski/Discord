import React, { Fragment } from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import _ from 'lodash';
import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import WarningIcon from '@material-ui/icons/Warning';
import InfoIcon from '@material-ui/icons/Info';
import HelpIcon from '@material-ui/icons/Help';
import { cellStyle } from '@main/constants/constants';
import { Message } from '@shared/utils/message';
import { GapContainer } from '@main/components/GapContainer/GapContainer';
import { QuickScanMitigation } from '../../components/QuickScanMitigation/QuickScanMitigation';

const useStyles = makeStyles(() =>
  createStyles({
    subTableTitle: {
      fontSize: '16px',
      marginLeft: '-3%',
      marginTop: '1%',
    },
    detailPanel: {
      marginLeft: '4%',
      marginTop: '1%',
      borderRadius: '4px',
      borderColor: '#737373',
      width: '94%',
    },
    subTable: {
      marginTop: '-1%',
      marginBottom: '3%',
    },
    messageICon: {
      marginBottom: '-0.5%',
      marginRight: '1%',
    },
    gapTitle: {
      fontSize: '16px',
      marginLeft: '45%',
      marginTop: '1%',
    },
    gapDetailPanel: {
      marginLeft: '1%',
      marginTop: '1%',
      borderRadius: '4px',
      borderColor: '#737373',
      marginBottom: '1%',
    },
    gapContainer: {
      marginTop: '-1%',
      marginBottom: '1%',
      width: '99%',
    },
    textField: {
      textAlign: 'center',
      marginTop: '8px',
      fontSize: '17px',
    },
  }),
);

const MessageIcon = ({ messageLevel }: { messageLevel: string }) => {
  const classes = useStyles();
  let Icon = null;
  if (messageLevel === 'WARN') {
    Icon = <WarningIcon className={classes.messageICon} />;
  } else if (messageLevel === 'INFO') {
    Icon = <InfoIcon className={classes.messageICon} />;
  } else if (messageLevel === 'MISSING') {
    Icon = <HelpIcon className={classes.messageICon} />;
  }
  return Icon;
};

export const getSubTableColumn = () => {
  const columns = [
    {
      title: 'Category',
      field: 'assessmentCategory',
      width: '10%',
    },
    {
      title: 'Score',
      field: 'ptrsScore',
      width: '10%',
    },
    {
      title: 'Comment',
      field: 'expertComment',
      width: '80%',
      render: rowData => {
        const messagesList = rowData.assessmentDetailMessageList;
        return _.map(messagesList, message => (
          <Fragment>
            <MessageIcon messageLevel={message.messageLevel} />
            <label>{message.message}</label>
            <br />
          </Fragment>
        ));
      },
    },
  ];
  return columns.map(column => ({
    ...column,
    cellStyle,
  }));
};

export const gapDetailPanel = () => {
  const classes = useStyles();
  const title = Message.ptrs.segmentGapInformation;
  return [
    {
      render: rowData => {
        return (
          <div className={classes.detailPanel}>
            <h6 className={classes.gapTitle}>{title}</h6>
            <GapContainer itemRenderOptions={rowData} cssClass={classes.gapContainer} />
          </div>
        );
      },
    },
  ];
};

export const assessmentDetailPanel = () => {
  const classes = useStyles();
  return [
    {
      render: rowData => {
        const assessmentDetailList = rowData.assessmentDetailList;
        const subPanels = _.keys(assessmentDetailList);
        const panelDetails = _.map(subPanels, subPanel => (
          <div className={classes.detailPanel}>
            <h6 className={classes.subTableTitle}>{subPanel}</h6>
            <div className={classes.subTable}>
              <TableComponent
                itemRenderOptions={{
                  columns: getSubTableColumn(),
                  data: assessmentDetailList[subPanel],
                  maxBodyHeight: '400px',
                  toolbar: false,
                }}
              />
            </div>
          </div>
        ));
        return (
          <div>
            {rowData?.isAllMitigationPresent !== false && rowData?.mitigationDetail ? (
              <QuickScanMitigation itemRenderOptions={rowData.mitigationDetail} />
            ) : (
              // <div className={classes.textField}></div>
              <div></div>
            )}
            {panelDetails}
          </div>
        );
      },
    },
  ];
};
