import {
  getLockGroups,
  updateUnLockGroup,
  updateLockGroup,
} from '@main/serviceData/permission/permission';
export const AdminArea = {
  state: { lockGroups: [], isLoadding: false },

  effects: () => ({
    async fetchLockGroups() {
      this.setLoading(true);
      const lockGroups = await getLockGroups();
      this.setLockGroups(lockGroups);
      this.setLoading(false);
    },
    async updatePermission({ lockGroups, unLockGroups }) {
      this.setLoading(true);
      await updateLockGroup(lockGroups);
      await updateUnLockGroup(unLockGroups);
      this.setLoading(false);
    },
  }),

  reducers: {
    setLockGroups(state, lockGroups) {
      state.lockGroups = lockGroups;
      return state;
    },
    setLoading(state, isLoading) {
      state.isLoadding = isLoading;
      return state;
    },
  },
};
