import _ from 'lodash';
import {
  RS_REGULATORY_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_FIELD,
} from '@main/constants/segmentOptions';
import { FilterInfo } from '@main/modules/masterList/FacetUtil';
import { typeState } from '@main/stateManagement/store';
import {
  getProjectDataById,
  updateProject,
  getAllowableEditFields,
  updateSegment,
  getSegmentDataById,
  getQuickscanAssessments,
  downloadExport,
  getProjectDataByDate,
  searchSegmentsOfProjectsBySelectedDate,
  getPreciseCostListOfSegment,
  updatePreciseCostListOfSegment,
  downloadPreciseCostListExport,
  getMilestonesOfSegment,
  getSegmentsByProjectId,
  getQuickscanMitigation,
  getMileStoneOfProject,
} from '@main/serviceData/project/projects';
import { defaultPageable } from '@main/constants/constants';
import { calculateWeightedScore } from '@main/modules/matserListUtil';
import { getSearchFiltersFromLocalStorage } from '../security/localStore';

export const checkFilterActive = filters => filters.length > 0;
export const buildFilter = (
  filterInfos: Array<FilterInfo>,
  targetSearchType: 'projects' | 'segments',
) => {
  if (targetSearchType === 'segments') {
    const adaptedFilters = _.map(filterInfos, fi => {
      const filter = fi.filter;
      const fieldName = (filter.entityType === 'PROJECT' ? 'project.' : '') + filter.fieldName;
      return { ...filter, fieldName: fieldName };
    });
    return adaptedFilters;
  } else if (targetSearchType === 'projects') {
    const adaptedFilters = _.map(filterInfos, fi => {
      const filter = fi.filter;
      const fieldName = (filter.entityType === 'SEGMENT' ? 'segments.' : '') + filter.fieldName;
      return { ...filter, fieldName: fieldName };
    });
    return adaptedFilters;
  }
  return filterInfos;
};
// TODO: this is not a good solution as it copies data which is originally present in the database and may change in the future
const defaultFilters: Array<FilterInfo> = [
  {
    facet: {
      dataType: 'string',
      endpointAddress: null,
      entityType: 'PROJECT',
      facetName: 'Project: NewPort Status',
      facetType: 'checkbox',
      fieldName: 'newportStatus',
      values: [
        'Draft',
        'Proposal',
        'Freeze',
        'In Progress',
        'Launched',
        'Under Assessment',
        'Cancelled',
        'Deleted',
        'On Hold',
      ],
    },
    filter: {
      entityType: 'PROJECT',
      fieldName: 'newportStatus',
      operator: 'in',
      stringValues: ['Draft', 'Proposal', 'Freeze', 'In Progress', 'Under Assessment', 'On Hold'],
    },
  },
];

export const MasterList = {
  state: {
    projectId: '',
    filters: defaultFilters,
    openSearchFilter: false,
    filterInfos: {},
    projects: {
      currentItem: {},
      selectedColumns: [],
      unSelectedColumns: [],
      editbaleFieldsMap: new Map(),
      quickscanAssessments: {},
      quickscanMitigation: {},
      mileStones: [],
    },
    segments: {
      currentItem: {},
      segmentsData: [],
      weightedRSScore: 0,
      weightedFSScore: 0,
      selectedColumns: [],
      unSelectedColumns: [],
      editbaleFieldsMap: new Map(),
      quickscanAssessments: {},
      newPortCostList: [],
      preciseCostList: [],
      mileStones: {},
      quickscanMitigation: {},
    },
  },
  effects: () => ({
    async downloadExport({ failureCallback, stopLoading, isMounted }, rootState: typeState) {
      const localFilters = getSearchFiltersFromLocalStorage();
      const reducerFilter = rootState.MasterList.filters;
      const filters = localFilters !== null ? localFilters : reducerFilter;

      const filtersForDownload = buildFilter(filters, 'projects');
      const filtersForDownloadSegments = buildFilter(filters, 'segments');
      downloadExport(
        {
          filterConditions: filtersForDownload,
          filterConditionSegment: filtersForDownloadSegments,
          defaultPageable,
        },
        failureCallback,
        stopLoading,
        isMounted,
      );
    },
    async getProjectDataById(id) {
      const currentItem = await getProjectDataById(id);
      this.setCurrentItem({ item: currentItem, type: 'projects' });
    },
    async getProjectDataByDate({ id, date }) {
      const currentItem = await getProjectDataByDate(id, date);
      this.setCurrentItem({ item: currentItem, type: 'projects' });
    },
    async getSegmentDataById(id) {
      const currentItem = await getSegmentDataById(id);
      this.setCurrentItem({ item: currentItem, type: 'segments' });
    },
    async updateProject({ entity, id }) {
      const newEntity = await updateProject(entity, id);
      newEntity && this.setCurrentItem({ item: newEntity, type: 'projects' });
    },
    async updateSegment({ entity, id }) {
      const newEntity = await updateSegment(entity, id);
      newEntity && this.setCurrentItem({ item: newEntity, type: 'segments' });
    },
    async fetchSegmentsByProjectIdWithoutPaging(id) {
      const results = await getSegmentsByProjectId(id);
      this.setSegmentTableData(results);
    },
    async fetchSegmentByDate({ id, date }) {
      const results = await searchSegmentsOfProjectsBySelectedDate(id, date);
      this.setSegmentTableData(results);
    },
    async fetchEditableFieldsOfProject(id) {
      const editbaleFields = await getAllowableEditFields(id, 'projects');
      this.setEditbaleFields({ id, editbaleFields, type: 'projects' });
    },
    async fetchEditableFieldsOfSegment(id) {
      const editbaleFields = await getAllowableEditFields(id, 'segments');
      this.setEditbaleFields({ id, editbaleFields, type: 'segments' });
    },
    async fetchQuickscanMitigation({ id, type }) {
      const quickscanMitigation = await getQuickscanMitigation(id, type);
      this.setQuickscanMitigation({ quickscanMitigation, type });
    },
    async fetchQuickscanAssessments({ id, type }) {
      const quickscanAssessments = await getQuickscanAssessments(id, type);
      this.setQuickscanAssessments({ quickscanAssessments: quickscanAssessments, type });
    },
    async fetchPreciseCostListOfSegment({ id }) {
      const preciseCostList = await getPreciseCostListOfSegment(id, defaultPageable);
      this.setPreciseCostList({ preciseCostList });
    },
    async updatePreciseCostListOfSegment({ entity, segmentId }) {
      const newEntity = await updatePreciseCostListOfSegment(entity.id, entity);
      newEntity && this.fetchPreciseCostListOfSegment({ id: segmentId });
    },
    async downloadPreciseCostListExport({ segmentId, failureCallback }) {
      downloadPreciseCostListExport(segmentId, failureCallback);
    },
    async fetchMilestonesOfSegment({ id }) {
      const milestones = await getMilestonesOfSegment(id, defaultPageable);
      this.setMilestones({ milestones });
    },
    async fetchMilestoneOfProject({ id }) {
      const milestones = await getMileStoneOfProject(id);
      this.setMilestonesForProject({ milestones });
    },
  }),
  reducers: {
    setProjectID(state, id) {
      state.projectId = id;
      return state;
    },
    setCurrentItem(state, { item, type }) {
      state[type].currentItem = item;
      return state;
    },
    setSelectedColumns(state, { columns, type }) {
      state[type].selectedColumns = columns;
      return state;
    },
    setUnSelectedColumns(state, { columns, type }) {
      state[type].unSelectedColumns = columns;
      return state;
    },
    setSegmentTableData(state, segments) {
      state.segments.segmentsData = segments;
      const weightedRSScore = calculateWeightedScore(segments, RS_REGULATORY_PTRS_SCORE_FIELD);
      const weightedFSScore = calculateWeightedScore(segments, FS_PTRS_SCORE_FIELD);
      state.segments.weightedRSScore = weightedRSScore;
      state.segments.weightedFSScore = weightedFSScore;
      return state;
    },
    setEditbaleFields(state, { id, editbaleFields, type }) {
      state[type].editbaleFieldsMap.set(id, editbaleFields);
      return state;
    },
    setFilterConfigrationDatas(state, filters) {
      state.filters = filters;
      return state;
    },
    setQuickscanAssessments(state, { quickscanAssessments, type }) {
      state[type].quickscanAssessments = quickscanAssessments;
      return state;
    },
    setQuickscanMitigation(state, { quickscanMitigation, type }) {
      state[type].quickscanMitigation = quickscanMitigation;
      return state;
    },
    initColumns(
      state,
      {
        projectSelectedColumns,
        projectUnselectedColumns,
        segmentSelectedColumns,
        segmentUnSelectedColumns,
      },
    ) {
      state.projects.selectedColumns = projectSelectedColumns;
      state.projects.unSelectedColumns = projectUnselectedColumns;
      state.segments.selectedColumns = segmentSelectedColumns;
      state.segments.unSelectedColumns = segmentUnSelectedColumns;
      return state;
    },
    setNewPortCostList(state, { newPortCostList }) {
      state.segments.newPortCostList = newPortCostList;
      return state;
    },
    setPreciseCostList(state, { preciseCostList }) {
      state.segments.preciseCostList = preciseCostList;
      return state;
    },
    setMilestones(state, { milestones }) {
      state.segments.mileStones = milestones;
      return state;
    },
    setMilestonesForProject(state, { milestones }) {
      state.projects.mileStones = milestones;
      return state;
    },
    openSearchFilterView(state, openSearchFilter) {
      state.openSearchFilter = openSearchFilter;
      return state;
    },
  },
};
