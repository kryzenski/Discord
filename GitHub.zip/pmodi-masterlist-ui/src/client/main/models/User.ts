import { getCurrentUser } from '@main/serviceData/user/users';

export const User = {
  state: {
    userName: 'loading',
    userRoles: [],
    userRolesStr: 'Default User',
  },
  effects: () => ({
    async getUserInfo() {
      const currentUser = await getCurrentUser();
      this.setUserInfo(currentUser);
    },
  }),
  reducers: {
    setUserInfo(state, data) {
      state.userName = data.userName;
      state.userRoles = data.userRoles;
      state.userRolesStr = data.userRolesStr;
      return state;
    },
  },
};
