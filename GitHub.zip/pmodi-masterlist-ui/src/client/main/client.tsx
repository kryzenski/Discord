require('jspolyfill-array.prototype.findIndex');
import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Provider } from 'react-redux';

import { initSecurity } from '@shared/utils/securityUtils';
import { store } from '@main/stateManagement/store';
import { Routers } from '@main/modules/Routers';
import { setGetState } from '@main/serviceData/apiUtils';

initSecurity();
setGetState(store.getState);

ReactDom.render(
  <Provider store={store}>
    <Routers />
  </Provider>,
  document.getElementById('root'),
);
