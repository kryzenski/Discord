import React, { createContext, useState } from 'react';
import { Route, Switch, Redirect, BrowserRouter as Router, useLocation } from 'react-router-dom';

import MainPage from '@main/modules/masterList/MainPage';
import projectDetail from '@main/modules/projectDetails/index';
import segmentDetail from '@main/modules/segmentDetails/index';
import projectPtrsAssessment from '@main/modules/projectPtrsAssessment/index';
import segmentPtrs from '@main/modules/segmentPtrsAssessment/index';
import adminArea from '@main/modules/admin/adminArea';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import CssBaseline from '@material-ui/core/CssBaseline';
import AccountCircle from '@material-ui/icons/AccountCircle';
import { makeStyles } from '@material-ui/core/styles';
import UserInfo from '@main/modules/user/UserInfo';
import logoSmallSrc from '@main/resources/images/pmo_logo.png';
import restrictedLogoSrc from '@main/resources/images/restricted_logo.png';
import { ErrorHandler } from '@main/components/ErrorHandler/ErrorHandler';

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
  },
  grow: {
    width: '100px',
  },
  userinfo: {
    display: 'flex',
    position: 'absolute',
    right: 0,
  },
  margin: {
    margin: theme.spacing(1),
  },
  large: {
    margin: '0 10px',
    width: theme.spacing(7),
    height: theme.spacing(7),
  },
  header: {
    backgroundColor: '#4169e1',
    height: '64px',
  },
  logo: {
    marginLeft: '-20%',
    marginTop: '10%',
    height: '60px',
  },
  title: {
    marginLeft: '-2.5%',
  },
  restrictedLogo: {
    height: '40px',
    marginLeft: '25%',
    marginTop: '5%',
  },
}));

interface LoadingContextType {
  loading: boolean;
  startLoading: () => void;
  stopLoading: () => void;
}

const defaultLoadingState: LoadingContextType = {
  loading: false,
  startLoading: () => {
    console.log('startLoading function is not implemented');
  },
  stopLoading: () => {
    console.log('stopLoading function is not implemented');
  },
};

export const LoadingContext = createContext<LoadingContextType>(defaultLoadingState);

export const Routers = () => {
  const classes = useStyles();
  const [loading, setLoading] = useState(false);

  const startLoading = () => {
    document.title = 'Downloading...';
    setLoading(true);
  };

  const stopLoading = () => {
    setLoading(false);
    document.title = 'PRECISE Bayer CropScience';
  };
  return (
    <Router>
      <ErrorHandler>
        <div className={classes.root}>
          <CssBaseline />
          <AppBar position="fixed" className={classes.header}>
            <Toolbar>
              <div className={classes.grow}>
                <img src={logoSmallSrc} className={classes.logo} />
              </div>
              <Typography variant="h5" className={classes.title}>
                PRECISE
              </Typography>
              <div className={classes.grow}>
                <img src={restrictedLogoSrc} className={classes.restrictedLogo} />
              </div>
              <div className={classes.userinfo}>
                <UserInfo />
                <AccountCircle className={classes.large} />
              </div>
            </Toolbar>
          </AppBar>
          <LoadingContext.Provider value={{ loading, startLoading, stopLoading }}>
            {
              <Switch>
                <Route exact path="/">
                  <MainPage />
                </Route>
                <Route exact path="/project/:id" component={projectDetail} />
                <Route exact path="/project/:id/at-date/:date" component={projectDetail} />
                <Route exact path="/project/:id/ptrs" component={projectPtrsAssessment} />
                <Route exact path="/segment/:segmentId" component={segmentDetail} />
                <Route exact path="/segment/:segmentId/ptrs" component={segmentPtrs} />
                <Route exact path="/admin" component={adminArea} />
                <Route path="*">
                  <NoMatch />
                </Route>
                <Redirect to="/home"></Redirect>
              </Switch>
            }
          </LoadingContext.Provider>
        </div>
      </ErrorHandler>
    </Router>
  );
};

function NoMatch() {
  const location = useLocation();
  return (
    <div>
      <h3>
        No match for <code>{location.pathname}</code>
      </h3>
    </div>
  );
}
