import React, { useState } from 'react';
import clsx from 'clsx';
import _ from 'lodash';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { Icon, Tooltip, TextField } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CloseSharpIcon from '@material-ui/icons/CloseSharp';
import { Message } from '@shared/utils/message';
import { Facet, ValuesCriterion } from './FacetUtil';
import { getValueOfAutoComplete } from '../../serviceData/ui/filter';
import SearchIcon from '@material-ui/icons/Search';
import { isNotEmptyValue, isEmptyValue } from '@shared/utils/functionUtils';
import { monthValue } from '../../constants/projectOptions';

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      display: 'flex',
      flexDirection: 'column',
      marginBottom: '4px',
      backgroundColor: 'white',
    },
    header: {
      backgroundColor: '#6495ED',
      justifyContent: 'space-between',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
    },
    headerLeft: {
      alignSelf: 'center',
      display: 'flex',
      flexDirection: 'row',
    },
    title: {
      fontWeight: 'bold',
      alignSelf: 'center',
      color: '#FFFFFF',
    },
    filterTypeIcon: {
      marginLeft: '5px',
      marginRight: '5px',
      color: '#FFFFFF',
    },
    closeIcon: {
      marginRight: '3px',
      color: '#FFFFFF',
    },
    errorColor: {
      color: 'red',
    },
    errorBorder: {
      border: '1px solid red',
    },
    line: {
      display: 'flex',
      flexDirection: 'row',
    },
  }),
);

interface DropdownItem {
  value: any;
  title: string;
}

interface CreationDateCriterion {
  yearCriterion: ValuesCriterion;
  monthCriterion: ValuesCriterion;
}

export interface AutocompleteFacetProps {
  facet: Facet;
  initialCriterion: any;
  delete(facet: Facet): any;
  criteriaChange(criterion: ValuesCriterion | null);
}

const AutocompleteFacet = React.memo((props: AutocompleteFacetProps) => {
  const classes = useStyles();
  const isYearFilter =
    props.facet.fieldName === 'draftYear' ||
    props.facet.fieldName === 'approvalYear' ||
    props.facet.fieldName === 'creationYear';

  let initialSelectedValue = [];
  let initialOptions: Array<DropdownItem> = [];
  let initialMonthSelectedValue = [];
  let initialMonthOptions: Array<DropdownItem> = [];

  if (isYearFilter) {
    const initialValuesYear = props.initialCriterion.yearCriterion.values;
    if (isNotEmptyValue(initialValuesYear)) {
      initialSelectedValue = _.map(initialValuesYear, value => ({ title: value, value }));
      initialOptions = initialSelectedValue;
    }
    const initialValuesMonth = props.initialCriterion.monthCriterion.values;
    if (isNotEmptyValue(initialValuesMonth)) {
      initialMonthSelectedValue = _.map(initialValuesMonth, value => ({ title: value, value }));
      initialMonthOptions = initialMonthSelectedValue;
    }
  } else {
    const initialValus = props.initialCriterion.values;
    if (isNotEmptyValue(initialValus)) {
      initialSelectedValue = _.map(initialValus, value => ({ title: value, value }));
      initialOptions = initialSelectedValue;
    }
  }
  const [state, setState] = useState({
    selectedValue: initialSelectedValue,
    options: initialOptions,
    monthSelectedVal: initialMonthSelectedValue,
    monthOptions: initialMonthOptions,
    loading: false,
    loadingError: null,
  });

  const handleSearch = searchTerm => {
    if (searchTerm) {
      const searchParam = {
        entityType: props.facet.entityType,
        fieldName: props.facet.fieldName,
        limit: 10000,
        startsWith: searchTerm,
      };
      setState({ ...state, loading: true, loadingError: null });
      const promise = getValueOfAutoComplete(searchParam);
      promise.then(
        successResponse => {
          setState({ ...state, options: successResponse, loading: false });
        },
        err => {
          // TODO: test this code part
          const msg = JSON.stringify(err);
          console.log('Error: ' + msg);
          setState({ ...state, loading: false, loadingError: msg });
        },
      );
    }
  };

  let errorControl = null;
  let errorInfo = isEmptyValue(state.selectedValue)
    ? Message.filter.autocomplete.errorMessageNoValue
    : null;
  if (errorInfo === null && state.loadingError) {
    errorInfo = state.loadingError;
  }
  const hasError = errorInfo !== null;
  if (hasError) {
    errorControl = (
      <Tooltip title={errorInfo}>
        <Icon className={classes.errorColor}>error</Icon>
      </Tooltip>
    );
  }

  const onSelectionChange = newSelectedValues => {
    if (newSelectedValues) {
      const crit: ValuesCriterion = {
        values: newSelectedValues.map(option => option.value),
      };
      props.criteriaChange(crit);
      setState({ ...state, selectedValue: newSelectedValues });
    } else {
      props.criteriaChange(null);
      setState({ ...state, selectedValue: [] });
    }
  };

  const onYearChange = newSelectedValues => {
    if (newSelectedValues.length > 0) {
      const arr = [];
      if (state.monthSelectedVal.length > 0) {
        for (const yearVal of newSelectedValues) {
          for (const monthVal of state.monthSelectedVal) {
            const monthAndYear = `${yearVal.value}-${monthVal.value}`;
            arr.push(monthAndYear);
          }
        }
        const crit: ValuesCriterion = {
          values: arr,
        };
        props.criteriaChange(crit);
        setState({ ...state, selectedValue: newSelectedValues });
      } else {
        const crit: ValuesCriterion = {
          values: newSelectedValues.map(option => option.value),
        };
        props.criteriaChange(crit);
        setState({ ...state, selectedValue: newSelectedValues });
      }
    } else {
      props.criteriaChange(null);
      setState({ ...state, selectedValue: [] });
    }
  };

  const onMonthChange = newSelectedValues => {
    if (newSelectedValues.length > 0) {
      const arr = [];
      if (state.selectedValue) {
        for (const yearVal of state.selectedValue) {
          for (const monthVal of newSelectedValues) {
            const monthAndYear = `${yearVal.value}-${monthVal.value}`;
            arr.push(monthAndYear);
          }
        }
        const crit: ValuesCriterion = {
          values: arr,
        };
        props.criteriaChange(crit);
        setState({ ...state, monthSelectedVal: newSelectedValues });
      }
    } else {
      const crit: ValuesCriterion = {
        values: _.map(state.selectedValue, option => option.value),
      };
      props.criteriaChange(crit);
      setState({ ...state, monthSelectedVal: newSelectedValues });
    }
  };

  return (
    <div
      key={'auto_' + props.facet.facetName}
      className={hasError ? clsx(classes.root, classes.errorBorder) : classes.root}
    >
      <div className={classes.header}>
        <div className={classes.headerLeft}>
          <SearchIcon className={classes.filterTypeIcon} />
          <div className={classes.title}>{props.facet.facetName}</div>
          {errorControl}
        </div>
        <CloseSharpIcon className={classes.closeIcon} onClick={() => props.delete(props.facet)} />
      </div>
      {isYearFilter ? (
        <div style={{ display: 'flex' }}>
          <div style={{ margin: '4px', width: '50%' }}>
            <Autocomplete
              filterSelectedOptions
              multiple
              options={state.options}
              loading={state.loading}
              defaultValue={initialSelectedValue}
              getOptionLabel={option => option.title}
              noOptionsText={Message.filter.autocomplete.comboNoOptions}
              autoHighlight
              style={{ flex: 1 }}
              size="small"
              renderInput={params => (
                <TextField
                  {...params}
                  placeholder={Message.filter.autocomplete.comboPlaceholderYear}
                  variant="outlined"
                />
              )}
              onChange={(event, value) => onYearChange(value)}
              onInputChange={(event, value) => handleSearch(value)}
            />
          </div>
          <div style={{ margin: '4px', width: '50%' }}>
            <Autocomplete
              multiple
              filterSelectedOptions
              options={monthValue}
              getOptionLabel={monthValue => monthValue.title}
              autoHighlight
              style={{ flex: 1 }}
              defaultValue={initialMonthSelectedValue}
              size="small"
              disabled={state.selectedValue.length > 0 ? false : true}
              renderInput={params => (
                <TextField
                  {...params}
                  placeholder={Message.filter.autocomplete.comboPlaceholderMonth}
                  variant="outlined"
                />
              )}
              onChange={(event, value) => onMonthChange(value)}
              onInputChange={(event, value) => handleSearch(value)}
            />
          </div>
        </div>
      ) : (
        <div style={{ margin: '4px' }}>
          <Autocomplete
            multiple
            filterSelectedOptions
            options={state.options}
            loading={state.loading}
            defaultValue={initialSelectedValue}
            getOptionLabel={option => option.title}
            noOptionsText={Message.filter.autocomplete.comboNoOptions}
            autoHighlight
            style={{ flex: 1 }}
            size="small"
            renderInput={params => (
              <TextField
                {...params}
                placeholder={Message.filter.autocomplete.comboPlaceholder}
                variant="outlined"
              />
            )}
            onChange={(event, value) => onSelectionChange(value)}
            onInputChange={(event, value) => handleSearch(value)}
          />
        </div>
      )}
    </div>
  );
});
AutocompleteFacet.displayName = 'AutocompleteFacet';

export default AutocompleteFacet;
