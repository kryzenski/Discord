import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import {
  getMatsterViewOptionsFromLocalStorage,
  setMatsterViewOptionsToLocalStorage,
} from '@main/security/localStore';
import { SegmentPanel } from './subComponents/SegmentPanel';
import { ProjectPanel } from './subComponents/ProjectPanel';
import { getSortedFieldsOfProject, getSortedFieldsOfSegment } from '@main/constants/fieldsInfo';
import _ from 'lodash';
import { isNotEmptyValue } from '@shared/utils/functionUtils';

const paddingHeight = '160px';
const overViewHeight = `calc(100vh - ${paddingHeight})`;

const useData = () => {
  const projectOptions = getMatsterViewOptionsFromLocalStorage('projects');
  const initExpandedProject = isNotEmptyValue(_.get(projectOptions, 'expanded'))
    ? _.get(projectOptions, 'expanded')
    : true;

  const [expandedProject, setExpandedProject] = React.useState(initExpandedProject);

  const handleProjectExpansionChange = isExpanded => {
    setExpandedProject(isExpanded);
    setMatsterViewOptionsToLocalStorage({ expanded: isExpanded }, 'projects');
  };

  const segmentOptions = getMatsterViewOptionsFromLocalStorage('segments');
  const initExpandedSegment = _.get(segmentOptions, 'expanded') || false;
  const [expandedSegment, setExpandedSegment] = React.useState(initExpandedSegment);
  const handleSegmentExpansionChange = isExpanded => {
    setExpandedSegment(isExpanded);
    setMatsterViewOptionsToLocalStorage({ expanded: isExpanded }, 'segments');
  };

  const dispatch = useDispatch<typeDispatch>();
  useEffect(() => {
    dispatch.MasterList.initColumns({
      projectSelectedColumns: getSortedFieldsOfProject(true),
      projectUnselectedColumns: getSortedFieldsOfProject(false),
      segmentSelectedColumns: getSortedFieldsOfSegment(true),
      segmentUnSelectedColumns: getSortedFieldsOfSegment(false),
    });
  }, []);

  let projectHeight = overViewHeight;
  let segmentHeight = overViewHeight;

  if (expandedSegment && expandedProject) {
    projectHeight = `calc((${projectHeight})*0.6)`;
    segmentHeight = `calc((${segmentHeight})*0.45)`;
  }
  if (!expandedProject) {
    projectHeight = '48px';
  }

  if (!expandedSegment) {
    segmentHeight = '48px';
  }
  const projectMaxBodyHeight = `calc(${projectHeight} - 190px)`;
  const segmentMaxBodyHeight = `calc(${segmentHeight} - 170px)`;
  return {
    projectMaxBodyHeight,
    projectHeight,
    handleProjectExpansionChange,
    expandedProject,
    expandedSegment,
    segmentHeight,
    handleSegmentExpansionChange,
    segmentMaxBodyHeight,
  };
};

const MasterListView = React.memo(() => {
  const {
    projectMaxBodyHeight,
    projectHeight,
    handleProjectExpansionChange,
    expandedProject,
    expandedSegment,
    segmentHeight,
    handleSegmentExpansionChange,
    segmentMaxBodyHeight,
  } = useData();
  return (
    <div>
      <div style={{ height: projectHeight, overflow: 'hidden' }}>
        <ProjectPanel
          handleChange={handleProjectExpansionChange}
          maxBodyHeight={projectMaxBodyHeight}
          expanded={expandedProject}
        />
      </div>
      <div style={{ height: segmentHeight, overflow: 'hidden' }}>
        <SegmentPanel
          handleChange={handleSegmentExpansionChange}
          maxBodyHeight={segmentMaxBodyHeight}
          expanded={expandedSegment}
        />
      </div>
    </div>
  );
});
MasterListView.displayName = 'MasterListView';

export default MasterListView;
