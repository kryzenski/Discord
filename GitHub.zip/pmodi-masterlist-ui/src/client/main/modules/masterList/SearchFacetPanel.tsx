import React, { Fragment, useState, useEffect, ReactElement } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import { Message } from '@shared/utils/message';
import { BasicButton } from '@shared/components/Buttons/BasicButton';
import CircularProgress from '@material-ui/core/CircularProgress';
import _ from 'lodash';
import { getFacetConfigurations } from '@main/serviceData/ui/filter';
import DecimalFacet from './DecimalFacet';
import SearchIcon from '@material-ui/icons/Search';
import DoneAllIcon from '@material-ui/icons/DoneAll';
import CompareArrowsIcon from '@material-ui/icons/CompareArrows';
import { sortByKey } from '@shared/utils/functionUtils';
import {
  MinMaxCriterion,
  IsSetCriterion,
  Facet,
  FilterInfo,
  getDecimalFacetCriterionFromFilter,
  isDecimalFacetPercent,
  createFilter,
  isDecimalRange,
  isAutocomplete,
  isCheckbox,
  AutocompleteCriterion,
  ValuesCriterion,
  getAutocompleteFacetCriterionFromFilter,
  getYearAndMonthForSegmentCreation,
  getCheckboxFacetCriterionFromFilter,
} from './FacetUtil';
import AutocompleteFacet from './AutocompleteFacet';
import CheckboxFacet from './CheckboxFacet';
import InputAdornment from '@material-ui/core/InputAdornment';
import {
  getSearchFiltersFromLocalStorage,
  setSearchFiltersFromLocalStorage,
} from '@main/security/localStore';
import { isNotEmptyValue } from '@shared/utils/functionUtils';

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      flex: 1,
      overflowY: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      margin: '4px',
    },
    header: {
      marginBottom: '4px',
      marginTop: '6px',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
    },
    headerLabel: {
      alignSelf: 'center',
      marginRight: '4px',
    },
    contentContainer: {
      flex: 1,
      minHeight: 0, // fix for several other browsers
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#EFEFEF',
    },
    contentWarningContainer: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    },
    contentWarning: {
      fontSize: '1.3rem',
      color: '#807C7C',
    },
    facetList: {
      flex: 1,
      overflow: 'auto',
      padding: '4px 4px 0px 4px',
    },
    footer: {
      flexShrink: 0,
      marginTop: '4px',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    filterTypeIcon: { marginRight: '4px' },
    inputFilterTypeIcon: { marginLeft: '10px', marginRight: '0px' },
  }),
);

interface ControlState {
  controls: Array<ReactElement>;
}

const initialControlState = { controls: [] };
const initialFilterState = { filterInfos: [] };

interface ClearAction {
  type: 'clear';
}

interface AddAction {
  type: 'add';
  control: ReactElement;
}

interface ResetAction {
  type: 'reset';
  control: ReactElement;
}

interface DeleteAction {
  type: 'delete';
  facetName: string;
}

interface FilterInfoAddAction {
  type: 'add';
  filterInfo: FilterInfo;
}

interface FilterInfoResetAction {
  type: 'reset';
  filterInfo: FilterInfo;
}

interface FilterInfoUpdateAction {
  type: 'update';
  criterion: IsSetCriterion | MinMaxCriterion | AutocompleteCriterion | ValuesCriterion | null;
  facet: Facet;
}

function filterInfoReducer(
  state,
  action:
    | FilterInfoAddAction
    | FilterInfoResetAction
    | FilterInfoUpdateAction
    | ClearAction
    | DeleteAction,
) {
  if (action.type === 'delete') {
    const identifyingKey = action.facetName;
    const adaptedFilterInfos = [...state.filterInfos];
    if (adaptedFilterInfos && adaptedFilterInfos.length > 0) {
      const filtered = adaptedFilterInfos.filter(item => {
        return String(item.facet.facetName) !== identifyingKey;
      });
      return { ...state, filterInfos: filtered };
    }
  } else if (action.type === 'add' || action.type === 'reset') {
    const updatedFilterInfos = action.type === 'reset' ? [] : [...state.filterInfos];
    const isExist = _.find(updatedFilterInfos, filter =>
      _.isEqual(filter.facet, action.filterInfo.facet),
    );
    !isExist && updatedFilterInfos.push(action.filterInfo);
    return { ...state, filterInfos: updatedFilterInfos };
  } else if (action.type === 'update') {
    const updatedFilterInfos = [];
    _.forEach(state.filterInfos, fi => {
      if (fi.facet.facetName === action.facet.facetName) {
        const filter = createFilter(action.criterion, action.facet);
        fi.filter = filter;
      }
      updatedFilterInfos.push(fi);
    });
    return { ...state, filterInfos: updatedFilterInfos };
  } else if (action.type === 'clear') {
    return { filterInfos: [] };
  }
  return state;
}

function controlStateReducer(state, action: AddAction | ResetAction | DeleteAction | ClearAction) {
  if (action.type === 'delete') {
    const identifyingKey = action.facetName;
    const adaptedControls = [...state.controls];
    if (adaptedControls && adaptedControls.length > 0) {
      const adaptedControlsFiltered = adaptedControls.filter(item => {
        return item.key !== identifyingKey;
      });
      return { ...state, controls: adaptedControlsFiltered };
    }
  } else if (action.type === 'add' || action.type === 'reset') {
    const adaptedControls = action.type === 'reset' ? [] : [...state.controls];
    const isExist = _.find(adaptedControls, item => item.key === action.control.key);
    !isExist && adaptedControls.push(action.control);
    return { ...state, controls: adaptedControls };
  } else if (action.type === 'clear') {
    return { controls: [] };
  }
  return state;
}

function isSelectedFacetAdded(
  controlState: ControlState,
  state: { facets: any[]; selectedFacet: any },
) {
  if (controlState.controls && state.selectedFacet) {
    const selectedFacetName = String(state.selectedFacet.value);
    const existing = _.find(controlState.controls, e => e.key === selectedFacetName);
    return !_.isNil(existing);
  }
  return false;
}

const getUnsupportedFacetErrorMessage = (facet: Facet) => {
  // eslint-disable-next-line prettier/prettier
  return (
    'Unsupported facet with data type ' +
    facet.dataType +
    ' and facet type ' +
    facet.facetType +
    '!'
  );
};

interface DropdownItem {
  value: string;
  title: string;
  facetName: string;
  entityType: 'PROJECT' | 'SEGMENT';
  fieldName: string;
  dataType: 'decimal' | 'string';
  facetType: 'range' | 'autocomplete' | 'checkbox';
}

interface FacetState {
  facets: Array<Facet>;
  selectedFacet: DropdownItem;
}

const SearchFacetPanel = () => {
  const dispatch = useDispatch<typeDispatch>();
  const classes = useStyles();
  const localFilters = getSearchFiltersFromLocalStorage();
  const reducerFilter = useSelector((state: typeState) => state.MasterList.filters);
  const reduxFilters = localFilters !== null ? localFilters : reducerFilter;

  const isClearPossibe = isNotEmptyValue(reduxFilters);

  const [state, setState] = useState<FacetState>({
    facets: [],
    selectedFacet: null,
  });
  const [controlState, dispatchControlStateChange] = React.useReducer(
    controlStateReducer,
    initialControlState,
  );
  const [filterState, dispatchFilterStateChange] = React.useReducer(
    filterInfoReducer,
    initialFilterState,
  );

  const criterionChange = (
    criterion: MinMaxCriterion | IsSetCriterion | AutocompleteCriterion | ValuesCriterion | null,
    facet: Facet,
  ) => {
    dispatchFilterStateChange({ type: 'update', criterion, facet });
  };

  const createDecimalFacetControl = (
    facet: Facet,
    initialCriterion: MinMaxCriterion | IsSetCriterion,
  ) => {
    const key = String(facet.facetName);
    const isPercent = isDecimalFacetPercent(facet);
    const control = (
      <DecimalFacet
        key={key}
        facet={facet}
        isPercent={isPercent}
        initialCriterion={initialCriterion}
        delete={() => {
          dispatchControlStateChange({ type: 'delete', facetName: key });
          dispatchFilterStateChange({ type: 'delete', facetName: key });
        }}
        criteriaChange={c => criterionChange(c, facet)}
      />
    );
    return control;
  };
  const createAutocompleteFacetControl = (facet: Facet, initialCriterion: any) => {
    const key = String(facet.facetName);
    const control = (
      <AutocompleteFacet
        key={key}
        facet={facet}
        initialCriterion={initialCriterion}
        criteriaChange={c => criterionChange(c, facet)}
        delete={() => {
          dispatchControlStateChange({ type: 'delete', facetName: key });
          dispatchFilterStateChange({ type: 'delete', facetName: key });
        }}
      />
    );
    return control;
  };
  const createCheckboxFacetControl = (facet: Facet, initialCriterion: ValuesCriterion) => {
    const key = String(facet.facetName);
    const control = (
      <CheckboxFacet
        key={key}
        facet={facet}
        initialCriterion={initialCriterion}
        criteriaChange={c => criterionChange(c, facet)}
        delete={() => {
          dispatchControlStateChange({ type: 'delete', facetName: key });
          dispatchFilterStateChange({ type: 'delete', facetName: key });
        }}
      />
    );
    return control;
  };
  useEffect(() => {
    const fetchData = async () => {
      const results = await getFacetConfigurations({});
      setState({ ...state, facets: results });
    };
    fetchData();

    const initControls = () => {
      if (reduxFilters.length > 0) {
        for (const rf of reduxFilters) {
          let control = null;
          if (isDecimalRange(rf.facet)) {
            const initialCriterion = getDecimalFacetCriterionFromFilter(rf.filter);
            control = createDecimalFacetControl(rf.facet, initialCriterion);
          } else if (isAutocomplete(rf.facet)) {
            if (
              rf.filter.fieldName !== 'creationYear' &&
              rf.filter.fieldName !== 'approvalYear' &&
              rf.filter.fieldName !== 'draftYear'
            ) {
              const initialCriterion = getAutocompleteFacetCriterionFromFilter(rf.filter);
              control = createAutocompleteFacetControl(rf.facet, initialCriterion);
            }
            //Year and month filter
            else {
              const initialCriterion = getYearAndMonthForSegmentCreation(rf.filter);
              control = createAutocompleteFacetControl(rf.facet, initialCriterion);
            }
          } else if (isCheckbox(rf.facet)) {
            const initialCriterion = getCheckboxFacetCriterionFromFilter(rf.filter);
            control = createCheckboxFacetControl(rf.facet, initialCriterion);
          }
          if (control === null) {
            throw new Error(getUnsupportedFacetErrorMessage(rf.facet));
          }
          dispatchControlStateChange({ type: 'add', control });
          const filterInfo: FilterInfo = { facet: rf.facet, filter: rf.filter };
          dispatchFilterStateChange({ type: 'add', filterInfo });
        }
      }
    };
    initControls();
  }, [reducerFilter]);

  const addFilter = () => {
    if (_.isNil(state.selectedFacet)) {
      //console.log('Add facet aborted because no facet was selected');
      return;
    }
    // Check if control is already present if the available facets are not restricted to unused facets
    const isSelectedFacetAlreadyAdded = isSelectedFacetAdded(controlState, state);
    if (isSelectedFacetAlreadyAdded) {
      //console.log('Add facet aborted because facet is already present');
      return;
    }
    const matchingFacet = _.find(state.facets, { facetName: state.selectedFacet.value });
    if (_.isNil(matchingFacet)) {
      throw new Error('No facet found for value ' + state.selectedFacet.value + '!');
    }
    let control = null;
    if (isDecimalRange(matchingFacet)) {
      const initialCriterion = getDecimalFacetCriterionFromFilter(null);
      const filter = createFilter(initialCriterion, matchingFacet);
      const filterInfo: FilterInfo = { facet: matchingFacet, filter };
      dispatchFilterStateChange({ type: 'add', filterInfo });
      control = createDecimalFacetControl(matchingFacet, initialCriterion);
    } else if (isAutocomplete(matchingFacet)) {
      const initialCriterion = getAutocompleteFacetCriterionFromFilter(null);
      const filter = createFilter(initialCriterion, matchingFacet);
      const filterInfo: FilterInfo = { facet: matchingFacet, filter };
      if (
        matchingFacet.fieldName === 'creationYear' ||
        matchingFacet.fieldName === 'draftYear' ||
        matchingFacet.fieldName === 'approvalYear'
      ) {
        dispatchFilterStateChange({ type: 'add', filterInfo });
        const initialYearAndMonthCriterion = getYearAndMonthForSegmentCreation(null);
        control = createAutocompleteFacetControl(matchingFacet, initialYearAndMonthCriterion);
      } else {
        dispatchFilterStateChange({ type: 'add', filterInfo });
        control = createAutocompleteFacetControl(matchingFacet, initialCriterion);
      }
    } else if (isCheckbox(matchingFacet)) {
      const initialCriterion = getCheckboxFacetCriterionFromFilter(null);
      const filter = createFilter(initialCriterion, matchingFacet);
      const filterInfo: FilterInfo = { facet: matchingFacet, filter };
      dispatchFilterStateChange({ type: 'add', filterInfo });
      control = createCheckboxFacetControl(matchingFacet, initialCriterion);
    } else {
      throw new Error(getUnsupportedFacetErrorMessage(matchingFacet));
    }
    if (control !== null) {
      dispatchControlStateChange({ type: 'add', control });
    }
  };

  const applyNewFilters = () => {
    // Prevent parameter from containing references
    const clonedFilters = _.cloneDeep(filterState.filterInfos);
    setSearchFiltersFromLocalStorage(clonedFilters);
    dispatch.MasterList.setFilterConfigrationDatas(clonedFilters);
  };
  const clearFilters = () => {
    dispatchControlStateChange({ type: 'clear' });
    dispatchFilterStateChange({ type: 'clear' });
    dispatch.MasterList.setFilterConfigrationDatas([]);
    setSearchFiltersFromLocalStorage([]);
  };
  const resetFilters = () => {
    // TODO: when later facet configurations may be defined by users this local state has to be completely moved to redux state
    // and therefore this reset would then be done there (as it is in parts already).
    const defaultFacet = _.find(state.facets, {
      entityType: 'PROJECT',
      fieldName: 'newportStatus',
    });
    if (defaultFacet) {
      const defaultCriterion: ValuesCriterion = {
        values: ['Draft', 'Proposal', 'Freeze', 'In Progress', 'Under Assessment', 'On Hold'],
      };
      const filter = createFilter(defaultCriterion, defaultFacet);
      const filterInfo: FilterInfo = { facet: defaultFacet, filter };
      dispatchFilterStateChange({ type: 'reset', filterInfo });
      const control = createCheckboxFacetControl(defaultFacet, defaultCriterion);
      dispatchControlStateChange({ type: 'reset', control });
      const defaultFilters = [];
      defaultFilters.push(filterInfo);
      dispatch.MasterList.setFilterConfigrationDatas(defaultFilters);
      setSearchFiltersFromLocalStorage(defaultFilters);
    }
  };
  const onChange = item => {
    setState({ ...state, selectedFacet: item });
  };

  const availableFilters: Array<DropdownItem> = state.facets.map(item => ({
    value: item.facetName,
    title: item.facetName,
    ...item,
  }));

  const sortedAvailableFilters = sortByKey(availableFilters, 'facetName');
  const currentValue = state.selectedFacet || null;
  const isLoadingFacets = state.facets.length === 0;
  const hasSelectedFacets = controlState.controls.length > 0;
  let content = null;
  if (hasSelectedFacets) {
    content = <div className={classes.facetList}>{controlState.controls}</div>;
  } else {
    content = (
      <div className={classes.contentWarningContainer}>
        <div className={classes.contentWarning}>{Message.filter.noContent}</div>
      </div>
    );
  }
  const isSelectedFacetAlreadyAdded = isSelectedFacetAdded(controlState, state);
  const hasInvalidFilter = _.some(filterState.filterInfos, f => f.filter === null);
  const isApplyPossible = filterState.filterInfos.length > 0 && !hasInvalidFilter;

  const getFilterTypeIcon = option => {
    if (isDecimalRange(option)) {
      return CompareArrowsIcon;
    } else if (isAutocomplete(option)) {
      return SearchIcon;
    } else if (isCheckbox(option)) {
      return DoneAllIcon;
    }
    return Fragment;
  };

  const renderOptionLabel = option => {
    const FilterTypeIcon = getFilterTypeIcon(option);

    return (
      <React.Fragment>
        <FilterTypeIcon className={classes.filterTypeIcon} />
        {option.title}
      </React.Fragment>
    );
  };
  const FilterTypeIcon = getFilterTypeIcon(state.selectedFacet);
  return (
    <div className={classes.root}>
      <div className={classes.header}>
        {isLoadingFacets && (
          <div style={{ flex: 1 }}>
            <CircularProgress />
          </div>
        )}
        {!isLoadingFacets && (
          <Autocomplete
            id="criterion-selection"
            options={sortedAvailableFilters}
            value={currentValue}
            getOptionLabel={option => option.title}
            getOptionSelected={option =>
              currentValue !== null && option.value === currentValue.value
            }
            autoHighlight
            style={{ flex: 1 }}
            size="small"
            renderOption={renderOptionLabel}
            renderInput={params => {
              return (
                <TextField
                  {...params}
                  label={Message.filter.autoCompleteLabel}
                  placeholder={Message.filter.autoCompletePlaceholder}
                  variant="outlined"
                  InputProps={{
                    ...params.InputProps,
                    startAdornment: (
                      <InputAdornment position="start" className={classes.inputFilterTypeIcon}>
                        <FilterTypeIcon />
                      </InputAdornment>
                    ),
                  }}
                />
              );
            }}
            onChange={(event, value) => onChange(value)}
          />
        )}
        <BasicButton
          isDisabled={isSelectedFacetAlreadyAdded || _.isNil(state.selectedFacet)}
          text={Message.filter.add}
          handleClick={addFilter}
        ></BasicButton>
      </div>
      <div className={classes.contentContainer}>{content}</div>
      <div className={classes.footer}>
        <BasicButton
          isDisabled={!isClearPossibe}
          text={Message.filter.clear}
          handleClick={clearFilters}
        ></BasicButton>
        <BasicButton
          isDisabled={false}
          text={Message.filter.reset}
          handleClick={resetFilters}
        ></BasicButton>
        <BasicButton
          isDisabled={!isApplyPossible}
          text={Message.filter.apply}
          handleClick={applyNewFilters}
        ></BasicButton>
      </div>
    </div>
  );
};
SearchFacetPanel.displayName = 'SearchFacetPanel';

export default SearchFacetPanel;
