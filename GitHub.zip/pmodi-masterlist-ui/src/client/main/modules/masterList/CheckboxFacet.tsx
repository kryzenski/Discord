import React, { useState } from 'react';
import clsx from 'clsx';
import _ from 'lodash';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { Icon, Tooltip, Checkbox, FormGroup, FormControlLabel } from '@material-ui/core';
import CloseSharpIcon from '@material-ui/icons/CloseSharp';
import { Message } from '@shared/utils/message';
import { Facet, ValuesCriterion } from './FacetUtil';
import DoneAllIcon from '@material-ui/icons/DoneAll';

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      display: 'flex',
      flexDirection: 'column',
      marginBottom: '4px',
      backgroundColor: 'white',
    },
    header: {
      backgroundColor: '#6495ED',
      justifyContent: 'space-between',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
    },
    headerLeft: {
      alignSelf: 'center',
      display: 'flex',
      flexDirection: 'row',
    },
    title: {
      fontWeight: 'bold',
      alignSelf: 'center',
      color: '#FFFFFF',
    },
    filterTypeIcon: {
      marginLeft: '5px',
      marginRight: '5px',
      color: '#FFFFFF',
    },
    closeIcon: {
      marginRight: '3px',
      color: '#FFFFFF',
    },
    errorColor: {
      color: 'red',
    },
    errorBorder: {
      border: '1px solid red',
    },
    checkboxContainer: {
      backgroundColor: 'white',
      margin: '4px',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
    },
  }),
);

export interface CheckboxFacetProps {
  facet: Facet;
  initialCriterion: ValuesCriterion;
  delete(facet: Facet): any;
  criteriaChange(criterion: ValuesCriterion | null);
}

const CheckboxFacet = React.memo((props: CheckboxFacetProps) => {
  const classes = useStyles();
  const [selectedValues, setSelectedValues] = useState(props.initialCriterion.values);

  let errorControl = null;
  const errorInfo = _.isEmpty(selectedValues) ? Message.filter.checkbox.errorMessageNoValue : null;
  const hasError = errorInfo !== null;
  if (hasError) {
    errorControl = (
      <Tooltip title={errorInfo}>
        <Icon className={classes.errorColor}>error</Icon>
      </Tooltip>
    );
  }

  const handleCheckChange = (event, key) => {
    const { checked } = event.target;
    const newSelectedValues = [...selectedValues];
    if (checked) {
      newSelectedValues.push(key);
    } else {
      _.remove(newSelectedValues, value => value === key);
    }
    setSelectedValues(newSelectedValues);
    if (newSelectedValues.length > 0) {
      const crit: ValuesCriterion = { values: newSelectedValues };
      props.criteriaChange(crit);
    } else {
      props.criteriaChange(null);
    }
  };

  const checkboxes = _.map(props.facet.values, val => {
    return (
      <FormGroup row key={'FormGroup_' + val}>
        <FormControlLabel
          control={
            <Checkbox
              name={val}
              checked={_.includes(selectedValues, val)}
              key={val}
              onChange={event => handleCheckChange(event, val)}
              color="primary"
            />
          }
          label={val}
        />
      </FormGroup>
    );
  });

  return (
    <div
      key={'chk_' + props.facet.facetName}
      className={hasError ? clsx(classes.root, classes.errorBorder) : classes.root}
    >
      <div className={classes.header}>
        <div className={classes.headerLeft}>
          <DoneAllIcon className={classes.filterTypeIcon} />
          <div className={classes.title}>{props.facet.facetName}</div>
          {errorControl}
        </div>
        <CloseSharpIcon className={classes.closeIcon} onClick={() => props.delete(props.facet)} />
      </div>
      <div className={classes.checkboxContainer}>{checkboxes}</div>
    </div>
  );
});
CheckboxFacet.displayName = 'CheckboxFacet';

export default CheckboxFacet;
