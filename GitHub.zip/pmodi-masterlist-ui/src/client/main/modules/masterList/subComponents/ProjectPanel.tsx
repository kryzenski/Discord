import React, { Fragment } from 'react';
import { Message } from '@shared/utils/message';
import { SimpleDialog } from '@shared/components/Dialog/SimpleDialog';
import { TransferList } from '@shared/components/TransferList/TransferList';
import { RemoteDataTable } from '@shared/components/TableComponent/RemoteDataTable';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import { useData } from './componentUtils';

const EXPANSION_PANEL_TITLE = 'Projects';

type projectPanelProps = {
  expanded: boolean;
  maxBodyHeight: string;
  handleChange: (expanded: boolean) => void;
};

export const ProjectPanel = (props: projectPanelProps): JSX.Element => {
  const { maxBodyHeight, handleChange, expanded } = props;
  const { isOpen, handleCloseColumnSelection, columnSelectionoptions, itemRenderOptions } = useData(
    maxBodyHeight,
    'projects',
  );
  const columnSelectionDialog = (
    <SimpleDialog
      open={isOpen}
      title={Message.masterList.selectColumn}
      ItemRender={TransferList}
      itemRenderOptions={columnSelectionoptions}
      onClose={handleCloseColumnSelection}
    />
  );

  return (
    <Fragment>
      <ExpansionPanelView
        text={EXPANSION_PANEL_TITLE}
        defaultExpanded={expanded}
        ItemRender={RemoteDataTable}
        itemRenderOptions={itemRenderOptions}
        onChange={handleChange}
        viewType={'masterList'}
      />
      {columnSelectionDialog}
    </Fragment>
  );
};
