import _ from 'lodash';
import moment from 'moment';
import React, { useRef, useEffect, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import GetAppIcon from '@material-ui/icons/GetApp';
import CircularProgress from '@material-ui/core/CircularProgress';
import PlaylistAddCheckIcon from '@material-ui/icons/PlaylistAddCheck';
import DateUtils from '@shared/utils/dateUtils';
import {
  FIELD_ORDER,
  // FIELD_TITLE,
  renderFunc,
  FORMATTER_TO_PERCENT,
  getFieldInfo,
  getAllFieldsInfo,
  FIELD_HIDDEN_COLUMN,
  getPageSize,
  FORMATTER_TO_NUMBER,
} from '@main/constants/fieldsInfo';
import { Message } from '@shared/utils/message';
import { buildFilter } from '@main/models/MasterList';
import { checkFilterActive } from '@main/models/MasterList';
import { typeDispatch, typeState } from '@main/stateManagement/store';
import { sortByKey, SortArray, isNotEmptyValue, DIGIT_PATTERN } from '@shared/utils/functionUtils';
import { defaultOptions } from '@main/constants/constants';
import { isLink, addLink } from '@main/modules/matserListUtil';
import {
  setMatsterViewOptionsToLocalStorage,
  getMatsterViewOptionsFromLocalStorage,
  getSearchFiltersFromLocalStorage,
  setSearchFiltersFromLocalStorage,
} from '@main/security/localStore';
import {
  searchProjects,
  searchSegments,
  searchAllSegments,
} from '@main/serviceData/project/projects';
import { PRECISE_NEW_PORT_ID_FIELD, projectUpdateOptions } from '@main/constants/projectOptions';
import { isValidateNumberValue, toInteger, toDecimal } from '@shared/utils/numberUtils';
import TextField from '@material-ui/core/TextField';
import { newPortNumberDefaultFilter } from '@main/constants/constants';
import { segmentUpdateOptions } from '~/client/main/constants/segmentOptions';
import { makeStyles } from '@material-ui/core/styles';
import { LoadingContext } from '../../Routers';

type editComponentProps = {
  value: number;
  onChange: any;
};

const useStyles = makeStyles(() => ({
  quickStyle: {
    width: 260,
    height: 80,
    marginTop: '25px',
    border: '0px',
    outline: '0px',
    textAlign: 'left',
    overflowY: 'auto',
    overflowX: 'hidden',
    paddingBottom: '10px',
    paddingTop: '15px',
  },
}));

const withEditComponent = fieldInfo => {
  const { formatter } = fieldInfo;
  const isNeedEditComponentForNumber = formatter === FORMATTER_TO_PERCENT;
  const isNeedEditComponentForId = formatter === FORMATTER_TO_NUMBER;
  if (isNeedEditComponentForNumber) {
    return {
      ...fieldInfo,
      isNeedEditComponent: isNeedEditComponentForNumber,
      editComponent: (props: editComponentProps) => {
        const { onChange } = props;
        const value = _.toNumber(props.value);
        let showValue = value;
        if (value <= 1) {
          showValue = toInteger(value);
        }
        const isValidate = isValidateNumberValue(showValue);
        return (
          <TextField
            type="number"
            error={!isValidate}
            helperText={isValidate ? '' : Message.validation.invalidNumber}
            value={showValue || ''}
            onChange={e =>
              setTimeout(
                onChange(
                  _.toNumber(e.target.value) === 1 ? toDecimal(e.target.value) : e.target.value,
                ),
                1000,
              )
            }
          />
        );
      },
    };
  } else if (isNeedEditComponentForId) {
    return {
      ...fieldInfo,
      isNeedEditComponentFor: isNeedEditComponentForId,
      editComponent: (props: editComponentProps) => {
        const { onChange } = props;
        const quickScanId: any = React.useRef('');
        const handleChange = () => {
          const input = quickScanId.current.value;
          const isNumber = DIGIT_PATTERN.test(input);
          if (isNumber) {
            setTimeout(onChange(input?.length > 16 ? input?.substring(0, 16) : input), 1000);
          }
        };
        return (
          <TextField
            id="qid"
            helperText="Enter one ID at a time"
            inputRef={quickScanId}
            onChange={handleChange}
            type="number"
            InputLabelProps={{ shrink: true }}
          />
        );
      },
    };
  } else {
    return { ...fieldInfo };
  }
};

const getColumnsByStorage = (columnsInStorage, type) => {
  return isNotEmptyValue(columnsInStorage)
    ? _.filter(
        _.map(columnsInStorage, col => getFieldInfo(col.field, type)),
        item => item != null,
      )
    : null;
};

const useDefaultColumns = type => {
  const tableOptions = getMatsterViewOptionsFromLocalStorage(type);
  const columnsInStorage = getColumnsByStorage(_.get(tableOptions, 'selectedColumns'), type);
  const { selectedColumns } = useSelector((state: typeState) => {
    return {
      selectedColumns: columnsInStorage || state.MasterList[type].selectedColumns,
    };
  });

  return selectedColumns.map(column => {
    return {
      ...column,
      cellStyle: {
        fontSize: 12,
        paddingBottom: '10px',
        paddingTop: '10px',
        textAlign: 'left',
        flexDirection: 'unset',
      },
      headerStyle: {
        textAlign: 'left',
        flexDirection: 'unset',
      },
      ...withEditComponent(column),
      render: isLink(column.field, type) ? addLink(column, type) : renderFunc(column),
    };
  });
};

const useColumnSelectionOption = type => {
  const dispatch = useDispatch<typeDispatch>();
  const columns = useDefaultColumns(type);
  const allFieldsInfo = getAllFieldsInfo(type);
  const columnNames = _.keys(_.groupBy(columns, 'field'));
  const unSelectedColumn = _.filter(
    allFieldsInfo,
    info => !_.includes(columnNames, info['field']) && !info[FIELD_HIDDEN_COLUMN],
  );
  const sortedUnSelectedColumn = unSelectedColumn.sort(SortArray);

  return {
    selectedColumn: columns,
    unSelectedColumn: sortedUnSelectedColumn,
    leftTitle: Message.masterList.availableColumn,
    rightTitle: Message.masterList.visibleCoulmn,
    setSelectedColumns: columns => {
      dispatch.MasterList.setSelectedColumns({ columns: sortByKey(columns, FIELD_ORDER), type });
      setMatsterViewOptionsToLocalStorage(
        { selectedColumns: sortByKey(columns, FIELD_ORDER) },
        type,
      );
    },
    setUnSelectedColumns: columns => {
      dispatch.MasterList.setUnSelectedColumns({ columns: sortByKey(columns, FIELD_ORDER), type });
    },
    type,
  };
};

const applyNewFiltersByCilckButton = (filters, rowData, dispatch) => {
  const newPortNumberFilters = _.find(filters, item => {
    return item.filter.fieldName === PRECISE_NEW_PORT_ID_FIELD;
  });
  const clonedFilters = [...filters];
  if (newPortNumberFilters) {
    _.map(clonedFilters, item => {
      if (item.filter.fieldName === PRECISE_NEW_PORT_ID_FIELD) {
        !_.includes(item.filter.stringValues, rowData[PRECISE_NEW_PORT_ID_FIELD]) &&
          item.filter.stringValues.push(rowData[PRECISE_NEW_PORT_ID_FIELD]);
      }
    });
  } else {
    newPortNumberDefaultFilter.filter.stringValues = [rowData[PRECISE_NEW_PORT_ID_FIELD]];
    clonedFilters.push(newPortNumberDefaultFilter);
  }
  setSearchFiltersFromLocalStorage(clonedFilters);
  dispatch.MasterList.setFilterConfigrationDatas(clonedFilters);
  dispatch.MasterList.openSearchFilterView(true);
};

const columnEditable = type => {
  let columns = useDefaultColumns(type);
  if (type === 'segments') {
    columns = _.map(columns, col => {
      if (
        col.field === 'rsOccupationalResidentialExposurePtrsScore' ||
        col.field === 'rsOccupationalResidentialExposurePtrsScoreRmk' ||
        col.field === 'rsRegDietaryPtrsScore' ||
        col.field === 'rsRegDietaryPtrsScoreRmk' ||
        col.field === 'rsToxicologyPtrsScore' ||
        col.field === 'rsToxicologyPtrsScoreRmk' ||
        col.field === 'rsEcotoxPtrsScore' ||
        col.field === 'rsEcotoxPtrsScoreRmk' ||
        col.field === 'rsEfatePtrsScore' ||
        col.field === 'rsEfatePtrsScoreRmk' ||
        col.field === 'rsRegistrationPtrsScore' ||
        col.field === 'rsRegistrationPtrsScoreRmk' ||
        col.field === 'rsRegistrationPtrsScore' ||
        col.field === 'rsRegistrationPtrsScoreRmk'
      ) {
        //NA and APAC common scores editability
        //     rowData && (rowData.region.roleSuffix === 'NA' || rowData.region.roleSuffix === 'APAC'),
        return {
          ...col,
          editable: (_, rowData) => rowData && rowData.region.roleSuffix === 'NA',
        };
      } else if (col.field === 'rsRegPtrsScore') {
        return {
          ...col,
          editable: (_, rowData) => (rowData && rowData.region.roleSuffix === 'NA' ? false : true),
        };
      }

      /* APAC editability check
      if (
         col.field === 'rsRegProductPtrsScore' ||
         col.field === 'rsRegProductPtrsScoreRmk' ||
         col.field === 'rsForeignInfluencePtrsScore' ||
         col.field === 'rsForeignInfluencePtrsScoreRmk' ||
        col.field === 'rsLocalRestrictionPolicyPtrsScore' ||
        col.field === 'rsLocalRestrictionPolicyPtrsScoreRmk' ||
         col.field === 'rsLocalRestrictionOthersPtrsScore' ||
        col.field === 'rsLocalRestrictionOthersPtrsScoreRmk' ||
         col.field === 'rsForeignInfluencePtrsScore' ||
         col.field === 'rsForeignInfluencePtrsScoreRmk'
       ) {
         return {
         ...col,
         editable: (_, rowData) => rowData && rowData.region.roleSuffix === 'APAC',
       };
      } */
      return col;
    });
  }
  return columns;
};

const getQuickScanId = ids => {
  const content = [];
  let item1;
  let item2;
  for (let i = 0; i < ids?.length; i++) {
    item1 = ids[i];
    item2 = ids[i + 1];

    if (item1 != undefined) {
      if (item2 != undefined) {
        if (i + 1 != ids?.length - 1) {
          content.push(
            <>
              <span>
                {item1},{item2},
              </span>
              <br />
            </>,
          );
        } else {
          content.push(
            <>
              <span>
                {item1},{item2}
              </span>
              <br />
            </>,
          );
        }
      } else {
        content.push(<span>{item1}</span>);
      }
    }
    i = i + 1;
  }
  return content;
};

const useTableOptions = (maxBodyHeight, handleOpenColumnSelection, type) => {
  const dispatch = useDispatch<typeDispatch>();
  //const [isLoading, setIsLoading] = useState(false);
  const isMounted = useRef(true);
  const tableElement = useRef(null);
  const classes = useStyles();
  let columns = columnEditable(type);
  let quickScanArray = [];
  const { loading, startLoading, stopLoading } = useContext(LoadingContext);

  console.log('loading.value :' + loading);

  const handleDownloadFailure = e => {
    // TODO: error handling
    const msg = e ? e.message : 'Error downloading export';
    console.log('Error downloading export: ' + msg);
  };

  const handleDownloadExcel = () => {
    console.log('Loading.starting');
    startLoading();
    //setIsLoading(true);
    dispatch.MasterList.downloadExport({
      failureCallback: handleDownloadFailure,
      stopLoading,
      isMounted,
    });
  };
  if (type === 'segments') {
    columns = _.map(columns, col => {
      if (col.field === 'isQuickScanNotApplicable') {
        return {
          ...col,
          render: rowData => <div>{rowData.isQuickScanNotApplicable ? 'No' : 'Yes'}</div>,
        };
      }
      if (col.field === 'creationDate') {
        return {
          ...col,
          render: rowData => (
            <div>
              {DateUtils.getStringFromDatePattern(
                DateUtils.getDateFormatForMonth(),
                rowData[col.field],
                false,
              )}
            </div>
          ),
        };
      }

      if (col.field === 'quickscanAssessmentId') {
        return {
          ...col,
          render: rowData => (
            (quickScanArray = rowData.quickscanAssessmentId
              ? rowData.quickscanAssessmentId?.split(',')
              : ''),
            (<div className={classes.quickStyle}>{getQuickScanId(quickScanArray)}</div>)
          ),
        };
      }

      return col;
    });
  }

  if (type === 'projects') {
    columns = _.map(columns, col => {
      if (col.field === 'approvalDate' || col.field === 'newportProjectCreated') {
        return {
          ...col,
          render: rowData => (
            <div>
              {rowData[col.field] === '00000000' || rowData[col.field] === null
                ? ''
                : DateUtils.getStringFromDatePattern(
                    DateUtils.getDateFormatForMonth(),
                    rowData[col.field],
                    false,
                  )}
            </div>
          ),
        };
      }
      return col;
    });
  }
  const { reducerFilter, projectId } = useSelector((state: typeState) => {
    return {
      reducerFilter: state.MasterList.filters,
      projectId: state.MasterList.projectId,
    };
  });
  const initialPageSize =
    type === 'projects' ? getPageSize().projectSize : getPageSize().segmentSize;
  const pageSizeFromLocalStorageProjects = type => {
    const tableOptions = getMatsterViewOptionsFromLocalStorage(type);
    const pageSizeInStorage = _.get(tableOptions, 'pageSize');
    return pageSizeInStorage;
  };
  const pageSizeLocalStorage =
    type === 'projects'
      ? pageSizeFromLocalStorageProjects('projects')
      : pageSizeFromLocalStorageProjects('segments');
  const pageSize = pageSizeLocalStorage || initialPageSize;
  const localFilters = getSearchFiltersFromLocalStorage();
  const filters = localFilters !== null ? localFilters : reducerFilter;
  const filterConditions = buildFilter(filters, type);
  const [firstLoad, setFirstLoad] = React.useState(true);

  useEffect(() => {
    if (type === 'segments' && tableElement.current && !firstLoad) {
      tableElement.current.onQueryChange({ page: 0 });
    }
  }, [projectId, reducerFilter]);

  useEffect(() => {
    if (type === 'projects' && tableElement.current && !firstLoad) {
      tableElement.current.onQueryChange({ page: 0 });
    }
  }, [reducerFilter]);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);
  console.log('isMounted.current in comp', isMounted.current);

  const clickFunc = rowData => {
    dispatch.MasterList.setCurrentItem({ item: rowData, type });
    dispatch.MasterList.setProjectID(rowData.id);
  };

  const handleColumnDrag = (sourceIndex, destinationIndex) => {
    const sortedOrder = columns.map(column => column.order).sort((a, b) => a - b);
    const sourceColumns = columns.splice(sourceIndex, 1);
    columns.splice(destinationIndex, 0, sourceColumns[0]);
    const newColumnsWithUpdatedOrder = columns.map((column, index) => {
      return {
        ...column,
        order: sortedOrder[index],
      };
    });
    setMatsterViewOptionsToLocalStorage({ selectedColumns: newColumnsWithUpdatedOrder }, type);
    dispatch.MasterList.setSelectedColumns({ columns: newColumnsWithUpdatedOrder, type });
  };

  const setLocalStorage = query => {
    const localData = getMatsterViewOptionsFromLocalStorage(type);
    const sortBy = _.get(query, 'orderBy.field') || localData?.sortBy;
    const sortDir = query.orderDirection || localData?.sortDir;
    !firstLoad &&
      setMatsterViewOptionsToLocalStorage(
        {
          page: query.page,
          pageSize: query.pageSize,
          sortBy,
          sortDir,
        },
        type,
      );
    setFirstLoad(false);
  };

  const loadProject = pageable => searchProjects({ filterConditions, pageable });
  let loadSegment = null;
  if (isNotEmptyValue(filterConditions)) {
    loadSegment = pageable =>
      searchAllSegments({
        filterConditions,
        pageable,
      });
  } else if (isNotEmptyValue(projectId)) {
    loadSegment = pageable => searchSegments(pageable, projectId);
  }

  return {
    tableElement,
    columns,
    toIntegerFields: _.filter(columns, col => col.formatter === FORMATTER_TO_PERCENT),
    ...defaultOptions,
    isFilterActive: checkFilterActive(filters),
    setLocalStorage,
    handleColumnDrag,
    pageSize,
    pageSizeOptions: [initialPageSize, initialPageSize * 2, initialPageSize * 4],
    maxBodyHeight,
    loadData: type === 'segments' ? loadSegment : loadProject,
    onTableRowClick: type === 'projects' ? clickFunc : null,
    updateData:
      type === 'projects' ? dispatch.MasterList.updateProject : dispatch.MasterList.updateSegment,
    customActions: [
      {
        icon: 'menuBook',
        tooltip: Message.masterList.selectColumn,
        isFreeAction: true,
        onClick: () => handleOpenColumnSelection(),
      },
      {
        icon: () => (loading ? <CircularProgress /> : <GetAppIcon />),
        tooltip: Message.masterList.download,
        isFreeAction: true,
        onClick: () => handleDownloadExcel(),
      },
      type === 'projects' && {
        icon: () => <PlaylistAddCheckIcon />,
        isFreeAction: false,
        onClick: (event, rowData) => {
          applyNewFiltersByCilckButton(filters, rowData, dispatch);
        },
      },
    ],
  };
};

export const useData = (maxBodyHeight, type) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const userNameStr = useSelector((state: typeState) => state.User.userName);
  const date = new Date();
  const lastDateModified = moment(date).format('YYYY-MM-DD');

  const handleCloseColumnSelection = () => {
    setIsOpen(false);
  };
  const handleOpenColumnSelection = () => {
    setIsOpen(true);
  };

  const toAppendQuickscanID = (newData, oldData) => {
    const id = _.toString(newData?.quickscanAssessmentId);
    const arr = _.split(oldData?.quickscanAssessmentId, ',');
    let flag = 0;
    _.forEach(arr, item => {
      if (id === item) flag = 1;
    });
    if (flag === 0) {
      const quickScanIds = oldData?.quickscanAssessmentId
        ? `${oldData?.quickscanAssessmentId},${id}`
        : id;
      newData.quickscanAssessmentId = quickScanIds;
      newData.isQuickScanNotApplicable = false;
      newData.quickScanNotApplicableReason = '';
    }
    if (flag === 1) {
      newData.quickscanAssessmentId = oldData?.quickscanAssessmentId;
    }
  };
  const toFetchUpdatedByAndDate = (newData, oldData, type) => {
    const difference = Object.keys(newData)?.filter(k => newData[k] !== oldData[k]);
    if (difference?.includes('quickscanAssessmentId')) {
      toAppendQuickscanID(newData, oldData);
    }
    const values = [];
    const updateOptions = type === 'projects' ? projectUpdateOptions : segmentUpdateOptions;
    difference?.forEach(field => {
      values.push(
        ..._.filter(
          updateOptions,
          option => option.ptrsField === field || option.rationaleField === field,
        ),
      );
    });
    _.uniqBy(values, 'ptrsField')?.forEach(val => {
      newData[val.updatedBy] = userNameStr;
      newData[val.updatedDate] = lastDateModified;
    });
  };

  const itemRenderOptions = useTableOptions(maxBodyHeight, handleOpenColumnSelection, type);

  const columnSelectionoptions = useColumnSelectionOption(type);
  return {
    isOpen,
    handleCloseColumnSelection,
    handleOpenColumnSelection,
    columnSelectionoptions,
    itemRenderOptions: { ...itemRenderOptions, toFetchUpdatedByAndDate, type },
  };
};
