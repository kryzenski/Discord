import React, { Fragment } from 'react';
import { Message } from '@shared/utils/message';
import { SimpleDialog } from '@shared/components/Dialog/SimpleDialog';
import { TransferList } from '@shared/components/TransferList/TransferList';
import { RemoteDataTable } from '@shared/components/TableComponent/RemoteDataTable';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import { useData } from './componentUtils';

const EXPANSION_PANEL_TITLE = 'Segments';

type projectPanelProps = {
  expanded: boolean;
  handleChange?: (expanded: boolean) => void;
  maxBodyHeight: string;
};

export const SegmentPanel = (props: projectPanelProps): JSX.Element => {
  const { maxBodyHeight, handleChange, expanded } = props;
  const { isOpen, handleCloseColumnSelection, columnSelectionoptions, itemRenderOptions } = useData(
    maxBodyHeight,
    'segments',
  );

  const columnSelectionDialog = (
    <SimpleDialog
      open={isOpen}
      title={Message.masterList.selectColumn}
      ItemRender={TransferList}
      itemRenderOptions={columnSelectionoptions}
      onClose={handleCloseColumnSelection}
    />
  );
  return (
    <Fragment>
      <ExpansionPanelView
        defaultExpanded={expanded}
        text={EXPANSION_PANEL_TITLE}
        ItemRender={RemoteDataTable}
        itemRenderOptions={itemRenderOptions}
        onChange={handleChange}
        viewType={'masterList'}
      />
      {columnSelectionDialog}
    </Fragment>
  );
};
