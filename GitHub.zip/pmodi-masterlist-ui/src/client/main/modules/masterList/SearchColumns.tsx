import React from 'react';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
    alignItems: 'center',
    boxShadow: '0px 0px 3px 1px #c1c7d0',
  },
  input: {
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  iconButton: {
    padding: 10,
  },
  divider: {
    height: 28,
    margin: 4,
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  container: {
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    padding: '0 2px 10px 2px',
  },
  progresContainer: {
    width: '30px',
    display: 'flex',
    alignItems: 'center',
  },
}));

type SearchColumnsProps = {
  handleSearch: Function;
  searchText: string;
};

const SearchColumns = ({ handleSearch, searchText }: SearchColumnsProps): JSX.Element => {
  const classes = useStyles();
  const onChangeHandler = ({ target: { value } }) => {
    handleSearch(value);
  };

  return (
    <div className={classes.container}>
      <Paper className={classes.root}>
        <TextField
          id="standard-required"
          value={searchText}
          style={{ margin: '5px', width: '100%' }}
          label=""
          placeholder="Search"
          onChange={onChangeHandler}
        />
      </Paper>
    </div>
  );
};

export default SearchColumns;
