import React, { useState } from 'react';
import clsx from 'clsx';
import _ from 'lodash';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { Icon, Tooltip, Radio, TextField } from '@material-ui/core';
import CloseSharpIcon from '@material-ui/icons/CloseSharp';
import { Message } from '@shared/utils/message';
import { Facet, MinMaxCriterion, IsSetCriterion } from './FacetUtil';
import CompareArrowsIcon from '@material-ui/icons/CompareArrows';

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      display: 'flex',
      flexDirection: 'column',
      marginBottom: '4px',
      backgroundColor: 'white',
    },
    header: {
      backgroundColor: '#6495ED',
      justifyContent: 'space-between',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
    },
    headerLeft: {
      alignSelf: 'center',
      display: 'flex',
      flexDirection: 'row',
    },
    title: {
      fontWeight: 'bold',
      alignSelf: 'center',
      color: '#FFFFFF',
    },
    filterTypeIcon: {
      marginLeft: '5px',
      marginRight: '5px',
      color: '#FFFFFF',
    },
    closeIcon: {
      marginRight: '3px',
      color: '#FFFFFF',
    },
    errorColor: {
      color: 'red',
    },
    errorBorder: {
      border: '1px solid red',
    },
    lineGroup1: {
      backgroundColor: 'white',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
    },
    group1Label: {
      alignSelf: 'center',
      whiteSpace: 'nowrap',
    },
    lineGroup2: {
      backgroundColor: 'white',
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'row',
      paddingLeft: '30px',
    },
    disabledColor: {
      color: 'gray',
    },
    paddedLeft: {
      paddingLeft: '8px',
    },
  }),
);

export interface DecimalFacetProps {
  facet: Facet;
  isPercent: boolean;
  initialCriterion: MinMaxCriterion | IsSetCriterion;
  delete(facet: Facet): any;
  criteriaChange(criterion: MinMaxCriterion | IsSetCriterion | null);
}

const DecimalFacet = React.memo((props: DecimalFacetProps) => {
  const classes = useStyles();

  const isIsSet = props.initialCriterion.hasOwnProperty('isSet');
  let initialSelectByValue = false;
  let initialValueSet = true;
  let initialMin = null;
  let initialMax = null;
  if (isIsSet) {
    initialValueSet = (props.initialCriterion as IsSetCriterion).isSet;
  } else {
    initialSelectByValue = true;
    initialMin = (props.initialCriterion as MinMaxCriterion).min;
    initialMax = (props.initialCriterion as MinMaxCriterion).max;
    if (props.isPercent === true) {
      initialMin = initialMin * 100.0;
      initialMax = initialMax * 100.0;
    }
  }

  const [errorInfo, setErrorInfo] = useState(null);
  const [isSelectByValue, setSelectByValue] = useState(initialSelectByValue);
  const [isValueSet, setIsValueSet] = useState(initialValueSet);
  const [min, setMin] = useState(initialMin);
  const [max, setMax] = useState(initialMax);
  const minLabel =
    props.isPercent === true ? Message.filter.decimal.minPercent : Message.filter.decimal.min;
  const maxLabel =
    props.isPercent === true ? Message.filter.decimal.maxPercent : Message.filter.decimal.max;
  let errorControl = null;
  const hasError = errorInfo !== null;
  if (hasError) {
    errorControl = (
      <Tooltip title={errorInfo}>
        <Icon className={classes.errorColor}>error</Icon>
      </Tooltip>
    );
  }

  const toNumber = (value: any, msgIdentifier: string) => {
    if (_.isNil(value)) {
      return { error: msgIdentifier + ' not set.' };
    }
    if (isNaN(value)) {
      return { error: msgIdentifier + ' is not a valid number.' };
    }
    return { error: null, numberValue: _.toNumber(value) };
  };
  const handleMinMaxError = (errorMsg: string) => {
    setErrorInfo(errorMsg);
    props.criteriaChange(null);
  };
  const adaptByFormat = (val: number) => (props.isPercent === true ? val / 100.0 : val);
  const handleMinMax = (minVal: any, maxVal: any) => {
    if (_.isNil(minVal) && _.isNil(maxVal)) {
      handleMinMaxError('Both (' + minLabel + ' and ' + maxLabel + ') values have to be entered!');
      return;
    }
    const minInfo = toNumber(minVal, minLabel);
    if (minInfo.error !== null) {
      handleMinMaxError(minInfo.error);
      return;
    }
    const maxInfo = toNumber(maxVal, maxLabel);
    if (maxInfo.error !== null) {
      handleMinMaxError(maxInfo.error);
      return;
    }
    if (minInfo.numberValue > maxInfo.numberValue) {
      handleMinMaxError(minLabel + ' is not allowed to be larger than ' + maxLabel + '.');
      return;
    }
    setErrorInfo(null);
    const crit: MinMaxCriterion = {
      min: adaptByFormat(minInfo.numberValue),
      max: adaptByFormat(maxInfo.numberValue),
    };
    props.criteriaChange(crit);
  };
  // ATTENTION: chromium browser send the onChange of number input elements twice when using the arrow buttons
  const validateAndSetMin = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setMin(event.target.value);
    handleMinMax(event.target.value, max);
  };
  const validateAndSetMax = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setMax(event.target.value);
    handleMinMax(min, event.target.value);
  };
  const handleValidIsValueSet = (isValueSet: boolean) => {
    setErrorInfo(null);
    setIsValueSet(isValueSet);
    const crit: IsSetCriterion = { isSet: isValueSet };
    props.criteriaChange(crit);
  };
  const validateAndSetIsValueSet = (isValueSet: boolean) => {
    setIsValueSet(isValueSet);
    handleValidIsValueSet(isValueSet);
  };
  const validateAndSelectByValue = (isSelectByValueChosen: boolean) => {
    setSelectByValue(isSelectByValueChosen);
    if (isSelectByValueChosen) {
      handleMinMax(min, max);
    } else {
      handleValidIsValueSet(isValueSet);
    }
  };

  return (
    <div
      key={'dec' + props.facet.facetName}
      className={hasError ? clsx(classes.root, classes.errorBorder) : classes.root}
    >
      <div className={classes.header}>
        <div className={classes.headerLeft}>
          <CompareArrowsIcon className={classes.filterTypeIcon} />
          <div className={classes.title}>{props.facet.facetName}</div>
          {errorControl}
        </div>
        <CloseSharpIcon className={classes.closeIcon} onClick={() => props.delete(props.facet)} />
      </div>
      <div className={classes.lineGroup1}>
        <Radio
          style={{ color: '#4169e1', padding: '4px' }}
          size="small"
          checked={!isSelectByValue}
          value={false}
          onChange={() => validateAndSelectByValue(false)}
        />
        <span className={classes.group1Label}>{Message.filter.decimal.checkAvailability}</span>
      </div>
      <div className={classes.lineGroup2}>
        <Radio
          disabled={isSelectByValue}
          style={{ padding: '4px' }}
          size="small"
          checked={isValueSet}
          value={true}
          onChange={() => validateAndSetIsValueSet(true)}
        />
        <span
          className={
            isSelectByValue ? clsx(classes.group1Label, classes.disabledColor) : classes.group1Label
          }
        >
          {Message.filter.decimal.isSet}
        </span>
        <Radio
          disabled={isSelectByValue}
          style={{ padding: '4px' }}
          size="small"
          checked={!isValueSet}
          value={false}
          onChange={() => validateAndSetIsValueSet(false)}
        />
        <span
          className={
            isSelectByValue ? clsx(classes.group1Label, classes.disabledColor) : classes.group1Label
          }
        >
          {Message.filter.decimal.isNotSet}
        </span>
      </div>
      <div className={classes.lineGroup1}>
        <Radio
          style={{ color: '#4169e1', padding: '4px' }}
          size="small"
          checked={isSelectByValue}
          value={true}
          onChange={() => validateAndSelectByValue(true)}
        />
        <span className={classes.group1Label}>{Message.filter.decimal.selectValue}</span>
      </div>
      <div className={classes.lineGroup2}>
        <span
          className={
            !isSelectByValue
              ? clsx(classes.group1Label, classes.paddedLeft, classes.disabledColor)
              : clsx(classes.group1Label, classes.paddedLeft)
          }
        >
          {minLabel + ':'}
        </span>
        <TextField
          disabled={!isSelectByValue}
          margin="none"
          variant="outlined"
          size="small"
          type="number"
          name="min"
          value={min || ''}
          onChange={event => validateAndSetMin(event)}
          style={{ margin: '4px 4px 4px 4px' }}
        />
        <span
          className={
            !isSelectByValue
              ? clsx(classes.group1Label, classes.disabledColor)
              : classes.group1Label
          }
        >
          {maxLabel + ':'}
        </span>
        <TextField
          disabled={!isSelectByValue}
          margin="none"
          variant="outlined"
          size="small"
          type="number"
          name="max"
          value={max || ''}
          onChange={event => validateAndSetMax(event)}
          style={{ margin: '4px 4px 4px 4px' }}
        />
      </div>
    </div>
  );
});
DecimalFacet.displayName = 'DecimalFacet';

export default DecimalFacet;
