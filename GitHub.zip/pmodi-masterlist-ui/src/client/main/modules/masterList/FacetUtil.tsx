import _ from 'lodash';

export interface Facet {
  facetName: string;
  entityType: 'PROJECT' | 'SEGMENT';
  fieldName: string;
  dataType: 'decimal' | 'string';
  facetType: 'range' | 'autocomplete' | 'checkbox';
  endpointAddress?: string;
  values?: Array<string>;
}
export interface MinMaxCriterion {
  min: number;
  max: number;
}
export interface IsSetCriterion {
  isSet: boolean;
}
export interface AutocompleteCriterion {
  selectedValue: any;
}
export interface ValuesCriterion {
  values: Array<string>;
}
export interface Filter {
  entityType: 'PROJECT' | 'SEGMENT';
  operator: string;
  fieldName: string;
  stringValues?: Array<string>;
  doubleValues?: Array<number>;
}
export interface FilterInfo {
  facet: Facet;
  filter?: Filter;
}

export const isDecimalRange = (facet: Facet) => {
  return facet && facet.dataType === 'decimal' && facet.facetType === 'range';
};

export const isAutocomplete = (facet: Facet) => {
  return facet && facet.dataType === 'string' && facet.facetType === 'autocomplete';
};

export const isCheckbox = (facet: Facet) => {
  return facet && facet.dataType === 'string' && facet.facetType === 'checkbox';
};

export const isDecimalFacetPercent = (facet: Facet) => {
  return facet.facetName.includes('Score'); // TODO JaW: which facets are in percent?
};

export const getDecimalFacetCriterionFromFilter = (filter: Filter | null) => {
  if (filter === null) {
    // Default i.e. initial value
    const criterion: IsSetCriterion = { isSet: true };
    return criterion;
  } else {
    if (filter.operator === 'isNotNull') {
      const criterion: IsSetCriterion = { isSet: true };
      return criterion;
    } else if (filter.operator === 'isNull') {
      const criterion: IsSetCriterion = { isSet: false };
      return criterion;
    } else if (filter.operator === 'between') {
      if (filter.doubleValues && filter.doubleValues.length === 2) {
        const criterion: MinMaxCriterion = {
          min: filter.doubleValues[0],
          max: filter.doubleValues[1],
        };
        return criterion;
      }
    }
  }
  throw new Error('Unsupported decimal facet filter!');
};

export const getAutocompleteFacetCriterionFromFilter = (filter: Filter | null) => {
  if (filter === null) {
    // Default i.e. initial value
    const criterion: ValuesCriterion = { values: [] };
    return criterion;
  } else {
    if (filter.operator === 'in' || filter.operator === 'equals') {
      //if (filter.stringValues && filter.stringValues.length === 1) {
      const criterion: ValuesCriterion = { values: filter.stringValues };
      return criterion;
      // }
    }
  }
  throw new Error('Unsupported autocomplete facet filter!');
};

export const getYearAndMonthForSegmentCreation = (filter: Filter | null) => {
  if (filter === null) {
    // Default i.e. initial value
    const yearCriterion: ValuesCriterion = { values: [] };
    const monthCriterion: ValuesCriterion = { values: [] };
    return { yearCriterion, monthCriterion };
  } else {
    const isMonthPresent = _.find(filter.stringValues, val => _.includes(val, '-'));

    if (isMonthPresent) {
      const arrYear = _.map(filter.stringValues, val => {
        const arr = _.split(val, '-');
        return arr[0];
      });
      const arrMonth = _.map(filter.stringValues, val => {
        const arr = _.split(val, '-');
        return arr[1];
      });

      const yearCriterion: ValuesCriterion = {
        values: _.uniq(arrYear),
      };
      const monthCriterion: ValuesCriterion = {
        values: _.uniq(arrMonth),
      };
      return {
        yearCriterion,
        monthCriterion,
      };
    } else {
      const yearCriterion: ValuesCriterion = { values: filter.stringValues };
      const monthCriterion: ValuesCriterion = { values: [] };
      return {
        yearCriterion,
        monthCriterion,
      };
    }
  }
};

export const getCheckboxFacetCriterionFromFilter = (filter: Filter | null) => {
  if (filter === null) {
    // Default i.e. initial value
    const criterion: ValuesCriterion = { values: [] };
    return criterion;
  } else {
    if (filter.operator === 'in') {
      if (_.isArray(filter.stringValues)) {
        const criterion: ValuesCriterion = {
          values: [...filter.stringValues],
        };
        return criterion;
      }
    }
  }
  throw new Error('Unsupported checkbox facet filter!');
};

export const createFilter = (criterion, facet: Facet) => {
  let filter = null;
  if (criterion) {
    if (criterion.hasOwnProperty('isSet')) {
      filter = {
        entityType: facet.entityType,
        fieldName: facet.fieldName,
        operator: (criterion as IsSetCriterion).isSet ? 'isNotNull' : 'isNull',
      };
    } else if (criterion.hasOwnProperty('min')) {
      const m: MinMaxCriterion = criterion as MinMaxCriterion;
      filter = {
        entityType: facet.entityType,
        fieldName: facet.fieldName,
        operator: 'between',
        doubleValues: [m.min, m.max],
      };
    } else if (criterion.hasOwnProperty('selectedValue')) {
      const a: AutocompleteCriterion = criterion as AutocompleteCriterion;
      // If no value is selected the filter would be invalid -> then null is returned
      if (!_.isNil(a.selectedValue)) {
        filter = {
          entityType: facet.entityType,
          fieldName: facet.fieldName,
          operator: 'equals',
          stringValues: [a.selectedValue],
        };
      }
    } else if (criterion.hasOwnProperty('values')) {
      const v: ValuesCriterion = criterion as ValuesCriterion;
      // If no value is selected the filter would be invalid -> then null is returned
      if (v.values && v.values.length > 0) {
        filter = {
          entityType: facet.entityType,
          fieldName: facet.fieldName,
          operator: 'in',
          stringValues: [...v.values],
        };
      }
    }
  }
  return filter;
};
