import React from 'react';
import clsx from 'clsx';
import { useDispatch, useSelector } from 'react-redux';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import CssBaseline from '@material-ui/core/CssBaseline';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';

import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import MasterListView from './MasterListView';
import SearchFacetPanel from './SearchFacetPanel';
import { getSearchFiltersFromLocalStorage } from '@main/security/localStore';
import { ListOfLinks } from '../../components/ListOfLinks/ListOfLinks';
const drawerWidth = '30vw';
const headerHeight = '64px';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
      width: '100%',
      paddingTop: headerHeight,
      overflow: 'hidden',
    },
    appBar: {
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      top: 'auto',
      color: '#3f51b5',
      backgroundColor: '#fafafa',
      height: '48px',
    },
    appBarShift: {
      width: `calc(100% - ${drawerWidth})`,
      marginLeft: drawerWidth,
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    menuRightButton: {
      marginRight: '8px',
    },
    menuLeftButton: {
      marginLeft: '2px',
    },
    hide: {
      display: 'none',
    },
    drawer: {
      flexShrink: 0,
    },
    drawerPaper: {
      width: drawerWidth,
      top: 'auto',
      height: `calc(100% - ${headerHeight} - 2px)`,
      // backgroundColor: 'green',
    },
    drawerHeader: {
      display: 'flex',
      alignItems: 'center',
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
      justifyContent: 'flex-end',
    },
    content: {
      flexGrow: 1,
      paddingTop: '48px',
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      marginLeft: 0,
    },
    contentShift: {
      width: `calc(100% - ${drawerWidth})`,
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: drawerWidth,
    },
    paper: {
      display: 'flex',
      overflow: 'auto',
    },
    container: { margin: '-5px' },
    heading: {
      fontSize: theme.typography.pxToRem(20),
      fontWeight: theme.typography.fontWeightRegular,
    },
    toolbar: {
      minHeight: '48px',
    },
  }),
);

export default function MainPage() {
  const classes = useStyles();
  const dispatch = useDispatch<typeDispatch>();
  const openSearchFilter = useSelector((state: typeState) => state.MasterList.openSearchFilter);
  const localFilters = getSearchFiltersFromLocalStorage();
  const reducerFilter = useSelector((state: typeState) => state.MasterList.filters);
  const filters = localFilters !== null ? localFilters : reducerFilter;
  const handleDrawerOpen = () => {
    dispatch.MasterList.openSearchFilterView(!openSearchFilter);
  };

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        color="inherit"
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: openSearchFilter,
        })}
      >
        <Toolbar className={classes.toolbar}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuRightButton)}
          >
            {openSearchFilter ? <ArrowBackIosIcon /> : <ArrowForwardIosIcon />}
          </IconButton>
          <Typography variant="h6" noWrap>
            Filters
          </Typography>
          {isNotEmptyValue(filters) && <CheckCircleIcon className={clsx(classes.menuLeftButton)} />}
          <ListOfLinks />
        </Toolbar>
      </AppBar>
      <Drawer
        className={classes.drawer}
        variant="persistent"
        anchor="left"
        open={openSearchFilter}
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <SearchFacetPanel />
      </Drawer>
      <main
        className={clsx(classes.content, {
          [classes.contentShift]: openSearchFilter,
        })}
      >
        <MasterListView />
      </main>
    </div>
  );
}
