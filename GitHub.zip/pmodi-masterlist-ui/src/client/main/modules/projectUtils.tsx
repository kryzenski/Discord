import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import { useParams } from 'react-router-dom';
import {
  PRECISE_NEW_PORT_ID_FIELD,
  PROJECT_STATUS_FIELD,
  PROJECT_NAME_FIELD,
  FREE_NAMES_FIELD,
  PROJECT_CATEGORY_FILED,
  PROJECT_MANAGER_FIELD,
  PRIORITIZATION_GOVERNNCE_FIELD,
  PRIORITIZATION_TYPE_FIELD,
  PROJECT_ID,
  VERSION,
  FT_PTRS_SCORE_FIELD,
  FT_PTRS_SCORE_REMARK_FIELD,
  FS_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_REMARK_FIELD,
} from '@main/constants/projectOptions';

import { isEmptyValue, isNotEmptyValue } from '@shared/utils/functionUtils';
import { useOptions, isEmptyPtrsEditPanel } from './matserListUtil';
import _ from 'lodash';

export const getItemValueForProp = (item, prop) => {
  if (_.isNull(item)) {
    return null;
  }
  switch (prop) {
    case PROJECT_NAME_FIELD:
      return _.get(item, PROJECT_NAME_FIELD);
    case PROJECT_CATEGORY_FILED:
      return _.get(item, PROJECT_CATEGORY_FILED);
    case PROJECT_STATUS_FIELD:
      return _.get(item, PROJECT_STATUS_FIELD);
    case PROJECT_MANAGER_FIELD:
      return _.get(item, PROJECT_MANAGER_FIELD);
    case FREE_NAMES_FIELD:
      return _.get(item, FREE_NAMES_FIELD);
    case PRECISE_NEW_PORT_ID_FIELD:
      return _.get(item, PRECISE_NEW_PORT_ID_FIELD);
    case PRIORITIZATION_GOVERNNCE_FIELD:
      return _.get(item, PRIORITIZATION_GOVERNNCE_FIELD);
    case PRIORITIZATION_TYPE_FIELD:
      return _.get(item, PRIORITIZATION_TYPE_FIELD);
    case PROJECT_ID:
      return _.get(item, PROJECT_ID);
    case VERSION:
      return _.get(item, VERSION);
    case 'includes':
      return _.get(item, 'includes');
    default:
      return null;
  }
};

export const useProject = props => {
  const dispatch = useDispatch<typeDispatch>();
  const { id, date }: any = useParams();
  const {
    currentProject,
    editableFieldsMap,
    isLoading,
    quickscanAssessments,
    quickscanMitigation,
    segments,
    weightedRSScore,
    weightedFSScore,
    mileStones,
  } = useSelector((state: typeState) => {
    return {
      currentProject: state.MasterList.projects.currentItem,
      editableFieldsMap: state.MasterList.projects.editbaleFieldsMap,
      isLoading:
        state.loading.effects.MasterList.getProjectDataById ||
        state.loading.effects.MasterList.updateProject ||
        state.loading.effects.MasterList.fetchEditableFieldsOfProject ||
        state.loading.effects.MasterList.fetchQuickscanAssessments ||
        state.loading.effects.MasterList.fetchQuickscanMitigation ||
        state.loading.effects.MasterList.fetchMilestoneOfProject ||
        state.loading.effects.MasterList.getProjectDataByDate,
      quickscanAssessments: state.MasterList.projects.quickscanAssessments,
      quickscanMitigation: state.MasterList.projects.quickscanMitigation,
      mileStones: state.MasterList.projects.mileStones,
      segments: state.MasterList.segments.segmentsData,
      weightedRSScore: state.MasterList.segments.weightedRSScore,
      weightedFSScore: state.MasterList.segments.weightedFSScore,
    };
  });
  const editableFields = editableFieldsMap.get(id);
  const isEmptyView = !currentProject || isEmptyPtrsEditPanel(currentProject);
  const textProjectDetails =
    getItemValueForProp(currentProject, PRECISE_NEW_PORT_ID_FIELD) +
    ': ' +
    getItemValueForProp(currentProject, PROJECT_NAME_FIELD);

  const regprimeDetailSegment = _.map(segments, segment => {
    const [mileStone] = mileStones?.filter(item => item?.segmentId === segment.id);

    return {
      registrationStatus: mileStone?.milestoneRegprimeDto?.registrationStatus,
      mileStone: mileStone?.milestoneRegprimeDto,
      ...segment,
    };
  });

  const detailsOption = {
    id,
    currentProject,
    segments: regprimeDetailSegment,
    editableFields,
    weightedRSScore,
    hasAuditLog: props.hasAuditLog,
    hasDatePickerView: isNotEmptyValue(date),
    textProjectDetails,
    quickscanMitigation,
  };
  useEffect(() => {
    isEmptyValue(date) && dispatch.MasterList.getProjectDataById(id);
    isEmptyValue(editableFields) && dispatch.MasterList.fetchEditableFieldsOfProject(id);
    isNotEmptyValue(date) && dispatch.MasterList.getProjectDataByDate({ id, date });
    isEmptyValue(date) && dispatch.MasterList.fetchQuickscanAssessments({ id, type: 'projects' });
    isEmptyValue(date) && dispatch.MasterList.fetchQuickscanMitigation({ id, type: 'projects' });
    isEmptyValue(date) && dispatch.MasterList.fetchMilestoneOfProject({ id });
    isEmptyValue(date) && dispatch.MasterList.fetchSegmentsByProjectIdWithoutPaging(id);
    isNotEmptyValue(date) && dispatch.MasterList.fetchSegmentByDate({ id, date });
  }, [id, date]);

  const ftPtrsOPtions = useOptions(
    currentProject,
    FT_PTRS_SCORE_FIELD,
    FT_PTRS_SCORE_REMARK_FIELD,
    editableFields,
    isEmptyView,
    'projects',
    props.hasAuditLog,
  );

  const fsPtrsOPtions = useOptions(
    currentProject,
    FS_PTRS_SCORE_FIELD,
    FS_PTRS_SCORE_REMARK_FIELD,
    editableFields,
    false,
    'projects',
    props.hasAuditLog,
  );

  return {
    currentProject,
    editableFields,
    isLoading,
    id,
    quickscanAssessments,
    quickscanMitigation,
    detailsOption,
    ftPtrsOPtions,
    fsPtrsOPtions: {
      ...fsPtrsOPtions,
      segments: regprimeDetailSegment,
      weightedFSScore,
      quickscanMitigation,
    },
    date,
  };
};
