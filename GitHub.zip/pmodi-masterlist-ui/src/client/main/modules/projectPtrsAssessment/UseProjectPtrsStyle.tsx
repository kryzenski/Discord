import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';

export const useProjectPtrsStyle = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: '100%',
      paddingTop: '65px',
    },
    textField: {
      marginTop: theme.spacing(2),
      marginLeft: theme.spacing(2),
      marginBottom: theme.spacing(2),
    },
    label: {
      marginTop: theme.spacing(2),
      fontSize: '16px',
      fontWeight: 500,
    },
    textRiskField: {
      width: '100%',
    },
    textRationaleField: {
      width: '100%',
      marginTop: '0%',
      marginLeft: '15%',
    },
    multiLine: {
      width: '105%',
      marginLeft: '12%',
      display: 'inline-block',
    },
    textArea: {
      marginLeft: '0% !important',
      width: '100%',
    },
    divider: {
      marginTop: theme.spacing(1),
      width: '114%',
      marginBottom: theme.spacing(1),
      height: '2px',
      backgroundColor: '#AAAAAA',
    },
    button: {
      marginLeft: '100%',
      marginTop: theme.spacing(2),
    },
    propertyLabel: {
      fontSize: '15px !important',
      paddingTop: '2%',
    },
    rationaleLabel: {
      marginLeft: '50%',
      display: 'inline',
    },
    riskLabel: {
      marginLeft: '32%',
      display: 'inline',
    },
    quickScanResultTable: {
      width: '99%',
      marginLeft: '5px',
      marginTop: '1%',
      marginBottom: '2%',
    },
    ptrsPanel: {
      width: '100%',
    },
    emptyView: {
      marginLeft: '40%  !important',
      marginBottom: '2%',
    },
    weightedScore: {
      marginBottom: '2%',
    },
    textAreaLog: {
      marginTop: '2%',
      top: 'auto',
      position: 'absolute',
      marginLeft: '0.5px',
    },
    textAuditLog: {
      top: 'auto',
      position: 'absolute',
      marginLeft: '89%',
    },
    numberTextField: {
      marginRight: '-100%',
    },
    segmentTable: {
      marginBottom: '2%',
      marginTop: '1%',
      width: '99%',
    },
    textFieldWithAuditLog: {
      display: 'inline-block',
      marginLeft: '85%',
      width: '100%',
    },
    labelText: {
      marginTop: theme.spacing(2),
      fontSize: '15px',
      color: 'black',
    },
    labelTextRS: {
      fontSize: '15px',
      color: 'black',
    },
    customDropDownList: {
      paddingLeft: '15px',
      fontSize: '14px',
      fontWeight: 500,
    },
    customDropDownListRS: {
      paddingLeft: '15px',
      fontSize: '15px',
      color: 'black',
      marginLeft: '27%',
      width: '87%',
      marginBottom: theme.spacing(3),
      marginTop: theme.spacing(2),
    },
    warningMessage: {
      color: '#ff1a1a',
      fontSize: '16px',
      marginBottom: '1%',
      display: 'flex',
      marginLeft: '15%',
    },
  }),
);
