import React, { useState, useEffect } from 'react';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import LoaderComponent from '@shared/components/LoaderComponent/LoaderComponent';
import { PtrsPanel } from './PtrsPanel';
import { RegulatoryScience } from './RegulatoryScience/RegulatoryScience';
import { FsPtrsPanel } from './FsPtrsPanel';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import { PtrsEditPanel } from '@main/components/PtrsEditPanel/PtrsEditPanel';
import { useProjectPtrsStyle } from '@main/modules/projectPtrsAssessment/UseProjectPtrsStyle';
import CssBaseline from '@material-ui/core/CssBaseline';
import { Message } from '@shared/utils/message';
import { toInteger } from '@shared/utils/numberUtils';
import {
  FT_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_FIELD,
  RS_PTRS_SCORE_FIELD,
} from '@main/constants/projectOptions';
import { useProject } from '@main/modules/projectUtils';

type ProjectPtrsProps = {
  currentProject?: any;
  isLoading?: boolean;
  ftPtrsOPtions?: any;
  id?: string;
  fsPtrsOPtions?: any;
  detailsOption?: any;
};

export default function projectPtrsAssessment() {
  const classes = useProjectPtrsStyle();
  const [allExpanded, setAllExpanded] = useState(true);
  const {
    currentProject,
    isLoading,
    ftPtrsOPtions,
    fsPtrsOPtions,
    detailsOption,
    quickscanAssessments,
  } = useProject({ hasAuditLog: true });
  const onExpandAllClick = () => {
    setAllExpanded(!allExpanded);
  };

  const ProjectPtrs = ({ detailsOption, isLoading }: ProjectPtrsProps) => {
    return (
      <ExpansionPanelView
        text={Message.ptrs.projectPtrs}
        ItemRender={isLoading ? LoaderComponent : PtrsPanel}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        shownExpandIcon={false}
        showExpandAll={true}
        expandOverride={allExpanded}
        expandAllClick={onExpandAllClick}
      ></ExpansionPanelView>
    );
  };

  const RegulatorySciencePanel = ({ detailsOption, isLoading }: ProjectPtrsProps) => {
    const regulatoryScienceText =
      Message.ptrs.regulatoryScience + toInteger(detailsOption.currentProject[RS_PTRS_SCORE_FIELD]);
    return (
      <ExpansionPanelView
        text={regulatoryScienceText}
        ItemRender={isLoading ? LoaderComponent : RegulatoryScience}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const FormulationTechnology = ({
    currentProject,
    isLoading,
    ftPtrsOPtions,
  }: ProjectPtrsProps) => {
    ftPtrsOPtions.test = 'technology';
    const emptyText = Message.ptrs.formulationTechnology + 100;
    const formulationTechnologyText = ftPtrsOPtions.isEmptyView
      ? emptyText
      : Message.ptrs.formulationTechnology + toInteger(currentProject[FT_PTRS_SCORE_FIELD]);
    return (
      <ExpansionPanelView
        text={formulationTechnologyText}
        ItemRender={isLoading ? LoaderComponent : PtrsEditPanel}
        itemRenderOptions={ftPtrsOPtions}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const FieldSolutions = ({ currentProject, isLoading, fsPtrsOPtions }: ProjectPtrsProps) => {
    const emptyText = Message.ptrs.fieldSolutions + 100;
    fsPtrsOPtions.test = 'solution';
    const fieldSolutionsText = fsPtrsOPtions.isEmptyView
      ? emptyText
      : Message.ptrs.fieldSolutions + toInteger(currentProject[FS_PTRS_SCORE_FIELD]);
    return (
      <ExpansionPanelView
        text={fieldSolutionsText}
        ItemRender={isLoading ? LoaderComponent : FsPtrsPanel}
        itemRenderOptions={fsPtrsOPtions}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };
  const globalDispatch = useDispatch<typeDispatch>();
  useEffect(() => {
    return () => globalDispatch.MasterList.setCurrentItem({ item: {}, type: 'segments' });
  }, []);
  return (
    <div className={classes.root}>
      <CssBaseline />
      <ProjectPtrs detailsOption={detailsOption} isLoading={isLoading} />
      <FormulationTechnology
        currentProject={currentProject}
        isLoading={isLoading}
        ftPtrsOPtions={{ ...ftPtrsOPtions, quickscanAssessments }}
      />
      <FieldSolutions
        currentProject={currentProject}
        isLoading={isLoading}
        fsPtrsOPtions={{ ...fsPtrsOPtions, quickscanAssessments }}
      />
      <RegulatorySciencePanel
        detailsOption={{ ...detailsOption, quickscanAssessments }}
        isLoading={isLoading}
      />
    </div>
  );
}
