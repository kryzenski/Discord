import React from 'react';
import { BreadCrumbs } from '@main/components/BreadCrumbs/BreadCrumbs';
import { useProjectPtrsStyle } from '@main/modules/projectPtrsAssessment/UseProjectPtrsStyle';
import { ScoreContainer } from '@main/components/ScoreContainer/ScoreContainer';
import { ProjectDetailsBasicInfo } from '@main/modules/projectDetails/ProjectDetailsBasicInfo';
import { Message } from '@shared/utils/message';
import { PtrsFollowUp, PtrsFollowUpType } from '../../components/PtrsFollowUp/PtrsFollowUp';

type ptrsPanelProps = {
  itemRenderOptions: {
    currentProject: any;
    textProjectDetails: string;
  };
};

const useData = itemRenderOptions => {
  const { currentProject, textProjectDetails } = itemRenderOptions;
  const linkItems = [
    { path: '/', text: Message.masterList.masterListLink },
    { path: `/project/${itemRenderOptions.id}`, text: textProjectDetails },
    { path: null, text: 'PTRS' },
  ];
  return { linkItems, currentProject };
};

export const PtrsPanel = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const classes = useProjectPtrsStyle();
  const { linkItems, currentProject } = useData(itemRenderOptions);
  const breadCrumbs = <BreadCrumbs items={linkItems} />;

  return (
    <div className={classes.ptrsPanel}>
      {breadCrumbs}
      <ProjectDetailsBasicInfo project={currentProject} />
      <ScoreContainer data={currentProject} hasButton={false} type="projects" />
      <PtrsFollowUp entity={currentProject} type={PtrsFollowUpType.PROJECT} />
    </div>
  );
};
