import _ from 'lodash';
import React from 'react';
import { Message } from '@shared/utils/message';
import { sortByKey } from '@shared/utils/functionUtils';
import { BasicTextField } from '@shared/components/TextField/BasicTextField';
import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import { Aprs } from '@main/components/PtrsEditPanel/Aprs';
import { cellStyle } from '@main/constants/constants';
import Grid from '@material-ui/core/Grid';
import {
  assessmentDetailPanel,
  gapDetailPanel,
} from '@main/hook/SubTablePanelOfQuickSacn/useDetailPanel';
import { QuickScanResult } from '@main/components/QuickScanResultTable/QuickScanResult';

import { useProjectPtrsStyle } from '@main/modules/projectPtrsAssessment/UseProjectPtrsStyle';
import { FIELD_ORDER, getFieldsInfoOfSegment } from '@main/constants/fieldsInfo';
import { segmentColumnsOfRS, segmentColumnsOfFS } from '@main/constants/segmentOptions';
import { WARNING_MESSAGE_RS } from '@main/constants/projectOptions';

export const useSegmentTableOptions = (segments, type, category) => {
  const segmentColumnsInfo = getFieldsInfoOfSegment();
  const segmentColumns = type === 'RS' ? segmentColumnsOfRS : segmentColumnsOfFS;
  console.log('segment column', segmentColumnsInfo);
  const columns = _.map(segmentColumns, col => {
    const column = segmentColumnsInfo[col];
    return {
      ...column,
      hidden:
        column?.field === 'registrationStatus' && category === 'New Formulation Proof of Concept'
          ? true
          : false,
      cellStyle,
    };
  });
  const sortedColumns = sortByKey(columns, FIELD_ORDER);
  return {
    columns: sortedColumns,
    data: segments,
    maxBodyHeight: '200px',
    toolbar: false,
  };
};

export const segmentTable = (
  classes,
  weightedScore,
  segments,
  type,
  currentProject,
  label = '',
) => {
  const classVal = useProjectPtrsStyle();
  return (
    <>
      <div className={classes.weightedScore}>
        <Grid container xs={12} spacing={1}>
          <Grid item xs={2}>
            <BasicTextField
              value={weightedScore}
              textFiledClass={classes.textField}
              isDisabled={true}
              label={label}
            />
          </Grid>
        </Grid>
        <div className={classes.segmentTable}>
          <TableComponent
            itemRenderOptions={useSegmentTableOptions(
              segments,
              type,
              currentProject?.newportCategory,
            )}
          />
        </div>
      </div>
      <Grid container xs={12} spacing={1}>
        <Grid item xs={2}></Grid>
        <Grid item xs={8}>
          {type === 'RS' && segments['checkRS'] && (
            <span className={classVal.warningMessage}> {WARNING_MESSAGE_RS} </span>
          )}
        </Grid>
      </Grid>
    </>
  );
};

const getWeightedScore = (weightedScore, segments, classes, label, type, currentProject) => ({
  label,
  index: 0,
  children: segmentTable(classes, weightedScore, segments, type, currentProject),
});

const getQuickScanDetailForGap = (quickScanData, detailPanelType, classes, label, index) => {
  const detailPanel = gapDetailPanel();
  quickScanData =
    quickScanData?.length > 0
      ? _.map(quickScanData, item => {
          return { ...item, detailPanelType };
        })
      : [];
  return {
    label,
    index,
    children: (
      <QuickScanResult
        quickScanData={quickScanData}
        detailPanel={detailPanel}
        hasTitle={false}
        cssClass={classes.quickScanResultTable}
        type={detailPanelType}
      />
    ),
  };
};

const getQuickScan = (quickScanData, segments, detailPanelType, classes, label, index) => {
  const detailPanel = detailPanelType === 'gap' ? gapDetailPanel() : assessmentDetailPanel();
  quickScanData = _.map(quickScanData, item => {
    return { ...item, detailPanelType };
  });
  const isNotApplicableArray = [];
  _.forEach(segments, data => {
    if (data.isQuickScanNotApplicable) {
      const countryCropObj = {
        countryName: data.country.displayName,
        cropText: data.crop.displayName,
      };
      const temp = _.pick(data, ['isQuickScanNotApplicable', 'quickScanNotApplicableReason']);
      isNotApplicableArray.push({ ...temp, ...countryCropObj });
    }
  });
  if (detailPanelType === 'assessment') {
    quickScanData = [...quickScanData, ...isNotApplicableArray];
  }
  return {
    label,
    index,
    children: (
      <QuickScanResult
        quickScanData={quickScanData}
        detailPanel={detailPanel}
        hasTitle={false}
        cssClass={classes.quickScanResultTable}
        type={detailPanelType}
      />
    ),
  };
};

const getAprs = (aprsData, isAprsTableLoading, label) => ({
  label,
  index: 2,
  children: <Aprs data={aprsData} isLoading={isAprsTableLoading} isSegment={false} />,
});

export const useFsTabs = ({ weightedScore, segments, quickScanData, currentProject }) => {
  console.log('category', currentProject?.newportCategory);
  const classes = useProjectPtrsStyle();
  return [
    getWeightedScore(
      weightedScore,
      segments,
      classes,
      Message.ptrs.weightedFSScore,
      'FS',
      currentProject,
    ),
    getQuickScan(quickScanData, segments, 'gap', classes, Message.ptrs.gapFSInformation, 1),
  ];
};
export const useGapTabs = quickScanData => {
  const classes = useProjectPtrsStyle();
  return [
    getQuickScanDetailForGap(
      quickScanData,
      'gapSegmentInfo',
      classes,
      Message.ptrs.gapFSInformation,
      0,
    ),
  ];
};

export const useRsTabs = ({
  weightedScore,
  segments,
  quickScanData,
  isAprsTableLoading,
  aprsData,
  currentProject,
}) => {
  const classes = useProjectPtrsStyle();
  return [
    getWeightedScore(
      weightedScore,
      segments,
      classes,
      Message.ptrs.weightedRSScore,
      'RS',
      currentProject,
    ),
    getQuickScan(quickScanData, segments, 'assessment', classes, Message.ptrs.quickScanResult, 1),
    getAprs(aprsData, isAprsTableLoading, Message.ptrs.aprsLabel),
    getQuickScan(quickScanData, segments, 'gap', classes, Message.ptrs.gapFSInformation, 3),
  ];
};
