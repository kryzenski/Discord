import React, { Fragment } from 'react';
import { PtrsEditPanel } from '@main/components/PtrsEditPanel/PtrsEditPanel';
import { getQuickScanData, getAssessments, getMitigations } from '@main/modules/matserListUtil';
import CustomizedTabs from '@shared/components/Tab/CustomizedTabs';
import { useFsTabs } from './UseTabs';

type FsPtrsPanelProps = {
  itemRenderOptions: {
    scoreKey: string;
    scoreLabel: string;
    emptyText?: string;
    rationaleKey: string;
    rationaleLabel: string;
    recommendationKey: string;
    objectiveKey: string;
    resultKey: string;
    isEmptyView?: boolean;
    hasAuditLog?: boolean;
    path?: Array<string>;
    editableFields?: Array<string>;
    item: { [propName: string]: any };
    handleClick: Function;
  };
};

const useData = itemRenderOptions => {
  const {
    segments,
    weightedFSScore,
    quickscanAssessments,
    quickscanMitigation,
    item,
  } = itemRenderOptions;
  const assessments = getAssessments(quickscanAssessments);
  const quickScanMitigationFilter = getMitigations(quickscanMitigation);
  const quickScanData = getQuickScanData(assessments, quickScanMitigationFilter);
  return { quickScanData, weightedFSScore, segments, item };
};

export const FsPtrsPanel = ({ itemRenderOptions }: FsPtrsPanelProps): JSX.Element => {
  const { quickScanData, weightedFSScore, segments, item } = useData(itemRenderOptions);
  const tabs = useFsTabs({
    weightedScore: weightedFSScore,
    segments,
    quickScanData,
    currentProject: item,
  });

  return (
    <Fragment>
      <CustomizedTabs tabs={tabs} />
      <PtrsEditPanel itemRenderOptions={itemRenderOptions} />
    </Fragment>
  );
};
