import CssBaseline from '@material-ui/core/CssBaseline';
import React, { Fragment } from 'react';

import CustomizedTabs from '@shared/components/Tab/CustomizedTabs';
import { useAprsUtils } from '@main/components/PtrsEditPanel/Aprs';
import { getQuickScanData, getAssessments, getMitigations } from '@main/modules/matserListUtil';
import { useRsTabs } from '../UseTabs';
import { RiskAssessmentPanel } from './RiskAssessmentPanel';

type RegulatoryScience = {
  itemRenderOptions: {
    id: string;
    currentProject: any;
  };
};

const useData = itemRenderOptions => {
  const {
    id,
    segments,
    currentProject,
    editableFields,
    weightedRSScore,
    quickscanAssessments,
    quickscanMitigation,
  } = itemRenderOptions;
  const [aprsData, isAprsTableLoading] = useAprsUtils(id, false);
  const assessments = getAssessments(quickscanAssessments);
  const mitigations = getMitigations(quickscanMitigation);
  const quickScanData = getQuickScanData(assessments, mitigations);
  return {
    weightedRSScore,
    segments,
    currentProject,
    editableFields,
    quickScanData,
    aprsData,
    isAprsTableLoading,
  };
};

export const RegulatoryScience = ({ itemRenderOptions }: RegulatoryScience): JSX.Element => {
  const [isWarningMessageforRS, setIsWarningMessage] = React.useState(false);

  const setMessage = isWarningmsg => {
    setIsWarningMessage(isWarningmsg);
  };

  const {
    weightedRSScore,
    segments,
    currentProject,
    editableFields,
    quickScanData,
    aprsData,
    isAprsTableLoading,
  } = useData(itemRenderOptions);
  segments.checkRS = isWarningMessageforRS;

  const tabs = useRsTabs({
    weightedScore: weightedRSScore,
    segments,
    quickScanData,
    aprsData,
    isAprsTableLoading,
    currentProject,
  });
  return (
    <Fragment>
      <CustomizedTabs tabs={tabs} />
      <CssBaseline />
      <RiskAssessmentPanel
        item={currentProject}
        editableFields={editableFields}
        setMessage={setMessage}
      ></RiskAssessmentPanel>
    </Fragment>
  );
};
