import React from 'react';
import { useSelector } from 'react-redux';
import { typeState } from '@main/stateManagement/store';

import { useDispatch } from 'react-redux';
import _ from 'lodash';
import { typeDispatch } from '@main/stateManagement/store';
import { toInteger, toDecimal } from '@shared/utils/numberUtils';
import {
  RS_ENSA_PTRS_SCORE_REMARK_FIELD,
  RS_ENSA_PTRS_SCORE_FIELD,
  RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD,
  RS_OPERATOR_RISK_PTRS_SCORE_FIELD,
  RS_DIETARY_SAFETY_PTRS_SCORE_FIELD,
  RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD,
  RS_REGULATORY_AFFAIRS_SCORE_FIELD,
  RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD,
  RS_PTRS_SCORE_REMARK_FIELD,
  FT_PTRS_SCORE_FIELD,
  FT_PTRS_SCORE_MODIFIED_BY_FIELD,
  FT_PTRS_SCORE_MODIFIED_DATE_FIELD,
  FS_PTRS_SCORE_MODIFIED_BY_FIELD,
  FS_PTRS_SCORE_MODIFIED_DATE_FIELD,
  RS_DIETARY_PTRS_SCORE_MODIFIED_BY_FIELD,
  RS_DIETARY_PTRS_SCORE_MODIFIED_DATE_FIELD,
  RS_ENSA_PTRS_SCORE_MODIFIED_BY_FIELD,
  RS_ENSA_PTRS_SCORE_MODIFIED_DATE_FIELD,
  RS_OPERATOR_PTRS_SCORE_MODIFIED_BY_FIELD,
  RS_OPERATOR_PTRS_SCORE_MODIFIED_DATE_FIELD,
  RS_REG_AFFAIR_SCORE_MODIFIED_BY_FIELD,
  RS_REG_AFFAIR_SCORE_MODIFIED_DATE_FIELD,
  RS_PTRS_SCORE_REMARK_MODIFIED_BY_FIELD,
  RS_PTRS_SCORE_REMARK_MODIFIED_DATE_FIELD,
  FS_PTRS_SCORE_FIELD,
  RS_RECOMMENDATION_MODIFIED_BY_FIELD,
  RS_RECOMMENDATION_MODIFIED_DATE_FIELD,
} from '@main/constants/projectOptions';
import moment from 'moment';
import { RS_RECOMMENDATION_FIELD } from '~/client/main/constants/constants';

export const useRiskAssessmentData = props => {
  const dispatch = useDispatch<typeDispatch>();
  const { editableFields, item, hasAuditLog = true } = props;
  const { version, id } = item;

  const entity = {
    rsEnsaPtrsScoreRmk: _.get(item, RS_ENSA_PTRS_SCORE_REMARK_FIELD),
    rsEnsaPtrsScore: toInteger(_.get(item, RS_ENSA_PTRS_SCORE_FIELD)) || '',
    rsOperatorPtrsScoreRmk: _.get(item, RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD),
    rsOperatorPtrsScore: toInteger(_.get(item, RS_OPERATOR_RISK_PTRS_SCORE_FIELD)) || '',
    rsDietaryPtrsScore: toInteger(_.get(item, RS_DIETARY_SAFETY_PTRS_SCORE_FIELD)) || '',
    rsRegAffairsScore: toInteger(_.get(item, RS_REGULATORY_AFFAIRS_SCORE_FIELD)) || '',
    rsPtrsScoreRmk: _.get(item, RS_PTRS_SCORE_REMARK_FIELD),
    rsDietaryPtrsScoreRmk: _.get(item, RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD),
    rsRegAffairsScoreRmk: _.get(item, RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD),
    shownScienceRecommendation: _.get(item, 'scienceRecommendation'),
    isNull: false,
  };

  const [editEntity, setEntity] = React.useState({ version, id });
  const [shownEntity, setShownEntity] = React.useState(entity);
  const [isValidate, setVaidate] = React.useState(true);
  const userRolesStr = useSelector((state: typeState) => state.User.userName);
  const date = new Date();
  const lastDateModified = moment(date).format('YYYY-MM-DD');
  const checkingCategory =
    item.newportCategory === 'Label Expansion' || item.newportCategory === 'Country Extension'
      ? true
      : false;
  const validatorListener = isValidate => {
    setVaidate(isValidate);
  };
  const handleChange = event => {
    const { value, name, type } = event.target;
    const newShownEntity = { ...shownEntity };
    newShownEntity[name] = value;
    setShownEntity(newShownEntity);
    let checkingForRSSubScores = {};
    if (
      checkingCategory &&
      item[RS_REGULATORY_AFFAIRS_SCORE_FIELD] === null &&
      item[RS_ENSA_PTRS_SCORE_FIELD] === null &&
      item[RS_DIETARY_SAFETY_PTRS_SCORE_FIELD] === null &&
      item[RS_OPERATOR_RISK_PTRS_SCORE_FIELD] === null
    ) {
      checkingForRSSubScores = { isNull: false };

      !(item.weightedRsScore == 0) &&
        setShownEntity(shownEntity => ({ ...shownEntity, ...checkingForRSSubScores }));
    } else {
      checkingForRSSubScores = {
        isNull:
          (newShownEntity[RS_REGULATORY_AFFAIRS_SCORE_FIELD] === null ||
            newShownEntity[RS_REGULATORY_AFFAIRS_SCORE_FIELD] === '') &&
          (newShownEntity[RS_ENSA_PTRS_SCORE_FIELD] === null ||
            newShownEntity[RS_ENSA_PTRS_SCORE_FIELD] === '') &&
          (newShownEntity[RS_DIETARY_SAFETY_PTRS_SCORE_FIELD] === null ||
            newShownEntity[RS_DIETARY_SAFETY_PTRS_SCORE_FIELD] === '') &&
          (newShownEntity[RS_OPERATOR_RISK_PTRS_SCORE_FIELD] === null ||
            newShownEntity[RS_OPERATOR_RISK_PTRS_SCORE_FIELD] === '')
            ? true
            : false,
      };
      checkingCategory &&
        !(item.weightedRsScore == 0) &&
        setShownEntity(shownEntity => ({ ...shownEntity, ...checkingForRSSubScores }));
    }

    const newEntity: any = { ...editEntity };
    newEntity[name] = type === 'number' ? toDecimal(value) : value;
    if (name === FT_PTRS_SCORE_FIELD) {
      newEntity[FT_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[FT_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (name === FS_PTRS_SCORE_FIELD) {
      newEntity[FS_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[FS_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (name === RS_ENSA_PTRS_SCORE_FIELD || name === RS_ENSA_PTRS_SCORE_REMARK_FIELD) {
      newEntity[RS_ENSA_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_ENSA_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (
      name === RS_DIETARY_SAFETY_PTRS_SCORE_FIELD ||
      name === RS_DIETARY_SAFETY_PTRS_SCORE_REMARK_FIELD
    ) {
      newEntity[RS_DIETARY_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_DIETARY_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (
      name === RS_OPERATOR_RISK_PTRS_SCORE_FIELD ||
      name === RS_OPERATOR_RISK_PTRS_SCORE_REMARK_FIELD
    ) {
      newEntity[RS_OPERATOR_PTRS_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_OPERATOR_PTRS_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (
      name === RS_REGULATORY_AFFAIRS_SCORE_FIELD ||
      name === RS_REGULATORY_AFFAIRS_SCORE_REMARK_FIELD
    ) {
      newEntity[RS_REG_AFFAIR_SCORE_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_REG_AFFAIR_SCORE_MODIFIED_DATE_FIELD] = lastDateModified;
    } else if (name === RS_PTRS_SCORE_REMARK_FIELD || RS_RECOMMENDATION_FIELD) {
      newEntity[RS_PTRS_SCORE_REMARK_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_PTRS_SCORE_REMARK_MODIFIED_DATE_FIELD] = lastDateModified;
      newEntity[RS_RECOMMENDATION_MODIFIED_BY_FIELD] = userRolesStr;
      newEntity[RS_RECOMMENDATION_MODIFIED_DATE_FIELD] = lastDateModified;
    }

    newEntity.byUser = checkingCategory ? 'true' : '';

    setEntity(newEntity);
  };

  const handleSubmit = () => {
    dispatch.MasterList.updateProject({ entity: editEntity, id });
  };

  const isSaveAble = isValidate && !_.isEqual({ ...item, ...editEntity }, item);
  return {
    id,
    hasAuditLog,
    handleSubmit,
    shownEntity,
    handleChange,
    validatorListener,
    editableFields,
    isSaveAble,
    checkingCategory,
  };
};
