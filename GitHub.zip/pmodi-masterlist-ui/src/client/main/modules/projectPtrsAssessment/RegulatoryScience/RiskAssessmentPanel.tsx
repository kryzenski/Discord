import React, { Fragment } from 'react';
import { ValidatorForm } from 'react-material-ui-form-validator';
import { NumberTextField } from '@shared/components/TextField/NumberTextField';
import Button from '@material-ui/core/Button';
import { useProjectPtrsStyle } from '@main/modules/projectPtrsAssessment/UseProjectPtrsStyle';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';
import FormControl from '@material-ui/core/FormControl';
import { Message } from '@shared/utils/message';
import _ from 'lodash';
import { TextArea } from '@shared/components/TextField/TextArea';
import { createTextField } from '@main/modules/matserListUtil';
import {
  RS_REGULATORY_AFFAIRS_SCORE_FIELD,
  RiskAssessmentFields,
} from '@main/constants/projectOptions';
import { useRiskAssessmentData } from './UseRiskAssessmentData';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import clsx from 'clsx';
import { AuditLog } from '@main/components/AuditLog/AuditLog';
import { InputLabel, Select, MenuItem } from '@material-ui/core';

type RiskAssessmentPanel = {
  item: any;
  editableFields: Array<string>;
  setMessage: any;
};
type FormRowProps = {
  id?: string;
  item?: any;
  hasAuditLog?: boolean;
  shownEntity: any;
  editableFields: Array<string>;
  propertyLabel?: string;
  handleChange: (event: object) => void;
  riskKey?: string;
  validatorListener?: (validatorListener: boolean) => void;
  rationaleKey?: string;
  propertyKey?: string;
};

const getGridItem = (
  id,
  item,
  hasAuditLog,
  handleChange,
  validatorListener,
  editableFields,
  shownEntity,
) => {
  const classes = useProjectPtrsStyle();
  return _.map(RiskAssessmentFields, field => (
    <Grid container item xs={10} spacing={1} key={field.rationale + 'Grid'}>
      {isNotEmptyValue(field.risk) ? (
        <FormRow
          id={id}
          hasAuditLog={hasAuditLog}
          propertyLabel={Message.ptrs[field.risk]}
          rationaleKey={field.rationale}
          riskKey={field.risk}
          shownEntity={shownEntity}
          handleChange={handleChange}
          validatorListener={validatorListener}
          editableFields={editableFields}
        />
      ) : (
        <FormLastRow
          id={id}
          item={item}
          key={field.rationale}
          hasAuditLog={hasAuditLog}
          propertyLabel={Message.ptrs[field.rationale]}
          propertyKey={field.rationale}
          shownEntity={shownEntity}
          handleChange={handleChange}
          editableFields={editableFields}
        />
      )}
      {field.risk === RS_REGULATORY_AFFAIRS_SCORE_FIELD && <Divider className={classes.divider} />}
    </Grid>
  ));
};

const FormRow = ({
  id,
  hasAuditLog,
  propertyLabel,
  rationaleKey,
  riskKey,
  handleChange,
  validatorListener,
  editableFields,
  shownEntity,
}: FormRowProps) => {
  const classes = useProjectPtrsStyle();
  const riskValue = shownEntity[riskKey] || '';
  return (
    <Fragment>
      <Grid item xs={2}>
        <div key={rationaleKey + 'propertyLabel'} className={classes.propertyLabel}>
          {propertyLabel}
        </div>
      </Grid>
      <Grid item xs={8}>
        {createTextField({
          fieldName: rationaleKey,
          entity: shownEntity,
          rows: '3',
          textFiledClass: classes.textRationaleField,
          isDisabled: !_.includes(editableFields, rationaleKey),
          handleChange,
        })}
      </Grid>
      <Grid item xs={2}>
        <div className={classes.textFieldWithAuditLog} key={riskKey + 'div'}>
          <NumberTextField
            handleChange={handleChange}
            value={riskValue}
            isDisabled={!_.includes(editableFields, riskKey)}
            name={riskKey}
            customerClass={classes.textRiskField}
            validatorListener={validatorListener}
            isFormValidator={true}
            key={riskKey + 'NumberTextField'}
          />
          {hasAuditLog && (
            <AuditLog
              paths={['projects']}
              id={id}
              customClass={classes.numberTextField}
              fieldName={riskKey}
            />
          )}
        </div>
      </Grid>
    </Fragment>
  );
};

const FormLastRow = ({
  id,
  item,
  hasAuditLog,
  propertyLabel,
  propertyKey,
  shownEntity,
  handleChange,
  editableFields,
}: FormRowProps) => {
  const classes = useProjectPtrsStyle();
  const rationaleValue = shownEntity[propertyKey] || '';
  const rsRecommendation = 'scienceRecommendation';
  const visiblity =
    item['newportCategory'] !== 'Country Extension' && item['newportCategory'] !== 'Label Expansion'
      ? true
      : false;
  const formulationDevelopmentForFD = item['newportCategory'] === 'Formulation Development';

  const formulationDevelopmentForFT =
    item['newportCategory'] === 'New Active Substance Developments' ||
    item['newportCategory'] === 'Third Party';
  const [selectValue, setSelectValue] = React.useState(
    shownEntity['shownScienceRecommendation'] || '',
  );
  return (
    <Fragment>
      {visiblity &&
        (formulationDevelopmentForFD ? (
          <Fragment>
            <Grid item xs={2} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <InputLabel className={classes.labelTextRS} id="demo-simple-select-label">
                  RS Recommendation
                </InputLabel>
              </FormControl>
            </Grid>
            <Grid item xs={12} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <Select
                  className={classes.customDropDownListRS}
                  labelId="demo-simple-select-label"
                  id="scienceRecommendation"
                  name="scienceRecommendation"
                  value={selectValue}
                  label="Age"
                  onChange={val => {
                    setSelectValue(val.target.value);
                    handleChange(val);
                  }}
                >
                  <MenuItem value={'Registration Submitted'}>Registration Submitted</MenuItem>
                  <MenuItem value={'Registration Partially Submitted'}>
                    Registration Partially Submitted
                  </MenuItem>
                  <MenuItem value={'Registration Approved'}>Registration Approved</MenuItem>
                  <MenuItem value={'Registration Partially Approved'}>
                    Registration Partially Approved
                  </MenuItem>
                  <MenuItem value={'Continue Project'}>Continue Project</MenuItem>
                  <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                  <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                  <MenuItem value={'Other (see RS Rationale)'}>Other (see RS Rationale)</MenuItem>
                </Select>
              </FormControl>
              {hasAuditLog && (
                <AuditLog
                  id={id}
                  paths={['projects']}
                  customClass={classes.textAuditLog}
                  fieldName={rsRecommendation}
                />
              )}
            </Grid>
            <br />
            <br />
          </Fragment>
        ) : formulationDevelopmentForFT ? (
          <Fragment>
            <Grid item xs={2} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <InputLabel className={classes.labelTextRS} id="demo-simple-select-label">
                  RS Recommendation
                </InputLabel>
              </FormControl>
            </Grid>
            <Grid item xs={12} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <Select
                  className={classes.customDropDownListRS}
                  labelId="demo-simple-select-label"
                  id="scienceRecommendation"
                  name="scienceRecommendation"
                  value={selectValue}
                  label="Age"
                  onChange={val => {
                    setSelectValue(val.target.value);
                    handleChange(val);
                  }}
                >
                  <MenuItem value={'Continue Project'}>Continue Project</MenuItem>
                  <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                  <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                  <MenuItem value={'Other (see RS Rationale)'}>Other (see RS Rationale)</MenuItem>
                </Select>
              </FormControl>
              {hasAuditLog && (
                <AuditLog
                  id={id}
                  paths={['projects']}
                  customClass={classes.textAuditLog}
                  fieldName={rsRecommendation}
                />
              )}
            </Grid>
            <br />
            <br />
          </Fragment>
        ) : (
          <Fragment>
            <Grid item xs={2} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <InputLabel className={classes.labelTextRS} id="demo-simple-select-label">
                  RS Recommendation
                </InputLabel>
              </FormControl>
            </Grid>
            <Grid item xs={12} style={{ display: 'flex' }}>
              <FormControl fullWidth>
                <Select
                  className={classes.customDropDownListRS}
                  labelId="demo-simple-select-label"
                  id="scienceRecommendation"
                  name="scienceRecommendation"
                  value={selectValue}
                  label="Age"
                  onChange={val => {
                    setSelectValue(val.target.value);
                    handleChange(val);
                  }}
                >
                  <MenuItem value={'Continue POC'}>Continue POC</MenuItem>
                  <MenuItem value={'Promote to Formulation Development'}>
                    Promote to Formulation Development
                  </MenuItem>
                  <MenuItem value={'Discontinue Project'}>Discontinue Project</MenuItem>
                  <MenuItem value={'Place on hold'}>Place on hold</MenuItem>
                  <MenuItem value={'Other (see RS Rationale)'}>Other (see RS Rationale)</MenuItem>
                </Select>
              </FormControl>
              {hasAuditLog && (
                <AuditLog
                  id={id}
                  paths={['projects']}
                  customClass={classes.textAuditLog}
                  fieldName={rsRecommendation}
                />
              )}
            </Grid>
            <br />
            <br />
          </Fragment>
        ))}
      <Grid item xs={2}>
        <div className={classes.propertyLabel}>{propertyLabel}</div>
      </Grid>
      <Grid item xs={10}>
        <TextArea
          customerClass={classes.multiLine}
          textFiledClass={classes.textArea}
          value={rationaleValue}
          name={propertyKey}
          handleChange={handleChange}
          isDisabled={!_.includes(editableFields, propertyKey)}
          textWithLog={true}
          lableWithLog={false}
          auditLog={
            hasAuditLog && (
              <AuditLog
                id={id}
                paths={['projects']}
                customClass={classes.textAreaLog}
                fieldName={propertyKey}
              />
            )
          }
        />
      </Grid>
    </Fragment>
  );
};

export const RiskAssessmentPanel = (props: RiskAssessmentPanel): JSX.Element => {
  const classes = useProjectPtrsStyle();
  const {
    id,
    hasAuditLog,
    handleSubmit,
    shownEntity,
    handleChange,
    validatorListener,
    editableFields,
    isSaveAble,
    checkingCategory,
  } = useRiskAssessmentData(props);
  const { item } = props;
  props.setMessage(checkingCategory && shownEntity.isNull);
  return (
    <Fragment>
      <FormControl>
        <ValidatorForm onSubmit={handleSubmit} style={{ marginLeft: '5%' }}>
          <div className={clsx(classes.propertyLabel, classes.rationaleLabel)}>
            {Message.ptrs.rationale}
          </div>
          <div className={clsx(classes.propertyLabel, classes.riskLabel)}>{Message.ptrs.risk}</div>
          <Grid container spacing={1}>
            {getGridItem(
              id,
              item,
              hasAuditLog,
              handleChange,
              validatorListener,
              editableFields,
              shownEntity,
            )}
            <Grid container item xs={11} spacing={1}>
              <Button
                type="submit"
                className={classes.button}
                variant="outlined"
                disabled={!isSaveAble}
              >
                {Message.button.save}
              </Button>
            </Grid>
          </Grid>
        </ValidatorForm>
      </FormControl>
    </Fragment>
  );
};
