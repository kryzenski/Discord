import React from 'react';
import { cellStyle } from '../../constants/constants';
import { toInteger } from '@shared/utils/numberUtils';
import { Tooltip } from '@material-ui/core';
import { useSegmentPtrsStyle } from './UseSegmentPtrsStyle';

export const getSegmentColumn = props => {
  const classes = useSegmentPtrsStyle();
  const { columnVisiblity, pannelType, regionRoleSuffix } = props;

  const column = [
    {
      title: 'Country',
      field: 'countryName',
      width: '5%',
    },
    {
      title: 'Crop',
      field: 'cropName',
      width: '5%',
    },
    {
      title: 'Target',
      field: 'target',
      width: '5%',
    },
    {
      title: 'Region',
      field: 'regionName',
      width: '5%',
    },
    {
      title: 'Product Score',
      field: 'rsRegProductPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegProductPtrsScore ? false : true,
      render: rowdata => (
        <div>
          {rowdata.rsRegProductPtrsScore !== null && rowdata.rsRegProductPtrsScore > 0
            ? toInteger(rowdata.rsRegProductPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Product Rationale',
      field: 'rsRegProductPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegProductPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsRegProductPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsRegProductPtrsScoreRmk !== null && rowdata.rsRegProductPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Occupational Residential Exposure Score',
      field: 'rsOccupationalResidentialExposurePtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' &&
        columnVisiblity.rsOccupationalResidentialExposurePtrsScore
          ? false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsOccupationalResidentialExposurePtrsScore !== null &&
          rowdata.rsOccupationalResidentialExposurePtrsScore > 0
            ? toInteger(rowdata.rsOccupationalResidentialExposurePtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Occupational Residential Exposure Rationale',
      field: 'rsOccupationalResidentialExposurePtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' &&
        columnVisiblity.rsOccupationalResidentialExposurePtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={
            <span className={classes.toolTip}>
              {rowdata.rsOccupationalResidentialExposurePtrsScoreRmk}
            </span>
          }
        >
          <div>
            {rowdata.rsOccupationalResidentialExposurePtrsScoreRmk !== null &&
            rowdata.rsOccupationalResidentialExposurePtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Dietary Score',
      field: 'rsRegDietaryPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegDietaryPtrsScore ? false : true,
      render: rowdata => (
        <div>
          {rowdata.rsRegDietaryPtrsScore !== null && rowdata.rsRegDietaryPtrsScore > 0
            ? toInteger(rowdata.rsRegDietaryPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Dietary Rationale',
      field: 'rsRegDietaryPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegDietaryPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsRegDietaryPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsRegDietaryPtrsScoreRmk !== null && rowdata.rsRegDietaryPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Toxicology Score',
      field: 'rsToxicologyPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsToxicologyPtrsScore ? false : true,
      render: rowdata => (
        <div>
          {rowdata.rsToxicologyPtrsScore !== null && rowdata.rsToxicologyPtrsScore > 0
            ? toInteger(rowdata.rsToxicologyPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Toxicology Rationale',
      field: 'rsToxicologyPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsToxicologyPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsToxicologyPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsToxicologyPtrsScoreRmk !== null && rowdata.rsToxicologyPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Ecotox Score',
      field: 'rsEcotoxPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsEcotoxPtrsScore ? false : true,
      render: rowdata => (
        <div>
          {rowdata.rsEcotoxPtrsScore !== null && rowdata.rsEcotoxPtrsScore > 0
            ? toInteger(rowdata.rsEcotoxPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Ecotox Rationale',
      field: 'rsEcotoxPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsEcotoxPtrsScoreRmk ? false : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsEcotoxPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsEcotoxPtrsScoreRmk !== null && rowdata.rsEcotoxPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Effate Score',
      field: 'rsEfatePtrsScore',
      width: '3%',
      hidden: pannelType === 'regulatoryScience' && columnVisiblity.rsEfatePtrsScore ? false : true,
      render: rowdata => (
        <div>
          {rowdata.rsEfatePtrsScore !== null && rowdata.rsEfatePtrsScore > 0
            ? toInteger(rowdata.rsEfatePtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Effate Rationale',
      field: 'rsEfatePtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsEfatePtrsScoreRmk ? false : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsEfatePtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsEfatePtrsScoreRmk !== null && rowdata.rsEfatePtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Local Restriction_Policy Score',
      field: 'rsLocalRestrictionPolicyPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsLocalRestrictionPolicyPtrsScore
          ? false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsLocalRestrictionPolicyPtrsScore !== null &&
          rowdata.rsLocalRestrictionPolicyPtrsScore > 0
            ? toInteger(rowdata.rsLocalRestrictionPolicyPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Local Restriction_Policy Rationale',
      field: 'rsLocalRestrictionOthersPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsLocalRestrictionOthersPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={
            <span className={classes.toolTip}>{rowdata.rsLocalRestrictionOthersPtrsScoreRmk}</span>
          }
        >
          <div>
            {rowdata.rsLocalRestrictionOthersPtrsScoreRmk !== null &&
            rowdata.rsLocalRestrictionOthersPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Local Restriction_Others Score',
      field: 'rsLocalRestrictionOthersPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsLocalRestrictionOthersPtrsScore
          ? false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsLocalRestrictionOthersPtrsScore !== null &&
          rowdata.rsLocalRestrictionOthersPtrsScore > 0
            ? toInteger(rowdata.rsLocalRestrictionOthersPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Local Restriction_Policy Rationale',
      field: 'rsLocalRestrictionOthersPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsLocalRestrictionOthersPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={
            <span className={classes.toolTip}>{rowdata.rsLocalRestrictionOthersPtrsScoreRmk}</span>
          }
        >
          <div>
            {rowdata.rsLocalRestrictionOthersPtrsScoreRmk !== null &&
            rowdata.rsLocalRestrictionOthersPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Foreign Influence Score',
      field: 'rsForeignInfluencePtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsForeignInfluencePtrsScore
          ? false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsLocalRestrictionOthersPtrsScore !== null &&
          rowdata.rsLocalRestrictionOthersPtrsScore > 0
            ? toInteger(rowdata.rsForeignInfluencePtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Foreign Influence Rationale',
      field: 'rsForeignInfluencePtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsForeignInfluencePtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsForeignInfluencePtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsForeignInfluencePtrsScoreRmk !== null &&
            rowdata.rsForeignInfluencePtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Registration Score',
      field: 'rsRegistrationPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegistrationPtrsScore
          ? false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsRegistrationPtrsScore !== null && rowdata.rsRegistrationPtrsScore > 0
            ? toInteger(rowdata.rsRegistrationPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'Registration Rationale',
      field: 'rsRegistrationPtrsScoreRmk',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && columnVisiblity.rsRegistrationPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsRegistrationPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsRegistrationPtrsScoreRmk !== null &&
            rowdata.rsRegistrationPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'FS Score',
      field: 'fsPtrsScore',
      width: '3%',
      hidden: pannelType === 'fieldSolution' ? false : true,
      render: rowdata => (
        <div>
          {rowdata.fsPtrsScore !== null && rowdata.fsPtrsScore > 0
            ? toInteger(rowdata.fsPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: 'FS Rationale',
      field: 'fsPtrsScoreRmk',
      width: '3%',
      hidden: pannelType === 'fieldSolution' ? false : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.fsPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.fsPtrsScoreRmk !== null && rowdata.fsPtrsScoreRmk !== '' ? 'Available' : ''}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'RS Score',
      field: 'rsRegPtrsScore',
      width: '3%',
      hidden:
        pannelType === 'regulatoryScience' && regionRoleSuffix !== 'NA'
          ? //regionRoleSuffix !== 'APAC'
            false
          : true,
      render: rowdata => (
        <div>
          {rowdata.rsRegPtrsScore !== null && rowdata.rsRegPtrsScore > 0
            ? toInteger(rowdata.rsRegPtrsScore)
            : ''}
        </div>
      ),
    },
    {
      title: columnVisiblity.rsRegPtrsScoreRmk ? 'Overall RS Rationale' : 'RS Rationale',
      field: 'rsRegPtrsScoreRmk',
      width: '3%',
      hidden:
        (pannelType === 'regulatoryScience' && regionRoleSuffix !== 'NA') ||
        // && regionRoleSuffix !== 'APAC') ||
        columnVisiblity.rsRegPtrsScoreRmk
          ? false
          : true,
      render: rowdata => (
        <Tooltip
          placement="top-end"
          title={<span className={classes.toolTip}>{rowdata.rsRegPtrsScoreRmk}</span>}
        >
          <div>
            {rowdata.rsRegPtrsScoreRmk !== null && rowdata.rsRegPtrsScoreRmk !== ''
              ? 'Available'
              : ''}
          </div>
        </Tooltip>
      ),
    },
  ];

  return column.map(column => ({
    ...column,
    cellStyle,
  }));
};
