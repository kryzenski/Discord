import _ from 'lodash';
import { useEffect, useState } from 'react';
import { getSegmentsByProjectId, updateSegment } from '../../serviceData/project/projects';
import {
  FS_PTRS_SCORE_UPDATED_BY_FIELD,
  RS_DIETARY_PTRS_SCORE,
  RS_DIETARY_PTRS_SCORE_MODIFIED_BY,
  RS_DIETARY_PTRS_SCORE_MODIFIED_DATE,
  RS_DIETARY_REMARK_FIELD,
  RS_ECOTOX_PTRS_SCORE,
  RS_ECOTOX_PTRS_SCORE_MODIFIED_BY,
  RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE,
  RS_ECOTOX_REMARK_FIELD,
  RS_EFATE_PTRS_SCORE,
  RS_EFATE_PTRS_SCORE_MODIFIED_BY,
  RS_EFATE_PTRS_SCORE_MODIFIED_DATE,
  RS_EFATE_REMARK_FIELD,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY,
  RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE,
  RS_FOREIGN_INFLUENZE_REMARK_FIELD,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY,
  RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE,
  RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY,
  RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE,
  RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE,
  RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD,
  RS_PRODUCT_PTRS_SCORE,
  RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD,
  RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE,
  RS_PRODUCT_REMARK_FEILD,
  RS_PTRS_SCORE_UPDATED_BY_FIELD,
  RS_PTRS_SCORE_UPDATED_DATE_FIELD,
  RS_REGISTRATION_PTRS_SCORE,
  RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY,
  RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE,
  RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
  RS_TOXICOLOGY_PTRS_SCORE,
  RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY,
  RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE,
  RS_TOXICOLOGY_REMARK_FIELD,
  SegmentSubScoresForAPAC,
  SegmentSubScoresForNA,
} from '../../constants/segmentOptions';
import { getSegmentColumn } from './useColumnSegment';
import { ItemRenderOptions } from './ApplySegmentsDialog';

const ACTION_ASYNC_GET_SEGMENTS = 'ACTION_ASYNC_GET_SEGMENTS';
const ACTION_OPEN_SCORES_DIALOG = 'ACTION_OPEN_SCORES_DIALOG';
const ACTION_CLOSE_SCORES_DIALOG = 'ACTION_CLOSE_SCORES_DIALOG';
const ACTION_SCORES_AND_RATIONALE_SELECTION = 'ACTION_SCORES_AND_RATIONALE_SELECTION';
const ACTION_SEGMENT_SELECTION_PAGE_FOR_SUBSCORE = 'ACTION_SEGMENT_SELECTION_PAGE_FOR_SUBSCORE';
const ACTION_CLOSE_SEGMENT_SELECTION = 'ACTION_CLOSE_SEGMENT_SELECTION';
const ACTION_TO_PREVIOUS_STATE = 'ACTION_TO_PREVIOUS_STATE';

export const reducerForCustomCopy = (state, action) => {
  switch (action.type) {
    case ACTION_ASYNC_GET_SEGMENTS: {
      const { segments, currentSegment } = action.payload;
      const values = _.map(segments, seg => {
        return {
          ...seg,
          isChecked: false,
        };
      });

      const filteredSegments = _.filter(values, seg => {
        if (
          seg.id != currentSegment.id &&
          seg.region.roleSuffix === currentSegment.region.roleSuffix
        ) {
          return seg;
        }
      });

      return {
        ...state,
        values: filteredSegments,
        filteredSegments,
      };
    }
    case ACTION_SCORES_AND_RATIONALE_SELECTION: {
      const { option, currentSegment } = action.payload;
      const { pannelType, isCheckedOptions, modifiedBy, modifiedDate } = option;
      const { isPtrsScoreChecked, isPtrsRmkChecked } = isCheckedOptions;

      if (pannelType === 'fieldSolution') {
        const rationaleAndScore = {};
        isPtrsScoreChecked &&
          Object.assign(rationaleAndScore, {
            ['fsPtrsScore']: _.get(currentSegment, 'fsPtrsScore'),
          });
        isPtrsRmkChecked &&
          Object.assign(rationaleAndScore, {
            ['fsPtrsScoreRmk']: _.get(currentSegment, 'fsPtrsScoreRmk'),
          });
        rationaleAndScore[RS_PTRS_SCORE_UPDATED_BY_FIELD] = modifiedBy;
        rationaleAndScore[RS_PTRS_SCORE_UPDATED_DATE_FIELD] = modifiedDate;
        return {
          ...state,
          rationaleAndScore,
          isSegmentSelection: true,
        };
      } else if (pannelType === 'regulatoryScience') {
        const rationaleAndScore = {};
        isPtrsScoreChecked &&
          Object.assign(rationaleAndScore, {
            ['rsRegPtrsScore']: _.get(currentSegment, 'rsRegPtrsScore'),
          });
        isPtrsRmkChecked &&
          Object.assign(rationaleAndScore, {
            ['rsRegPtrsScoreRmk']: _.get(currentSegment, 'rsRegPtrsScoreRmk'),
          });
        rationaleAndScore[FS_PTRS_SCORE_UPDATED_BY_FIELD] = modifiedBy;
        rationaleAndScore[FS_PTRS_SCORE_UPDATED_BY_FIELD] = modifiedDate;
        return {
          ...state,
          rationaleAndScore,
          isSegmentSelection: true,
        };
      }
      return state;
    }
    case ACTION_SEGMENT_SELECTION_PAGE_FOR_SUBSCORE: {
      return {
        ...state,
        isSegmentSelectionPageForSubscores: true,
      };
    }

    case ACTION_TO_PREVIOUS_STATE: {
      const { segments } = action.payload;
      return {
        ...state,
        values: segments,
        isSegmentSelectionPageForSubscores: false,
        isSegmentSelection: false,
      };
    }

    case ACTION_OPEN_SCORES_DIALOG: {
      return {
        ...state,
        isScoresDialogOpen: true,
        pannelType: action.pannelType,
      };
    }

    case ACTION_CLOSE_SCORES_DIALOG: {
      return {
        ...state,
        values: state.filteredSegments,
        isScoresDialogOpen: false,
        isSegmentSelectionPageForSubscores: false,
        isSegmentSelection: false,
        isSegmentCountPage: false,
      };
    }
    case ACTION_CLOSE_SEGMENT_SELECTION: {
      const { count } = action.payload;
      const successMessageOfUpdate =
        state.pannelType === 'fieldSolution'
          ? `FS PTRS details successfully updated to ${count} segments`
          : `RS PTRS details successfully got updated to ${count} segments`;

      return {
        ...state,
        isSegmentSelectionPageForSubscores: false,
        isSegmentSelection: false,
        isSegmentCountPage: true,
        countOfSegment: count,
        successMessageOfUpdate,
      };
    }
    default: {
      return state;
    }
  }
};

export const applyToSpecificSegment = (
  coustomizeState,
  dispatchCoustom,
  detailsOption,
  currentSegment,
) => {
  const {
    isScoresDialogOpen,
    currentSegmentForCustomCopy,
    pannelType,
    isSegmentSelectionPageForSubscores,
    rationaleAndScore,
    isSegmentSelection,
    countOfSegment,
    isSegmentCountPage,
    successMessageOfUpdate,
  } = coustomizeState;
  const subscoresOption: Array<any> = [
    {
      fieldScore: 'rsOccupationalResidentialExposurePtrsScore',
      fieldRmk: 'rsOccupationalResidentialExposurePtrsScoreRmk',
      title: 'Occupational Residential Exposure',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsOccupationalResidentialExposurePtrsScore: _.get(
        currentSegmentForCustomCopy,
        'rsOccupationalResidentialExposurePtrsScore',
      ),
      rsOccupationalResidentialExposurePtrsScoreRmk: _.get(
        currentSegmentForCustomCopy,
        'rsOccupationalResidentialExposurePtrsScoreRmk',
      ),
    },
    {
      fieldScore: 'rsRegDietaryPtrsScore',
      fieldRmk: 'rsRegDietaryPtrsScoreRmk',
      title: 'Dietary',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsRegDietaryPtrsScore: _.get(currentSegmentForCustomCopy, 'rsRegDietaryPtrsScore'),
      rsRegDietaryPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsRegDietaryPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsToxicologyPtrsScore',
      fieldRmk: 'rsToxicologyPtrsScoreRmk',
      title: 'Toxicology',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsToxicologyPtrsScore: _.get(currentSegmentForCustomCopy, 'rsToxicologyPtrsScore'),
      rsToxicologyPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsToxicologyPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsEcotoxPtrsScore',
      fieldRmk: 'rsEcotoxPtrsScoreRmk',
      title: 'Ecotox',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEcotoxPtrsScore: _.get(currentSegmentForCustomCopy, 'rsEcotoxPtrsScore'),
      rsEcotoxPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsEcotoxPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsEfatePtrsScore',
      fieldRmk: 'rsEfatePtrsScoreRmk',
      title: 'Effate',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEfatePtrsScore: _.get(currentSegmentForCustomCopy, 'rsEfatePtrsScore'),
      rsEfatePtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsEfatePtrsScoreRmk'),
    },
    {
      fieldScore: 'rsRegistrationPtrsScore',
      fieldRmk: 'rsRegistrationPtrsScoreRmk',
      title: 'Registration',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsRegistrationPtrsScore: _.get(currentSegmentForCustomCopy, 'rsRegistrationPtrsScore'),
      rsRegistrationPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsRegistrationPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsRegPtrsScore',
      fieldRmk: 'rsRegPtrsScoreRmk',
      title: 'Overall RS Rationale',
      isRmkChecked: false,
      rsRegPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsRegPtrsScoreRmk'),
    },
  ];

  const subscoresOptionAPAC: Array<any> = [
    {
      fieldScore: 'rsRegProductPtrsScore',
      fieldRmk: 'rsRegProductPtrsScoreRmk',
      title: 'Product',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsRegProductPtrsScore: _.get(currentSegmentForCustomCopy, 'rsRegProductPtrsScore'),
      rsOccupationalResidentialExposurePtrsScoreRmk: _.get(
        currentSegmentForCustomCopy,
        'rsRegProductPtrsScoreRmk',
      ),
    },
    {
      fieldScore: 'rsOccupationalResidentialExposurePtrsScore',
      fieldRmk: 'rsOccupationalResidentialExposurePtrsScoreRmk',
      title: 'Occupational Residential Exposure',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsOccupationalResidentialExposurePtrsScore: _.get(
        currentSegmentForCustomCopy,
        'rsOccupationalResidentialExposurePtrsScore',
      ),
      rsOccupationalResidentialExposurePtrsScoreRmk: _.get(
        currentSegmentForCustomCopy,
        'rsOccupationalResidentialExposurePtrsScoreRmk',
      ),
    },
    {
      fieldScore: 'rsRegDietaryPtrsScore',
      fieldRmk: 'rsRegDietaryPtrsScoreRmk',
      title: 'Dietary',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsRegDietaryPtrsScore: _.get(currentSegmentForCustomCopy, 'rsRegDietaryPtrsScore'),
      rsRegDietaryPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsRegDietaryPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsToxicologyPtrsScore',
      fieldRmk: 'rsToxicologyPtrsScoreRmk',
      title: 'Toxicology',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsToxicologyPtrsScore: _.get(currentSegmentForCustomCopy, 'rsToxicologyPtrsScore'),
      rsToxicologyPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsToxicologyPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsEcotoxPtrsScore',
      fieldRmk: 'rsEcotoxPtrsScoreRmk',
      title: 'Ecotox',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEcotoxPtrsScore: _.get(currentSegmentForCustomCopy, 'rsEcotoxPtrsScore'),
      rsEcotoxPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsEcotoxPtrsScoreRmk'),
    },
    {
      fieldScore: 'rsEfatePtrsScore',
      fieldRmk: 'rsEfatePtrsScoreRmk',
      title: 'Effate',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEfatePtrsScore: _.get(currentSegmentForCustomCopy, 'rsEfatePtrsScore'),
      rsEfatePtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsEfatePtrsScoreRmk'),
    },
    {
      fieldScore: 'rsLocalRestrictionPolicyPtrsScore',
      fieldRmk: 'rsLocalRestrictionPolicyPtrsScoreRmk',
      title: 'Local Restriction_Policy',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEfatePtrsScore: _.get(currentSegmentForCustomCopy, 'rsLocalRestrictionPolicyPtrsScore'),
      rsEfatePtrsScoreRmk: _.get(
        currentSegmentForCustomCopy,
        'rsLocalRestrictionPolicyPtrsScoreRmk',
      ),
    },
    {
      fieldScore: 'rsLocalRestrictionOthersPtrsScore',
      fieldRmk: 'rsLocalRestrictionOthersPtrsScoreRmk',
      title: 'Local Restriction_Others',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEfatePtrsScore: _.get(currentSegmentForCustomCopy, 'rsLocalRestrictionOthersPtrsScore'),
      rsEfatePtrsScoreRmk: _.get(
        currentSegmentForCustomCopy,
        'rsLocalRestrictionOthersPtrsScoreRmk',
      ),
    },
    {
      fieldScore: 'rsForeignInfluencePtrsScore',
      fieldRmk: 'rsForeignInfluencePtrsScoreRmk',
      title: 'Foreign Influence',
      isPtrsChecked: false,
      isRmkChecked: false,
      rsEfatePtrsScore: _.get(currentSegmentForCustomCopy, 'rsForeignInfluencePtrsScore'),
      rsEfatePtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsForeignInfluencePtrsScoreRmk'),
    },
    {
      fieldScore: 'rsRegPtrsScore',
      fieldRmk: 'rsRegPtrsScoreRmk',
      title: 'Overall RS Rationale',
      isRmkChecked: false,
      rsRegPtrsScoreRmk: _.get(currentSegmentForCustomCopy, 'rsRegPtrsScoreRmk'),
    },
  ];

  const [subScoresObject, setSubScoresObject] = useState({});
  const [listOfSubScoresForNA, setlistOfSubScoresForNA] = useState(subscoresOption);
  const [listOfSubScoresForAPAC, setListOfSubScoresForAPAC] = useState(subscoresOptionAPAC);
  const values = _.get(coustomizeState, 'values');
  const [segmentsList, setSegmentsList] = useState(values);
  const regionRoleSuffix = _.get(currentSegment, 'region.roleSuffix');
  const subScoresFieldNames =
    regionRoleSuffix === 'NA'
      ? SegmentSubScoresForNA
      : regionRoleSuffix === 'APAC'
      ? SegmentSubScoresForAPAC
      : [];

  const projectId = _.get(detailsOption, 'projectId');
  useEffect(() => {
    if (projectId) {
      const fetchSegmentsByProjectId = async () => {
        const segments = await getSegmentsByProjectId(projectId);
        dispatchCoustom({
          type: ACTION_ASYNC_GET_SEGMENTS,
          payload: { segments, currentSegment },
        });
      };
      fetchSegmentsByProjectId();
    }
  }, [projectId, successMessageOfUpdate]);

  const currentfsPtrsScore = _.get(currentSegment, 'fsPtrsScore');
  const currentfsPtrsScoreRmk = _.get(currentSegment, 'fsPtrsScoreRmk');
  const currentrsRegPtrsScore = _.get(currentSegment, 'rsRegPtrsScore');
  const currentrsRegPtrsScoreRmk = _.get(currentSegment, 'rsRegPtrsScoreRmk');

  const isDisableFSButton =
    (currentfsPtrsScore !== null && currentfsPtrsScore > 0) ||
    (currentfsPtrsScoreRmk !== null && currentfsPtrsScoreRmk !== '');

  const isDisableRSNonSubscores =
    (currentrsRegPtrsScore !== null && currentrsRegPtrsScore > 0) ||
    (currentrsRegPtrsScoreRmk !== null && currentrsRegPtrsScoreRmk !== '');

  let isDisableOfRSSubscore;
  _.forEach(subScoresFieldNames, item => {
    const ptrsScore = _.get(currentSegment, item.risk);
    const ptrsRmk = _.get(currentSegment, item.rationale);
    const overAllScoreRationale = _.get(currentSegment, 'rsRegPtrsScoreRmk');
    if ((ptrsScore !== null && ptrsScore > 0) || (ptrsRmk !== null && ptrsRmk !== '')) {
      isDisableOfRSSubscore = true;
      return false;
    } else if (overAllScoreRationale !== null && overAllScoreRationale !== '') {
      isDisableOfRSSubscore = true;
      return false;
    }
  });

  const openScoresDialog = pannelType => {
    dispatchCoustom({ type: ACTION_OPEN_SCORES_DIALOG, pannelType });
  };

  const closeScoresDialog = () => {
    setlistOfSubScoresForNA(subscoresOption);
    setListOfSubScoresForAPAC(subscoresOptionAPAC);
    dispatchCoustom({ type: ACTION_CLOSE_SCORES_DIALOG });
  };

  //fs and rs ptrs and rationale selection
  const handleSubmitScoresRmk = option => {
    dispatchCoustom({
      type: ACTION_SCORES_AND_RATIONALE_SELECTION,
      payload: { option, currentSegment },
    });
    setSegmentsList(values);
  };

  //subscores selection
  const handleSubScoresChanges = (event, fieldName: any) => {
    const { name } = event.target;
    let tempSubScores = [...listOfSubScoresForNA];
    tempSubScores = _.map(tempSubScores, scores => {
      if (scores.fieldScore === name) {
        return {
          ...scores,
          isPtrsChecked:
            fieldName === 'isPtrsChecked' ? !scores.isPtrsChecked : scores.isPtrsChecked,
          isRmkChecked: fieldName === 'isRmkChecked' ? !scores.isRmkChecked : scores.isRmkChecked,
        };
      }
      return scores;
    });
    setlistOfSubScoresForNA(tempSubScores);
  };

  const handleSubScoresChangesOfAPAC = (event, fieldName: any) => {
    const { name } = event.target;
    let tempSubScores = [...listOfSubScoresForAPAC];
    tempSubScores = _.map(tempSubScores, scores => {
      if (scores.fieldScore === name) {
        return {
          ...scores,
          isPtrsChecked:
            fieldName === 'isPtrsChecked' ? !scores.isPtrsChecked : scores.isPtrsChecked,
          isRmkChecked: fieldName === 'isRmkChecked' ? !scores.isRmkChecked : scores.isRmkChecked,
        };
      }
      return scores;
    });
    setListOfSubScoresForAPAC(tempSubScores);
  };

  //to segment page
  const toSegmentSelectionSubscores = details => {
    const { lastDateModified, userRolesStr } = details;

    const listOfSubscores = [...listOfSubScoresForNA];
    //regionRoleSuffix === 'NA' ? [...listOfSubScoresForNA] : [...listOfSubScoresForAPAC];
    _.forEach(listOfSubscores, scores => {
      const fieldNameScore = scores.fieldScore;
      const fieldNameRationale = scores.fieldRmk;
      const ptrsScore = _.get(currentSegment, fieldNameScore);
      const rationale = _.get(currentSegment, fieldNameRationale);

      const obj = {};
      if (scores.isPtrsChecked) {
        Object.assign(obj, { [fieldNameScore]: ptrsScore });
      }
      if (scores.isRmkChecked) {
        Object.assign(obj, { [fieldNameRationale]: rationale });
      }

      setSubScoresObject(subScoresObject => ({
        ...subScoresObject,
        ...obj,
        lastDateModified,
        userRolesStr,
      }));
    });

    setSegmentsList(values);
    dispatchCoustom({
      type: ACTION_SEGMENT_SELECTION_PAGE_FOR_SUBSCORE,
      payload: { subScoresObject },
    });
  };

  //handle segment selection
  const handleSegmentSelection = rows => {
    const tempSegments = _.map(segmentsList, segment => {
      return {
        ...segment,
        isChecked: rows?.some(row => row.id == segment.id),
      };
    });
    setSegmentsList(tempSegments);
  };

  const upDatePtrsScoreAndRationale = () => {
    const updateValue = _.filter(segmentsList, segment => {
      return segment.isChecked === true;
    });
    const updatePaylod = _.map(updateValue, item => {
      return {
        id: item.id,
        version: item.version,
        ...rationaleAndScore,
      };
    });
    Promise.all(
      _.map(updatePaylod, async segment => {
        return await updateSegment(segment, _.get(segment, 'id'));
      }),
    ).then(() => {
      dispatchCoustom({
        type: ACTION_CLOSE_SEGMENT_SELECTION,
        payload: { count: updateValue.length },
      });
    });
  };

  //update subscores to segments
  const updateSubScores = () => {
    const modifiedByAndDate = {};
    for (const key in subScoresObject) {
      if (
        key === RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE ||
        key === RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_REMARK_FIELD
      ) {
        modifiedByAndDate[RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_BY] =
          subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_OCCUPATIONAL_RESIDENTIAL_EXPOSURE_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (key === RS_EFATE_PTRS_SCORE || key === RS_EFATE_REMARK_FIELD) {
        modifiedByAndDate[RS_EFATE_PTRS_SCORE_MODIFIED_BY] = subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_EFATE_PTRS_SCORE_MODIFIED_DATE] = subScoresObject['lastDateModified'];
      }
      if (key === RS_ECOTOX_PTRS_SCORE || key === RS_ECOTOX_REMARK_FIELD) {
        modifiedByAndDate[RS_ECOTOX_PTRS_SCORE_MODIFIED_BY] = subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_ECOTOX_PTRS_SCORE_MODIFIED_DATE] = subScoresObject['lastDateModified'];
      }
      if (key === RS_DIETARY_PTRS_SCORE || key === RS_DIETARY_REMARK_FIELD) {
        modifiedByAndDate[RS_DIETARY_PTRS_SCORE_MODIFIED_BY] = subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_DIETARY_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (key === RS_TOXICOLOGY_PTRS_SCORE || key === RS_TOXICOLOGY_REMARK_FIELD) {
        modifiedByAndDate[RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_BY] = subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_TOXICOLOGY_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (key === RS_REGISTRATION_PTRS_SCORE || key === RS_REGULATORY_PTRS_SCORE_REMARK_FIELD) {
        modifiedByAndDate[RS_REGISTRATION_PTRS_SCORE_MODIFIED_BY] = subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_REGISTRATION_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (key === RS_PRODUCT_PTRS_SCORE || key === RS_PRODUCT_REMARK_FEILD) {
        modifiedByAndDate[RS_PRODUCT_PTRS_SCORE_MODIFIED_BY_FIELD] =
          subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_PRODUCT_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (
        key === RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE ||
        key === RS_LOCAL_RESTRICTION_POLICY_REMARK_FIELD
      ) {
        modifiedByAndDate[RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_BY] =
          subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_LOCAL_RESTRICTION_POLICY_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (
        key === RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE ||
        key === RS_LOCAL_RESTRICTION_OTHERS_REMARK_FIELD
      ) {
        modifiedByAndDate[RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_BY] =
          subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_LOCAL_RESTRICTION_OTHERS_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
      if (key === RS_FOREIGN_INFLUENCE_PTRS_SCORE || key === RS_FOREIGN_INFLUENZE_REMARK_FIELD) {
        modifiedByAndDate[RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_BY] =
          subScoresObject['userRolesStr'];
        modifiedByAndDate[RS_FOREIGN_INFLUENCE_PTRS_SCORE_MODIFIED_DATE] =
          subScoresObject['lastDateModified'];
      }
    }

    const updateValue = _.filter(segmentsList, segment => {
      return segment.isChecked === true;
    });
    const updatePaylod = _.map(updateValue, item => {
      return {
        id: item.id,
        version: item.version,
        ...subScoresObject,
        ...modifiedByAndDate,
      };
    });

    Promise.all(
      _.map(updatePaylod, async segment => await updateSegment(segment, _.get(segment, 'id'))),
    ).then(() => {
      dispatchCoustom({
        type: ACTION_CLOSE_SEGMENT_SELECTION,
        payload: { count: updateValue.length },
      });
    });
  };

  const toPreviousState = () => {
    dispatchCoustom({ type: ACTION_TO_PREVIOUS_STATE, payload: { segments: segmentsList } });
  };

  const columnVisiblity = {};

  if (
    (pannelType === 'regulatoryScience' && regionRoleSuffix === 'NA') ||
    regionRoleSuffix === 'APAC'
  ) {
    const listOfSubscores =
      regionRoleSuffix === 'NA' ? [...listOfSubScoresForNA] : [...listOfSubScoresForAPAC];
    _.forEach(listOfSubscores, scores => {
      if (scores.isPtrsChecked) Object.assign(columnVisiblity, { [scores.fieldScore]: true });
      if (scores.isRmkChecked) Object.assign(columnVisiblity, { [scores.fieldRmk]: true });
    });
  }
  const columnDetails = {
    columnVisiblity,
    pannelType,
    regionRoleSuffix,
    handleSegmentSelection,
  };

  const tableOptions = {
    columns: getSegmentColumn(columnDetails),
    data: segmentsList,
    toolbar: false,
    selection: true,
    handleSelection: handleSegmentSelection,
  };

  const itemsOfCopySegment: ItemRenderOptions = {
    isScoresDialogOpen,
    currentSegmentForCustomCopy: currentSegment,
    openScoresDialog,
    closeScoresDialog,
    pannelType,
    handleSubmitScoresRmk,
    handleSubScoresChanges,
    listOfSubScoresForNA,
    listOfSubScoresForAPAC,
    toSegmentSelectionSubscores,
    isSegmentSelectionPageForSubscores,
    segmentsList,
    handleSegmentSelection,
    updateSubScores,
    upDatePtrsScoreAndRationale,
    isSegmentSelection,
    toPreviousState,
    handleSubScoresChangesOfAPAC,
    isDisableFSButton,
    isDisableRSNonSubscores,
    isDisableOfRSSubscore,
    countOfSegment,
    isSegmentCountPage,
    successMessageOfUpdate,
    tableOptions,
  };

  return itemsOfCopySegment;
};
