import React, { Fragment } from 'react';
import { GapContainer } from '@main/components/GapContainer/GapContainer';
import CustomizedAccordions from '@shared/components/ExpansionPanel/CustomAccordions';
import { BreadCrumbs } from '@main/components/BreadCrumbs/BreadCrumbs';
import { ScoreContainer } from '@main/components/ScoreContainer/ScoreContainer';
import { getItemValueForProp } from '@main/modules/segmentUtils';
import { Message } from '@shared/utils/message';
import { isEmptyValue } from '@shared/utils/functionUtils';
import { PROJECT_ID, SEGMENT_ID } from '@main/constants/segmentOptions';
import { ProjectDetailsBasicInfo } from '@main/modules/projectDetails/ProjectDetailsBasicInfo';
import { PtrsFollowUp, PtrsFollowUpType } from '../../components/PtrsFollowUp/PtrsFollowUp';

type ptrsPanelProps = {
  itemRenderOptions: {
    currentSegment: any;
    type: any;
  };
};

const usePtrs = itemRenderOptions => {
  const {
    currentSegment,
    quickscanAssessments,
    linkProjectDetails,
    detailsText,
    currentProject,
  } = itemRenderOptions;
  const projectId = getItemValueForProp(currentSegment, PROJECT_ID);
  const segmentId = getItemValueForProp(currentSegment, SEGMENT_ID);
  const isEmptyView = isEmptyValue(quickscanAssessments);
  const linkItems = [
    { path: '/', text: Message.masterList.masterListLink },
    { path: `/project/${projectId}`, text: linkProjectDetails },
    { path: `/segment/${segmentId}`, text: detailsText },
    { path: null, text: 'PTRS' },
  ];
  return {
    projectId,
    segmentId,
    currentSegment,
    isEmptyView,
    quickscanAssessments,
    linkItems,
    currentProject,
  };
};

export const PtrsPanel = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const { currentSegment, quickscanAssessments, isEmptyView, linkItems, currentProject } = usePtrs(
    itemRenderOptions,
  );
  const { type } = itemRenderOptions;
  const { ftPtrsScore } = currentProject;
  const ptrsData = {
    ...currentSegment,
    ftPtrsScore,
  };
  return (
    <Fragment>
      <BreadCrumbs items={linkItems} />
      <ProjectDetailsBasicInfo project={currentProject} segment={currentSegment} type={type} />
      <ScoreContainer data={ptrsData} hasButton={false} type="segments" />
      <PtrsFollowUp entity={currentSegment} type={PtrsFollowUpType.SEGMENT} />
      <CustomizedAccordions
        ItemRender={GapContainer}
        itemRenderOptions={quickscanAssessments}
        showText={Message.ptrs.segmentGapInformation}
        emptyText={isEmptyView ? Message.ptrs.emptyQuickScan : ''}
      />
    </Fragment>
  );
};
