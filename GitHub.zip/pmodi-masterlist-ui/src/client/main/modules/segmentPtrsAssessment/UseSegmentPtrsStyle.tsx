import { makeStyles, createStyles } from '@material-ui/core/styles';

export const useSegmentPtrsStyle = makeStyles(() =>
  createStyles({
    root: {
      width: '100%',
      paddingTop: '65px',
    },

    quickScanResultTable: {
      width: '90%',
      marginLeft: '5%',
      marginTop: '1%',
      marginBottom: '2%',
    },
    emptyView: {
      marginLeft: '40%  !important',
    },
    circularProgress: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    },
    customerClass: {
      width: '50%',
      height: '60%',
    },
    smallDialog: {
      width: '40%',
      height: '30%',
    },
    rows: {
      marginTop: '3%',
    },
    makeStyles: {
      marginTop: '12px',
      marginleft: '5px',
    },
    headingGrid: {
      marginBottom: '20px',
      fontWeight: 'bold',
    },
    line: {
      color: '#808080',
    },
    countPage: {
      width: '40%',
      height: '20%',
    },
    infoButton: {
      marginLeft: '20px',
      width: '20px',
    },
    toolTip: {
      fontSize: '1.5em',
    },
  }),
);
