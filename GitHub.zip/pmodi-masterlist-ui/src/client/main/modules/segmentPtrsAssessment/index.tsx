import _ from 'lodash';
import CssBaseline from '@material-ui/core/CssBaseline';
import React, { useState, useReducer, useEffect } from 'react';
import { typeDispatch } from '@main/stateManagement/store';
import { useDispatch } from 'react-redux';
import { Message } from '@shared/utils/message';
import LoaderComponent from '@shared/components/LoaderComponent/LoaderComponent';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import { useSegment } from '@main/modules/segmentUtils';
import { PtrsEditPanel } from '@main/components/PtrsEditPanel/PtrsEditPanel';
import { PtrsPanel } from './PtrsPanel';
import { useSegmentPtrsStyle } from './UseSegmentPtrsStyle';
import { RegulatoryScience as RegulatorySciencePanel } from './RegulatoryScience';
import { applyToSpecificSegment, reducerForCustomCopy } from './applyToSpecificSegmentUtils';
import { ApplySegmentsDialog, ItemRenderOptions } from './ApplySegmentsDialog';

type segmentPtrsProps = {
  options?: any;
  isLoading?: boolean;
  ftPtrs?: any;
  ftPtrsOPtions?: any;
  regulatoryScienceText?: string;
  rsPtrsOptions?: any;
  fieldSolutionsText?: string;
  fsPtrsOPtions?: any;
  allExpanded?: boolean;
  isApplyButtonDisabled?: boolean;
  onExpandAllClick?: () => void;
  applyPtrsScrore?: () => void;
  isDisableSegmentCopy?: boolean;
  isDisableFSButton?: boolean;
  openScoresDialog?: (pannelType: string) => void;
};

const SegmentPtrs = ({ options, isLoading, allExpanded, onExpandAllClick }: segmentPtrsProps) => {
  options.type = 'segments';
  return (
    <ExpansionPanelView
      text={Message.ptrs.segmentPtrs}
      ItemRender={isLoading ? LoaderComponent : PtrsPanel}
      itemRenderOptions={options}
      defaultExpanded={true}
      shownExpandIcon={false}
      showExpandAll={true}
      expandOverride={allExpanded}
      expandAllClick={onExpandAllClick}
    />
  );
};

const RegulatoryScience = ({
  isLoading,
  allExpanded,
  rsPtrsOptions,
  regulatoryScienceText,
  isApplyButtonDisabled,
  openScoresDialog,
  isDisableSegmentCopy,
  applyPtrsScrore,
}: segmentPtrsProps) => {
  rsPtrsOptions.test = 'rsSubScore';
  return (
    <ExpansionPanelView
      text={regulatoryScienceText}
      ItemRender={isLoading ? LoaderComponent : RegulatorySciencePanel}
      itemRenderOptions={rsPtrsOptions}
      defaultExpanded
      expandOverride={allExpanded}
      showApplyButton
      isApplyButtonDisabled={isApplyButtonDisabled}
      applyPtrsScrore={applyPtrsScrore}
      openScoresDialog={openScoresDialog}
      isDisableSegmentCopy={isDisableSegmentCopy}
      type="regulatoryScience"
    />
  );
};

const FieldSolutions = ({
  isLoading,
  allExpanded,
  fsPtrsOPtions,
  fieldSolutionsText,
  isApplyButtonDisabled,
  openScoresDialog,
  isDisableFSButton,
  applyPtrsScrore,
}: segmentPtrsProps) => {
  return (
    <ExpansionPanelView
      text={fieldSolutionsText}
      ItemRender={isLoading ? LoaderComponent : PtrsEditPanel}
      itemRenderOptions={fsPtrsOPtions}
      defaultExpanded
      expandOverride={allExpanded}
      showApplyButton
      isApplyButtonDisabled={isApplyButtonDisabled}
      isDisableSegmentCopy={isDisableFSButton}
      applyPtrsScrore={applyPtrsScrore}
      openScoresDialog={openScoresDialog}
      type="fieldSolution"
    />
  );
};

export default function segmentPtrs() {
  const classes = useSegmentPtrsStyle();
  const [allExpanded, setAllExpanded] = useState(true);
  const {
    segmentId,
    isLoading,
    detailsOption,
    rsPtrsOptions,
    fsPtrsOPtions,
    fieldSolutionsText,
    quickscanAssessments,
    quickscanMitigation,
    regulatoryScienceText,
    currentSegment,
  } = useSegment({
    hasAuditLog: true,
  });
  const onExpandAllClick = () => {
    setAllExpanded(!allExpanded);
  };

  //for new copy functionality
  const [coustomizeState, dispatchCoustom] = useReducer(reducerForCustomCopy, {
    currentSegmentForCustomCopy: { id: _.toInteger(segmentId) },
  });
  const itemsOfCopySegment: ItemRenderOptions = applyToSpecificSegment(
    coustomizeState,
    dispatchCoustom,
    detailsOption,
    currentSegment,
  );

  const regionRoleSuffix = _.get(currentSegment, 'region.roleSuffix');

  const globalDispatch = useDispatch<typeDispatch>();
  useEffect(() => {
    return () => globalDispatch.MasterList.setCurrentItem({ item: {}, type: 'segments' });
  }, []);

  return (
    <div className={classes.root}>
      <CssBaseline />
      <SegmentPtrs
        isLoading={isLoading}
        options={detailsOption}
        allExpanded={allExpanded}
        onExpandAllClick={onExpandAllClick}
      />
      <FieldSolutions
        isLoading={isLoading}
        allExpanded={allExpanded}
        fieldSolutionsText={fieldSolutionsText}
        openScoresDialog={itemsOfCopySegment?.openScoresDialog}
        fsPtrsOPtions={{
          ...fsPtrsOPtions,
          quickscanAssessments,
        }}
        isDisableFSButton={itemsOfCopySegment?.isDisableFSButton}
      />
      <RegulatoryScience
        isLoading={isLoading}
        allExpanded={allExpanded}
        regulatoryScienceText={regulatoryScienceText}
        openScoresDialog={itemsOfCopySegment?.openScoresDialog}
        isDisableSegmentCopy={
          //regionRoleSuffix === 'NA' || regionRoleSuffix === 'APAC'
          regionRoleSuffix === 'NA'
            ? itemsOfCopySegment?.isDisableOfRSSubscore
            : itemsOfCopySegment?.isDisableRSNonSubscores
        }
        rsPtrsOptions={{
          ...rsPtrsOptions,
          quickscanAssessments,
          quickscanMitigation,
        }}
      />

      <ApplySegmentsDialog itemRenderOptions={itemsOfCopySegment} />
    </div>
  );
}
