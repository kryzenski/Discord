import React, { Fragment } from 'react';
import { useParams } from 'react-router-dom';
import CssBaseline from '@material-ui/core/CssBaseline';

import { Message } from '@shared/utils/message';
import CustomizedTabs from '@shared/components/Tab/CustomizedTabs';
import { Aprs } from '@main/components/PtrsEditPanel/Aprs';
import { useAprsUtils } from '@main/components/PtrsEditPanel/Aprs';
import { PtrsEditPanel } from '@main/components/PtrsEditPanel/PtrsEditPanel';
import { assessmentDetailPanel } from '@main/hook/SubTablePanelOfQuickSacn/useDetailPanel';
import { QuickScanResult } from '@main/components/QuickScanResultTable/QuickScanResult';
import { getQuickScanData } from '@main/modules/matserListUtil';
import { useSegmentPtrsStyle } from './UseSegmentPtrsStyle';

type RegulatoryScienceProps = {
  itemRenderOptions: {
    scoreKey: string;
    scoreLabel: string;
    emptyText?: string;
    rationaleKey: string;
    rationaleLabel: string;
    isEmptyView?: boolean;
    hasAuditLog?: boolean;
    path?: Array<string>;
    editableFields?: Array<string>;
    item: { [propName: string]: any };
    handleClick: Function;
  };
};

const getTabs = (quickScanData, detailPanel, classes, aprsData, isAprsTableLoading) => [
  {
    label: Message.ptrs.quickScanResult,
    index: 0,
    children: (
      <QuickScanResult
        quickScanData={quickScanData}
        detailPanel={detailPanel}
        hasTitle={false}
        cssClass={classes.quickScanResultTable}
        type={'segmentPtrs'}
      />
    ),
  },
  {
    label: Message.ptrs.aprsLabel,
    index: 1,
    children: <Aprs data={aprsData} isLoading={isAprsTableLoading} isSegment />,
  },
];

const useData = itemRenderOptions => {
  const quickscanAssessments = itemRenderOptions.quickscanAssessments;
  const quickScanData = getQuickScanData(
    quickscanAssessments,
    itemRenderOptions.quickscanMitigation,
  );
  const { segmentId }: any = useParams();
  const [aprsData, isAprsTableLoading] = useAprsUtils(segmentId, true);
  const isQuickScanNotApplicable = itemRenderOptions.item.isQuickScanNotApplicable;
  if (isQuickScanNotApplicable) {
    const notApplicable = {
      isQuickScanNotApplicable: isQuickScanNotApplicable,
      quickScanNotApplicableReason: itemRenderOptions.item['quickScanNotApplicableReason'],
      countryName: itemRenderOptions.item.country['displayName'],
      cropText: itemRenderOptions.item.crop['displayName'],
    };
    quickScanData.push(notApplicable);
  }
  return { quickScanData, aprsData, isAprsTableLoading };
};

export const RegulatoryScience = ({ itemRenderOptions }: RegulatoryScienceProps): JSX.Element => {
  const classes = useSegmentPtrsStyle();
  const detailPanel = assessmentDetailPanel();
  const { quickScanData, aprsData, isAprsTableLoading } = useData(itemRenderOptions);
  const tabs = getTabs(quickScanData, detailPanel, classes, aprsData, isAprsTableLoading);

  return (
    <Fragment>
      <CustomizedTabs tabs={tabs} />
      <CssBaseline />
      <PtrsEditPanel itemRenderOptions={itemRenderOptions} />
    </Fragment>
  );
};
