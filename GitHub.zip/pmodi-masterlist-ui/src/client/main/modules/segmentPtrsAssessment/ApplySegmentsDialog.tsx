import {
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  Checkbox,
  Button,
  IconButton,
} from '@material-ui/core';
import React, { Fragment } from 'react';
import { useSegmentPtrsStyle } from './UseSegmentPtrsStyle';
import _ from 'lodash';
import { useSelector } from 'react-redux';
import { typeState } from '../../stateManagement/store';
import moment from 'moment';
import InfoIcon from '@material-ui/icons/Info';
import { TableComponent } from '~/shared/components/TableComponent/TableComponent';

export interface ItemRenderOptions {
  isScoresDialogOpen?: boolean;
  currentSegmentForCustomCopy?: any;
  openScoresDialog?: (pannelType: any) => void;
  closeScoresDialog?: () => void;
  pannelType?: string;
  handleSubmitScoresRmk?: (option: any) => void;
  handleSubScoresChanges?: (event: any, fieldName: string) => void;
  listOfSubScoresForNA?: any;
  listOfSubScoresForAPAC?: any;
  toSegmentSelectionSubscores?: ({}: any) => void;
  isSegmentSelectionPageForSubscores?: boolean;
  segmentsList?: any;
  handleSegmentSelection?: any;
  isSegmentSelection?: boolean;
  upDatePtrsScoreAndRationale?: () => void;
  updateSubScores?: () => void;
  toPreviousState?: () => void;
  handleSubScoresChangesOfAPAC?: (event: any, fieldName: string) => void;
  countOfSegment?: any;
  isSegmentCountPage?: boolean;
  successMessageOfUpdate?: string;
  tableOptions?: any;
  isDisableFSButton?: boolean;
  isDisableOfRSSubscore?: boolean;
  isDisableRSNonSubscores?: boolean;
}

interface ApplySegmentsDialogProps {
  itemRenderOptions: ItemRenderOptions;
}

interface FormRowPropsType {
  title?: string;
  field?: string;
  isPtrsChecked?: boolean;
  isRmkChecked?: boolean;
  handleSubScoresChanges?: (event: any, fieldName: string) => void;
}

export const ApplySegmentsDialog = (props: ApplySegmentsDialogProps): JSX.Element => {
  //for FS and RS scores and rationale
  const [isCheckedOptions, setIsCheckedOptions] = React.useState({
    isPtrsScoreChecked: false,
    isPtrsRmkChecked: false,
  });

  //array for subscores
  const {
    isScoresDialogOpen,
    currentSegmentForCustomCopy,
    closeScoresDialog,
    pannelType,
    handleSubmitScoresRmk,
    handleSubScoresChanges,
    listOfSubScoresForNA,
    listOfSubScoresForAPAC,
    toSegmentSelectionSubscores,
    isSegmentSelectionPageForSubscores,
    segmentsList,
    upDatePtrsScoreAndRationale,
    isSegmentSelection,
    updateSubScores,
    toPreviousState,
    handleSubScoresChangesOfAPAC,
    isSegmentCountPage = false,
    successMessageOfUpdate,
    tableOptions,
  } = props?.itemRenderOptions;
  const classes = useSegmentPtrsStyle();
  const regionRoleSuffix = _.get(currentSegmentForCustomCopy, 'region.roleSuffix');
  const ptrsScoreName = pannelType === 'fieldSolution' ? 'fsPtrsScore' : 'rsRegPtrsScore';
  const ptrsRmkName = pannelType === 'fieldSolution' ? 'fsPtrsRmk' : 'rsRegPtrsRmk';
  const title = 'Apply to Segments in same Region';
  const userRolesStr = useSelector((state: typeState) => state.User.userName);
  const date = new Date();
  const segmentUpdateMessage = `Selected segments value will be replaced with the Current segment's value.`;
  let isDisableFSAndRSButton = false;
  const lastDateModified = moment(date).format('YYYY-MM-DD');
  const handleCheckboxChange = event => {
    const { name } = event.target;
    if (name === 'fsPtrsRmk' || name === 'rsRegPtrsRmk')
      setIsCheckedOptions(isCheckedOptions => ({
        ...isCheckedOptions,
        isPtrsRmkChecked: !isCheckedOptions.isPtrsRmkChecked,
      }));
    else if (name === 'fsPtrsScore' || name === 'rsRegPtrsScore')
      setIsCheckedOptions(isCheckedOptions => ({
        ...isCheckedOptions,
        isPtrsScoreChecked: !isCheckedOptions.isPtrsScoreChecked,
      }));
  };
  isDisableFSAndRSButton =
    isCheckedOptions.isPtrsRmkChecked || isCheckedOptions.isPtrsScoreChecked ? true : false;
  let isApplyToSegmentsSubscoreNA = false;
  _.forEach(listOfSubScoresForNA, item => {
    if (item.isPtrsChecked || item.isRmkChecked) {
      isApplyToSegmentsSubscoreNA = true;
      return false;
    }
  });

  let isSegmentUpdateDisable = false;
  _.forEach(segmentsList, segment => {
    if (segment.isChecked) {
      isSegmentUpdateDisable = true;
      return false;
    }
  });

  let isApplyToSegmentsSubscoreAPAC = false;
  _.forEach(listOfSubScoresForAPAC, item => {
    if (item.isPtrsChecked || item.isRmkChecked) {
      isApplyToSegmentsSubscoreAPAC = true;
      return false;
    }
  });
  const userDetails = {
    modifiedBy: userRolesStr,
    modifiedDate: lastDateModified,
  };
  const submitResponse = () => {
    const option = {
      pannelType,
      isCheckedOptions,
      ...userDetails,
    };
    handleSubmitScoresRmk(option);
  };

  const dialogClose = () => {
    closeScoresDialog();
    setIsCheckedOptions(isCheckedOptions => ({
      ...isCheckedOptions,
      isPtrsScoreChecked: false,
      isPtrsRmkChecked: false,
    }));
  };

  //for subscores of NA and APAC
  const FormRow = ({
    title,
    field,
    isPtrsChecked,
    isRmkChecked,
    handleSubScoresChanges,
  }: FormRowPropsType) => {
    return (
      <Fragment>
        <Grid container spacing={1}>
          <Grid item xs={6} spacing={1}>
            {title}
          </Grid>
          <Grid item xs={3} spacing={1}>
            <Checkbox
              checked={isRmkChecked}
              name={field}
              onChange={event => {
                handleSubScoresChanges(event, 'isRmkChecked');
              }}
            />
          </Grid>
          {field !== 'rsRegPtrsScore' && (
            <Grid item xs={3} spacing={1}>
              <Checkbox
                checked={isPtrsChecked}
                name={field}
                onChange={event => {
                  handleSubScoresChanges(event, 'isPtrsChecked');
                }}
              />
            </Grid>
          )}
        </Grid>
      </Fragment>
    );
  };

  const saveValues = () => {
    // pannelType === 'regulatoryScience' && (regionRoleSuffix === 'NA' || regionRoleSuffix === 'APAC')
    pannelType === 'regulatoryScience' && regionRoleSuffix === 'NA'
      ? updateSubScores()
      : upDatePtrsScoreAndRationale();
  };

  return (
    <Fragment>
      <Dialog
        onClose={dialogClose}
        open={isScoresDialogOpen}
        maxWidth="lg"
        classes={{
          paper: isSegmentCountPage
            ? classes.countPage
            : (pannelType === 'fieldSolution' ||
                (pannelType === 'regulatoryScience' && regionRoleSuffix !== 'NA')) &&
              //regionRoleSuffix !== 'APAC')) &&
              !isSegmentSelection &&
              !isSegmentSelectionPageForSubscores
            ? classes.smallDialog
            : classes.customerClass,
        }}
      >
        <DialogTitle>{title}</DialogTitle>
        <DialogContent>
          {!isSegmentSelection &&
          !isSegmentCountPage &&
          (pannelType === 'fieldSolution' ||
            (pannelType === 'regulatoryScience' && !isSegmentSelectionPageForSubscores)) ? (
            <Grid container spacing={1} className={classes.headingGrid}>
              <Grid container item xs={6} spacing={1}></Grid>
              <Grid container item xs={3} spacing={1}>
                <span>Rationale</span>
              </Grid>
              <Grid container item xs={3} spacing={1}>
                <span>PTRS Score</span>
              </Grid>
            </Grid>
          ) : (
            ''
          )}
          {/* content of the dialog */}
          {!isSegmentSelection &&
          !isSegmentCountPage &&
          (pannelType === 'fieldSolution' ||
            (pannelType === 'regulatoryScience' && regionRoleSuffix !== 'NA')) ? (
            //regionRoleSuffix !== 'APAC')) ? (
            <Fragment>
              <Grid container spacing={1} className={classes.rows}>
                <Grid container item xs={6} spacing={1}>
                  {pannelType === 'fieldSolution' ? 'Field Solution' : 'Regulatory Science'}
                </Grid>
                <Grid container item xs={3} spacing={1}>
                  <Checkbox
                    name={ptrsRmkName}
                    checked={isCheckedOptions.isPtrsRmkChecked}
                    onChange={event => {
                      handleCheckboxChange(event);
                    }}
                  />
                </Grid>
                <Grid container item xs={3} spacing={1}>
                  <Checkbox
                    name={ptrsScoreName}
                    checked={isCheckedOptions.isPtrsScoreChecked}
                    onChange={event => {
                      handleCheckboxChange(event);
                    }}
                  />
                </Grid>
              </Grid>
              <Grid container justify="flex-end" alignItems="flex-end">
                <Grid item>
                  <Button
                    onClick={submitResponse}
                    color="primary"
                    className={classes.makeStyles}
                    disabled={!isDisableFSAndRSButton}
                  >
                    Select Segments
                  </Button>
                </Grid>
              </Grid>
            </Fragment>
          ) : (
            ''
          )}
          {pannelType === 'regulatoryScience' &&
          regionRoleSuffix === 'NA' &&
          // (regionRoleSuffix === 'NA' || regionRoleSuffix === 'APAC') &&
          !isSegmentSelectionPageForSubscores &&
          !isSegmentCountPage ? (
            <Fragment>
              {regionRoleSuffix === 'NA'
                ? _.map(listOfSubScoresForNA, subscores => (
                    <FormRow
                      title={subscores.title}
                      field={subscores.fieldScore}
                      isPtrsChecked={subscores.isPtrsChecked}
                      isRmkChecked={subscores.isRmkChecked}
                      handleSubScoresChanges={handleSubScoresChanges}
                    />
                  ))
                : _.map(listOfSubScoresForAPAC, subscores => (
                    <FormRow
                      title={subscores.title}
                      field={subscores.fieldScore}
                      isPtrsChecked={subscores.isPtrsChecked}
                      isRmkChecked={subscores.isRmkChecked}
                      handleSubScoresChanges={handleSubScoresChangesOfAPAC}
                    />
                  ))}
              <Grid container justify="flex-end" alignItems="flex-end">
                <Grid item>
                  <Button
                    disabled={
                      regionRoleSuffix == 'NA'
                        ? !isApplyToSegmentsSubscoreNA
                        : !isApplyToSegmentsSubscoreAPAC
                    }
                    onClick={() =>
                      toSegmentSelectionSubscores({
                        regionRoleSuffix,
                        lastDateModified,
                        userRolesStr,
                      })
                    }
                    color="primary"
                    className={classes.makeStyles}
                  >
                    Select Segments
                  </Button>
                </Grid>
              </Grid>
            </Fragment>
          ) : (
            ''
          )}
          {(isSegmentSelectionPageForSubscores || isSegmentSelection) && !isSegmentCountPage ? (
            <Fragment>
              {/* for Segment selection */}
              <TableComponent itemRenderOptions={tableOptions} />
              <Grid container justify="flex-end">
                <Grid item xs={8} spacing={2}>
                  {isSegmentUpdateDisable && (
                    <div>
                      <IconButton edge="start" color="secondary" className={classes.infoButton}>
                        <InfoIcon />
                      </IconButton>
                      {segmentUpdateMessage}
                    </div>
                  )}
                </Grid>
                <Grid item xs={4} spacing={2}>
                  <Button color="primary" className={classes.makeStyles} onClick={toPreviousState}>
                    Back
                  </Button>
                  <Button
                    onClick={saveValues}
                    color="primary"
                    disabled={!isSegmentUpdateDisable}
                    className={classes.makeStyles}
                  >
                    Update Segments
                  </Button>
                </Grid>
              </Grid>
            </Fragment>
          ) : (
            ''
          )}
          {isSegmentCountPage && (
            <div>
              <div> {successMessageOfUpdate} </div>
              <Grid container justify="flex-end" alignItems="flex-end">
                <Grid item>
                  <Button onClick={dialogClose} color="primary" className={classes.makeStyles}>
                    ok
                  </Button>
                </Grid>
              </Grid>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Fragment>
  );
};
