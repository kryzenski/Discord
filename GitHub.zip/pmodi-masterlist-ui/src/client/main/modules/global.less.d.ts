declare namespace GlobalLessModule {
  export interface IGlobalLess {
    mainContainer: string;
  }
}

declare const GlobalLessModule: GlobalLessModule.IGlobalLess & {
  /** WARNING: Only available when `css-loader` is used without `style-loader` or `mini-css-extract-plugin` */
  locals: GlobalLessModule.IGlobalLess;
};

export = GlobalLessModule;
