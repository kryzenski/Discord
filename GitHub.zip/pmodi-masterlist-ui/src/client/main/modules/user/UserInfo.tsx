import React, { useEffect } from 'react';
import { Typography } from '@material-ui/core';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import { useDispatch, useSelector } from 'react-redux';

const UserInfo = () => {
  const dispatch = useDispatch<typeDispatch>();
  const userName = useSelector((state: typeState) => state.User.userName);
  const userRoles = useSelector((state: typeState) => state.User.userRoles);
  const userRolesStr = useSelector((state: typeState) => state.User.userRolesStr);

  useEffect(() => {
    dispatch.User.getUserInfo();
  }, [dispatch.User.getUserInfo]);

  return (
    <div>
      <Typography>{userName}</Typography>
      <Typography>
        <span title={userRoles?.join(', ')}>{userRolesStr}</span>
      </Typography>
    </div>
  );
};

export default UserInfo;
