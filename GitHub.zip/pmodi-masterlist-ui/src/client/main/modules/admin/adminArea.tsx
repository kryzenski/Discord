import React, { useState, useEffect, Fragment } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { SaveButton } from '@shared/components/Buttons/SaveButton';
import LoaderComponent from '@shared/components/LoaderComponent/LoaderComponent';
import { SwitchGroup } from '@shared/components/SwitchGroup/SwitchGroup';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import { Message } from '@shared/utils/message';
import { allowEditGroups } from '@main/constants/constants';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import CustomizedTabs from '@shared/components/Tab/CustomizedTabs';
import _ from 'lodash';

const useStyles = makeStyles(() =>
  createStyles({
    root: {
      width: '100%',
      paddingTop: '65px',
    },
  }),
);

const useData = () => {
  const dispatch = useDispatch<typeDispatch>();
  const lockGroups = useSelector((state: typeState) => state.AdminArea.lockGroups);
  const isUpdateLoading = useSelector(
    (state: typeState) => state.loading.effects.AdminArea.updatePermission,
  );
  const isFetchLoading = useSelector(
    (state: typeState) => state.loading.effects.AdminArea.fetchLockGroups,
  );

  const initSwitchGroups = { ...allowEditGroups };
  _.forEach(initSwitchGroups, (item, key) => {
    item.value = !_.includes(lockGroups, key);
  });
  const [switchGroups, setSwitchGroups] = useState(initSwitchGroups);

  useEffect(() => {
    !isUpdateLoading && dispatch.AdminArea.fetchLockGroups();
  }, [isUpdateLoading]);

  const handleSwitchChange = event => {
    const { checked, name } = event.target;
    const newSwitchGroup = { ...switchGroups };
    const newEntity = { ...newSwitchGroup[name] };
    newEntity.value = checked;
    newSwitchGroup[name] = newEntity;
    setSwitchGroups(newSwitchGroup);
  };
  const updatePermission = () => {
    const newLockGroups = [];
    const unLockGroups = [];
    _.forEach(switchGroups, (item, key) => {
      if (!item.value) {
        newLockGroups.push(key);
      } else {
        unLockGroups.push(key);
      }
    });

    dispatch.AdminArea.updatePermission({ lockGroups: newLockGroups, unLockGroups });
  };

  const isSaveAble = !_.isEqual(switchGroups, initSwitchGroups);
  const tabs = [
    {
      label: Message.admin.tab,
      index: 0,
      children: isFetchLoading ? (
        <LoaderComponent />
      ) : (
        <Fragment>
          <SwitchGroup
            title={Message.admin.title}
            switchGroups={switchGroups}
            handleSwitchChange={handleSwitchChange}
          ></SwitchGroup>
          <SaveButton onClick={updatePermission} isDisabled={!isSaveAble} />
        </Fragment>
      ),
    },
  ];

  return { tabs };
};

const Content = (): JSX.Element => {
  const { tabs } = useData();
  return <CustomizedTabs tabs={tabs} />;
};

export default function adminArea() {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <ExpansionPanelView
        shownExpandIcon={false}
        text={Message.admin.admin}
        ItemRender={Content}
        defaultExpanded={true}
      ></ExpansionPanelView>
    </div>
  );
}
