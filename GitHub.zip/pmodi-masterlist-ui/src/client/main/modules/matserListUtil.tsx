import React from 'react';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import { Message } from '@shared/utils/message';
import { AUDIT_LOG_URL_SEGMENTS, AUDIT_LOG_URL_PROJECTS } from '@main/constants/constants';
import { makeStyles } from '@material-ui/styles';
import { RadioGroups } from '@shared/components/RadioGroup/RadioGroup';
import { TextArea } from '@shared/components/TextField/TextArea';
import { BasicTextField } from '@shared/components/TextField/BasicTextField';
import {
  PROJECT_CATEGORY_FILED,
  PRECISE_NEW_PORT_ID_FIELD,
  withLinkPropertiesOfProject,
  FS_RECOMMENDATION_ONLY_NF_POC_PROJECT_FEILD,
} from '@main/constants/projectOptions';
import { ASSESSMENT_DETAIL_LIST, ACTIVE_SUBSTANCE_NAME } from '@main/constants/constants';
import {
  SegmentPtrsFields,
  NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD,
  withLinkPropertiesOfSegment,
  SegmentNASubscores,
} from '@main/constants/segmentOptions';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import { toInteger } from '@shared/utils/numberUtils';
import { getLabel } from '@main/constants/fieldsInfo';
import { AuditLog } from '@main/components/AuditLog/AuditLog';
import { auditLogStyles } from '@main/components/AuditLog/useAuditLogUtils';
import { Link } from 'react-router-dom';
import { FORMATTER_TO_PERCENT } from '@main/constants/fieldsInfo';
import _ from 'lodash';
import {
  FS_RESULT_FEILD,
  FS_OBJECTIVE_FEILD,
  FT_RESPONSIBLITY_FIELD,
  FT_RECOMMENDATION_FIELD,
  FT_STATUS_FIELD,
} from '@main/constants/constants';

export const isLink = (field, type) => {
  if (type === 'projects') {
    return _.includes(withLinkPropertiesOfProject, field);
  }
  const segmentLinkFields = [...SegmentPtrsFields, ...SegmentNASubscores];
  return _.includes(_.concat(segmentLinkFields, withLinkPropertiesOfSegment), field);
};

const getLinkPath = (field, type, id) => {
  const segmentLinkFields = [...SegmentPtrsFields, ...SegmentNASubscores];
  if (type === 'segments') {
    return _.includes(segmentLinkFields, field) ? `/segment/${id}/ptrs` : `/segment/${id}`;
  } else {
    return field === PRECISE_NEW_PORT_ID_FIELD ? `/project/${id}` : `/project/${id}/ptrs`;
  }
};

export const addLink = (column, type) => rowData => {
  const path = getLinkPath(column.field, type, rowData.id);
  return (
    <Link to={path} style={{ textDecoration: 'none', color: 'rgb(0, 0, 238)' }}>
      {column.formatter === FORMATTER_TO_PERCENT
        ? _.isNull(_.get(rowData, column.field))
          ? 'N/A'
          : toInteger(_.get(rowData, column.field))
        : _.get(rowData, column.field)}
    </Link>
  );
};

export const isEmptyPtrsEditPanel = currentProject => {
  const isEmptyView =
    currentProject[PROJECT_CATEGORY_FILED] !== 'New Formulation Proof of Concept' &&
    currentProject[PROJECT_CATEGORY_FILED] !== 'Formulation Development' &&
    currentProject[PROJECT_CATEGORY_FILED] !== 'New Active Substance Developments';
  return isEmptyView;
};

const useStyles = makeStyles(() => ({
  prioritizationGovernance: {
    marginLeft: '3%',
  },
  prioritizationTypeGroup: {
    marginLeft: '8%',
  },
  prioritizationRmk: {
    marginTop: '-1%',
  },
}));

export const useOptions = (
  item,
  scoreKey,
  rationaleKey,
  editableFields,
  isEmptyView,
  type,
  hasAuditLog = false,
) => {
  const dispatch = useDispatch<typeDispatch>();
  const resultKey = FS_RESULT_FEILD;
  const objectiveKey = FS_OBJECTIVE_FEILD;
  const recommendationKey = FS_RECOMMENDATION_ONLY_NF_POC_PROJECT_FEILD;
  const responsiblityKey = FT_RESPONSIBLITY_FIELD;
  const statusKey = FT_STATUS_FIELD;
  const ftrecommendationKey = FT_RECOMMENDATION_FIELD;
  return {
    isEmptyView,
    item,
    scoreKey,
    rationaleKey,
    recommendationKey,
    resultKey,
    objectiveKey,
    responsiblityKey,
    statusKey,
    ftrecommendationKey,
    handleClick:
      type === 'segments' ? dispatch.MasterList.updateSegment : dispatch.MasterList.updateProject,
    scoreLabel: Message.ptrs[scoreKey],
    rationaleLabel: Message.ptrs[rationaleKey],
    editableFields,
    emptyText: Message.ptrs.emptyText,
    hasAuditLog,
    path: type === 'segments' ? [AUDIT_LOG_URL_SEGMENTS] : [AUDIT_LOG_URL_PROJECTS],
  };
};

type PrioritizationProps = {
  name: string;
  value?: string;
  handleChange?: (event: object) => void;
  isDisabled?: boolean;
  label?: string;
};
const prioritizationTypeGroup = [
  { value: 'A', label: 'A' },
  { value: 'B', label: 'B' },
  { value: 'Cancelled', label: 'Canceled' },
  { value: 'null', label: 'No Category' },
];
export const PrioritizationType = ({
  name,
  value,
  handleChange,
  isDisabled,
}: PrioritizationProps) => {
  const classes = useStyles();
  const paths = ['projects'];
  const label = getLabel(name, paths);

  return (
    <RadioGroups
      name={name}
      value={value || 'null'}
      label={label}
      handleRadioChange={handleChange}
      radioGroups={prioritizationTypeGroup}
      customerClass={classes.prioritizationTypeGroup}
      isDisabled={isDisabled}
    />
  );
};

const prioritizationGovernanceGroup = [
  { value: 'GLOBAL', label: 'Global' },
  { value: 'REGIONAL', label: 'Regional' },
];
export const PrioritizationGovernance = ({
  name,
  value,
  handleChange,
  isDisabled,
}: PrioritizationProps) => {
  const classes = useStyles();
  const paths = ['projects'];
  const label = getLabel(name, paths);
  return (
    <RadioGroups
      name={name}
      value={value}
      label={label}
      handleRadioChange={handleChange}
      radioGroups={prioritizationGovernanceGroup}
      customerClass={classes.prioritizationGovernance}
      isDisabled={isDisabled}
    />
  );
};

const groupingMitigation = (assessment, mitigationDetails): Array<any> => {
  //console.log("project assessment", assessment, mitigationDetails);
  return _.filter(
    mitigationDetails,
    mitigation => mitigation?.generalReviewDetails?.assessmentId === assessment.id,
  );
};

const groupMitigationPresent = (assessment, quickscanMitigation): any => {
  // console.log('mitigationListNew', assessment, quickscanMitigation);
  const mitigationList = _.filter(
    quickscanMitigation,
    mitigation => mitigation?.generalReviewDetails?.assessmentId === assessment.id,
  );

  if (mitigationList.length > 0) {
    let allMitigationList = mitigationList[0]?.generalReviewDetails?.mitigationDetails?.mitigations;
    allMitigationList = {
      ...allMitigationList,
      ...mitigationList[0]?.generalReviewDetails?.reviewDetails?.reviews,
    };
    const isAllMitigationPresent = !Object?.values(allMitigationList).every(o => o === null);
    return isAllMitigationPresent;
  }
  return false;
};

export const getQuickScanData = (assessments, quickscanMitigation?) => {
  if (_.isArray(assessments)) {
    return _.map(assessments, assessment => ({
      ...assessment,
      assessmentDetailList: _.groupBy(assessment[ASSESSMENT_DETAIL_LIST], ACTIVE_SUBSTANCE_NAME),
      mitigationDetail: groupingMitigation(assessment, quickscanMitigation),
      isAllMitigationPresent: groupMitigationPresent(assessment, quickscanMitigation),
    }));
  } else {
    return isNotEmptyValue(assessments)
      ? [
          {
            ...assessments,
            assessmentDetailList: _.groupBy(
              assessments[ASSESSMENT_DETAIL_LIST],
              ACTIVE_SUBSTANCE_NAME,
            ),
          },
        ]
      : [];
  }
};

export const getAssessments = quickscanAssessments => {
  const assessments = [];
  _.forEach(quickscanAssessments, item => {
    assessments.push(...item?.assessment);
  });
  return assessments;
};

export const getMitigations = quickscanMitigations => {
  const mitigations = [];
  _.forEach(quickscanMitigations, item => {
    mitigations.push(...item?.assessment);
  });
  return mitigations;
};

export const calculateWeightedScore = (segments, scoreKey) => {
  let totalScore = 0;
  let totalWeighted = 0;
  _.forEach(segments, function(segment) {
    const score = _.get(segment, scoreKey) || 0;
    const weighted = _.get(segment, NEWPORT_GLOBAL_PEAK_NET_NET_SALES_FIELD);
    // TODO: what if weighted is undefined?
    totalScore += score * weighted;
    totalWeighted += weighted;
  });
  return totalWeighted ? toInteger(_.divide(totalScore, totalWeighted)) : 0;
};

type TextAreaProps = {
  id?: string;
  fieldName: string;
  customClass?: string;
  handleChange?: (event: object) => void;
  shownEntity: { [propName: string]: any };
  editableFields?: Array<string>;
  hasAuditLog?: boolean;
  hasDatePickerView?: boolean;
  paths?: Array<string>;
};

export const createTextAreaField = ({
  id,
  fieldName,
  shownEntity,
  customClass,
  editableFields,
  handleChange,
  hasAuditLog,
  hasDatePickerView = false,
  paths = ['projects'],
}: TextAreaProps) => {
  const classes = auditLogStyles();
  const label = getLabel(fieldName, paths);
  const isDisabled = hasDatePickerView ? true : !_.includes(editableFields, fieldName);
  return (
    <TextArea
      key={'GlobalGuidance-' + fieldName}
      rows="3"
      name={fieldName}
      label={label}
      customerClass={customClass}
      value={shownEntity[fieldName] || ''}
      isDisabled={isDisabled}
      handleChange={handleChange}
      auditLog={
        hasAuditLog ? (
          <AuditLog id={id} paths={paths} customClass={classes.label} fieldName={fieldName} />
        ) : null
      }
    />
  );
};

type TextFiledProps = {
  fieldName: string;
  customerClass?: string;
  handleChange?: (event: object) => void;
  entity: { [propName: string]: any };
  editableFields?: Array<string>;
  label?: string;
  rows?: string;
  textFiledClass?: string;
  isDisabled?: boolean;
  isValidate?: boolean;
  auditLog?: JSX.Element;
  lableWithLog?: boolean;
};
export const createTextField = ({
  fieldName,
  entity,
  customerClass,
  label,
  rows,
  isDisabled,
  textFiledClass,
  handleChange,
  isValidate,
  lableWithLog,
  auditLog,
}: TextFiledProps) => {
  return (
    <BasicTextField
      value={_.get(entity, fieldName)}
      textFiledClass={textFiledClass}
      isDisabled={isDisabled}
      label={label}
      customerClass={customerClass}
      name={fieldName}
      rows={rows}
      handleChange={handleChange}
      error={isValidate}
      lableWithLog={lableWithLog}
      auditLog={auditLog}
    />
  );
};
