import _ from 'lodash';
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import { Message } from '@shared/utils/message';
import { toInteger } from '@shared/utils/numberUtils';
import { isEmptyValue } from '@shared/utils/functionUtils';
import { typeState, typeDispatch } from '@main/stateManagement/store';
import { PRECISE_NEW_PORT_ID_FIELD, PROJECT_NAME_FIELD } from '@main/constants/projectOptions';
import {
  PROJECT_ID,
  SEGMENT_ID,
  CROP_FIELD,
  TARGET_FIELD,
  COUNTRY_FIELD,
  PRECISE_NEWPORT_ID,
  RS_REGULATORY_PTRS_SCORE_FIELD,
  RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
  FS_PTRS_SCORE_FIELD,
  FT_PTRS_SCORE_FIELD,
  FS_PTRS_SCORE_REMARK_FIELD,
} from '@main/constants/segmentOptions';
import { useOptions, isEmptyPtrsEditPanel } from './matserListUtil';

export const getItemValueForProp = (item, prop) => {
  switch (prop) {
    case PRECISE_NEWPORT_ID:
      return _.get(item, PRECISE_NEWPORT_ID);
    case PROJECT_ID:
      return _.get(item, PROJECT_ID);
    case CROP_FIELD:
      return _.get(item, CROP_FIELD);
    case TARGET_FIELD:
      return _.get(item, TARGET_FIELD);
    case COUNTRY_FIELD:
      return _.get(item, COUNTRY_FIELD);
    case SEGMENT_ID:
      return _.get(item, SEGMENT_ID);
    case 'includes':
      return _.get(item, 'includes');
    default:
      return null;
  }
};

export const useSegment = props => {
  const dispatch = useDispatch<typeDispatch>();
  const { segmentId }: any = useParams();
  const {
    currentProject,
    editableFieldsMap,
    currentSegment,
    isLoading,
    quickscanAssessments,
    preciseCostListOfSegment,
    milestonesOfSegment,
    quickscanMitigation,
  } = useSelector((state: typeState) => {
    return {
      currentProject: state.MasterList.projects.currentItem,
      editableFieldsMap: state.MasterList.segments.editbaleFieldsMap,
      currentSegment: state.MasterList.segments.currentItem,
      isLoading:
        state.loading.effects.MasterList.getSegmentDataById ||
        state.loading.effects.MasterList.fetchEditableFieldsOfSegment ||
        state.loading.effects.MasterList.updateSegment ||
        state.loading.effects.MasterList.fetchQuickscanAssessments ||
        state.loading.effects.MasterList.fetchMilestonesOfSegment ||
        state.loading.effects.MasterList.fetchPreciseCostListOfSegment ||
        state.loading.effects.MasterList.fetchQuickscanMitigation,
      quickscanAssessments: state.MasterList.segments.quickscanAssessments,
      quickscanMitigation: state.MasterList.segments.quickscanMitigation,
      preciseCostListOfSegment: state.MasterList.segments.preciseCostList,
      milestonesOfSegment: state.MasterList.segments.mileStones,
    };
  });
  const editableFields = editableFieldsMap.get(segmentId);
  const projectId = getItemValueForProp(currentSegment, PROJECT_ID);
  const isEmptyView = isEmptyPtrsEditPanel(currentProject);
  const quickscanAssessmentId = _.get(currentSegment, 'quickscanAssessmentId');
  const mileStoneZNumber = _.get(currentSegment, 'regprimeZNumber');
  const mileStoneSecquence = _.get(currentSegment, 'regprimeSequenceNumber');
  const coutryName = getItemValueForProp(currentSegment, COUNTRY_FIELD);
  const cropName = getItemValueForProp(currentSegment, CROP_FIELD);
  const target = getItemValueForProp(currentSegment, TARGET_FIELD);
  const detailsText = coutryName + ' - ' + cropName + ' - ' + target;
  const detailsTitle = 'Segment: ' + detailsText;
  const linkProjectDetails =
    _.get(currentProject, PRECISE_NEW_PORT_ID_FIELD) +
    ': ' +
    _.get(currentProject, PROJECT_NAME_FIELD);
  const detailsOption = {
    detailsTitle,
    projectId,
    currentSegment: {
      ...currentSegment,
      ftPtrsScore: currentProject[FT_PTRS_SCORE_FIELD],
    },
    editableFields,
    quickscanAssessments,
    quickscanMitigation,
    detailsText,
    currentProject,
    linkProjectDetails,
    milestonesOfSegment,
    hasAuditLog: props.hasAuditLog,
  };

  const regulatoryScienceText =
    Message.ptrs.regulatoryScience + toInteger(currentSegment[RS_REGULATORY_PTRS_SCORE_FIELD]);
  const fieldSolutionsText =
    Message.ptrs.fieldSolutions + toInteger(currentSegment[FS_PTRS_SCORE_FIELD]);

  const rsPtrsOptions = useOptions(
    currentSegment,
    RS_REGULATORY_PTRS_SCORE_FIELD,
    RS_REGULATORY_PTRS_SCORE_REMARK_FIELD,
    editableFields,
    false,
    'segments',
    props.hasAuditLog,
  );

  const fsPtrsOPtions = useOptions(
    currentSegment,
    FS_PTRS_SCORE_FIELD,
    FS_PTRS_SCORE_REMARK_FIELD,
    editableFields,
    false,
    'segments',
    props.hasAuditLog,
  );
  useEffect(() => {
    segmentId && dispatch.MasterList.getSegmentDataById(segmentId);
    projectId && dispatch.MasterList.getProjectDataById(projectId);
    isEmptyValue(editableFields) && dispatch.MasterList.fetchEditableFieldsOfSegment(segmentId);
    dispatch.MasterList.fetchPreciseCostListOfSegment({ id: segmentId });
    dispatch.MasterList.fetchMilestonesOfSegment({ id: segmentId });
  }, [projectId, segmentId]);

  useEffect(() => {
    dispatch.MasterList.fetchQuickscanAssessments({ id: segmentId, type: 'segments' });
  }, [segmentId, quickscanAssessmentId]);
  useEffect(() => {
    dispatch.MasterList.fetchMilestonesOfSegment({ id: segmentId });
  }, [segmentId, mileStoneZNumber, mileStoneSecquence]);

  return {
    segmentId,
    detailsOption,
    currentProject,
    editableFields,
    preciseCostListOfSegment,
    isLoading,
    currentSegment,
    isEmptyView,
    regulatoryScienceText,
    fieldSolutionsText,
    quickscanAssessments,
    quickscanMitigation,
    rsPtrsOptions,
    fsPtrsOPtions,
  };
};
