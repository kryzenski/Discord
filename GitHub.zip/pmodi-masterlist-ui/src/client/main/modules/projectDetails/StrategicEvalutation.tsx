import React, { Fragment } from 'react';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';
import { SaveButton } from '@shared/components/Buttons/SaveButton';
import { PrioritizationType, PrioritizationGovernance } from '@main/modules/matserListUtil';
import {
  STRATEGIC_FIT_REMARK,
  PRIORITIZATION_TYPE_FIELD,
  PRIORITIZATION_REMARK_FIELD,
  PRIORITIZATION_GOVERNNCE_FIELD,
} from '@main/constants/projectOptions';
import { segmentColumnsOfProjectDetails } from '@main/constants/segmentOptions';
import _ from 'lodash';
import { SegmentTable, useSegmentColumns } from './indexUtils';
import { createTextAreaField } from '@main/modules/matserListUtil';

type ptrsPanelProps = {
  itemRenderOptions: {
    id: string;
    currentProject: { [propName: string]: any };
    segments: Array<object>;
    editableFields?: Array<string>;
  };
};

const useData = itemRenderOptions => {
  const classes = useProjectDetailsStyle();
  const dispatch = useDispatch<typeDispatch>();
  const {
    id,
    segments,
    currentProject,
    editableFields,
    hasAuditLog,
    hasDatePickerView,
  } = itemRenderOptions;
  const version = _.get(currentProject, 'version');
  const [editEntity, setEntity] = React.useState({ version });
  const [shownEntity, setShownEntity] = React.useState({ ...currentProject });

  const handleChange = event => {
    const { value, name } = event.target;
    const newShownEntity = { ...shownEntity, [name]: value };
    setShownEntity(newShownEntity);
    const newEntity = { ...editEntity, [name]: value };
    setEntity(newEntity);
  };

  const onClick = () => {
    dispatch.MasterList.updateProject({ entity: editEntity, id });
  };
  const strategicFitRmk = createTextAreaField({
    id,
    fieldName: STRATEGIC_FIT_REMARK,
    shownEntity,
    editableFields,
    customClass: classes.strategicFitRmk,
    hasAuditLog: hasDatePickerView ? false : hasAuditLog,
    handleChange,
    hasDatePickerView,
  });
  const prioritizationRmk = createTextAreaField({
    id,
    fieldName: PRIORITIZATION_REMARK_FIELD,
    shownEntity,
    editableFields,
    hasAuditLog: hasDatePickerView ? false : hasAuditLog,
    handleChange,
    hasDatePickerView,
  });
  const isSaveAble = !_.isEqual({ ...currentProject, ...editEntity }, currentProject);
  const renderFunc = column => rowData => _.get(rowData, column.field);
  const columns = useSegmentColumns(
    segmentColumnsOfProjectDetails,
    renderFunc,
    currentProject?.newportCategory,
  );
  return {
    strategicFitRmk,
    prioritizationRmk,
    isSaveAble,
    segments,
    shownEntity,
    editableFields,
    handleChange,
    onClick,
    columns,
    hasDatePickerView,
  };
};

export const StrategicEvalutation = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const {
    strategicFitRmk,
    prioritizationRmk,
    isSaveAble,
    segments,
    shownEntity,
    editableFields,
    handleChange,
    onClick,
    columns,
    hasDatePickerView,
  } = useData(itemRenderOptions);

  return (
    <Fragment>
      <SegmentTable segments={segments} columns={columns} />
      {strategicFitRmk}
      <PrioritizationGovernance
        value={shownEntity[PRIORITIZATION_GOVERNNCE_FIELD] || ''}
        name={PRIORITIZATION_GOVERNNCE_FIELD}
        isDisabled={
          hasDatePickerView ? true : !_.includes(editableFields, PRIORITIZATION_GOVERNNCE_FIELD)
        }
        handleChange={handleChange}
      />
      <PrioritizationType
        value={shownEntity[PRIORITIZATION_TYPE_FIELD] || ''}
        name={PRIORITIZATION_TYPE_FIELD}
        isDisabled={
          hasDatePickerView ? true : !_.includes(editableFields, PRIORITIZATION_TYPE_FIELD)
        }
        handleChange={handleChange}
      />
      {prioritizationRmk}
      {!hasDatePickerView && <SaveButton onClick={onClick} isDisabled={!isSaveAble} />}
    </Fragment>
  );
};
