import _ from 'lodash';
import React, { Fragment } from 'react';
import { Message } from '@shared/utils/message';
import { FieldSet } from '@shared/components/FieldSet/FieldSet';
import { getLabelOfProjectField, getLabelOfSegmentField } from '@main/constants/fieldsInfo';
import {
  projectDetailsProjectIdentifiers,
  projectDetailsProjectProperties,
  segmentDetailsSegmentProperties,
  PRECISE_NEW_PORT_ID_FIELD,
  NEWPORT_PROJECT_ID,
} from '@main/constants/projectOptions';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';
import { linkNewPort } from '@main/constants/constants';

interface ProjectDetailsBasicInfoProps {
  project?: any;
  segment?: any;
  type?: any;
}

const createItems = (project, fields) =>
  _.map(fields, field => ({
    label: getLabelOfProjectField(field),
    value: _.get(project, field),
    type: field === PRECISE_NEW_PORT_ID_FIELD ? 'link' : 'text',
    url: linkNewPort + _.get(project, NEWPORT_PROJECT_ID),
    field,
  }));

const createItemsForSegment = (segment, fields) =>
  _.map(fields, field => ({
    label: getLabelOfSegmentField(field),
    value: _.get(segment, field),
    type: '',
    url: '',
    field,
  }));

const category = value => {
  if (value !== undefined && value !== null && value !== '') {
    return value;
  }
};

export const ProjectDetailsBasicInfo = (props: ProjectDetailsBasicInfoProps) => {
  const { project, segment, type = 'projects' } = props;

  const identifiers = createItems(project, projectDetailsProjectIdentifiers);
  const newportCat = identifiers.find(item => item.field === 'newportCategory')?.value;
  const value = category(newportCat);
  const properties = createItems(project, projectDetailsProjectProperties);
  const propertiesSegment = createItemsForSegment(segment, segmentDetailsSegmentProperties);
  const classes = useProjectDetailsStyle();
  return (
    <Fragment>
      <FieldSet
        items={identifiers}
        custmerClass={classes.identifiersStyle}
        fieldSetText={Message.projectDetail.projectIdentifiers}
        type={type}
      />

      <div className={classes.container}>
        <FieldSet
          items={properties}
          custmerClass={classes.propertiesStyle}
          type={type}
          newCatogry={value}
        />
        {type == 'segments' && (
          <FieldSet
            items={propertiesSegment}
            custmerClass={classes.propertiesSegmentStyle}
            type={type}
          />
        )}
      </div>
    </Fragment>
  );
};
