import { makeStyles, createStyles } from '@material-ui/core/styles';

export const useProjectDetailsStyle = makeStyles(() =>
  createStyles({
    root: {
      width: '100%',
      paddingTop: '65px',
      overflow: 'hidden',
    },
    button: {
      marginLeft: '67%',
      marginTop: '1%',
    },
    segmentTable: {
      width: '96%',
      float: 'left',
      marginLeft: '3%',
    },
    strategicFitRmk: {
      marginTop: '1%',
    },
    prioritizationRmk: {
      marginTop: '25px',
    },
    viewOlderVersion: {
      display: 'block',
      overflow: 'auto',
      float: 'right',
    },
    projectDetailWithDatePicker: {
      marginTop: '48px !important',
    },
    identifiersStyle: {
      width: '30% !important',
    },
    propertiesStyle: {
      width: '60% !important',
      border: '0px !important',
      marginTop: '26px !important',
      marginLeft: '3% !important',
    },
    propertiesSegmentStyle: {
      width: '60% !important',
      border: '0px !important',
      marginTop: '-1px !important',
      marginLeft: '3% !important',
    },
    container: {
      display: 'flex',
      flexDirection: 'column',
    },
    tableTitle: {
      float: 'left',
      marginLeft: '3%',
      marginBottom: '1%',
      fontSize: '1.25rem',
      fontWeight: 500,
      width: '90%',
    },
    financialTableCell: {
      float: 'right',
    },
  }),
);
