import React from 'react';
import { useHistory } from 'react-router-dom';
import { Message } from '@shared/utils/message';
import { BreadCrumbs } from '@main/components/BreadCrumbs/BreadCrumbs';
import { ScoreContainer } from '@main/components/ScoreContainer/ScoreContainer';
import { SegmentTable, useSegmentColumns } from './indexUtils';
import Button from '@material-ui/core/Button';
import DateUtils from '@shared/utils/dateUtils';
import { segmentColumnsOfProjectDetails } from '@main/constants/segmentOptions';
import { ProjectDetailsBasicInfo } from './ProjectDetailsBasicInfo';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';

type ptrsPanelProps = {
  itemRenderOptions: {
    id: string;
    currentProject: {
      [propName: string]: any;
      id: string;
      rsPtrsScore: number;
      fsPtrsScore: number;
      ftPtrsScore: number;
      overallPtrsScore: number;
    };
    segments: { [propName: string]: any };
    textProjectDetails: string;
  };
};

const BreadCrumb = ({ textProjectDetails }: { textProjectDetails: string }) => {
  const linkItems = [
    { path: '/', text: Message.masterList.masterListLink },
    { path: null, text: textProjectDetails },
  ];
  return <BreadCrumbs items={linkItems} />;
};

const useData = itemRenderOptions => {
  const history = useHistory();
  const { id, currentProject, segments, hasDatePickerView, textProjectDetails } = itemRenderOptions;

  const goToPtrsAssessment = () => {
    history.push(`/project/${id}/ptrs`);
  };
  const goToCompareView = () => {
    const date = new Date();
    date.setMonth(date.getMonth() - 3);
    const dateString = DateUtils.getDateString(date, 'yyyy-MM-dd');
    window.open(`/project/${id}/at-date/${dateString}`, '_blank');
  };

  const columns = useSegmentColumns(
    segmentColumnsOfProjectDetails,
    hasDatePickerView,
    currentProject?.newportCategory,
  );
  return {
    currentProject,
    segments,
    columns,
    goToPtrsAssessment,
    goToCompareView,
    textProjectDetails,
    hasDatePickerView,
  };
};

export const ProjectDetail = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const classes = useProjectDetailsStyle();
  const {
    currentProject,
    segments,
    columns,
    goToPtrsAssessment,
    goToCompareView,
    textProjectDetails,
    hasDatePickerView,
  } = useData(itemRenderOptions);
  return (
    <div style={{ width: '100%' }}>
      <BreadCrumb textProjectDetails={textProjectDetails} />
      <ProjectDetailsBasicInfo project={currentProject} />
      {!hasDatePickerView && (
        <div className={classes.viewOlderVersion}>
          <Button variant="outlined" onClick={goToCompareView}>
            {Message.compare.viewOlderVersion}
          </Button>
        </div>
      )}
      <SegmentTable segments={segments} columns={columns} title="Segments" />
      <ScoreContainer
        type="projects"
        data={currentProject}
        hasButton={!hasDatePickerView}
        onClick={goToPtrsAssessment}
        buttonText={Message.projectDetail.updatePtrs}
      />
    </div>
  );
};
