import _ from 'lodash';
import React, { Fragment } from 'react';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';
import { TableComponent } from '@shared/components/TableComponent/TableComponent';
import { isLink, addLink } from '@main/modules/matserListUtil';
import { cellStyle } from '@main/constants/constants';
import { FIELD_ORDER, getFieldsInfoOfSegment } from '@main/constants/fieldsInfo';
import { sortByKey } from '@shared/utils/functionUtils';

export const SegmentTable = ({
  segments,
  columns,
  title,
}: {
  segments: any;
  columns: any;
  title?: string;
}) => {
  const classes = useProjectDetailsStyle();
  const tableOptions = {
    columns,
    data: segments,
    maxBodyHeight: '20vh',
    toolbar: false,
  };
  return (
    <Fragment>
      <h6 className={classes.tableTitle}>{title}</h6>
      <div className={classes.segmentTable}>
        <TableComponent itemRenderOptions={tableOptions} />
      </div>
    </Fragment>
  );
};

export const useSegmentColumns = (segmentColumns, hasDatePickerView, category) => {
  const segmentColumnsInfo = getFieldsInfoOfSegment();
  const columns = _.map(segmentColumns, col => {
    const column = segmentColumnsInfo[col];
    return {
      ...column,
      cellStyle,
      hidden:
        column?.field === 'registrationStatus' && category === 'New Formulation Proof of Concept'
          ? true
          : false,
      render:
        isLink(column?.field, 'segments') && !hasDatePickerView
          ? addLink(column, 'segments')
          : column?.render,
    };
  });
  return sortByKey(columns, FIELD_ORDER);
};
