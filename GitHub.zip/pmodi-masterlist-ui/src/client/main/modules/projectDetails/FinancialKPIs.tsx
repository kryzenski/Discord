import React from 'react';
import _ from 'lodash';
import CustomTable from '@shared/components/TableComponent/CustomTable';
import { FinancialKPIColumns } from '@main/constants/projectOptions';
import { getStringFromNumberWithThousandsSeparator } from '@shared/utils/numberUtils';
import { getFieldsInfoOfProject } from '@main/constants/fieldsInfo';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';

type ptrsPanelProps = {
  itemRenderOptions: {
    id: string;
    currentProject: { [propName: string]: any };
  };
};

const createData = (name, values) => {
  return { name, values };
};

const columnsInfo = getFieldsInfoOfProject();
const getRows = projects => {
  return _.map(FinancialKPIColumns, col => {
    return createData(_.get(columnsInfo[col], 'label'), [
      getStringFromNumberWithThousandsSeparator(_.get(projects, col)),
    ]);
  });
};

export const FinancialKPIs = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const projects = itemRenderOptions.currentProject;
  const classes = useProjectDetailsStyle();
  const rows = getRows(projects);
  return <CustomTable rows={rows} customerTableCellClass={classes.financialTableCell} />;
};
