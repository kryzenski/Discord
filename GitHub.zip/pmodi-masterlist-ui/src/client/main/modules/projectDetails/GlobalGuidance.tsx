import _ from 'lodash';
import { useDispatch } from 'react-redux';
import React, { useCallback, Fragment } from 'react';

import { SaveButton } from '@shared/components/Buttons/SaveButton';
import { PROJECT_ID } from '@main/constants/projectOptions';
import { typeDispatch } from '@main/stateManagement/store';
import { createTextAreaField } from '@main/modules/matserListUtil';
import { globalGuidanceFields } from '@main/constants/projectOptions';

type ptrsPanelProps = {
  itemRenderOptions: {
    id: string;
    currentProject: { fieldName: string; auditLogFieldNames: [] };
    editableFields?: Array<string>;
  };
};

const useData = itemRenderOptions => {
  const dispatch = useDispatch<typeDispatch>();
  const {
    id,
    currentProject: projects,
    editableFields,
    hasAuditLog,
    hasDatePickerView,
  } = itemRenderOptions;
  const version = _.get(projects, 'version');
  const [editEntity, setEntity] = React.useState({ version });
  const setEntityCallback = useCallback((arg: any) => setEntity(arg), []);
  const [shownEntity, setShownEntity] = React.useState({ ...projects });
  const setShownEntityCallback = useCallback((arg: any) => setShownEntity(arg), []);
  const isSaveAble = !_.isEqual({ ...projects, ...editEntity }, projects);

  const handleChange = event => {
    const { value, name } = event.target;
    const newShownEntity = { ...shownEntity };
    newShownEntity[name] = value;
    setShownEntityCallback(newShownEntity);
    const newEntity = { ...editEntity };
    newEntity[name] = value;
    setEntityCallback(newEntity);
  };

  const updateProject = () => {
    dispatch.MasterList.updateProject({ entity: editEntity, id: projects[PROJECT_ID] });
  };

  const fields = _.map(globalGuidanceFields, fieldName =>
    createTextAreaField({
      id,
      fieldName,
      shownEntity,
      editableFields,
      handleChange,
      hasAuditLog: hasDatePickerView ? false : hasAuditLog,
      hasDatePickerView,
    }),
  );

  return {
    fields,
    isSaveAble,
    updateProject,
    hasDatePickerView,
  };
};

export const GlobalGuidance = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const { fields, isSaveAble, updateProject, hasDatePickerView } = useData(itemRenderOptions);

  return (
    <Fragment>
      {fields}
      {!hasDatePickerView && <SaveButton onClick={updateProject} isDisabled={!isSaveAble} />}
    </Fragment>
  );
};
