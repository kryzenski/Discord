import React, { Fragment } from 'react';
import { Message } from '@shared/utils/message';
import { TextArea } from '@shared/components/TextField/TextArea';
import {
  NEW_PORT_OBJECTIVE_FIELD,
  NEW_PORT_PRODUCT_PROFILE_FIELD,
  NEW_PORT_SUCCESS_FACTORS_FIELD,
} from '@main/constants/projectOptions';
import _ from 'lodash';

type ptrsPanelProps = {
  itemRenderOptions: {
    id: string;
    currentProject: { [propName: string]: any };
  };
};

const textArea = (name, label, projects) => {
  return (
    <TextArea value={_.get(projects, name) || ''} name={name} isDisabled={true} label={label} />
  );
};

const ProjectRationale = ({ projects }: { projects: { [propName: string]: any } }) => {
  return textArea(NEW_PORT_OBJECTIVE_FIELD, Message.projectDetail.projectRationale, projects);
};

const ProductProfile = ({ projects }: { projects: { [propName: string]: any } }) => {
  return textArea(NEW_PORT_PRODUCT_PROFILE_FIELD, Message.projectDetail.productProfile, projects);
};

const ImportantSuccessFactors = ({ projects }: { projects: { [propName: string]: any } }) => {
  return textArea(
    NEW_PORT_SUCCESS_FACTORS_FIELD,
    Message.projectDetail.importantSuccessFactors,
    projects,
  );
};

export const Projectinformation = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const projects = itemRenderOptions.currentProject;

  return (
    <Fragment>
      <ProjectRationale projects={projects} />
      <ProductProfile projects={projects} />
      <ImportantSuccessFactors projects={projects} />
    </Fragment>
  );
};
