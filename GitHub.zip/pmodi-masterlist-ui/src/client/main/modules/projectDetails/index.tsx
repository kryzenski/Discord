import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import LoaderComponent from '@shared/components/LoaderComponent/LoaderComponent';
import DatePicker from '@shared/components/DatePicker/DatePicker';
import { ProjectDetail } from './ProjectDetail';
import { StrategicEvalutation } from './StrategicEvalutation';
import { GlobalGuidance } from './GlobalGuidance';
import { Projectinformation } from './Projectinformation';
import { FinancialKPIs as FinancialKPIsPanel } from './FinancialKPIs';
import { useProjectDetailsStyle } from './UseProjectDetailsStyle';
import CssBaseline from '@material-ui/core/CssBaseline';
import { Message } from '@shared/utils/message';
import { useProject } from '@main/modules/projectUtils';

type projectsDetailsProps = {
  detailsOption?: any;
  isLoading?: boolean;
};

export default function projectDetail() {
  const { isLoading, detailsOption, date, id } = useProject({ hasAuditLog: true });
  const [allExpanded, setAllExpanded] = useState(true);
  const classes = useProjectDetailsStyle();
  const dispatch = useDispatch<typeDispatch>();
  const getNewItemBySelectedData = date => {
    dispatch.MasterList.getProjectDataByDate({ id, date });
    dispatch.MasterList.fetchSegmentByDate({ id, date });
  };

  const onExpandAllClick = () => {
    setAllExpanded(!allExpanded);
  };

  const ProjectDetails = ({ isLoading, detailsOption }: projectsDetailsProps) => {
    const classes = useProjectDetailsStyle();
    return (
      <ExpansionPanelView
        text={Message.projectDetail.details}
        ItemRender={isLoading ? LoaderComponent : ProjectDetail}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        shownExpandIcon={false}
        showExpandAll={true}
        expandOverride={allExpanded}
        expandAllClick={onExpandAllClick}
        cssClass={detailsOption.hasDatePickerView ? classes.projectDetailWithDatePicker : ''}
      ></ExpansionPanelView>
    );
  };

  const ProjectInformation = ({ isLoading, detailsOption }: projectsDetailsProps) => {
    return (
      <ExpansionPanelView
        ItemRender={isLoading ? LoaderComponent : Projectinformation}
        text={Message.projectDetail.information}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const GlobalGuidanceAndIpCheck = ({ isLoading, detailsOption }: projectsDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.projectDetail.globalGuidance}
        ItemRender={isLoading ? LoaderComponent : GlobalGuidance}
        itemRenderOptions={detailsOption}
        expandOverride={allExpanded}
        defaultExpanded={true}
      ></ExpansionPanelView>
    );
  };

  const StrategicEvaluationAndPrioritization = ({
    isLoading,
    detailsOption,
  }: projectsDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.projectDetail.strategic}
        ItemRender={isLoading ? LoaderComponent : StrategicEvalutation}
        itemRenderOptions={detailsOption}
        expandOverride={allExpanded}
        defaultExpanded={true}
      ></ExpansionPanelView>
    );
  };

  const FinancialKPIs = ({ isLoading, detailsOption }: projectsDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.projectDetail.financial}
        ItemRender={isLoading ? LoaderComponent : FinancialKPIsPanel}
        itemRenderOptions={detailsOption}
        expandOverride={allExpanded}
        defaultExpanded={true}
      ></ExpansionPanelView>
    );
  };
  const globalDispatch = useDispatch<typeDispatch>();
  useEffect(() => {
    return () => globalDispatch.MasterList.setCurrentItem({ item: {}, type: 'segments' });
  }, []);
  return (
    <div className={classes.root}>
      <CssBaseline />
      {detailsOption.hasDatePickerView && (
        <DatePicker
          value={date}
          onClick={getNewItemBySelectedData}
          title={Message.compare.projectViewHeader}
        />
      )}
      <ProjectDetails isLoading={isLoading} detailsOption={detailsOption} />
      <ProjectInformation isLoading={isLoading} detailsOption={detailsOption} />
      <GlobalGuidanceAndIpCheck isLoading={isLoading} detailsOption={detailsOption} />
      <StrategicEvaluationAndPrioritization isLoading={isLoading} detailsOption={detailsOption} />
      <FinancialKPIs isLoading={isLoading} detailsOption={detailsOption} />
    </div>
  );
}
