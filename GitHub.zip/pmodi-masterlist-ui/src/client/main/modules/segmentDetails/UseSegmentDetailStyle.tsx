import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';

export const useSegmentDetailStyle = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: '100%',
      paddingTop: '65px',
      overflow: 'hidden',
    },
    scoreContainer: {
      float: 'none',
      marginTop: '-1%',
    },

    subTableTitle: {
      fontSize: '16px',
      marginLeft: '-3%',
      marginTop: '1%',
    },
    detailPanel: {
      marginLeft: '4%',
      marginTop: '1%',
      borderRadius: '4px',
      borderColor: '#737373',
      width: '94%',
    },
    subTable: {
      marginTop: '-1%',
      marginBottom: '3%',
    },
    gapContainer: {
      width: '65% !important',
      overflow: 'hidden',
      marginLeft: '5%',
    },
    panelTitle: {
      marginBottom: '0',
      fontSize: '1.25rem',
      fontWeight: 500,
      marginTop: '1%',
      marginLeft: '3%',
    },
    propertyLabel: {
      fontSize: '15px !important',
      paddingTop: '2%',
      wordBreak: 'break-all',
      color: 'rgba(0, 0, 0, 0.87)',
    },
    newPortTitle: {
      marginLeft: '14%',
      display: 'inline',
    },
    regPrimeTitle: {
      marginLeft: '18%',
      display: 'inline',
    },
    textField: {
      width: '90%',
      marginTop: '0%',
    },
    strategicFitRmk: {
      marginTop: theme.spacing(5),
    },
    prioritizationRmk: {
      marginTop: '-1%',
    },
    newPortTextField: {
      width: '19%',
      marginLeft: '14%',
      marginTop: '-1.5%',
    },
    newPortPanelOfMilestones: {
      marginLeft: '5%',
    },
    regPrimeNumberText: {
      width: '35%',
      marginLeft: '1%',
      marginTop: '-2%',
    },
    zNumberFields: {
      display: 'inline-flex',
      marginTop: '1%',
      marginLeft: '5%',
    },
    sequenceNumberFields: {
      display: 'inline-flex',
      alignItems: 'baseline',
      marginTop: '1%',
    },
    linkRegulatoryAction: {
      marginLeft: '-3%',
    },
    dialogPanel: {
      width: '33%',
      marginLeft: '5%',
    },
    dialogTextField: {
      marginTop: '3%',
    },
    dialogText: {
      marginTop: '-5%',
      marginLeft: '25%',
      width: '70%',
    },
    savePrecise: {
      marginLeft: '37%',
    },
    auditLogOfMilestone: {
      marginTop: '-2%',
      marginLeft: '6%',
    },
    preciseTextField: {
      width: '19%',
      marginLeft: '5%',
      marginTop: '-1.5%',
    },
  }),
);
