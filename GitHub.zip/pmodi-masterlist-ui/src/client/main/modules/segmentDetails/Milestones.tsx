import React, { Fragment } from 'react';
import { UseMilestones } from './UseMilestones';
type MilestonesProps = {
  itemRenderOptions: {
    currentSegment: { [propName: string]: any; id: string };
    milestonesOfSegment: any;
    editableFields: Array<string>;
  };
};

export const Milestones = ({ itemRenderOptions }: MilestonesProps): JSX.Element => {
  const { newPortPanel, regprimePanel } = UseMilestones(
    itemRenderOptions.currentSegment,
    itemRenderOptions.milestonesOfSegment,
    itemRenderOptions.editableFields,
  );
  return (
    <Fragment>
      {newPortPanel}
      {regprimePanel}
    </Fragment>
  );
};
