import React from 'react';
import { BreadCrumbs } from '@main/components/BreadCrumbs/BreadCrumbs';
import { Message } from '@shared/utils/message';
import { ProjectDetailsBasicInfo } from '@main/modules/projectDetails/ProjectDetailsBasicInfo';

type ptrsPanelProps = {
  itemRenderOptions: {
    currentSegment: { [propName: string]: any; id: string };
    detailsText: string;
    currentProject: { [propName: string]: any; id: string };
    linkProjectDetails: string;
  };
};

type BreadCrumbProps = {
  linkProjectDetails: string;
  projectID: string;
  textSegment: string;
};

const BreadCrumb = ({ projectID, linkProjectDetails, textSegment }: BreadCrumbProps) => {
  const linkItems = [
    { path: '/', text: Message.masterList.masterListLink },
    { path: `/project/${projectID}`, text: linkProjectDetails },
    { path: null, text: textSegment },
  ];
  return <BreadCrumbs items={linkItems} />;
};

export const SegmentDetail = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const { detailsText, currentProject, linkProjectDetails, currentSegment } = itemRenderOptions;
  const { id } = currentProject;
  return (
    <div style={{ width: '100%' }}>
      <BreadCrumb
        projectID={id}
        linkProjectDetails={linkProjectDetails}
        textSegment={detailsText}
      />
      <ProjectDetailsBasicInfo type="segments" project={currentProject} segment={currentSegment} />
    </div>
  );
};
