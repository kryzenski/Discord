import React, { Fragment } from 'react';

import {
  PrioritizationType,
  PrioritizationGovernance,
  createTextAreaField,
} from '@main/modules/matserListUtil';
import {
  PRIORITIZATION_TYPE_FIELD,
  PRIORITIZATION_REMARK_FIELD,
  PRIORITIZATION_GOVERNNCE_FIELD,
} from '@main/constants/projectOptions';

type ptrsPanelProps = { itemRenderOptions: { currentProject: { [propName: string]: any } } };

export const StrategicEvalutation = ({
  itemRenderOptions: { currentProject },
}: ptrsPanelProps): JSX.Element => (
  <Fragment>
    <PrioritizationGovernance
      isDisabled
      name={PRIORITIZATION_GOVERNNCE_FIELD}
      value={currentProject[PRIORITIZATION_GOVERNNCE_FIELD] || ''}
    />
    <PrioritizationType
      isDisabled
      name={PRIORITIZATION_TYPE_FIELD}
      value={currentProject[PRIORITIZATION_TYPE_FIELD] || ''}
    />
    {createTextAreaField({ fieldName: PRIORITIZATION_REMARK_FIELD, shownEntity: currentProject })}
  </Fragment>
);
