import React, { useState, useEffect } from 'react';
import { ExpansionPanelView } from '@shared/components/ExpansionPanel/ExpansionPanelView';
import LoaderComponent from '@shared/components/LoaderComponent/LoaderComponent';
import { SegmentDetail as SegmentDetailPanel } from './SegmentDetail';
import { GapInformation } from './GapInformation';
// import { ProjectCost } from './ProjectCost';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import { Milestones } from './Milestones';
import { PtrsScoreAndQuickScan } from './PtrsScoreAndQuickScan';
import { StrategicEvalutation } from './StrategicEvalutation';
import { useSegmentDetailStyle } from './UseSegmentDetailStyle';
import CssBaseline from '@material-ui/core/CssBaseline';
import { Message } from '@shared/utils/message';
import { useSegment } from '@main/modules/segmentUtils';
// import _ from 'lodash';

type segmentDetailsProps = {
  detailsOption?: any;
  isLoading?: boolean;
  detailsText?: string;
  quickscanAssessments?: any;
  preciseCostListOfSegment?: any;
  //allExpanded?: boolean;
  //onExpandAllClick?: any;
};
export default function segmentDetail() {
  const classes = useSegmentDetailStyle();
  const {
    detailsOption,
    isLoading,
    quickscanAssessments,
    // preciseCostListOfSegment
  } = useSegment({
    hasAuditLog: true,
  });
  const [allExpanded, setAllExpanded] = useState(true);

  const onExpandAllClick = () => {
    setAllExpanded(!allExpanded);
  };
  const Details = ({
    detailsOption,
    isLoading,
  }: //allExpanded,
  //onExpandAllClick,
  segmentDetailsProps) => {
    return (
      <ExpansionPanelView
        text={detailsOption.detailsText}
        ItemRender={isLoading ? LoaderComponent : SegmentDetailPanel}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        shownExpandIcon={false}
        showExpandAll={true}
        expandOverride={allExpanded}
        expandAllClick={onExpandAllClick}
      ></ExpansionPanelView>
    );
  };

  const PtrsScoreAndQuickScanPanel = ({
    detailsOption,
    isLoading,
  }: //allExpanded,
  segmentDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.segmentDetail.ptrsText}
        ItemRender={isLoading ? LoaderComponent : PtrsScoreAndQuickScan}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const GapMappingAndInfoPanel = ({
    quickscanAssessments,
    isLoading,
  }: //allExpanded,
  segmentDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.segmentDetail.gapMapping}
        ItemRender={isLoading ? LoaderComponent : GapInformation}
        itemRenderOptions={quickscanAssessments}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const MilestonesPanel = ({ detailsOption, isLoading }: segmentDetailsProps) => {
    return (
      <ExpansionPanelView
        ItemRender={isLoading ? LoaderComponent : Milestones}
        text={Message.segmentDetail.milestones}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  // const ProjectCosts = ({
  //   preciseCostListOfSegment,
  //   isLoading,
  //   //allExpanded,
  //   detailsOption,
  // }: segmentDetailsProps) => {
  //   const costsOptions = {
  //     preciseCostListOfSegment,
  //     segmentId:
  //       detailsOption && detailsOption.currentSegment ? detailsOption.currentSegment.id : null,
  //     newportCurrency: _.get(detailsOption, 'currentSegment.newportCurrency', 'USD'),
  //   };
  //   return (
  //     <ExpansionPanelView
  //       ItemRender={isLoading ? LoaderComponent : ProjectCost}
  //       text={Message.segmentDetail.projectCosts}
  //       itemRenderOptions={costsOptions}
  //       defaultExpanded={true}
  //       expandOverride={allExpanded}
  //     ></ExpansionPanelView>
  //   );
  // };
  const StrategicEvaluationAndPrioritization = ({
    detailsOption,
    isLoading,
  }: //allExpanded,
  segmentDetailsProps) => {
    return (
      <ExpansionPanelView
        text={Message.segmentDetail.strategic}
        ItemRender={isLoading ? LoaderComponent : StrategicEvalutation}
        itemRenderOptions={detailsOption}
        defaultExpanded={true}
        expandOverride={allExpanded}
      ></ExpansionPanelView>
    );
  };

  const globalDispatch = useDispatch<typeDispatch>();
  useEffect(() => {
    return () => globalDispatch.MasterList.setCurrentItem({ item: {}, type: 'segments' });
  }, []);
  return (
    <div className={classes.root}>
      <CssBaseline />
      <Details
        isLoading={isLoading}
        detailsOption={detailsOption}
        //onExpandAllClick={onExpandAllClick}
      />
      <PtrsScoreAndQuickScanPanel
        isLoading={isLoading}
        detailsOption={detailsOption}
        //allExpanded={allExpanded}
      />
      <GapMappingAndInfoPanel
        isLoading={isLoading}
        quickscanAssessments={quickscanAssessments}
        //allExpanded={allExpanded}
      />
      <MilestonesPanel
        isLoading={isLoading}
        detailsOption={detailsOption}
        //allExpanded={allExpanded}
      />
      {/* <ProjectCosts
        isLoading={isLoading}
        preciseCostListOfSegment={preciseCostListOfSegment}
        //allExpanded={allExpanded}
        detailsOption={detailsOption}
      /> */}
      <StrategicEvaluationAndPrioritization
        isLoading={isLoading}
        detailsOption={detailsOption}
        //allExpanded={allExpanded}
      />
    </div>
  );
}
