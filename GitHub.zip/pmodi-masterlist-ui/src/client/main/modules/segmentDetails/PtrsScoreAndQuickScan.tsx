import _ from 'lodash';
import React, { Fragment } from 'react';
import { useHistory } from 'react-router-dom';
import { Message } from '@shared/utils/message';
import { ScoreContainer } from '@main/components/ScoreContainer/ScoreContainer';
import { useSegmentDetailStyle } from './UseSegmentDetailStyle';
import { QuickScanResult } from '@main/components/QuickScanResultTable/QuickScanResult';
import { SEGMENT_ID } from '@main/constants/segmentOptions';
import { getQuickScanData } from '@main/modules/matserListUtil';
import { getItemValueForProp } from '@main/modules/segmentUtils';
import { assessmentDetailPanel } from '@main/hook/SubTablePanelOfQuickSacn/useDetailPanel';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '../../stateManagement/store';

type ptrsPanelProps = {
  itemRenderOptions: {
    currentSegment: { [propName: string]: any };
  };
};

const useData = itemRenderOptions => {
  const history = useHistory();
  const { currentSegment, quickscanAssessments, quickscanMitigation } = itemRenderOptions;
  const segmentId = getItemValueForProp(currentSegment, SEGMENT_ID);
  const quickScanData = getQuickScanData(quickscanAssessments, quickscanMitigation);

  const goToPtrsAssessment = () => {
    history.push(`/segment/${segmentId}/ptrs`);
  };

  return { currentSegment, goToPtrsAssessment, quickScanData };
};

export const PtrsScoreAndQuickScan = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const dispatch = useDispatch<typeDispatch>();
  const classes = useSegmentDetailStyle();
  const { currentSegment, goToPtrsAssessment, quickScanData } = useData(itemRenderOptions);
  const detailPanel = assessmentDetailPanel();
  const segmentData = {
    quickScanNotApplicableReason: currentSegment?.quickScanNotApplicableReason,
    isQuickScanNotApplicable: currentSegment?.isQuickScanNotApplicable,
  };
  const onLinkAssessement = (assessmentid: number | null) => {
    const id = _.toString(assessmentid);
    const updatedSegment = { ...currentSegment };
    const arr = _.split(updatedSegment.quickscanAssessmentId, ',');
    let flag = 0;
    _.forEach(arr, item => {
      if (id === item) flag = 1;
    });
    if (flag === 0) {
      const quickScanIds = updatedSegment.quickscanAssessmentId
        ? `${updatedSegment.quickscanAssessmentId},${id}`
        : id;
      updatedSegment.quickscanAssessmentId = quickScanIds;
      updatedSegment.isQuickScanNotApplicable = false;
      updatedSegment.quickScanNotApplicableReason = '';
      const payload = { entity: updatedSegment, id: updatedSegment.id };
      // TODO: error handling does not work e.g. when using unknown ids. In the console
      // an error thrown in redux leads to the follwing output:
      // "Error: Invalid hook call. Hooks can only be called inside of the body of a function component."
      // TODO: update call does not trigger reload
      dispatch.MasterList.updateSegment(payload);
    }
  };
  const onSaveReason = reason => {
    const updatedSegment = { ...currentSegment };
    updatedSegment.isQuickScanNotApplicable = reason.notApplicable;
    updatedSegment.quickScanNotApplicableReason = reason.validReason;
    updatedSegment.quickscanAssessmentId = null;
    const payload = { entity: updatedSegment, id: updatedSegment.id };
    dispatch.MasterList.updateSegment(payload);
  };
  const onDeleteQuickScanId = quickScanDeletedIds => {
    const updatedSegment = { ...currentSegment };
    updatedSegment.quickscanAssessmentId = quickScanDeletedIds === '' ? null : quickScanDeletedIds;
    const payload = { entity: updatedSegment, id: updatedSegment.id };
    dispatch.MasterList.updateSegment(payload);
  };
  return (
    <Fragment>
      <ScoreContainer
        data={currentSegment}
        type="segments"
        hasButton={true}
        buttonText={Message.segmentDetail.edit}
        onClick={goToPtrsAssessment}
        custmerClass={classes.scoreContainer}
      />
      <QuickScanResult
        quickScanData={quickScanData}
        detailPanel={detailPanel}
        quickScanAssessmentId={currentSegment?.quickscanAssessmentId}
        onLinkAssessement={onLinkAssessement}
        onSaveReason={onSaveReason}
        segmentData={segmentData}
        type="segment"
        onDeleteQuickScanId={onDeleteQuickScanId}
      />
    </Fragment>
  );
};
