import _ from 'lodash';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '@main/stateManagement/store';
import React, { Fragment, useState } from 'react';
import { getLabelOfSegmentField } from '@main/constants/fieldsInfo';
import { useSegmentDetailStyle } from './UseSegmentDetailStyle';
import { Button } from '@material-ui/core';
import {
  NewPortFieldsOfMilestones,
  REGPRIME_ZNUMBER,
  REGPRIME_SEQUENCE_NUMBER,
  numbesOfMilestones,
  PreciseFieldsOfMilestones,
} from '@main/constants/segmentOptions';
import { Message } from '@shared/utils/message';
import { SimpleDialog } from '@shared/components/Dialog/SimpleDialog';
import { isNotEmptyValue, isEmptyValue } from '@shared/utils/functionUtils';
import { createTextField } from '@main/modules/matserListUtil';
import { NumberTextField } from '@shared/components/TextField/NumberTextField';
import InputLabel from '@material-ui/core/InputLabel';
import { SaveButton } from '@shared/components/Buttons/SaveButton';
import { DATE_PATTERN } from '@shared/utils/functionUtils';
import { AuditLog } from '@main/components/AuditLog/AuditLog';
import { BasicTextField } from '~/shared/components/TextField/BasicTextField';
import { MileStoneItems } from '../../constants/constants';
import { useGapContainerStyle } from '../../components/GapContainer/UseGapContainerStyle';

const useNewPortPanel = segments => {
  const classes = useSegmentDetailStyle();
  const newPortField = _.map(NewPortFieldsOfMilestones, fieldName =>
    createTextField({
      fieldName: fieldName,
      entity: segments,
      textFiledClass: classes.newPortTextField,
      isDisabled: true,
      label: getLabelOfSegmentField(fieldName),
      customerClass: classes.newPortPanelOfMilestones,
    }),
  );
  return (
    <Fragment>
      <h6 className={classes.panelTitle}>{Message.segmentDetail.newPort}</h6>
      {newPortField}
    </Fragment>
  );
};

type DialogContentProps = {
  itemRenderOptions: {
    editEntity: any;
    isValidate?: boolean;
    editableFields?: Array<string>;
    handleChange?: (event: object) => void;
  };
};

const DialogContent = ({ itemRenderOptions }: DialogContentProps): JSX.Element => {
  const classes = useSegmentDetailStyle();
  const { editEntity, handleChange, editableFields, isValidate } = itemRenderOptions;
  return (
    <Fragment>
      {createTextField({
        fieldName: REGPRIME_ZNUMBER,
        entity: editEntity,
        textFiledClass: classes.dialogText,
        isDisabled: !_.includes(editableFields, REGPRIME_ZNUMBER),
        label: getLabelOfSegmentField(REGPRIME_ZNUMBER),
        customerClass: classes.dialogTextField,
        handleChange,
        isValidate: !isValidate[REGPRIME_ZNUMBER],
      })}
      <div className={classes.dialogTextField}>
        <InputLabel className={classes.propertyLabel}>
          {getLabelOfSegmentField(REGPRIME_SEQUENCE_NUMBER)}
        </InputLabel>
        <NumberTextField
          error={!isValidate[REGPRIME_SEQUENCE_NUMBER]}
          // helperText={isValidate ? '' : Message.validation.invalidNumber}
          handleChange={handleChange}
          value={editEntity[REGPRIME_SEQUENCE_NUMBER]}
          isDisabled={!_.includes(editableFields, REGPRIME_SEQUENCE_NUMBER)}
          name={REGPRIME_SEQUENCE_NUMBER}
          customerClass={classes.dialogText}
        />
      </div>
    </Fragment>
  );
};

const useDialog = (segments, editableFields) => {
  const classes = useSegmentDetailStyle();
  const dispatch = useDispatch<typeDispatch>();
  const [isOpen, setIsOpen] = useState(false);
  const initValidate = {
    regprimeZNumber: true,
    regprimeSequenceNumber: true,
  };
  const [isValidate, setValidate] = React.useState(initValidate);
  const handleClickOpen = () => {
    setIsOpen(true);
  };
  const handleClose = () => {
    setIsOpen(false);
  };
  const { id, version, regprimeZNumber, regprimeSequenceNumber } = segments;
  const [editEntity, setEntity] = React.useState({
    version,
    id,
    regprimeZNumber,
    regprimeSequenceNumber,
  });

  const handleChange = event => {
    const { value, name } = event.target;
    if (value.length > 7) {
      setValidate({ ...isValidate, [name]: false });
    } else {
      setValidate({ ...isValidate, [name]: true });
    }
    const newEntity = { ...editEntity, [name]: value.toUpperCase() };
    setEntity(newEntity);
  };

  const handleOK = () => {
    dispatch.MasterList.updateSegment({ entity: editEntity, id });
  };

  const itemRenderOptions = { editEntity, handleChange, isValidate, editableFields };
  const isAllValidate = _.every([isValidate], initValidate);
  const disableOKButton =
    (isAllValidate &&
      isNotEmptyValue(editEntity[REGPRIME_SEQUENCE_NUMBER]) &&
      isNotEmptyValue(editEntity[REGPRIME_ZNUMBER])) ||
    (isEmptyValue(editEntity[REGPRIME_SEQUENCE_NUMBER]) &&
      isEmptyValue(editEntity[REGPRIME_ZNUMBER]));

  const dialog = (
    <SimpleDialog
      hasButton={true}
      open={isOpen}
      title={Message.segmentDetail.linkRegulatoryAction}
      ItemRender={DialogContent}
      itemRenderOptions={itemRenderOptions}
      onClose={handleClose}
      handleCancel={handleClose}
      handleOK={handleOK}
      cancelText={Message.button.cancel}
      okText={Message.button.save}
      customerClass={classes.dialogPanel}
      disableOKButton={!disableOKButton}
    />
  );

  return { handleClickOpen, dialog };
};

const useNumberField = (segments, editableFields) => {
  const classes = useSegmentDetailStyle();
  const { handleClickOpen, dialog } = useDialog(segments, editableFields);
  return (
    <Fragment>
      {_.map(numbesOfMilestones, fieldName =>
        createTextField({
          fieldName,
          entity: segments,
          textFiledClass: classes.regPrimeNumberText,
          isDisabled: true,
          label: getLabelOfSegmentField(fieldName),
          customerClass:
            fieldName === REGPRIME_ZNUMBER ? classes.zNumberFields : classes.sequenceNumberFields,
        }),
      )}
      <Button variant="outlined" onClick={_.debounce(handleClickOpen, 300)}>
        {Message.segmentDetail.linkRegulatoryAction}
      </Button>
      {dialog}
    </Fragment>
  );
};

const useRegprimePanel = (segments, milestones, editableFields) => {
  const useItem = milestones => {
    return _.map(MileStoneItems, items => ({
      leftLabel: Message.milestone[items.left],
      leftValue: _.get(milestones, items.left),
      rightLabel: Message.milestone[items.right],
      rightValue: _.get(milestones, items.right),
    }));
  };
  const cropName = _.join(milestones?.cropNames, ',');
  const styles = useGapContainerStyle();
  const items = useItem(milestones);
  const classes = useSegmentDetailStyle();
  return (
    <Fragment>
      <h6 className={classes.panelTitle}>{Message.segmentDetail.regPrime}</h6>
      {useNumberField(segments, editableFields)}
      {milestones ? (
        <div style={{ paddingRight: '5%', paddingLeft: '5%' }}>
          {items?.map(item => (
            <div className={styles.details} key={item.leftLabel + 'divDetails'}>
              {item.leftLabel != null ? (
                <>
                  <div
                    className={styles.propertyLabelRegPrime}
                    key={item.leftLabel + 'propertyLabel'}
                  >
                    {item.leftLabel}
                  </div>
                  <div
                    className={styles.propertyValueRegPrime}
                    key={item.leftLabel + 'propertyValue'}
                  >
                    <BasicTextField
                      value={item.leftValue}
                      textFiledClass={item.rightLabel ? styles.textField : styles.textFieldLeft}
                      key={item.leftLabel}
                      isDisabled={true}
                    />
                  </div>
                </>
              ) : (
                ''
              )}

              <div
                className={styles.propertyLabelRegPrime}
                style={{ marginLeft: '3%' }}
                key={item.rightLabel + 'propertyLabel'}
              >
                {item.rightLabel}
              </div>
              {item.rightLabel && (
                <div
                  className={styles.propertyValueRegPrime}
                  key={item.rightLabel + 'propertyValue'}
                >
                  <BasicTextField
                    key={item.rightLabel}
                    value={item.rightLabel === 'Crop' ? cropName : item.rightValue}
                    textFiledClass={styles.textField}
                    isDisabled={true}
                  />
                </div>
              )}
            </div>
          ))}
          <div className={styles.details}>
            <div className={styles.propertyLabelRegPrime} style={{ width: '24%' }} key={'key'}>
              PLT
            </div>
            <div
              className={styles.propertyValueRegPrime}
              style={{ width: '100%' }}
              key={'propertyValue'}
            >
              <BasicTextField
                key={'key'}
                value={milestones?.productLineText}
                textFiledClass={styles.textField}
                isDisabled={true}
              />
            </div>
          </div>
          <div className={styles.details} style={{ marginBottom: '3%' }}>
            <div className={styles.propertyLabelRegPrime} style={{ width: '24%' }} key={'key'}>
              Crop
            </div>
            <div
              className={styles.propertyValueRegPrime}
              key={'propertyValue'}
              style={{ width: '100%' }}
            >
              <BasicTextField
                key={'key'}
                value={cropName}
                textFiledClass={styles.textField}
                isDisabled={true}
              />
            </div>
          </div>
        </div>
      ) : (
        ''
      )}
    </Fragment>
  );
};

const usePrecisePanel = (segments, editableFields) => {
  const classes = useSegmentDetailStyle();
  const dispatch = useDispatch<typeDispatch>();
  const initValidate = {
    submissionDate: true,
    launchDate: true,
  };
  const [isValidate, setValidate] = React.useState(initValidate);

  const { id, version, submissionDate, launchDate } = segments;
  const [editEntity, setEntity] = React.useState({
    version,
    id,
    submissionDate,
    launchDate,
  });
  const handleChange = event => {
    const { value, name } = event.target;
    if (DATE_PATTERN.test(value)) {
      setValidate({ ...isValidate, [name]: true });
    } else {
      setValidate({ ...isValidate, [name]: false });
    }
    const newEntity = { ...editEntity, [name]: value };
    setEntity(newEntity);
  };

  const preciseField = _.map(PreciseFieldsOfMilestones, fieldName =>
    createTextField({
      fieldName: fieldName,
      entity: editEntity,
      textFiledClass: classes.preciseTextField,
      isDisabled: !_.includes(editableFields, fieldName),
      label: getLabelOfSegmentField(fieldName),
      customerClass: classes.newPortPanelOfMilestones,
      handleChange,
      isValidate: !isValidate[fieldName],
      lableWithLog: true,
      auditLog: (
        <AuditLog
          id={id}
          customClass={classes.auditLogOfMilestone}
          paths={['segments']}
          fieldName={fieldName}
        />
      ),
    }),
  );
  const updateEntity = () => {
    dispatch.MasterList.updateSegment({ entity: editEntity, id });
  };
  const isAllValidate = _.every([isValidate], initValidate);
  const isSaveable = isAllValidate && !_.isEqual({ ...segments, ...editEntity }, segments);
  return (
    <Fragment>
      <h6 className={classes.panelTitle}>{Message.segmentDetail.precise}</h6>
      {preciseField}
      <SaveButton cssClass={classes.savePrecise} onClick={updateEntity} isDisabled={!isSaveable} />
    </Fragment>
  );
};

export const UseMilestones = (segments, milestones, editableFields) => {
  const newPortPanel = useNewPortPanel(segments);
  const regprimePanel = useRegprimePanel(segments, milestones, editableFields);
  const precisePanel = usePrecisePanel(segments, editableFields);
  return { newPortPanel, regprimePanel, precisePanel };
};
