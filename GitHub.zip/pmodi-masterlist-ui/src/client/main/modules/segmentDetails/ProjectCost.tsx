import React, { Fragment, useState } from 'react';
import _ from 'lodash';
import { SegmentCostListMap } from '@main/constants/segmentOptions';
import { isNotEmptyValue } from '@shared/utils/functionUtils';
import MaterialTable, { Column } from 'material-table';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import { Message } from '@shared/utils/message';
import { useDispatch } from 'react-redux';
import { typeDispatch } from '../../stateManagement/store';

type ptrsPanelProps = {
  itemRenderOptions: {
    segmentId: any;
    preciseCostListOfSegment: any;
    newportCurrency: string;
  };
};

const useStyles = makeStyles({
  tableContainer: {
    width: '92%',
    marginTop: '1%',
    marginBottom: '1%',
    border: '1px solid rgba(224, 224, 224, 1)',
    marginLeft: '3%',
  },
});

const formatPreciseData = itemRenderOptions => {
  const costList = itemRenderOptions.preciseCostListOfSegment;
  const currencyCode = itemRenderOptions.newportCurrency || 'EUR';
  const groupData = _.groupBy(costList, 'year');
  const years = _.keys(groupData);

  const names = _.keys(SegmentCostListMap);

  type RowData = { id: string; category: string; (years): any };

  const rows = names.map(category => {
    const catYearData = {};
    years.forEach(year => {
      const yearData = groupData[year][0];
      const categoryvalue = isNotEmptyValue(yearData[category]) ? yearData[category] : 0;
      catYearData[year] = categoryvalue;
    });
    return { id: category, category: _.get(SegmentCostListMap, category), ...catYearData };
  }) as RowData[];

  const yearTotals = {};
  for (const year in groupData) {
    yearTotals[year] = Object.keys(groupData[year][0]).reduce(
      (accumaltor, category) =>
        Object.keys(SegmentCostListMap).includes(category)
          ? accumaltor + groupData[year][0][category]
          : accumaltor,
      0,
    );
  }
  const totalRow = { id: 'total', category: 'Total Yearly Cost', ...yearTotals } as RowData;
  rows.push(totalRow);

  const columns = [
    { title: 'Category', field: 'category', editable: 'never', type: 'string' },
    ..._.keys(groupData).map(col => ({
      title: col,
      field: col,
      type: 'currency',
      currencySetting: {
        currencyCode,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      },
      validate: rowData =>
        rowData[col] < 0
          ? { isValid: false, helperText: Message.segmentDetail.projectCostValidationError }
          : true,
    })),
  ] as Column<RowData>[];

  const title = null;
  return { columns, data: [...rows], title };
};

export const ProjectCost = ({ itemRenderOptions }: ptrsPanelProps): JSX.Element => {
  const dispatch = useDispatch<typeDispatch>();
  const customClasses = useStyles();
  const [preciseData] = useState(formatPreciseData(itemRenderOptions));

  const handleDownloadFailure = (e: { message: any }) => {
    const msg = e ? e.message : 'Error downloading export';
    console.log('Error downloading export: ' + msg);
  };

  return (
    <Fragment>
      <Paper elevation={1} className={customClasses.tableContainer}>
        <MaterialTable
          columns={preciseData.columns}
          data={preciseData.data}
          title={preciseData.title}
          actions={[
            {
              icon: 'get_app',
              tooltip: 'Download costs to excel',
              isFreeAction: true,
              onClick: () => {
                const segmentId = itemRenderOptions.segmentId;
                dispatch.MasterList.downloadPreciseCostListExport({
                  segmentId,
                  failureCallback: handleDownloadFailure,
                });
              },
            },
          ]}
          options={{
            search: false,
            paging: false,
          }}
          editable={{
            isEditable: rowData => rowData.id !== 'total',
            onRowUpdate: (newData, oldData) =>
              new Promise(resolve => {
                const yearsToUpdate = {};
                const category = newData['id'];
                for (const key in newData) {
                  if (key != 'category' && key != 'id' && newData[key] != oldData[key]) {
                    yearsToUpdate[key] = {
                      ...itemRenderOptions.preciseCostListOfSegment.find(
                        yearlyCost => yearlyCost.year === key,
                      ),
                    };
                    yearsToUpdate[key][category] = newData[key] > 0 ? newData[key] : null;
                  }
                }
                for (const [key, value] of Object.entries(yearsToUpdate)) {
                  if (key != 'tableData') {
                    const segmentId = itemRenderOptions.segmentId;
                    dispatch.MasterList.updatePreciseCostListOfSegment({
                      segmentId,
                      entity: value,
                    });
                  }
                }
                resolve();
              }),
          }}
        />
      </Paper>
    </Fragment>
  );
};
