import React, { Fragment } from 'react';
import CustomizedTabs from '@shared/components/Tab/CustomizedTabs';
import { useGapTabs } from '../projectPtrsAssessment/UseTabs';

type GapMappingAndInfoProps = {
  itemRenderOptions: any;
};
export const GapInformation = ({ itemRenderOptions }: GapMappingAndInfoProps): JSX.Element => {
  const tabs = useGapTabs(itemRenderOptions);
  return (
    <Fragment>
      <CustomizedTabs tabs={tabs} />
    </Fragment>
  );
};
